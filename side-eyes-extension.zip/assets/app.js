(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else {
		var a = factory();
		for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];
	}
})(typeof self !== 'undefined' ? self : this, function() {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/assets/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 8);
/******/ })
/************************************************************************/
/******/ ({

/***/ "../../../node_modules/base64-js/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
exports.byteLength=byteLength;exports.toByteArray=toByteArray;exports.fromByteArray=fromByteArray;var lookup=[];var revLookup=[];var Arr=typeof Uint8Array!=='undefined'?Uint8Array:Array;var code='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';for(var i=0,len=code.length;i<len;++i){lookup[i]=code[i];revLookup[code.charCodeAt(i)]=i;}// Support decoding URL-safe base64 strings, as Node.js does.
// See: https://en.wikipedia.org/wiki/Base64#URL_applications
revLookup['-'.charCodeAt(0)]=62;revLookup['_'.charCodeAt(0)]=63;function getLens(b64){var len=b64.length;if(len%4>0){throw new Error('Invalid string. Length must be a multiple of 4');}// Trim off extra bytes after placeholder bytes are found
// See: https://github.com/beatgammit/base64-js/issues/42
var validLen=b64.indexOf('=');if(validLen===-1)validLen=len;var placeHoldersLen=validLen===len?0:4-validLen%4;return[validLen,placeHoldersLen];}// base64 is 4/3 + up to two characters of the original data
function byteLength(b64){var lens=getLens(b64);var validLen=lens[0];var placeHoldersLen=lens[1];return(validLen+placeHoldersLen)*3/4-placeHoldersLen;}function _byteLength(b64,validLen,placeHoldersLen){return(validLen+placeHoldersLen)*3/4-placeHoldersLen;}function toByteArray(b64){var tmp;var lens=getLens(b64);var validLen=lens[0];var placeHoldersLen=lens[1];var arr=new Arr(_byteLength(b64,validLen,placeHoldersLen));var curByte=0;// if there are placeholders, only get up to the last complete 4 chars
var len=placeHoldersLen>0?validLen-4:validLen;var i;for(i=0;i<len;i+=4){tmp=revLookup[b64.charCodeAt(i)]<<18|revLookup[b64.charCodeAt(i+1)]<<12|revLookup[b64.charCodeAt(i+2)]<<6|revLookup[b64.charCodeAt(i+3)];arr[curByte++]=tmp>>16&0xFF;arr[curByte++]=tmp>>8&0xFF;arr[curByte++]=tmp&0xFF;}if(placeHoldersLen===2){tmp=revLookup[b64.charCodeAt(i)]<<2|revLookup[b64.charCodeAt(i+1)]>>4;arr[curByte++]=tmp&0xFF;}if(placeHoldersLen===1){tmp=revLookup[b64.charCodeAt(i)]<<10|revLookup[b64.charCodeAt(i+1)]<<4|revLookup[b64.charCodeAt(i+2)]>>2;arr[curByte++]=tmp>>8&0xFF;arr[curByte++]=tmp&0xFF;}return arr;}function tripletToBase64(num){return lookup[num>>18&0x3F]+lookup[num>>12&0x3F]+lookup[num>>6&0x3F]+lookup[num&0x3F];}function encodeChunk(uint8,start,end){var tmp;var output=[];for(var i=start;i<end;i+=3){tmp=(uint8[i]<<16&0xFF0000)+(uint8[i+1]<<8&0xFF00)+(uint8[i+2]&0xFF);output.push(tripletToBase64(tmp));}return output.join('');}function fromByteArray(uint8){var tmp;var len=uint8.length;var extraBytes=len%3;// if we have 1 byte left, pad 2 bytes
var parts=[];var maxChunkLength=16383;// must be multiple of 3
// go through the array every three bytes, we'll deal with trailing stuff later
for(var i=0,len2=len-extraBytes;i<len2;i+=maxChunkLength){parts.push(encodeChunk(uint8,i,i+maxChunkLength>len2?len2:i+maxChunkLength));}// pad the end with zeros, but make sure to not forget the extra bytes
if(extraBytes===1){tmp=uint8[len-1];parts.push(lookup[tmp>>2]+lookup[tmp<<4&0x3F]+'==');}else if(extraBytes===2){tmp=(uint8[len-2]<<8)+uint8[len-1];parts.push(lookup[tmp>>10]+lookup[tmp>>4&0x3F]+lookup[tmp<<2&0x3F]+'=');}return parts.join('');}

/***/ }),

/***/ "../../../node_modules/classnames/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/*!
  Copyright (c) 2017 Jed Watson.
  Licensed under the MIT License (MIT), see
  http://jedwatson.github.io/classnames
*/ /* global define */(function(){'use strict';var hasOwn={}.hasOwnProperty;function classNames(){var classes=[];for(var i=0;i<arguments.length;i++){var arg=arguments[i];if(!arg)continue;var argType=typeof arg;if(argType==='string'||argType==='number'){classes.push(arg);}else if(Array.isArray(arg)&&arg.length){var inner=classNames.apply(null,arg);if(inner){classes.push(inner);}}else if(argType==='object'){for(var key in arg){if(hasOwn.call(arg,key)&&arg[key]){classes.push(key);}}}}return classes.join(' ');}if(typeof module!=='undefined'&&module.exports){classNames.default=classNames;module.exports=classNames;}else if(true){// register as 'classnames', consistent with npm package name
!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function(){return classNames;}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));}else{window.classNames=classNames;}})();

/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/ActionButtons/AddButton/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".add.outer {\n  border: 1px solid #a2a2a2;\n  border-radius: 2px;\n  width: 11px;\n  height: 11px;\n  cursor: pointer;\n  margin-top: 2px;\n}\n\n.add.inner {\n  background-color: #767676;\n  width: 11px;\n  height: 11px;\n}\n\n.add.outer.selected,\n.add.outer:hover {\n  border: 1px solid transparent;\n  background-color: #318ede;\n}\n\n.add.inner.selected,\n.add.outer:hover .add.inner {\n  background-color: #ffffff;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/ActionButtons/DeleteButton/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".delete.close {\n  float: left;\n  margin-left: 1px;\n}\n\n.delete.close.outer {\n  width: 16px;\n  height: 16px;\n  cursor: pointer;\n}\n\n.delete.close.inner {\n  background-color: #767676;\n  width: 14px;\n  height: 16px;\n  padding-right: 1px;\n}\n\n.delete.close.inner:hover {\n  background-color: #505050;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/ActionButtons/DownloadButton/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".download.close {\n  float: left;\n  margin-left: 1px;\n}\n\n.download.close.outer {\n  width: 28px;\n  height: 28px;\n  cursor: pointer;\n}\n\n.download.close.inner {\n  background-color: #767676;\n  width: 26px;\n  height: 28px;\n  padding-right: 1px;\n}\n\n.download.close.inner:hover {\n  background-color: #505050;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/ActionButtons/RemoveButton/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".remove.close {\n  background-color: #d6ecf7;\n}\n\n.remove.close {\n  float: left;\n  margin-left: 1px;\n  padding-top: 1px;\n}\n\n.remove.close.outer {\n  width: 16px;\n  height: 16px;\n  cursor: pointer;\n}\n\n.remove.close.inner {\n  background-color: #767676;\n  width: 14px;\n  height: 14px;\n  padding-right: 1px;\n}\n\n.remove.close.outer:hover {\n  background-color: #b2dbf0;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/ButtonList/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "ul.buttons {\n    list-style: none;\n    padding: 0;\n}\n\nul.buttons li {\n    display: -ms-flexbox;\n    display: flex;\n    cursor: pointer;\n    padding: 5px;\n    border: 1px solid transparent;\n    border-radius: 2px;\n    margin: 2px 0;\n    transition: background-color 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,box-shadow 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;\n}\n\nul.buttons li:hover {\n    background-color: #F3F3F3;\n}\n\nul.buttons li:focus {\n    background-color: #F3F3F3;\n    outline: 0;\n}\n\nul.buttons li:hover:active {\n    box-shadow: inset -1px 1px 1px 0 #CACACA;\n    border-color: rgba(0,0,0,.05);\n}\n\nul.buttons button {\n    border: none;\n    color: #505050;\n    font-size: 13px;\n    background: transparent;\n    cursor: inherit;\n    -ms-flex-positive: 1;\n        flex-grow: 1;\n    text-align: left;\n    padding: 0;\n}\n\nul.buttons button:focus {\n    outline: 0;\n}\n\nul.buttons li > a {\n    opacity: 0;\n    font-size: 10px;\n    -ms-flex-item-align: center;\n        -ms-grid-row-align: center;\n        align-self: center;\n    transition: opacity 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;\n}\n\nul.buttons li:hover > a {\n    opacity: 1;\n}\n\n.selected-command {\n  opacity: 1 !important;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/SpinnerBanner/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".banner {\n    display: -ms-flexbox;\n    display: flex;\n    -ms-flex-align: center;\n        align-items: center;\n    color: #f1f1f1;\n    font-size: 14px;\n    padding: 0 20px;\n    min-height: 75px;\n}\n\n.banner > span {\n    margin: 0 5px;\n}\n\n.banner > span:last-child {\n    font-weight: bold;\n}\n\n.loader,\n.loader:after {\n    border-radius: 50%;\n    width: 10em;\n    height: 10em;\n}\n.loader {\n    -ms-flex-negative: 0;\n        flex-shrink: 0;\n    margin: 60px auto;\n    font-size: 3px;\n    position: relative;\n    text-indent: -9999em;\n    border-left: 1.1em solid #ffffff;\n    -ms-transform: translateZ(0);\n    transform: translateZ(0);\n    animation: load8 1.1s infinite linear;\n    border-top: 1.1em solid rgba(0, 0, 0, 0.3);\n    border-right: 1.1em solid rgba(0, 0, 0, 0.3);\n    border-bottom: 1.1em solid rgba(0, 0, 0, 0.3);\n}\n@keyframes load8 {\n    0% {\n        transform: rotate(0deg);\n    }\n    100% {\n        transform: rotate(360deg);\n    }\n}\n\n.banner.success, .banner.setup {\n    background-color: #40A6FF;\n}\n\n.banner.error {\n    background-color: #FF5F7B;\n}\n\n.loader.stopped {\n    border: 1.1em solid rgba(0, 0, 0, 0.3);\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/VisualGrid/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".visual-grid-options {\n  padding-top: 7px;\n  position: relative;\n}\n\n.visual-grid-options .option-header .title {\n  float: left;\n  padding-right: 5px;\n}\n\n.visual-grid-options .option-header .add {\n  float: left;\n}\n\n.error-message {\n  color: red;\n}\n\n.general-error {\n  padding: 0 0 8px 27px !important;\n}\n\n.download-config {\n  position: absolute;\n  top: -29px;\n  right: -3px;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/VisualGridCustomViewportSize/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".custom-viewport-size {\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-direction: row;\n      flex-direction: row;\n  -ms-flex-wrap: no-wrap;\n      flex-wrap: no-wrap;\n  -ms-flex-align: center;\n      align-items: center;\n  margin: 1px 0;\n}\n\n.custom-viewport-size:hover .close {\n  visibility: visible;\n}\n\n.custom-viewport-size .input {\n  margin: 4px 0;\n  width: 28%;\n  line-height: 0;\n}\n\n.custom-viewport-size .input input {\n  font-size: 12px;\n  line-height: 12px;\n  width: auto;\n  padding: 3px;\n}\n\n.custom-viewport-size .input input[type='number']::-webkit-inner-spin-button,\n.custom-viewport-size .input input[type='number']::-webkit-outer-spin-button {\n  -webkit-appearance: none;\n  margin: 0;\n}\n\n.custom-viewport-size .input input {\n  -moz-appearance: textfield;\n}\n\n.custom-viewport-size .close.outer {\n  background-color: transparent;\n}\n\n.custom-viewport-size .close {\n  margin-bottom: 7px;\n  visibility: hidden;\n}\n\n.custom-viewport-size .close .inner {\n  width: 20px;\n  height: 20px;\n  -webkit-mask-size: 20px !important;\n          mask-size: 20px !important;\n}\n\n.custom-viewport-size .dimension-separator {\n  padding-left: 4px;\n  padding-right: 4px;\n  padding-bottom: 2px;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/VisualGridOptionCategory/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".selections {\n  max-height: 310px;\n  overflow-y: auto;\n}\n\n.selections + .btn.confirm {\n  float: right;\n  margin: 10px -5px -4px 0 !important;\n}\n\n.selections .title {\n  padding-bottom: 5px;\n}\n\n.option-header {\n  padding-bottom: 28px;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/VisualGridOptionGroup/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".visual-grid-options .group {\n  cursor: pointer;\n}\n\n.visual-grid-options .group .group-header {\n  height: 25px;\n  width: 220px;\n  margin-top: 8px;\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-direction: row;\n      flex-direction: row;\n  -ms-flex-line-pack: stretch;\n      align-content: stretch;\n}\n\n.visual-grid-options .group-header .title {\n  width: 30px;\n  margin-left: 27px;\n  font-weight: bold;\n}\n\n.visual-grid-options .group-header .selected-count {\n  margin: 2px 0 0 46px;\n  font-size: 11px;\n  height: 16px;\n  width: 16px;\n  line-height: 16px;\n  border-radius: 50%;\n  background-color: #40A6FF;\n  color: #FFFFFF;\n  text-align: center;\n}\n\n.visual-grid-options .group-header .control {\n  margin-left: 10px;\n}\n\n.visual-grid-options .group-divider {\n  margin-left: 27px;\n  width: 220px;\n}\n\n.visual-grid-options .group .contents {\n  padding-top: 5px;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/VisualGridOptionSelector/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".selections {\n  max-height: 310px;\n  overflow-y: scroll;\n}\n\n.selections + .btn.confirm {\n  float: right;\n  margin: 10px -5px -4px 0 !important;\n}\n\n.selections .title {\n  padding-bottom: 5px;\n}\n\n.selections .input {\n  margin: 0px;\n  margin-bottom: 10px;\n  padding-right: 15px;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/VisualGridSelectedOptions/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".visual-grid-options .category {\n  padding-left: 27px;\n  padding-bottom: 12px;\n}\n\n.visual-grid-options .selected-options {\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-direction: row;\n      flex-direction: row;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n}\n\n.visual-grid-options .option {\n  height: 16px;\n  padding-right: 9px;\n  padding-bottom: 5px;\n}\n\n.visual-grid-options .option-text {\n  background-color: #d6ecf7;\n  float: left;\n  font-size: 12px;\n  line-height: 12px;\n  color: #454545;\n  padding-left: 4px;\n  padding-right: 4px;\n  padding-top: 2px;\n  padding-bottom: 3px;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/VisualGridViewports/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".custom-viewport-sizes .collection {\n  max-height: 100px;\n  overflow-y: auto;\n}\n\n.custom-viewport-sizes .header {\n  display: -ms-flexbox;\n  display: flex;\n}\n\n.custom-viewport-sizes .header .title {\n  margin-right: 7px;\n}\n\n.btn.confirm {\n  float: right;\n  margin: 10px 0 0 0;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/containers/Disconnect/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".disconnect {\n    display: -ms-flexbox;\n    display: flex;\n    -ms-flex-direction: column;\n        flex-direction: column;\n    -ms-flex-align: center;\n        align-items: center;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/containers/Normal/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".body {\n  height: 605px;\n}\n\n.open-global-settings {\n  line-height: 27px;\n  padding-top: 5px;\n}\n\n.more-options {\n  line-height: 21px;\n}\n\n.project-settings .input {\n  -ms-flex-direction: row;\n      flex-direction: row;\n  margin: 11px 0;\n}\n\n.project-settings .input label {\n  font-weight: normal;\n  font-size: 14px;\n  text-transform: none;\n  color: inherit;\n  -ms-flex-preferred-size: 100%;\n      flex-basis: 100%;\n  padding-top: 3px;\n}\n\n.project-settings .input input {\n  height: 26px;\n  width: 122px;\n  border: 1px solid #dcdcdc;\n  border-radius: 2px;\n  padding: 0;\n  text-indent: 5px;\n}\n\n.disclaimer {\n  font-size: 13px;\n  padding-left: 27px;\n}\n\n.disclaimer p {\n  margin: 3px 0;\n}\n\n.ReactModal__Overlay--after-open {\n  background-color: transparent !important;\n}\n\n.accessibility-option {\n  padding: 3px 50px 5px 27px;\n}\n\n#accessibility-options {\n  padding-top: 5px;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/containers/Playback/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".playback-info {\n    margin: 5px 10px;\n    font-size: 13px;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/containers/Setup/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "form.setup > div,\nform.setup > a {\n    margin: 10px 0;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/styles/app.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "html,\nbody {\n  width: 320px;\n  overflow: hidden;\n}\n\n.container {\n  overflow-y: auto;\n  max-height: 500px;\n  padding: 10px 18px 0px 18px;\n}\n\nhr {\n  height: 0;\n  border: 0;\n  border-top: 1px solid #cdcdcd;\n  margin: 10px 0;\n}\n\nh4 {\n  margin: 1em 0;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/components/Checkbox/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "input[type='checkbox'].checkbox {\n  position: absolute;\n  opacity: 0;\n  width: 0;\n  height: 0;\n}\n\ninput[type='checkbox'].checkbox + label {\n  display: block;\n  cursor: pointer;\n  padding: 5px 0;\n}\n\ninput[type='checkbox'].checkbox + label span {\n  display: inline-block;\n  background-color: #fff;\n  text-align: center;\n  line-height: 15px;\n  font-size: 15px;\n  width: 15px;\n  height: 15px;\n  margin: -2px 10px 0 0;\n  vertical-align: middle;\n  cursor: pointer;\n  border: 1px solid #dcdcdc;\n  border-radius: 2px;\n  box-shadow: inset 0 0 1px 1px transparent;\n  transition: background-color 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,\n    box-shadow 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;\n}\n\ninput[type='checkbox'].checkbox:focus + label span {\n  border-color: #40a6ff;\n}\n\ninput[type='checkbox'].checkbox + label:active span {\n  background-color: #fdfdfd;\n  box-shadow: inset 0 0 1px 1px #ececec;\n}\n\ninput[type='checkbox'].checkbox + label > div {\n  display: inline-block;\n}\n\n.checkbox + label .disclaimer {\n  padding-left: 25px;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/components/Combobox/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".combobox {\n    border: 1px solid #dcdcdc;\n    border-radius: 2px;\n    color: inherit;\n    padding: 2px 5px;\n}\n\n.combobox.disabled {\n    cursor: not-allowed;\n    color: gray;\n}\n\n.combobox-content {\n    list-style: none;\n}\n\n.combobox-item {\n    color: inherit;\n    display: block;\n    padding: 5px 15px;\n    background: white;\n    transition: all 250ms;\n}\n\n.combobox-item:hover {\n    background: #e6f7ff;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/components/FlatButton/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".btn {\n  color: #656565;\n  background-color: #f5f5f5;\n  padding: 10px 20px;\n  margin: 5px 8px;\n  border: 1px solid transparent;\n  border-radius: 4px;\n  outline: 0;\n  text-transform: capitalize;\n  box-shadow: inset -1px 1px 1px 0 transparent;\n  transition: background-color 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,\n    box-shadow 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;\n  font-size: 13px;\n}\n\n.btn:hover {\n  color: #333;\n}\n\n.btn:focus {\n  border-color: rgba(0, 0, 0, 0.25);\n}\n\n.btn:active {\n  background-color: #eeeeee;\n  box-shadow: inset -1px 1px 1px 0 #cacaca;\n}\n\n.btn:disabled {\n  color: #a9a9a9;\n  cursor: not-allowed;\n}\n\n.btn.icon {\n  font-size: 22px;\n  border: 1px solid #dcdcdc;\n  background-color: white;\n  padding: 5px 8px;\n  border-radius: 2px;\n}\n\n.btn.icon:hover {\n  color: #40a6ff;\n}\n\n.btn.icon:focus {\n  border-color: #40a6ff;\n}\n\n.btn.icon:active {\n  box-shadow: inset -1px 1px 1px 0 #ececec;\n}\n\n.btn.icon.active {\n  border-color: #40a6ff;\n  background-color: #e3f2ff;\n}\n\n.btn.icon.active:active {\n  box-shadow: inset -1px 1px 1px 0 #cacaca;\n}\n\n.btn.primary {\n  color: #fff;\n  background-color: #6fc8ea;\n}\n\n.btn.primary:hover {\n  background-color: #58b7dc;\n}\n\n.btn.primary:active {\n  background-color: #67c9ef;\n  box-shadow: inset -1px 1px 1px 0 #53a4c3;\n}\n\n.btn.primary:disabled {\n  background-color: #92d9f5;\n}\n\n.btn.secondary:hover {\n  background-color: #e0e0e0;\n}\n\n.btn.danger {\n  color: #fff;\n  background-color: #ff6b6b;\n}\n\n.btn.danger:hover {\n  background-color: #e2373f;\n}\n\n.btn.danger:active {\n  background-color: #f3535a;\n  box-shadow: inset -1px 1px 1px 0 #a72d43;\n}\n\n.btn.btn-full {\n  margin: 5px 0;\n  width: 100%;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/components/FormLabel/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".form-label {\n    margin: 10px 0;\n}\n\n.bold {\n    color: rgba(0, 0, 0, 0.55);\n    font-size: 10px;\n    font-weight: 600;\n    text-transform: uppercase;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/components/Input/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".input {\n    display: -ms-flexbox;\n    display: flex;\n    -ms-flex-direction: column;\n        flex-direction: column;\n    margin: 20px 0;\n}\n\n.input > label {\n    font-size: 10px;\n    font-weight: 600;\n    text-transform: uppercase;\n    margin: 2px 0;\n    color: rgba(0, 0, 0, 0.55);\n}\n\n.input > *:last-child {\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/components/Modal/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".keydownHook:focus {\n  outline: 0;\n  border: unset;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/components/Tooltip/style.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".eyes-tooltip {\n  cursor: pointer !important;\n  pointer-events: none !important;\n  padding: 0 !important;\n  border: none !important;\n  background: transparent !important;\n  margin-top: 5px !important;\n  opacity: 0 !important;\n  visibility: initial !important;\n  transition: opacity 287ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,\n    transform 191ms cubic-bezier(0.4, 0, 0.2, 1) 0ms !important;\n}\n\n.eyes-tooltip.show {\n  opacity: 1 !important;\n}\n\n.eyes-tooltip::before {\n  content: none !important;\n}\n\n.eyes-tooltip::after {\n  content: none !important;\n}\n\n.eyes-tooltip > p {\n  margin: 0;\n  padding: 7px;\n  border: 1px solid #dedede;\n  border-radius: 2px;\n  background-color: #fff;\n  box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.2);\n  color: #505050;\n  white-space: nowrap;\n  text-align: center;\n  font-size: 14px;\n  line-height: 1.2;\n  -ms-transform: scale(0, 0);\n      transform: scale(0, 0);\n  transition: opacity 287ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,\n    transform 191ms cubic-bezier(0.4, 0, 0.2, 1) 0ms !important;\n}\n\n.eyes-tooltip.show > p {\n  -ms-transform: scale(1, 1);\n      transform: scale(1, 1);\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/styles/chrome.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, ".banner {\n    border-radius: 2px 2px 0 0;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/styles/elements.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "body {\n    font-family: system, -apple-system, BlinkMacSystemFont, \"Helvetica Neue\", Arial, sans-serif !important;\n    font-size: 14px;\n    color: #505050;\n    margin: 0;\n}\n\na {\n    color: #40A6FF;\n    text-decoration: none;\n    cursor: pointer;\n}\n\na:visited {\n    color: #40A6FF;\n}\n\na:focus {\n    outline: 0;\n}\n\na.secondary {\n    color: #7ba3c5;\n    font-size: 0.9em;\n    text-align: right;\n    display: block;\n}\n\na.secondary:visited {\n    color: #7ba3c5;\n}\n\ninput,\ntextarea {\n    border: 1px #DCDCDC solid;\n    color: #3F3F3F;\n    border-radius: 2px;\n    font-size: 12px;\n    line-height: 17px;\n    padding: 5px;\n}\n\ntextarea {\n    resize: none;\n}\n\ntextarea {\n    font-family: inherit;\n}\n\ninput:focus,\ntextarea:focus {\n    border-color: #40A6FF;\n    outline: 0;\n}\n\ninput:disabled,\ntextarea:disabled {\n    background-color: whitesmoke;\n    border-color: whitesmoke;\n    cursor: not-allowed;\n}\n\ninput:-ms-input-placeholder,\ntextarea:-ms-input-placeholder {\n    color: #A0A0A0;\n}\n\ninput::placeholder,\ntextarea::placeholder {\n    color: #A0A0A0;\n}\n\nul {\n    padding: 0;\n    margin: 0;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/styles/windows.css":
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__("../../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "::-webkit-scrollbar {\n  width: 6px;\n  background-color: #F2F2F2;\n}\n\n::-webkit-scrollbar-thumb {\n  background-color: #767676;\n}\n", ""]);

// exports


/***/ }),

/***/ "../../../node_modules/css-loader/lib/css-base.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/ // css base code, injected by the css-loader
module.exports=function(useSourceMap){var list=[];// return the list of modules as css string
list.toString=function toString(){return this.map(function(item){var content=cssWithMappingToString(item,useSourceMap);if(item[2]){return"@media "+item[2]+"{"+content+"}";}else{return content;}}).join("");};// import a list of modules into the list
list.i=function(modules,mediaQuery){if(typeof modules==="string")modules=[[null,modules,""]];var alreadyImportedModules={};for(var i=0;i<this.length;i++){var id=this[i][0];if(typeof id==="number")alreadyImportedModules[id]=true;}for(i=0;i<modules.length;i++){var item=modules[i];// skip already imported module
// this implementation is not 100% perfect for weird media query combinations
//  when a module is imported multiple times with different media queries.
//  I hope this will never occur (Hey this way we have smaller bundles)
if(typeof item[0]!=="number"||!alreadyImportedModules[item[0]]){if(mediaQuery&&!item[2]){item[2]=mediaQuery;}else if(mediaQuery){item[2]="("+item[2]+") and ("+mediaQuery+")";}list.push(item);}}};return list;};function cssWithMappingToString(item,useSourceMap){var content=item[1]||'';var cssMapping=item[3];if(!cssMapping){return content;}if(useSourceMap&&typeof btoa==='function'){var sourceMapping=toComment(cssMapping);var sourceURLs=cssMapping.sources.map(function(source){return'/*# sourceURL='+cssMapping.sourceRoot+source+' */';});return[content].concat(sourceURLs).concat([sourceMapping]).join('\n');}return[content].join('\n');}// Adapted from convert-source-map (MIT)
function toComment(sourceMap){// eslint-disable-next-line no-undef
var base64=btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));var data='sourceMappingURL=data:application/json;charset=utf-8;base64,'+base64;return'/*# '+data+' */';}

/***/ }),

/***/ "../../../node_modules/esprima/dist/esprima.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
(function webpackUniversalModuleDefinition(root,factory){/* istanbul ignore next */if(true)module.exports=factory();else if(typeof define==='function'&&define.amd)define([],factory);/* istanbul ignore next */else if(typeof exports==='object')exports["esprima"]=factory();else root["esprima"]=factory();})(void 0,function(){return(/******/function(modules){// webpackBootstrap
/******/ // The module cache
/******/var installedModules={};/******/ // The require function
/******/function __webpack_require__(moduleId){/******/ // Check if module is in cache
/* istanbul ignore if */ /******/if(installedModules[moduleId])/******/return installedModules[moduleId].exports;/******/ // Create a new module (and put it into the cache)
/******/var module=installedModules[moduleId]={/******/exports:{},/******/id:moduleId,/******/loaded:false/******/};/******/ // Execute the module function
/******/modules[moduleId].call(module.exports,module,module.exports,__webpack_require__);/******/ // Flag the module as loaded
/******/module.loaded=true;/******/ // Return the exports of the module
/******/return module.exports;/******/}/******/ // expose the modules object (__webpack_modules__)
/******/__webpack_require__.m=modules;/******/ // expose the module cache
/******/__webpack_require__.c=installedModules;/******/ // __webpack_public_path__
/******/__webpack_require__.p="";/******/ // Load entry module and return exports
/******/return __webpack_require__(0);/******/}(/************************************************************************/ /******/[/* 0 */ /***/function(module,exports,__webpack_require__){"use strict";/*
	  Copyright JS Foundation and other contributors, https://js.foundation/

	  Redistribution and use in source and binary forms, with or without
	  modification, are permitted provided that the following conditions are met:

	    * Redistributions of source code must retain the above copyright
	      notice, this list of conditions and the following disclaimer.
	    * Redistributions in binary form must reproduce the above copyright
	      notice, this list of conditions and the following disclaimer in the
	      documentation and/or other materials provided with the distribution.

	  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
	  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
	  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
	  ARE DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
	  DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
	  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
	  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
	  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
	  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
	  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	*/Object.defineProperty(exports,"__esModule",{value:true});var comment_handler_1=__webpack_require__(1);var jsx_parser_1=__webpack_require__(3);var parser_1=__webpack_require__(8);var tokenizer_1=__webpack_require__(15);function parse(code,options,delegate){var commentHandler=null;var proxyDelegate=function(node,metadata){if(delegate){delegate(node,metadata);}if(commentHandler){commentHandler.visit(node,metadata);}};var parserDelegate=typeof delegate==='function'?proxyDelegate:null;var collectComment=false;if(options){collectComment=typeof options.comment==='boolean'&&options.comment;var attachComment=typeof options.attachComment==='boolean'&&options.attachComment;if(collectComment||attachComment){commentHandler=new comment_handler_1.CommentHandler();commentHandler.attach=attachComment;options.comment=true;parserDelegate=proxyDelegate;}}var isModule=false;if(options&&typeof options.sourceType==='string'){isModule=options.sourceType==='module';}var parser;if(options&&typeof options.jsx==='boolean'&&options.jsx){parser=new jsx_parser_1.JSXParser(code,options,parserDelegate);}else{parser=new parser_1.Parser(code,options,parserDelegate);}var program=isModule?parser.parseModule():parser.parseScript();var ast=program;if(collectComment&&commentHandler){ast.comments=commentHandler.comments;}if(parser.config.tokens){ast.tokens=parser.tokens;}if(parser.config.tolerant){ast.errors=parser.errorHandler.errors;}return ast;}exports.parse=parse;function parseModule(code,options,delegate){var parsingOptions=options||{};parsingOptions.sourceType='module';return parse(code,parsingOptions,delegate);}exports.parseModule=parseModule;function parseScript(code,options,delegate){var parsingOptions=options||{};parsingOptions.sourceType='script';return parse(code,parsingOptions,delegate);}exports.parseScript=parseScript;function tokenize(code,options,delegate){var tokenizer=new tokenizer_1.Tokenizer(code,options);var tokens;tokens=[];try{while(true){var token=tokenizer.getNextToken();if(!token){break;}if(delegate){token=delegate(token);}tokens.push(token);}}catch(e){tokenizer.errorHandler.tolerate(e);}if(tokenizer.errorHandler.tolerant){tokens.errors=tokenizer.errors();}return tokens;}exports.tokenize=tokenize;var syntax_1=__webpack_require__(2);exports.Syntax=syntax_1.Syntax;// Sync with *.json manifests.
exports.version='4.0.1';/***/},/* 1 */ /***/function(module,exports,__webpack_require__){"use strict";Object.defineProperty(exports,"__esModule",{value:true});var syntax_1=__webpack_require__(2);var CommentHandler=function(){function CommentHandler(){this.attach=false;this.comments=[];this.stack=[];this.leading=[];this.trailing=[];}CommentHandler.prototype.insertInnerComments=function(node,metadata){//  innnerComments for properties empty block
//  `function a() {/** comments **\/}`
if(node.type===syntax_1.Syntax.BlockStatement&&node.body.length===0){var innerComments=[];for(var i=this.leading.length-1;i>=0;--i){var entry=this.leading[i];if(metadata.end.offset>=entry.start){innerComments.unshift(entry.comment);this.leading.splice(i,1);this.trailing.splice(i,1);}}if(innerComments.length){node.innerComments=innerComments;}}};CommentHandler.prototype.findTrailingComments=function(metadata){var trailingComments=[];if(this.trailing.length>0){for(var i=this.trailing.length-1;i>=0;--i){var entry_1=this.trailing[i];if(entry_1.start>=metadata.end.offset){trailingComments.unshift(entry_1.comment);}}this.trailing.length=0;return trailingComments;}var entry=this.stack[this.stack.length-1];if(entry&&entry.node.trailingComments){var firstComment=entry.node.trailingComments[0];if(firstComment&&firstComment.range[0]>=metadata.end.offset){trailingComments=entry.node.trailingComments;delete entry.node.trailingComments;}}return trailingComments;};CommentHandler.prototype.findLeadingComments=function(metadata){var leadingComments=[];var target;while(this.stack.length>0){var entry=this.stack[this.stack.length-1];if(entry&&entry.start>=metadata.start.offset){target=entry.node;this.stack.pop();}else{break;}}if(target){var count=target.leadingComments?target.leadingComments.length:0;for(var i=count-1;i>=0;--i){var comment=target.leadingComments[i];if(comment.range[1]<=metadata.start.offset){leadingComments.unshift(comment);target.leadingComments.splice(i,1);}}if(target.leadingComments&&target.leadingComments.length===0){delete target.leadingComments;}return leadingComments;}for(var i=this.leading.length-1;i>=0;--i){var entry=this.leading[i];if(entry.start<=metadata.start.offset){leadingComments.unshift(entry.comment);this.leading.splice(i,1);}}return leadingComments;};CommentHandler.prototype.visitNode=function(node,metadata){if(node.type===syntax_1.Syntax.Program&&node.body.length>0){return;}this.insertInnerComments(node,metadata);var trailingComments=this.findTrailingComments(metadata);var leadingComments=this.findLeadingComments(metadata);if(leadingComments.length>0){node.leadingComments=leadingComments;}if(trailingComments.length>0){node.trailingComments=trailingComments;}this.stack.push({node:node,start:metadata.start.offset});};CommentHandler.prototype.visitComment=function(node,metadata){var type=node.type[0]==='L'?'Line':'Block';var comment={type:type,value:node.value};if(node.range){comment.range=node.range;}if(node.loc){comment.loc=node.loc;}this.comments.push(comment);if(this.attach){var entry={comment:{type:type,value:node.value,range:[metadata.start.offset,metadata.end.offset]},start:metadata.start.offset};if(node.loc){entry.comment.loc=node.loc;}node.type=type;this.leading.push(entry);this.trailing.push(entry);}};CommentHandler.prototype.visit=function(node,metadata){if(node.type==='LineComment'){this.visitComment(node,metadata);}else if(node.type==='BlockComment'){this.visitComment(node,metadata);}else if(this.attach){this.visitNode(node,metadata);}};return CommentHandler;}();exports.CommentHandler=CommentHandler;/***/},/* 2 */ /***/function(module,exports){"use strict";Object.defineProperty(exports,"__esModule",{value:true});exports.Syntax={AssignmentExpression:'AssignmentExpression',AssignmentPattern:'AssignmentPattern',ArrayExpression:'ArrayExpression',ArrayPattern:'ArrayPattern',ArrowFunctionExpression:'ArrowFunctionExpression',AwaitExpression:'AwaitExpression',BlockStatement:'BlockStatement',BinaryExpression:'BinaryExpression',BreakStatement:'BreakStatement',CallExpression:'CallExpression',CatchClause:'CatchClause',ClassBody:'ClassBody',ClassDeclaration:'ClassDeclaration',ClassExpression:'ClassExpression',ConditionalExpression:'ConditionalExpression',ContinueStatement:'ContinueStatement',DoWhileStatement:'DoWhileStatement',DebuggerStatement:'DebuggerStatement',EmptyStatement:'EmptyStatement',ExportAllDeclaration:'ExportAllDeclaration',ExportDefaultDeclaration:'ExportDefaultDeclaration',ExportNamedDeclaration:'ExportNamedDeclaration',ExportSpecifier:'ExportSpecifier',ExpressionStatement:'ExpressionStatement',ForStatement:'ForStatement',ForOfStatement:'ForOfStatement',ForInStatement:'ForInStatement',FunctionDeclaration:'FunctionDeclaration',FunctionExpression:'FunctionExpression',Identifier:'Identifier',IfStatement:'IfStatement',ImportDeclaration:'ImportDeclaration',ImportDefaultSpecifier:'ImportDefaultSpecifier',ImportNamespaceSpecifier:'ImportNamespaceSpecifier',ImportSpecifier:'ImportSpecifier',Literal:'Literal',LabeledStatement:'LabeledStatement',LogicalExpression:'LogicalExpression',MemberExpression:'MemberExpression',MetaProperty:'MetaProperty',MethodDefinition:'MethodDefinition',NewExpression:'NewExpression',ObjectExpression:'ObjectExpression',ObjectPattern:'ObjectPattern',Program:'Program',Property:'Property',RestElement:'RestElement',ReturnStatement:'ReturnStatement',SequenceExpression:'SequenceExpression',SpreadElement:'SpreadElement',Super:'Super',SwitchCase:'SwitchCase',SwitchStatement:'SwitchStatement',TaggedTemplateExpression:'TaggedTemplateExpression',TemplateElement:'TemplateElement',TemplateLiteral:'TemplateLiteral',ThisExpression:'ThisExpression',ThrowStatement:'ThrowStatement',TryStatement:'TryStatement',UnaryExpression:'UnaryExpression',UpdateExpression:'UpdateExpression',VariableDeclaration:'VariableDeclaration',VariableDeclarator:'VariableDeclarator',WhileStatement:'WhileStatement',WithStatement:'WithStatement',YieldExpression:'YieldExpression'};/***/},/* 3 */ /***/function(module,exports,__webpack_require__){"use strict";/* istanbul ignore next */var __extends=this&&this.__extends||function(){var extendStatics=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(d,b){d.__proto__=b;}||function(d,b){for(var p in b)if(b.hasOwnProperty(p))d[p]=b[p];};return function(d,b){extendStatics(d,b);function __(){this.constructor=d;}d.prototype=b===null?Object.create(b):(__.prototype=b.prototype,new __());};}();Object.defineProperty(exports,"__esModule",{value:true});var character_1=__webpack_require__(4);var JSXNode=__webpack_require__(5);var jsx_syntax_1=__webpack_require__(6);var Node=__webpack_require__(7);var parser_1=__webpack_require__(8);var token_1=__webpack_require__(13);var xhtml_entities_1=__webpack_require__(14);token_1.TokenName[100/* Identifier */]='JSXIdentifier';token_1.TokenName[101/* Text */]='JSXText';// Fully qualified element name, e.g. <svg:path> returns "svg:path"
function getQualifiedElementName(elementName){var qualifiedName;switch(elementName.type){case jsx_syntax_1.JSXSyntax.JSXIdentifier:var id=elementName;qualifiedName=id.name;break;case jsx_syntax_1.JSXSyntax.JSXNamespacedName:var ns=elementName;qualifiedName=getQualifiedElementName(ns.namespace)+':'+getQualifiedElementName(ns.name);break;case jsx_syntax_1.JSXSyntax.JSXMemberExpression:var expr=elementName;qualifiedName=getQualifiedElementName(expr.object)+'.'+getQualifiedElementName(expr.property);break;/* istanbul ignore next */default:break;}return qualifiedName;}var JSXParser=function(_super){__extends(JSXParser,_super);function JSXParser(code,options,delegate){return _super.call(this,code,options,delegate)||this;}JSXParser.prototype.parsePrimaryExpression=function(){return this.match('<')?this.parseJSXRoot():_super.prototype.parsePrimaryExpression.call(this);};JSXParser.prototype.startJSX=function(){// Unwind the scanner before the lookahead token.
this.scanner.index=this.startMarker.index;this.scanner.lineNumber=this.startMarker.line;this.scanner.lineStart=this.startMarker.index-this.startMarker.column;};JSXParser.prototype.finishJSX=function(){// Prime the next lookahead.
this.nextToken();};JSXParser.prototype.reenterJSX=function(){this.startJSX();this.expectJSX('}');// Pop the closing '}' added from the lookahead.
if(this.config.tokens){this.tokens.pop();}};JSXParser.prototype.createJSXNode=function(){this.collectComments();return{index:this.scanner.index,line:this.scanner.lineNumber,column:this.scanner.index-this.scanner.lineStart};};JSXParser.prototype.createJSXChildNode=function(){return{index:this.scanner.index,line:this.scanner.lineNumber,column:this.scanner.index-this.scanner.lineStart};};JSXParser.prototype.scanXHTMLEntity=function(quote){var result='&';var valid=true;var terminated=false;var numeric=false;var hex=false;while(!this.scanner.eof()&&valid&&!terminated){var ch=this.scanner.source[this.scanner.index];if(ch===quote){break;}terminated=ch===';';result+=ch;++this.scanner.index;if(!terminated){switch(result.length){case 2:// e.g. '&#123;'
numeric=ch==='#';break;case 3:if(numeric){// e.g. '&#x41;'
hex=ch==='x';valid=hex||character_1.Character.isDecimalDigit(ch.charCodeAt(0));numeric=numeric&&!hex;}break;default:valid=valid&&!(numeric&&!character_1.Character.isDecimalDigit(ch.charCodeAt(0)));valid=valid&&!(hex&&!character_1.Character.isHexDigit(ch.charCodeAt(0)));break;}}}if(valid&&terminated&&result.length>2){// e.g. '&#x41;' becomes just '#x41'
var str=result.substr(1,result.length-2);if(numeric&&str.length>1){result=String.fromCharCode(parseInt(str.substr(1),10));}else if(hex&&str.length>2){result=String.fromCharCode(parseInt('0'+str.substr(1),16));}else if(!numeric&&!hex&&xhtml_entities_1.XHTMLEntities[str]){result=xhtml_entities_1.XHTMLEntities[str];}}return result;};// Scan the next JSX token. This replaces Scanner#lex when in JSX mode.
JSXParser.prototype.lexJSX=function(){var cp=this.scanner.source.charCodeAt(this.scanner.index);// < > / : = { }
if(cp===60||cp===62||cp===47||cp===58||cp===61||cp===123||cp===125){var value=this.scanner.source[this.scanner.index++];return{type:7/* Punctuator */,value:value,lineNumber:this.scanner.lineNumber,lineStart:this.scanner.lineStart,start:this.scanner.index-1,end:this.scanner.index};}// " '
if(cp===34||cp===39){var start=this.scanner.index;var quote=this.scanner.source[this.scanner.index++];var str='';while(!this.scanner.eof()){var ch=this.scanner.source[this.scanner.index++];if(ch===quote){break;}else if(ch==='&'){str+=this.scanXHTMLEntity(quote);}else{str+=ch;}}return{type:8/* StringLiteral */,value:str,lineNumber:this.scanner.lineNumber,lineStart:this.scanner.lineStart,start:start,end:this.scanner.index};}// ... or .
if(cp===46){var n1=this.scanner.source.charCodeAt(this.scanner.index+1);var n2=this.scanner.source.charCodeAt(this.scanner.index+2);var value=n1===46&&n2===46?'...':'.';var start=this.scanner.index;this.scanner.index+=value.length;return{type:7/* Punctuator */,value:value,lineNumber:this.scanner.lineNumber,lineStart:this.scanner.lineStart,start:start,end:this.scanner.index};}// `
if(cp===96){// Only placeholder, since it will be rescanned as a real assignment expression.
return{type:10/* Template */,value:'',lineNumber:this.scanner.lineNumber,lineStart:this.scanner.lineStart,start:this.scanner.index,end:this.scanner.index};}// Identifer can not contain backslash (char code 92).
if(character_1.Character.isIdentifierStart(cp)&&cp!==92){var start=this.scanner.index;++this.scanner.index;while(!this.scanner.eof()){var ch=this.scanner.source.charCodeAt(this.scanner.index);if(character_1.Character.isIdentifierPart(ch)&&ch!==92){++this.scanner.index;}else if(ch===45){// Hyphen (char code 45) can be part of an identifier.
++this.scanner.index;}else{break;}}var id=this.scanner.source.slice(start,this.scanner.index);return{type:100/* Identifier */,value:id,lineNumber:this.scanner.lineNumber,lineStart:this.scanner.lineStart,start:start,end:this.scanner.index};}return this.scanner.lex();};JSXParser.prototype.nextJSXToken=function(){this.collectComments();this.startMarker.index=this.scanner.index;this.startMarker.line=this.scanner.lineNumber;this.startMarker.column=this.scanner.index-this.scanner.lineStart;var token=this.lexJSX();this.lastMarker.index=this.scanner.index;this.lastMarker.line=this.scanner.lineNumber;this.lastMarker.column=this.scanner.index-this.scanner.lineStart;if(this.config.tokens){this.tokens.push(this.convertToken(token));}return token;};JSXParser.prototype.nextJSXText=function(){this.startMarker.index=this.scanner.index;this.startMarker.line=this.scanner.lineNumber;this.startMarker.column=this.scanner.index-this.scanner.lineStart;var start=this.scanner.index;var text='';while(!this.scanner.eof()){var ch=this.scanner.source[this.scanner.index];if(ch==='{'||ch==='<'){break;}++this.scanner.index;text+=ch;if(character_1.Character.isLineTerminator(ch.charCodeAt(0))){++this.scanner.lineNumber;if(ch==='\r'&&this.scanner.source[this.scanner.index]==='\n'){++this.scanner.index;}this.scanner.lineStart=this.scanner.index;}}this.lastMarker.index=this.scanner.index;this.lastMarker.line=this.scanner.lineNumber;this.lastMarker.column=this.scanner.index-this.scanner.lineStart;var token={type:101/* Text */,value:text,lineNumber:this.scanner.lineNumber,lineStart:this.scanner.lineStart,start:start,end:this.scanner.index};if(text.length>0&&this.config.tokens){this.tokens.push(this.convertToken(token));}return token;};JSXParser.prototype.peekJSXToken=function(){var state=this.scanner.saveState();this.scanner.scanComments();var next=this.lexJSX();this.scanner.restoreState(state);return next;};// Expect the next JSX token to match the specified punctuator.
// If not, an exception will be thrown.
JSXParser.prototype.expectJSX=function(value){var token=this.nextJSXToken();if(token.type!==7/* Punctuator */||token.value!==value){this.throwUnexpectedToken(token);}};// Return true if the next JSX token matches the specified punctuator.
JSXParser.prototype.matchJSX=function(value){var next=this.peekJSXToken();return next.type===7/* Punctuator */&&next.value===value;};JSXParser.prototype.parseJSXIdentifier=function(){var node=this.createJSXNode();var token=this.nextJSXToken();if(token.type!==100/* Identifier */){this.throwUnexpectedToken(token);}return this.finalize(node,new JSXNode.JSXIdentifier(token.value));};JSXParser.prototype.parseJSXElementName=function(){var node=this.createJSXNode();var elementName=this.parseJSXIdentifier();if(this.matchJSX(':')){var namespace=elementName;this.expectJSX(':');var name_1=this.parseJSXIdentifier();elementName=this.finalize(node,new JSXNode.JSXNamespacedName(namespace,name_1));}else if(this.matchJSX('.')){while(this.matchJSX('.')){var object=elementName;this.expectJSX('.');var property=this.parseJSXIdentifier();elementName=this.finalize(node,new JSXNode.JSXMemberExpression(object,property));}}return elementName;};JSXParser.prototype.parseJSXAttributeName=function(){var node=this.createJSXNode();var attributeName;var identifier=this.parseJSXIdentifier();if(this.matchJSX(':')){var namespace=identifier;this.expectJSX(':');var name_2=this.parseJSXIdentifier();attributeName=this.finalize(node,new JSXNode.JSXNamespacedName(namespace,name_2));}else{attributeName=identifier;}return attributeName;};JSXParser.prototype.parseJSXStringLiteralAttribute=function(){var node=this.createJSXNode();var token=this.nextJSXToken();if(token.type!==8/* StringLiteral */){this.throwUnexpectedToken(token);}var raw=this.getTokenRaw(token);return this.finalize(node,new Node.Literal(token.value,raw));};JSXParser.prototype.parseJSXExpressionAttribute=function(){var node=this.createJSXNode();this.expectJSX('{');this.finishJSX();if(this.match('}')){this.tolerateError('JSX attributes must only be assigned a non-empty expression');}var expression=this.parseAssignmentExpression();this.reenterJSX();return this.finalize(node,new JSXNode.JSXExpressionContainer(expression));};JSXParser.prototype.parseJSXAttributeValue=function(){return this.matchJSX('{')?this.parseJSXExpressionAttribute():this.matchJSX('<')?this.parseJSXElement():this.parseJSXStringLiteralAttribute();};JSXParser.prototype.parseJSXNameValueAttribute=function(){var node=this.createJSXNode();var name=this.parseJSXAttributeName();var value=null;if(this.matchJSX('=')){this.expectJSX('=');value=this.parseJSXAttributeValue();}return this.finalize(node,new JSXNode.JSXAttribute(name,value));};JSXParser.prototype.parseJSXSpreadAttribute=function(){var node=this.createJSXNode();this.expectJSX('{');this.expectJSX('...');this.finishJSX();var argument=this.parseAssignmentExpression();this.reenterJSX();return this.finalize(node,new JSXNode.JSXSpreadAttribute(argument));};JSXParser.prototype.parseJSXAttributes=function(){var attributes=[];while(!this.matchJSX('/')&&!this.matchJSX('>')){var attribute=this.matchJSX('{')?this.parseJSXSpreadAttribute():this.parseJSXNameValueAttribute();attributes.push(attribute);}return attributes;};JSXParser.prototype.parseJSXOpeningElement=function(){var node=this.createJSXNode();this.expectJSX('<');var name=this.parseJSXElementName();var attributes=this.parseJSXAttributes();var selfClosing=this.matchJSX('/');if(selfClosing){this.expectJSX('/');}this.expectJSX('>');return this.finalize(node,new JSXNode.JSXOpeningElement(name,selfClosing,attributes));};JSXParser.prototype.parseJSXBoundaryElement=function(){var node=this.createJSXNode();this.expectJSX('<');if(this.matchJSX('/')){this.expectJSX('/');var name_3=this.parseJSXElementName();this.expectJSX('>');return this.finalize(node,new JSXNode.JSXClosingElement(name_3));}var name=this.parseJSXElementName();var attributes=this.parseJSXAttributes();var selfClosing=this.matchJSX('/');if(selfClosing){this.expectJSX('/');}this.expectJSX('>');return this.finalize(node,new JSXNode.JSXOpeningElement(name,selfClosing,attributes));};JSXParser.prototype.parseJSXEmptyExpression=function(){var node=this.createJSXChildNode();this.collectComments();this.lastMarker.index=this.scanner.index;this.lastMarker.line=this.scanner.lineNumber;this.lastMarker.column=this.scanner.index-this.scanner.lineStart;return this.finalize(node,new JSXNode.JSXEmptyExpression());};JSXParser.prototype.parseJSXExpressionContainer=function(){var node=this.createJSXNode();this.expectJSX('{');var expression;if(this.matchJSX('}')){expression=this.parseJSXEmptyExpression();this.expectJSX('}');}else{this.finishJSX();expression=this.parseAssignmentExpression();this.reenterJSX();}return this.finalize(node,new JSXNode.JSXExpressionContainer(expression));};JSXParser.prototype.parseJSXChildren=function(){var children=[];while(!this.scanner.eof()){var node=this.createJSXChildNode();var token=this.nextJSXText();if(token.start<token.end){var raw=this.getTokenRaw(token);var child=this.finalize(node,new JSXNode.JSXText(token.value,raw));children.push(child);}if(this.scanner.source[this.scanner.index]==='{'){var container=this.parseJSXExpressionContainer();children.push(container);}else{break;}}return children;};JSXParser.prototype.parseComplexJSXElement=function(el){var stack=[];while(!this.scanner.eof()){el.children=el.children.concat(this.parseJSXChildren());var node=this.createJSXChildNode();var element=this.parseJSXBoundaryElement();if(element.type===jsx_syntax_1.JSXSyntax.JSXOpeningElement){var opening=element;if(opening.selfClosing){var child=this.finalize(node,new JSXNode.JSXElement(opening,[],null));el.children.push(child);}else{stack.push(el);el={node:node,opening:opening,closing:null,children:[]};}}if(element.type===jsx_syntax_1.JSXSyntax.JSXClosingElement){el.closing=element;var open_1=getQualifiedElementName(el.opening.name);var close_1=getQualifiedElementName(el.closing.name);if(open_1!==close_1){this.tolerateError('Expected corresponding JSX closing tag for %0',open_1);}if(stack.length>0){var child=this.finalize(el.node,new JSXNode.JSXElement(el.opening,el.children,el.closing));el=stack[stack.length-1];el.children.push(child);stack.pop();}else{break;}}}return el;};JSXParser.prototype.parseJSXElement=function(){var node=this.createJSXNode();var opening=this.parseJSXOpeningElement();var children=[];var closing=null;if(!opening.selfClosing){var el=this.parseComplexJSXElement({node:node,opening:opening,closing:closing,children:children});children=el.children;closing=el.closing;}return this.finalize(node,new JSXNode.JSXElement(opening,children,closing));};JSXParser.prototype.parseJSXRoot=function(){// Pop the opening '<' added from the lookahead.
if(this.config.tokens){this.tokens.pop();}this.startJSX();var element=this.parseJSXElement();this.finishJSX();return element;};JSXParser.prototype.isStartOfExpression=function(){return _super.prototype.isStartOfExpression.call(this)||this.match('<');};return JSXParser;}(parser_1.Parser);exports.JSXParser=JSXParser;/***/},/* 4 */ /***/function(module,exports){"use strict";Object.defineProperty(exports,"__esModule",{value:true});// See also tools/generate-unicode-regex.js.
var Regex={// Unicode v8.0.0 NonAsciiIdentifierStart:
NonAsciiIdentifierStart:/[\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0561-\u0587\u05D0-\u05EA\u05F0-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u08A0-\u08B4\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C60\u0C61\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u170C\u170E-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1877\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1CE9-\u1CEC\u1CEE-\u1CF1\u1CF5\u1CF6\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2118-\u211D\u2124\u2126\u2128\u212A-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309B-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FD5\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7AD\uA7B0-\uA7B7\uA7F7-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB65\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD40-\uDD74\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF1F\uDF30-\uDF4A\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDD00-\uDD27\uDD30-\uDD63\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE33\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE4\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2]|\uD804[\uDC03-\uDC37\uDC83-\uDCAF\uDCD0-\uDCE8\uDD03-\uDD26\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE2B\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61]|\uD805[\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE80-\uDEAA\uDF00-\uDF19]|\uD806[\uDCA0-\uDCDF\uDCFF\uDEC0-\uDEF8]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|[\uD80C\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDF00-\uDF44\uDF50\uDF93-\uDF9F]|\uD82C[\uDC00\uDC01]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD83A[\uDC00-\uDCC4]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDED6\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF34\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1]|\uD87E[\uDC00-\uDE1D]/,// Unicode v8.0.0 NonAsciiIdentifierPart:
NonAsciiIdentifierPart:/[\xAA\xB5\xB7\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0300-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u0483-\u0487\u048A-\u052F\u0531-\u0556\u0559\u0561-\u0587\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u05D0-\u05EA\u05F0-\u05F2\u0610-\u061A\u0620-\u0669\u066E-\u06D3\u06D5-\u06DC\u06DF-\u06E8\u06EA-\u06FC\u06FF\u0710-\u074A\u074D-\u07B1\u07C0-\u07F5\u07FA\u0800-\u082D\u0840-\u085B\u08A0-\u08B4\u08E3-\u0963\u0966-\u096F\u0971-\u0983\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BC-\u09C4\u09C7\u09C8\u09CB-\u09CE\u09D7\u09DC\u09DD\u09DF-\u09E3\u09E6-\u09F1\u0A01-\u0A03\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A59-\u0A5C\u0A5E\u0A66-\u0A75\u0A81-\u0A83\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABC-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AD0\u0AE0-\u0AE3\u0AE6-\u0AEF\u0AF9\u0B01-\u0B03\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3C-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B56\u0B57\u0B5C\u0B5D\u0B5F-\u0B63\u0B66-\u0B6F\u0B71\u0B82\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD0\u0BD7\u0BE6-\u0BEF\u0C00-\u0C03\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C58-\u0C5A\u0C60-\u0C63\u0C66-\u0C6F\u0C81-\u0C83\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBC-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CDE\u0CE0-\u0CE3\u0CE6-\u0CEF\u0CF1\u0CF2\u0D01-\u0D03\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D-\u0D44\u0D46-\u0D48\u0D4A-\u0D4E\u0D57\u0D5F-\u0D63\u0D66-\u0D6F\u0D7A-\u0D7F\u0D82\u0D83\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DE6-\u0DEF\u0DF2\u0DF3\u0E01-\u0E3A\u0E40-\u0E4E\u0E50-\u0E59\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB9\u0EBB-\u0EBD\u0EC0-\u0EC4\u0EC6\u0EC8-\u0ECD\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00\u0F18\u0F19\u0F20-\u0F29\u0F35\u0F37\u0F39\u0F3E-\u0F47\u0F49-\u0F6C\u0F71-\u0F84\u0F86-\u0F97\u0F99-\u0FBC\u0FC6\u1000-\u1049\u1050-\u109D\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u135D-\u135F\u1369-\u1371\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u170C\u170E-\u1714\u1720-\u1734\u1740-\u1753\u1760-\u176C\u176E-\u1770\u1772\u1773\u1780-\u17D3\u17D7\u17DC\u17DD\u17E0-\u17E9\u180B-\u180D\u1810-\u1819\u1820-\u1877\u1880-\u18AA\u18B0-\u18F5\u1900-\u191E\u1920-\u192B\u1930-\u193B\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19DA\u1A00-\u1A1B\u1A20-\u1A5E\u1A60-\u1A7C\u1A7F-\u1A89\u1A90-\u1A99\u1AA7\u1AB0-\u1ABD\u1B00-\u1B4B\u1B50-\u1B59\u1B6B-\u1B73\u1B80-\u1BF3\u1C00-\u1C37\u1C40-\u1C49\u1C4D-\u1C7D\u1CD0-\u1CD2\u1CD4-\u1CF6\u1CF8\u1CF9\u1D00-\u1DF5\u1DFC-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u200C\u200D\u203F\u2040\u2054\u2071\u207F\u2090-\u209C\u20D0-\u20DC\u20E1\u20E5-\u20F0\u2102\u2107\u210A-\u2113\u2115\u2118-\u211D\u2124\u2126\u2128\u212A-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D7F-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2DE0-\u2DFF\u3005-\u3007\u3021-\u302F\u3031-\u3035\u3038-\u303C\u3041-\u3096\u3099-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FD5\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA62B\uA640-\uA66F\uA674-\uA67D\uA67F-\uA6F1\uA717-\uA71F\uA722-\uA788\uA78B-\uA7AD\uA7B0-\uA7B7\uA7F7-\uA827\uA840-\uA873\uA880-\uA8C4\uA8D0-\uA8D9\uA8E0-\uA8F7\uA8FB\uA8FD\uA900-\uA92D\uA930-\uA953\uA960-\uA97C\uA980-\uA9C0\uA9CF-\uA9D9\uA9E0-\uA9FE\uAA00-\uAA36\uAA40-\uAA4D\uAA50-\uAA59\uAA60-\uAA76\uAA7A-\uAAC2\uAADB-\uAADD\uAAE0-\uAAEF\uAAF2-\uAAF6\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB65\uAB70-\uABEA\uABEC\uABED\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE00-\uFE0F\uFE20-\uFE2F\uFE33\uFE34\uFE4D-\uFE4F\uFE70-\uFE74\uFE76-\uFEFC\uFF10-\uFF19\uFF21-\uFF3A\uFF3F\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD40-\uDD74\uDDFD\uDE80-\uDE9C\uDEA0-\uDED0\uDEE0\uDF00-\uDF1F\uDF30-\uDF4A\uDF50-\uDF7A\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDCA0-\uDCA9\uDD00-\uDD27\uDD30-\uDD63\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00-\uDE03\uDE05\uDE06\uDE0C-\uDE13\uDE15-\uDE17\uDE19-\uDE33\uDE38-\uDE3A\uDE3F\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE6\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2]|\uD804[\uDC00-\uDC46\uDC66-\uDC6F\uDC7F-\uDCBA\uDCD0-\uDCE8\uDCF0-\uDCF9\uDD00-\uDD34\uDD36-\uDD3F\uDD50-\uDD73\uDD76\uDD80-\uDDC4\uDDCA-\uDDCC\uDDD0-\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE37\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEEA\uDEF0-\uDEF9\uDF00-\uDF03\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3C-\uDF44\uDF47\uDF48\uDF4B-\uDF4D\uDF50\uDF57\uDF5D-\uDF63\uDF66-\uDF6C\uDF70-\uDF74]|\uD805[\uDC80-\uDCC5\uDCC7\uDCD0-\uDCD9\uDD80-\uDDB5\uDDB8-\uDDC0\uDDD8-\uDDDD\uDE00-\uDE40\uDE44\uDE50-\uDE59\uDE80-\uDEB7\uDEC0-\uDEC9\uDF00-\uDF19\uDF1D-\uDF2B\uDF30-\uDF39]|\uD806[\uDCA0-\uDCE9\uDCFF\uDEC0-\uDEF8]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|[\uD80C\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE60-\uDE69\uDED0-\uDEED\uDEF0-\uDEF4\uDF00-\uDF36\uDF40-\uDF43\uDF50-\uDF59\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDF00-\uDF44\uDF50-\uDF7E\uDF8F-\uDF9F]|\uD82C[\uDC00\uDC01]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99\uDC9D\uDC9E]|\uD834[\uDD65-\uDD69\uDD6D-\uDD72\uDD7B-\uDD82\uDD85-\uDD8B\uDDAA-\uDDAD\uDE42-\uDE44]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB\uDFCE-\uDFFF]|\uD836[\uDE00-\uDE36\uDE3B-\uDE6C\uDE75\uDE84\uDE9B-\uDE9F\uDEA1-\uDEAF]|\uD83A[\uDC00-\uDCC4\uDCD0-\uDCD6]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDED6\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF34\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1]|\uD87E[\uDC00-\uDE1D]|\uDB40[\uDD00-\uDDEF]/};exports.Character={/* tslint:disable:no-bitwise */fromCodePoint:function(cp){return cp<0x10000?String.fromCharCode(cp):String.fromCharCode(0xD800+(cp-0x10000>>10))+String.fromCharCode(0xDC00+(cp-0x10000&1023));},// https://tc39.github.io/ecma262/#sec-white-space
isWhiteSpace:function(cp){return cp===0x20||cp===0x09||cp===0x0B||cp===0x0C||cp===0xA0||cp>=0x1680&&[0x1680,0x2000,0x2001,0x2002,0x2003,0x2004,0x2005,0x2006,0x2007,0x2008,0x2009,0x200A,0x202F,0x205F,0x3000,0xFEFF].indexOf(cp)>=0;},// https://tc39.github.io/ecma262/#sec-line-terminators
isLineTerminator:function(cp){return cp===0x0A||cp===0x0D||cp===0x2028||cp===0x2029;},// https://tc39.github.io/ecma262/#sec-names-and-keywords
isIdentifierStart:function(cp){return cp===0x24||cp===0x5F||cp>=0x41&&cp<=0x5A||cp>=0x61&&cp<=0x7A||cp===0x5C||cp>=0x80&&Regex.NonAsciiIdentifierStart.test(exports.Character.fromCodePoint(cp));},isIdentifierPart:function(cp){return cp===0x24||cp===0x5F||cp>=0x41&&cp<=0x5A||cp>=0x61&&cp<=0x7A||cp>=0x30&&cp<=0x39||cp===0x5C||cp>=0x80&&Regex.NonAsciiIdentifierPart.test(exports.Character.fromCodePoint(cp));},// https://tc39.github.io/ecma262/#sec-literals-numeric-literals
isDecimalDigit:function(cp){return cp>=0x30&&cp<=0x39;// 0..9
},isHexDigit:function(cp){return cp>=0x30&&cp<=0x39||cp>=0x41&&cp<=0x46||cp>=0x61&&cp<=0x66;// a..f
},isOctalDigit:function(cp){return cp>=0x30&&cp<=0x37;// 0..7
}};/***/},/* 5 */ /***/function(module,exports,__webpack_require__){"use strict";Object.defineProperty(exports,"__esModule",{value:true});var jsx_syntax_1=__webpack_require__(6);/* tslint:disable:max-classes-per-file */var JSXClosingElement=function(){function JSXClosingElement(name){this.type=jsx_syntax_1.JSXSyntax.JSXClosingElement;this.name=name;}return JSXClosingElement;}();exports.JSXClosingElement=JSXClosingElement;var JSXElement=function(){function JSXElement(openingElement,children,closingElement){this.type=jsx_syntax_1.JSXSyntax.JSXElement;this.openingElement=openingElement;this.children=children;this.closingElement=closingElement;}return JSXElement;}();exports.JSXElement=JSXElement;var JSXEmptyExpression=function(){function JSXEmptyExpression(){this.type=jsx_syntax_1.JSXSyntax.JSXEmptyExpression;}return JSXEmptyExpression;}();exports.JSXEmptyExpression=JSXEmptyExpression;var JSXExpressionContainer=function(){function JSXExpressionContainer(expression){this.type=jsx_syntax_1.JSXSyntax.JSXExpressionContainer;this.expression=expression;}return JSXExpressionContainer;}();exports.JSXExpressionContainer=JSXExpressionContainer;var JSXIdentifier=function(){function JSXIdentifier(name){this.type=jsx_syntax_1.JSXSyntax.JSXIdentifier;this.name=name;}return JSXIdentifier;}();exports.JSXIdentifier=JSXIdentifier;var JSXMemberExpression=function(){function JSXMemberExpression(object,property){this.type=jsx_syntax_1.JSXSyntax.JSXMemberExpression;this.object=object;this.property=property;}return JSXMemberExpression;}();exports.JSXMemberExpression=JSXMemberExpression;var JSXAttribute=function(){function JSXAttribute(name,value){this.type=jsx_syntax_1.JSXSyntax.JSXAttribute;this.name=name;this.value=value;}return JSXAttribute;}();exports.JSXAttribute=JSXAttribute;var JSXNamespacedName=function(){function JSXNamespacedName(namespace,name){this.type=jsx_syntax_1.JSXSyntax.JSXNamespacedName;this.namespace=namespace;this.name=name;}return JSXNamespacedName;}();exports.JSXNamespacedName=JSXNamespacedName;var JSXOpeningElement=function(){function JSXOpeningElement(name,selfClosing,attributes){this.type=jsx_syntax_1.JSXSyntax.JSXOpeningElement;this.name=name;this.selfClosing=selfClosing;this.attributes=attributes;}return JSXOpeningElement;}();exports.JSXOpeningElement=JSXOpeningElement;var JSXSpreadAttribute=function(){function JSXSpreadAttribute(argument){this.type=jsx_syntax_1.JSXSyntax.JSXSpreadAttribute;this.argument=argument;}return JSXSpreadAttribute;}();exports.JSXSpreadAttribute=JSXSpreadAttribute;var JSXText=function(){function JSXText(value,raw){this.type=jsx_syntax_1.JSXSyntax.JSXText;this.value=value;this.raw=raw;}return JSXText;}();exports.JSXText=JSXText;/***/},/* 6 */ /***/function(module,exports){"use strict";Object.defineProperty(exports,"__esModule",{value:true});exports.JSXSyntax={JSXAttribute:'JSXAttribute',JSXClosingElement:'JSXClosingElement',JSXElement:'JSXElement',JSXEmptyExpression:'JSXEmptyExpression',JSXExpressionContainer:'JSXExpressionContainer',JSXIdentifier:'JSXIdentifier',JSXMemberExpression:'JSXMemberExpression',JSXNamespacedName:'JSXNamespacedName',JSXOpeningElement:'JSXOpeningElement',JSXSpreadAttribute:'JSXSpreadAttribute',JSXText:'JSXText'};/***/},/* 7 */ /***/function(module,exports,__webpack_require__){"use strict";Object.defineProperty(exports,"__esModule",{value:true});var syntax_1=__webpack_require__(2);/* tslint:disable:max-classes-per-file */var ArrayExpression=function(){function ArrayExpression(elements){this.type=syntax_1.Syntax.ArrayExpression;this.elements=elements;}return ArrayExpression;}();exports.ArrayExpression=ArrayExpression;var ArrayPattern=function(){function ArrayPattern(elements){this.type=syntax_1.Syntax.ArrayPattern;this.elements=elements;}return ArrayPattern;}();exports.ArrayPattern=ArrayPattern;var ArrowFunctionExpression=function(){function ArrowFunctionExpression(params,body,expression){this.type=syntax_1.Syntax.ArrowFunctionExpression;this.id=null;this.params=params;this.body=body;this.generator=false;this.expression=expression;this.async=false;}return ArrowFunctionExpression;}();exports.ArrowFunctionExpression=ArrowFunctionExpression;var AssignmentExpression=function(){function AssignmentExpression(operator,left,right){this.type=syntax_1.Syntax.AssignmentExpression;this.operator=operator;this.left=left;this.right=right;}return AssignmentExpression;}();exports.AssignmentExpression=AssignmentExpression;var AssignmentPattern=function(){function AssignmentPattern(left,right){this.type=syntax_1.Syntax.AssignmentPattern;this.left=left;this.right=right;}return AssignmentPattern;}();exports.AssignmentPattern=AssignmentPattern;var AsyncArrowFunctionExpression=function(){function AsyncArrowFunctionExpression(params,body,expression){this.type=syntax_1.Syntax.ArrowFunctionExpression;this.id=null;this.params=params;this.body=body;this.generator=false;this.expression=expression;this.async=true;}return AsyncArrowFunctionExpression;}();exports.AsyncArrowFunctionExpression=AsyncArrowFunctionExpression;var AsyncFunctionDeclaration=function(){function AsyncFunctionDeclaration(id,params,body){this.type=syntax_1.Syntax.FunctionDeclaration;this.id=id;this.params=params;this.body=body;this.generator=false;this.expression=false;this.async=true;}return AsyncFunctionDeclaration;}();exports.AsyncFunctionDeclaration=AsyncFunctionDeclaration;var AsyncFunctionExpression=function(){function AsyncFunctionExpression(id,params,body){this.type=syntax_1.Syntax.FunctionExpression;this.id=id;this.params=params;this.body=body;this.generator=false;this.expression=false;this.async=true;}return AsyncFunctionExpression;}();exports.AsyncFunctionExpression=AsyncFunctionExpression;var AwaitExpression=function(){function AwaitExpression(argument){this.type=syntax_1.Syntax.AwaitExpression;this.argument=argument;}return AwaitExpression;}();exports.AwaitExpression=AwaitExpression;var BinaryExpression=function(){function BinaryExpression(operator,left,right){var logical=operator==='||'||operator==='&&';this.type=logical?syntax_1.Syntax.LogicalExpression:syntax_1.Syntax.BinaryExpression;this.operator=operator;this.left=left;this.right=right;}return BinaryExpression;}();exports.BinaryExpression=BinaryExpression;var BlockStatement=function(){function BlockStatement(body){this.type=syntax_1.Syntax.BlockStatement;this.body=body;}return BlockStatement;}();exports.BlockStatement=BlockStatement;var BreakStatement=function(){function BreakStatement(label){this.type=syntax_1.Syntax.BreakStatement;this.label=label;}return BreakStatement;}();exports.BreakStatement=BreakStatement;var CallExpression=function(){function CallExpression(callee,args){this.type=syntax_1.Syntax.CallExpression;this.callee=callee;this.arguments=args;}return CallExpression;}();exports.CallExpression=CallExpression;var CatchClause=function(){function CatchClause(param,body){this.type=syntax_1.Syntax.CatchClause;this.param=param;this.body=body;}return CatchClause;}();exports.CatchClause=CatchClause;var ClassBody=function(){function ClassBody(body){this.type=syntax_1.Syntax.ClassBody;this.body=body;}return ClassBody;}();exports.ClassBody=ClassBody;var ClassDeclaration=function(){function ClassDeclaration(id,superClass,body){this.type=syntax_1.Syntax.ClassDeclaration;this.id=id;this.superClass=superClass;this.body=body;}return ClassDeclaration;}();exports.ClassDeclaration=ClassDeclaration;var ClassExpression=function(){function ClassExpression(id,superClass,body){this.type=syntax_1.Syntax.ClassExpression;this.id=id;this.superClass=superClass;this.body=body;}return ClassExpression;}();exports.ClassExpression=ClassExpression;var ComputedMemberExpression=function(){function ComputedMemberExpression(object,property){this.type=syntax_1.Syntax.MemberExpression;this.computed=true;this.object=object;this.property=property;}return ComputedMemberExpression;}();exports.ComputedMemberExpression=ComputedMemberExpression;var ConditionalExpression=function(){function ConditionalExpression(test,consequent,alternate){this.type=syntax_1.Syntax.ConditionalExpression;this.test=test;this.consequent=consequent;this.alternate=alternate;}return ConditionalExpression;}();exports.ConditionalExpression=ConditionalExpression;var ContinueStatement=function(){function ContinueStatement(label){this.type=syntax_1.Syntax.ContinueStatement;this.label=label;}return ContinueStatement;}();exports.ContinueStatement=ContinueStatement;var DebuggerStatement=function(){function DebuggerStatement(){this.type=syntax_1.Syntax.DebuggerStatement;}return DebuggerStatement;}();exports.DebuggerStatement=DebuggerStatement;var Directive=function(){function Directive(expression,directive){this.type=syntax_1.Syntax.ExpressionStatement;this.expression=expression;this.directive=directive;}return Directive;}();exports.Directive=Directive;var DoWhileStatement=function(){function DoWhileStatement(body,test){this.type=syntax_1.Syntax.DoWhileStatement;this.body=body;this.test=test;}return DoWhileStatement;}();exports.DoWhileStatement=DoWhileStatement;var EmptyStatement=function(){function EmptyStatement(){this.type=syntax_1.Syntax.EmptyStatement;}return EmptyStatement;}();exports.EmptyStatement=EmptyStatement;var ExportAllDeclaration=function(){function ExportAllDeclaration(source){this.type=syntax_1.Syntax.ExportAllDeclaration;this.source=source;}return ExportAllDeclaration;}();exports.ExportAllDeclaration=ExportAllDeclaration;var ExportDefaultDeclaration=function(){function ExportDefaultDeclaration(declaration){this.type=syntax_1.Syntax.ExportDefaultDeclaration;this.declaration=declaration;}return ExportDefaultDeclaration;}();exports.ExportDefaultDeclaration=ExportDefaultDeclaration;var ExportNamedDeclaration=function(){function ExportNamedDeclaration(declaration,specifiers,source){this.type=syntax_1.Syntax.ExportNamedDeclaration;this.declaration=declaration;this.specifiers=specifiers;this.source=source;}return ExportNamedDeclaration;}();exports.ExportNamedDeclaration=ExportNamedDeclaration;var ExportSpecifier=function(){function ExportSpecifier(local,exported){this.type=syntax_1.Syntax.ExportSpecifier;this.exported=exported;this.local=local;}return ExportSpecifier;}();exports.ExportSpecifier=ExportSpecifier;var ExpressionStatement=function(){function ExpressionStatement(expression){this.type=syntax_1.Syntax.ExpressionStatement;this.expression=expression;}return ExpressionStatement;}();exports.ExpressionStatement=ExpressionStatement;var ForInStatement=function(){function ForInStatement(left,right,body){this.type=syntax_1.Syntax.ForInStatement;this.left=left;this.right=right;this.body=body;this.each=false;}return ForInStatement;}();exports.ForInStatement=ForInStatement;var ForOfStatement=function(){function ForOfStatement(left,right,body){this.type=syntax_1.Syntax.ForOfStatement;this.left=left;this.right=right;this.body=body;}return ForOfStatement;}();exports.ForOfStatement=ForOfStatement;var ForStatement=function(){function ForStatement(init,test,update,body){this.type=syntax_1.Syntax.ForStatement;this.init=init;this.test=test;this.update=update;this.body=body;}return ForStatement;}();exports.ForStatement=ForStatement;var FunctionDeclaration=function(){function FunctionDeclaration(id,params,body,generator){this.type=syntax_1.Syntax.FunctionDeclaration;this.id=id;this.params=params;this.body=body;this.generator=generator;this.expression=false;this.async=false;}return FunctionDeclaration;}();exports.FunctionDeclaration=FunctionDeclaration;var FunctionExpression=function(){function FunctionExpression(id,params,body,generator){this.type=syntax_1.Syntax.FunctionExpression;this.id=id;this.params=params;this.body=body;this.generator=generator;this.expression=false;this.async=false;}return FunctionExpression;}();exports.FunctionExpression=FunctionExpression;var Identifier=function(){function Identifier(name){this.type=syntax_1.Syntax.Identifier;this.name=name;}return Identifier;}();exports.Identifier=Identifier;var IfStatement=function(){function IfStatement(test,consequent,alternate){this.type=syntax_1.Syntax.IfStatement;this.test=test;this.consequent=consequent;this.alternate=alternate;}return IfStatement;}();exports.IfStatement=IfStatement;var ImportDeclaration=function(){function ImportDeclaration(specifiers,source){this.type=syntax_1.Syntax.ImportDeclaration;this.specifiers=specifiers;this.source=source;}return ImportDeclaration;}();exports.ImportDeclaration=ImportDeclaration;var ImportDefaultSpecifier=function(){function ImportDefaultSpecifier(local){this.type=syntax_1.Syntax.ImportDefaultSpecifier;this.local=local;}return ImportDefaultSpecifier;}();exports.ImportDefaultSpecifier=ImportDefaultSpecifier;var ImportNamespaceSpecifier=function(){function ImportNamespaceSpecifier(local){this.type=syntax_1.Syntax.ImportNamespaceSpecifier;this.local=local;}return ImportNamespaceSpecifier;}();exports.ImportNamespaceSpecifier=ImportNamespaceSpecifier;var ImportSpecifier=function(){function ImportSpecifier(local,imported){this.type=syntax_1.Syntax.ImportSpecifier;this.local=local;this.imported=imported;}return ImportSpecifier;}();exports.ImportSpecifier=ImportSpecifier;var LabeledStatement=function(){function LabeledStatement(label,body){this.type=syntax_1.Syntax.LabeledStatement;this.label=label;this.body=body;}return LabeledStatement;}();exports.LabeledStatement=LabeledStatement;var Literal=function(){function Literal(value,raw){this.type=syntax_1.Syntax.Literal;this.value=value;this.raw=raw;}return Literal;}();exports.Literal=Literal;var MetaProperty=function(){function MetaProperty(meta,property){this.type=syntax_1.Syntax.MetaProperty;this.meta=meta;this.property=property;}return MetaProperty;}();exports.MetaProperty=MetaProperty;var MethodDefinition=function(){function MethodDefinition(key,computed,value,kind,isStatic){this.type=syntax_1.Syntax.MethodDefinition;this.key=key;this.computed=computed;this.value=value;this.kind=kind;this.static=isStatic;}return MethodDefinition;}();exports.MethodDefinition=MethodDefinition;var Module=function(){function Module(body){this.type=syntax_1.Syntax.Program;this.body=body;this.sourceType='module';}return Module;}();exports.Module=Module;var NewExpression=function(){function NewExpression(callee,args){this.type=syntax_1.Syntax.NewExpression;this.callee=callee;this.arguments=args;}return NewExpression;}();exports.NewExpression=NewExpression;var ObjectExpression=function(){function ObjectExpression(properties){this.type=syntax_1.Syntax.ObjectExpression;this.properties=properties;}return ObjectExpression;}();exports.ObjectExpression=ObjectExpression;var ObjectPattern=function(){function ObjectPattern(properties){this.type=syntax_1.Syntax.ObjectPattern;this.properties=properties;}return ObjectPattern;}();exports.ObjectPattern=ObjectPattern;var Property=function(){function Property(kind,key,computed,value,method,shorthand){this.type=syntax_1.Syntax.Property;this.key=key;this.computed=computed;this.value=value;this.kind=kind;this.method=method;this.shorthand=shorthand;}return Property;}();exports.Property=Property;var RegexLiteral=function(){function RegexLiteral(value,raw,pattern,flags){this.type=syntax_1.Syntax.Literal;this.value=value;this.raw=raw;this.regex={pattern:pattern,flags:flags};}return RegexLiteral;}();exports.RegexLiteral=RegexLiteral;var RestElement=function(){function RestElement(argument){this.type=syntax_1.Syntax.RestElement;this.argument=argument;}return RestElement;}();exports.RestElement=RestElement;var ReturnStatement=function(){function ReturnStatement(argument){this.type=syntax_1.Syntax.ReturnStatement;this.argument=argument;}return ReturnStatement;}();exports.ReturnStatement=ReturnStatement;var Script=function(){function Script(body){this.type=syntax_1.Syntax.Program;this.body=body;this.sourceType='script';}return Script;}();exports.Script=Script;var SequenceExpression=function(){function SequenceExpression(expressions){this.type=syntax_1.Syntax.SequenceExpression;this.expressions=expressions;}return SequenceExpression;}();exports.SequenceExpression=SequenceExpression;var SpreadElement=function(){function SpreadElement(argument){this.type=syntax_1.Syntax.SpreadElement;this.argument=argument;}return SpreadElement;}();exports.SpreadElement=SpreadElement;var StaticMemberExpression=function(){function StaticMemberExpression(object,property){this.type=syntax_1.Syntax.MemberExpression;this.computed=false;this.object=object;this.property=property;}return StaticMemberExpression;}();exports.StaticMemberExpression=StaticMemberExpression;var Super=function(){function Super(){this.type=syntax_1.Syntax.Super;}return Super;}();exports.Super=Super;var SwitchCase=function(){function SwitchCase(test,consequent){this.type=syntax_1.Syntax.SwitchCase;this.test=test;this.consequent=consequent;}return SwitchCase;}();exports.SwitchCase=SwitchCase;var SwitchStatement=function(){function SwitchStatement(discriminant,cases){this.type=syntax_1.Syntax.SwitchStatement;this.discriminant=discriminant;this.cases=cases;}return SwitchStatement;}();exports.SwitchStatement=SwitchStatement;var TaggedTemplateExpression=function(){function TaggedTemplateExpression(tag,quasi){this.type=syntax_1.Syntax.TaggedTemplateExpression;this.tag=tag;this.quasi=quasi;}return TaggedTemplateExpression;}();exports.TaggedTemplateExpression=TaggedTemplateExpression;var TemplateElement=function(){function TemplateElement(value,tail){this.type=syntax_1.Syntax.TemplateElement;this.value=value;this.tail=tail;}return TemplateElement;}();exports.TemplateElement=TemplateElement;var TemplateLiteral=function(){function TemplateLiteral(quasis,expressions){this.type=syntax_1.Syntax.TemplateLiteral;this.quasis=quasis;this.expressions=expressions;}return TemplateLiteral;}();exports.TemplateLiteral=TemplateLiteral;var ThisExpression=function(){function ThisExpression(){this.type=syntax_1.Syntax.ThisExpression;}return ThisExpression;}();exports.ThisExpression=ThisExpression;var ThrowStatement=function(){function ThrowStatement(argument){this.type=syntax_1.Syntax.ThrowStatement;this.argument=argument;}return ThrowStatement;}();exports.ThrowStatement=ThrowStatement;var TryStatement=function(){function TryStatement(block,handler,finalizer){this.type=syntax_1.Syntax.TryStatement;this.block=block;this.handler=handler;this.finalizer=finalizer;}return TryStatement;}();exports.TryStatement=TryStatement;var UnaryExpression=function(){function UnaryExpression(operator,argument){this.type=syntax_1.Syntax.UnaryExpression;this.operator=operator;this.argument=argument;this.prefix=true;}return UnaryExpression;}();exports.UnaryExpression=UnaryExpression;var UpdateExpression=function(){function UpdateExpression(operator,argument,prefix){this.type=syntax_1.Syntax.UpdateExpression;this.operator=operator;this.argument=argument;this.prefix=prefix;}return UpdateExpression;}();exports.UpdateExpression=UpdateExpression;var VariableDeclaration=function(){function VariableDeclaration(declarations,kind){this.type=syntax_1.Syntax.VariableDeclaration;this.declarations=declarations;this.kind=kind;}return VariableDeclaration;}();exports.VariableDeclaration=VariableDeclaration;var VariableDeclarator=function(){function VariableDeclarator(id,init){this.type=syntax_1.Syntax.VariableDeclarator;this.id=id;this.init=init;}return VariableDeclarator;}();exports.VariableDeclarator=VariableDeclarator;var WhileStatement=function(){function WhileStatement(test,body){this.type=syntax_1.Syntax.WhileStatement;this.test=test;this.body=body;}return WhileStatement;}();exports.WhileStatement=WhileStatement;var WithStatement=function(){function WithStatement(object,body){this.type=syntax_1.Syntax.WithStatement;this.object=object;this.body=body;}return WithStatement;}();exports.WithStatement=WithStatement;var YieldExpression=function(){function YieldExpression(argument,delegate){this.type=syntax_1.Syntax.YieldExpression;this.argument=argument;this.delegate=delegate;}return YieldExpression;}();exports.YieldExpression=YieldExpression;/***/},/* 8 */ /***/function(module,exports,__webpack_require__){"use strict";Object.defineProperty(exports,"__esModule",{value:true});var assert_1=__webpack_require__(9);var error_handler_1=__webpack_require__(10);var messages_1=__webpack_require__(11);var Node=__webpack_require__(7);var scanner_1=__webpack_require__(12);var syntax_1=__webpack_require__(2);var token_1=__webpack_require__(13);var ArrowParameterPlaceHolder='ArrowParameterPlaceHolder';var Parser=function(){function Parser(code,options,delegate){if(options===void 0){options={};}this.config={range:typeof options.range==='boolean'&&options.range,loc:typeof options.loc==='boolean'&&options.loc,source:null,tokens:typeof options.tokens==='boolean'&&options.tokens,comment:typeof options.comment==='boolean'&&options.comment,tolerant:typeof options.tolerant==='boolean'&&options.tolerant};if(this.config.loc&&options.source&&options.source!==null){this.config.source=String(options.source);}this.delegate=delegate;this.errorHandler=new error_handler_1.ErrorHandler();this.errorHandler.tolerant=this.config.tolerant;this.scanner=new scanner_1.Scanner(code,this.errorHandler);this.scanner.trackComment=this.config.comment;this.operatorPrecedence={')':0,';':0,',':0,'=':0,']':0,'||':1,'&&':2,'|':3,'^':4,'&':5,'==':6,'!=':6,'===':6,'!==':6,'<':7,'>':7,'<=':7,'>=':7,'<<':8,'>>':8,'>>>':8,'+':9,'-':9,'*':11,'/':11,'%':11};this.lookahead={type:2/* EOF */,value:'',lineNumber:this.scanner.lineNumber,lineStart:0,start:0,end:0};this.hasLineTerminator=false;this.context={isModule:false,await:false,allowIn:true,allowStrictDirective:true,allowYield:true,firstCoverInitializedNameError:null,isAssignmentTarget:false,isBindingElement:false,inFunctionBody:false,inIteration:false,inSwitch:false,labelSet:{},strict:false};this.tokens=[];this.startMarker={index:0,line:this.scanner.lineNumber,column:0};this.lastMarker={index:0,line:this.scanner.lineNumber,column:0};this.nextToken();this.lastMarker={index:this.scanner.index,line:this.scanner.lineNumber,column:this.scanner.index-this.scanner.lineStart};}Parser.prototype.throwError=function(messageFormat){var values=[];for(var _i=1;_i<arguments.length;_i++){values[_i-1]=arguments[_i];}var args=Array.prototype.slice.call(arguments,1);var msg=messageFormat.replace(/%(\d)/g,function(whole,idx){assert_1.assert(idx<args.length,'Message reference must be in range');return args[idx];});var index=this.lastMarker.index;var line=this.lastMarker.line;var column=this.lastMarker.column+1;throw this.errorHandler.createError(index,line,column,msg);};Parser.prototype.tolerateError=function(messageFormat){var values=[];for(var _i=1;_i<arguments.length;_i++){values[_i-1]=arguments[_i];}var args=Array.prototype.slice.call(arguments,1);var msg=messageFormat.replace(/%(\d)/g,function(whole,idx){assert_1.assert(idx<args.length,'Message reference must be in range');return args[idx];});var index=this.lastMarker.index;var line=this.scanner.lineNumber;var column=this.lastMarker.column+1;this.errorHandler.tolerateError(index,line,column,msg);};// Throw an exception because of the token.
Parser.prototype.unexpectedTokenError=function(token,message){var msg=message||messages_1.Messages.UnexpectedToken;var value;if(token){if(!message){msg=token.type===2/* EOF */?messages_1.Messages.UnexpectedEOS:token.type===3/* Identifier */?messages_1.Messages.UnexpectedIdentifier:token.type===6/* NumericLiteral */?messages_1.Messages.UnexpectedNumber:token.type===8/* StringLiteral */?messages_1.Messages.UnexpectedString:token.type===10/* Template */?messages_1.Messages.UnexpectedTemplate:messages_1.Messages.UnexpectedToken;if(token.type===4/* Keyword */){if(this.scanner.isFutureReservedWord(token.value)){msg=messages_1.Messages.UnexpectedReserved;}else if(this.context.strict&&this.scanner.isStrictModeReservedWord(token.value)){msg=messages_1.Messages.StrictReservedWord;}}}value=token.value;}else{value='ILLEGAL';}msg=msg.replace('%0',value);if(token&&typeof token.lineNumber==='number'){var index=token.start;var line=token.lineNumber;var lastMarkerLineStart=this.lastMarker.index-this.lastMarker.column;var column=token.start-lastMarkerLineStart+1;return this.errorHandler.createError(index,line,column,msg);}else{var index=this.lastMarker.index;var line=this.lastMarker.line;var column=this.lastMarker.column+1;return this.errorHandler.createError(index,line,column,msg);}};Parser.prototype.throwUnexpectedToken=function(token,message){throw this.unexpectedTokenError(token,message);};Parser.prototype.tolerateUnexpectedToken=function(token,message){this.errorHandler.tolerate(this.unexpectedTokenError(token,message));};Parser.prototype.collectComments=function(){if(!this.config.comment){this.scanner.scanComments();}else{var comments=this.scanner.scanComments();if(comments.length>0&&this.delegate){for(var i=0;i<comments.length;++i){var e=comments[i];var node=void 0;node={type:e.multiLine?'BlockComment':'LineComment',value:this.scanner.source.slice(e.slice[0],e.slice[1])};if(this.config.range){node.range=e.range;}if(this.config.loc){node.loc=e.loc;}var metadata={start:{line:e.loc.start.line,column:e.loc.start.column,offset:e.range[0]},end:{line:e.loc.end.line,column:e.loc.end.column,offset:e.range[1]}};this.delegate(node,metadata);}}}};// From internal representation to an external structure
Parser.prototype.getTokenRaw=function(token){return this.scanner.source.slice(token.start,token.end);};Parser.prototype.convertToken=function(token){var t={type:token_1.TokenName[token.type],value:this.getTokenRaw(token)};if(this.config.range){t.range=[token.start,token.end];}if(this.config.loc){t.loc={start:{line:this.startMarker.line,column:this.startMarker.column},end:{line:this.scanner.lineNumber,column:this.scanner.index-this.scanner.lineStart}};}if(token.type===9/* RegularExpression */){var pattern=token.pattern;var flags=token.flags;t.regex={pattern:pattern,flags:flags};}return t;};Parser.prototype.nextToken=function(){var token=this.lookahead;this.lastMarker.index=this.scanner.index;this.lastMarker.line=this.scanner.lineNumber;this.lastMarker.column=this.scanner.index-this.scanner.lineStart;this.collectComments();if(this.scanner.index!==this.startMarker.index){this.startMarker.index=this.scanner.index;this.startMarker.line=this.scanner.lineNumber;this.startMarker.column=this.scanner.index-this.scanner.lineStart;}var next=this.scanner.lex();this.hasLineTerminator=token.lineNumber!==next.lineNumber;if(next&&this.context.strict&&next.type===3/* Identifier */){if(this.scanner.isStrictModeReservedWord(next.value)){next.type=4/* Keyword */;}}this.lookahead=next;if(this.config.tokens&&next.type!==2/* EOF */){this.tokens.push(this.convertToken(next));}return token;};Parser.prototype.nextRegexToken=function(){this.collectComments();var token=this.scanner.scanRegExp();if(this.config.tokens){// Pop the previous token, '/' or '/='
// This is added from the lookahead token.
this.tokens.pop();this.tokens.push(this.convertToken(token));}// Prime the next lookahead.
this.lookahead=token;this.nextToken();return token;};Parser.prototype.createNode=function(){return{index:this.startMarker.index,line:this.startMarker.line,column:this.startMarker.column};};Parser.prototype.startNode=function(token,lastLineStart){if(lastLineStart===void 0){lastLineStart=0;}var column=token.start-token.lineStart;var line=token.lineNumber;if(column<0){column+=lastLineStart;line--;}return{index:token.start,line:line,column:column};};Parser.prototype.finalize=function(marker,node){if(this.config.range){node.range=[marker.index,this.lastMarker.index];}if(this.config.loc){node.loc={start:{line:marker.line,column:marker.column},end:{line:this.lastMarker.line,column:this.lastMarker.column}};if(this.config.source){node.loc.source=this.config.source;}}if(this.delegate){var metadata={start:{line:marker.line,column:marker.column,offset:marker.index},end:{line:this.lastMarker.line,column:this.lastMarker.column,offset:this.lastMarker.index}};this.delegate(node,metadata);}return node;};// Expect the next token to match the specified punctuator.
// If not, an exception will be thrown.
Parser.prototype.expect=function(value){var token=this.nextToken();if(token.type!==7/* Punctuator */||token.value!==value){this.throwUnexpectedToken(token);}};// Quietly expect a comma when in tolerant mode, otherwise delegates to expect().
Parser.prototype.expectCommaSeparator=function(){if(this.config.tolerant){var token=this.lookahead;if(token.type===7/* Punctuator */&&token.value===','){this.nextToken();}else if(token.type===7/* Punctuator */&&token.value===';'){this.nextToken();this.tolerateUnexpectedToken(token);}else{this.tolerateUnexpectedToken(token,messages_1.Messages.UnexpectedToken);}}else{this.expect(',');}};// Expect the next token to match the specified keyword.
// If not, an exception will be thrown.
Parser.prototype.expectKeyword=function(keyword){var token=this.nextToken();if(token.type!==4/* Keyword */||token.value!==keyword){this.throwUnexpectedToken(token);}};// Return true if the next token matches the specified punctuator.
Parser.prototype.match=function(value){return this.lookahead.type===7/* Punctuator */&&this.lookahead.value===value;};// Return true if the next token matches the specified keyword
Parser.prototype.matchKeyword=function(keyword){return this.lookahead.type===4/* Keyword */&&this.lookahead.value===keyword;};// Return true if the next token matches the specified contextual keyword
// (where an identifier is sometimes a keyword depending on the context)
Parser.prototype.matchContextualKeyword=function(keyword){return this.lookahead.type===3/* Identifier */&&this.lookahead.value===keyword;};// Return true if the next token is an assignment operator
Parser.prototype.matchAssign=function(){if(this.lookahead.type!==7/* Punctuator */){return false;}var op=this.lookahead.value;return op==='='||op==='*='||op==='**='||op==='/='||op==='%='||op==='+='||op==='-='||op==='<<='||op==='>>='||op==='>>>='||op==='&='||op==='^='||op==='|=';};// Cover grammar support.
//
// When an assignment expression position starts with an left parenthesis, the determination of the type
// of the syntax is to be deferred arbitrarily long until the end of the parentheses pair (plus a lookahead)
// or the first comma. This situation also defers the determination of all the expressions nested in the pair.
//
// There are three productions that can be parsed in a parentheses pair that needs to be determined
// after the outermost pair is closed. They are:
//
//   1. AssignmentExpression
//   2. BindingElements
//   3. AssignmentTargets
//
// In order to avoid exponential backtracking, we use two flags to denote if the production can be
// binding element or assignment target.
//
// The three productions have the relationship:
//
//   BindingElements ⊆ AssignmentTargets ⊆ AssignmentExpression
//
// with a single exception that CoverInitializedName when used directly in an Expression, generates
// an early error. Therefore, we need the third state, firstCoverInitializedNameError, to track the
// first usage of CoverInitializedName and report it when we reached the end of the parentheses pair.
//
// isolateCoverGrammar function runs the given parser function with a new cover grammar context, and it does not
// effect the current flags. This means the production the parser parses is only used as an expression. Therefore
// the CoverInitializedName check is conducted.
//
// inheritCoverGrammar function runs the given parse function with a new cover grammar context, and it propagates
// the flags outside of the parser. This means the production the parser parses is used as a part of a potential
// pattern. The CoverInitializedName check is deferred.
Parser.prototype.isolateCoverGrammar=function(parseFunction){var previousIsBindingElement=this.context.isBindingElement;var previousIsAssignmentTarget=this.context.isAssignmentTarget;var previousFirstCoverInitializedNameError=this.context.firstCoverInitializedNameError;this.context.isBindingElement=true;this.context.isAssignmentTarget=true;this.context.firstCoverInitializedNameError=null;var result=parseFunction.call(this);if(this.context.firstCoverInitializedNameError!==null){this.throwUnexpectedToken(this.context.firstCoverInitializedNameError);}this.context.isBindingElement=previousIsBindingElement;this.context.isAssignmentTarget=previousIsAssignmentTarget;this.context.firstCoverInitializedNameError=previousFirstCoverInitializedNameError;return result;};Parser.prototype.inheritCoverGrammar=function(parseFunction){var previousIsBindingElement=this.context.isBindingElement;var previousIsAssignmentTarget=this.context.isAssignmentTarget;var previousFirstCoverInitializedNameError=this.context.firstCoverInitializedNameError;this.context.isBindingElement=true;this.context.isAssignmentTarget=true;this.context.firstCoverInitializedNameError=null;var result=parseFunction.call(this);this.context.isBindingElement=this.context.isBindingElement&&previousIsBindingElement;this.context.isAssignmentTarget=this.context.isAssignmentTarget&&previousIsAssignmentTarget;this.context.firstCoverInitializedNameError=previousFirstCoverInitializedNameError||this.context.firstCoverInitializedNameError;return result;};Parser.prototype.consumeSemicolon=function(){if(this.match(';')){this.nextToken();}else if(!this.hasLineTerminator){if(this.lookahead.type!==2/* EOF */&&!this.match('}')){this.throwUnexpectedToken(this.lookahead);}this.lastMarker.index=this.startMarker.index;this.lastMarker.line=this.startMarker.line;this.lastMarker.column=this.startMarker.column;}};// https://tc39.github.io/ecma262/#sec-primary-expression
Parser.prototype.parsePrimaryExpression=function(){var node=this.createNode();var expr;var token,raw;switch(this.lookahead.type){case 3/* Identifier */:if((this.context.isModule||this.context.await)&&this.lookahead.value==='await'){this.tolerateUnexpectedToken(this.lookahead);}expr=this.matchAsyncFunction()?this.parseFunctionExpression():this.finalize(node,new Node.Identifier(this.nextToken().value));break;case 6/* NumericLiteral */:case 8/* StringLiteral */:if(this.context.strict&&this.lookahead.octal){this.tolerateUnexpectedToken(this.lookahead,messages_1.Messages.StrictOctalLiteral);}this.context.isAssignmentTarget=false;this.context.isBindingElement=false;token=this.nextToken();raw=this.getTokenRaw(token);expr=this.finalize(node,new Node.Literal(token.value,raw));break;case 1/* BooleanLiteral */:this.context.isAssignmentTarget=false;this.context.isBindingElement=false;token=this.nextToken();raw=this.getTokenRaw(token);expr=this.finalize(node,new Node.Literal(token.value==='true',raw));break;case 5/* NullLiteral */:this.context.isAssignmentTarget=false;this.context.isBindingElement=false;token=this.nextToken();raw=this.getTokenRaw(token);expr=this.finalize(node,new Node.Literal(null,raw));break;case 10/* Template */:expr=this.parseTemplateLiteral();break;case 7/* Punctuator */:switch(this.lookahead.value){case'(':this.context.isBindingElement=false;expr=this.inheritCoverGrammar(this.parseGroupExpression);break;case'[':expr=this.inheritCoverGrammar(this.parseArrayInitializer);break;case'{':expr=this.inheritCoverGrammar(this.parseObjectInitializer);break;case'/':case'/=':this.context.isAssignmentTarget=false;this.context.isBindingElement=false;this.scanner.index=this.startMarker.index;token=this.nextRegexToken();raw=this.getTokenRaw(token);expr=this.finalize(node,new Node.RegexLiteral(token.regex,raw,token.pattern,token.flags));break;default:expr=this.throwUnexpectedToken(this.nextToken());}break;case 4/* Keyword */:if(!this.context.strict&&this.context.allowYield&&this.matchKeyword('yield')){expr=this.parseIdentifierName();}else if(!this.context.strict&&this.matchKeyword('let')){expr=this.finalize(node,new Node.Identifier(this.nextToken().value));}else{this.context.isAssignmentTarget=false;this.context.isBindingElement=false;if(this.matchKeyword('function')){expr=this.parseFunctionExpression();}else if(this.matchKeyword('this')){this.nextToken();expr=this.finalize(node,new Node.ThisExpression());}else if(this.matchKeyword('class')){expr=this.parseClassExpression();}else{expr=this.throwUnexpectedToken(this.nextToken());}}break;default:expr=this.throwUnexpectedToken(this.nextToken());}return expr;};// https://tc39.github.io/ecma262/#sec-array-initializer
Parser.prototype.parseSpreadElement=function(){var node=this.createNode();this.expect('...');var arg=this.inheritCoverGrammar(this.parseAssignmentExpression);return this.finalize(node,new Node.SpreadElement(arg));};Parser.prototype.parseArrayInitializer=function(){var node=this.createNode();var elements=[];this.expect('[');while(!this.match(']')){if(this.match(',')){this.nextToken();elements.push(null);}else if(this.match('...')){var element=this.parseSpreadElement();if(!this.match(']')){this.context.isAssignmentTarget=false;this.context.isBindingElement=false;this.expect(',');}elements.push(element);}else{elements.push(this.inheritCoverGrammar(this.parseAssignmentExpression));if(!this.match(']')){this.expect(',');}}}this.expect(']');return this.finalize(node,new Node.ArrayExpression(elements));};// https://tc39.github.io/ecma262/#sec-object-initializer
Parser.prototype.parsePropertyMethod=function(params){this.context.isAssignmentTarget=false;this.context.isBindingElement=false;var previousStrict=this.context.strict;var previousAllowStrictDirective=this.context.allowStrictDirective;this.context.allowStrictDirective=params.simple;var body=this.isolateCoverGrammar(this.parseFunctionSourceElements);if(this.context.strict&&params.firstRestricted){this.tolerateUnexpectedToken(params.firstRestricted,params.message);}if(this.context.strict&&params.stricted){this.tolerateUnexpectedToken(params.stricted,params.message);}this.context.strict=previousStrict;this.context.allowStrictDirective=previousAllowStrictDirective;return body;};Parser.prototype.parsePropertyMethodFunction=function(){var isGenerator=false;var node=this.createNode();var previousAllowYield=this.context.allowYield;this.context.allowYield=true;var params=this.parseFormalParameters();var method=this.parsePropertyMethod(params);this.context.allowYield=previousAllowYield;return this.finalize(node,new Node.FunctionExpression(null,params.params,method,isGenerator));};Parser.prototype.parsePropertyMethodAsyncFunction=function(){var node=this.createNode();var previousAllowYield=this.context.allowYield;var previousAwait=this.context.await;this.context.allowYield=false;this.context.await=true;var params=this.parseFormalParameters();var method=this.parsePropertyMethod(params);this.context.allowYield=previousAllowYield;this.context.await=previousAwait;return this.finalize(node,new Node.AsyncFunctionExpression(null,params.params,method));};Parser.prototype.parseObjectPropertyKey=function(){var node=this.createNode();var token=this.nextToken();var key;switch(token.type){case 8/* StringLiteral */:case 6/* NumericLiteral */:if(this.context.strict&&token.octal){this.tolerateUnexpectedToken(token,messages_1.Messages.StrictOctalLiteral);}var raw=this.getTokenRaw(token);key=this.finalize(node,new Node.Literal(token.value,raw));break;case 3/* Identifier */:case 1/* BooleanLiteral */:case 5/* NullLiteral */:case 4/* Keyword */:key=this.finalize(node,new Node.Identifier(token.value));break;case 7/* Punctuator */:if(token.value==='['){key=this.isolateCoverGrammar(this.parseAssignmentExpression);this.expect(']');}else{key=this.throwUnexpectedToken(token);}break;default:key=this.throwUnexpectedToken(token);}return key;};Parser.prototype.isPropertyKey=function(key,value){return key.type===syntax_1.Syntax.Identifier&&key.name===value||key.type===syntax_1.Syntax.Literal&&key.value===value;};Parser.prototype.parseObjectProperty=function(hasProto){var node=this.createNode();var token=this.lookahead;var kind;var key=null;var value=null;var computed=false;var method=false;var shorthand=false;var isAsync=false;if(token.type===3/* Identifier */){var id=token.value;this.nextToken();computed=this.match('[');isAsync=!this.hasLineTerminator&&id==='async'&&!this.match(':')&&!this.match('(')&&!this.match('*')&&!this.match(',');key=isAsync?this.parseObjectPropertyKey():this.finalize(node,new Node.Identifier(id));}else if(this.match('*')){this.nextToken();}else{computed=this.match('[');key=this.parseObjectPropertyKey();}var lookaheadPropertyKey=this.qualifiedPropertyName(this.lookahead);if(token.type===3/* Identifier */&&!isAsync&&token.value==='get'&&lookaheadPropertyKey){kind='get';computed=this.match('[');key=this.parseObjectPropertyKey();this.context.allowYield=false;value=this.parseGetterMethod();}else if(token.type===3/* Identifier */&&!isAsync&&token.value==='set'&&lookaheadPropertyKey){kind='set';computed=this.match('[');key=this.parseObjectPropertyKey();value=this.parseSetterMethod();}else if(token.type===7/* Punctuator */&&token.value==='*'&&lookaheadPropertyKey){kind='init';computed=this.match('[');key=this.parseObjectPropertyKey();value=this.parseGeneratorMethod();method=true;}else{if(!key){this.throwUnexpectedToken(this.lookahead);}kind='init';if(this.match(':')&&!isAsync){if(!computed&&this.isPropertyKey(key,'__proto__')){if(hasProto.value){this.tolerateError(messages_1.Messages.DuplicateProtoProperty);}hasProto.value=true;}this.nextToken();value=this.inheritCoverGrammar(this.parseAssignmentExpression);}else if(this.match('(')){value=isAsync?this.parsePropertyMethodAsyncFunction():this.parsePropertyMethodFunction();method=true;}else if(token.type===3/* Identifier */){var id=this.finalize(node,new Node.Identifier(token.value));if(this.match('=')){this.context.firstCoverInitializedNameError=this.lookahead;this.nextToken();shorthand=true;var init=this.isolateCoverGrammar(this.parseAssignmentExpression);value=this.finalize(node,new Node.AssignmentPattern(id,init));}else{shorthand=true;value=id;}}else{this.throwUnexpectedToken(this.nextToken());}}return this.finalize(node,new Node.Property(kind,key,computed,value,method,shorthand));};Parser.prototype.parseObjectInitializer=function(){var node=this.createNode();this.expect('{');var properties=[];var hasProto={value:false};while(!this.match('}')){properties.push(this.parseObjectProperty(hasProto));if(!this.match('}')){this.expectCommaSeparator();}}this.expect('}');return this.finalize(node,new Node.ObjectExpression(properties));};// https://tc39.github.io/ecma262/#sec-template-literals
Parser.prototype.parseTemplateHead=function(){assert_1.assert(this.lookahead.head,'Template literal must start with a template head');var node=this.createNode();var token=this.nextToken();var raw=token.value;var cooked=token.cooked;return this.finalize(node,new Node.TemplateElement({raw:raw,cooked:cooked},token.tail));};Parser.prototype.parseTemplateElement=function(){if(this.lookahead.type!==10/* Template */){this.throwUnexpectedToken();}var node=this.createNode();var token=this.nextToken();var raw=token.value;var cooked=token.cooked;return this.finalize(node,new Node.TemplateElement({raw:raw,cooked:cooked},token.tail));};Parser.prototype.parseTemplateLiteral=function(){var node=this.createNode();var expressions=[];var quasis=[];var quasi=this.parseTemplateHead();quasis.push(quasi);while(!quasi.tail){expressions.push(this.parseExpression());quasi=this.parseTemplateElement();quasis.push(quasi);}return this.finalize(node,new Node.TemplateLiteral(quasis,expressions));};// https://tc39.github.io/ecma262/#sec-grouping-operator
Parser.prototype.reinterpretExpressionAsPattern=function(expr){switch(expr.type){case syntax_1.Syntax.Identifier:case syntax_1.Syntax.MemberExpression:case syntax_1.Syntax.RestElement:case syntax_1.Syntax.AssignmentPattern:break;case syntax_1.Syntax.SpreadElement:expr.type=syntax_1.Syntax.RestElement;this.reinterpretExpressionAsPattern(expr.argument);break;case syntax_1.Syntax.ArrayExpression:expr.type=syntax_1.Syntax.ArrayPattern;for(var i=0;i<expr.elements.length;i++){if(expr.elements[i]!==null){this.reinterpretExpressionAsPattern(expr.elements[i]);}}break;case syntax_1.Syntax.ObjectExpression:expr.type=syntax_1.Syntax.ObjectPattern;for(var i=0;i<expr.properties.length;i++){this.reinterpretExpressionAsPattern(expr.properties[i].value);}break;case syntax_1.Syntax.AssignmentExpression:expr.type=syntax_1.Syntax.AssignmentPattern;delete expr.operator;this.reinterpretExpressionAsPattern(expr.left);break;default:// Allow other node type for tolerant parsing.
break;}};Parser.prototype.parseGroupExpression=function(){var expr;this.expect('(');if(this.match(')')){this.nextToken();if(!this.match('=>')){this.expect('=>');}expr={type:ArrowParameterPlaceHolder,params:[],async:false};}else{var startToken=this.lookahead;var params=[];if(this.match('...')){expr=this.parseRestElement(params);this.expect(')');if(!this.match('=>')){this.expect('=>');}expr={type:ArrowParameterPlaceHolder,params:[expr],async:false};}else{var arrow=false;this.context.isBindingElement=true;expr=this.inheritCoverGrammar(this.parseAssignmentExpression);if(this.match(',')){var expressions=[];this.context.isAssignmentTarget=false;expressions.push(expr);while(this.lookahead.type!==2/* EOF */){if(!this.match(',')){break;}this.nextToken();if(this.match(')')){this.nextToken();for(var i=0;i<expressions.length;i++){this.reinterpretExpressionAsPattern(expressions[i]);}arrow=true;expr={type:ArrowParameterPlaceHolder,params:expressions,async:false};}else if(this.match('...')){if(!this.context.isBindingElement){this.throwUnexpectedToken(this.lookahead);}expressions.push(this.parseRestElement(params));this.expect(')');if(!this.match('=>')){this.expect('=>');}this.context.isBindingElement=false;for(var i=0;i<expressions.length;i++){this.reinterpretExpressionAsPattern(expressions[i]);}arrow=true;expr={type:ArrowParameterPlaceHolder,params:expressions,async:false};}else{expressions.push(this.inheritCoverGrammar(this.parseAssignmentExpression));}if(arrow){break;}}if(!arrow){expr=this.finalize(this.startNode(startToken),new Node.SequenceExpression(expressions));}}if(!arrow){this.expect(')');if(this.match('=>')){if(expr.type===syntax_1.Syntax.Identifier&&expr.name==='yield'){arrow=true;expr={type:ArrowParameterPlaceHolder,params:[expr],async:false};}if(!arrow){if(!this.context.isBindingElement){this.throwUnexpectedToken(this.lookahead);}if(expr.type===syntax_1.Syntax.SequenceExpression){for(var i=0;i<expr.expressions.length;i++){this.reinterpretExpressionAsPattern(expr.expressions[i]);}}else{this.reinterpretExpressionAsPattern(expr);}var parameters=expr.type===syntax_1.Syntax.SequenceExpression?expr.expressions:[expr];expr={type:ArrowParameterPlaceHolder,params:parameters,async:false};}}this.context.isBindingElement=false;}}}return expr;};// https://tc39.github.io/ecma262/#sec-left-hand-side-expressions
Parser.prototype.parseArguments=function(){this.expect('(');var args=[];if(!this.match(')')){while(true){var expr=this.match('...')?this.parseSpreadElement():this.isolateCoverGrammar(this.parseAssignmentExpression);args.push(expr);if(this.match(')')){break;}this.expectCommaSeparator();if(this.match(')')){break;}}}this.expect(')');return args;};Parser.prototype.isIdentifierName=function(token){return token.type===3/* Identifier */||token.type===4/* Keyword */||token.type===1/* BooleanLiteral */||token.type===5/* NullLiteral */;};Parser.prototype.parseIdentifierName=function(){var node=this.createNode();var token=this.nextToken();if(!this.isIdentifierName(token)){this.throwUnexpectedToken(token);}return this.finalize(node,new Node.Identifier(token.value));};Parser.prototype.parseNewExpression=function(){var node=this.createNode();var id=this.parseIdentifierName();assert_1.assert(id.name==='new','New expression must start with `new`');var expr;if(this.match('.')){this.nextToken();if(this.lookahead.type===3/* Identifier */&&this.context.inFunctionBody&&this.lookahead.value==='target'){var property=this.parseIdentifierName();expr=new Node.MetaProperty(id,property);}else{this.throwUnexpectedToken(this.lookahead);}}else{var callee=this.isolateCoverGrammar(this.parseLeftHandSideExpression);var args=this.match('(')?this.parseArguments():[];expr=new Node.NewExpression(callee,args);this.context.isAssignmentTarget=false;this.context.isBindingElement=false;}return this.finalize(node,expr);};Parser.prototype.parseAsyncArgument=function(){var arg=this.parseAssignmentExpression();this.context.firstCoverInitializedNameError=null;return arg;};Parser.prototype.parseAsyncArguments=function(){this.expect('(');var args=[];if(!this.match(')')){while(true){var expr=this.match('...')?this.parseSpreadElement():this.isolateCoverGrammar(this.parseAsyncArgument);args.push(expr);if(this.match(')')){break;}this.expectCommaSeparator();if(this.match(')')){break;}}}this.expect(')');return args;};Parser.prototype.parseLeftHandSideExpressionAllowCall=function(){var startToken=this.lookahead;var maybeAsync=this.matchContextualKeyword('async');var previousAllowIn=this.context.allowIn;this.context.allowIn=true;var expr;if(this.matchKeyword('super')&&this.context.inFunctionBody){expr=this.createNode();this.nextToken();expr=this.finalize(expr,new Node.Super());if(!this.match('(')&&!this.match('.')&&!this.match('[')){this.throwUnexpectedToken(this.lookahead);}}else{expr=this.inheritCoverGrammar(this.matchKeyword('new')?this.parseNewExpression:this.parsePrimaryExpression);}while(true){if(this.match('.')){this.context.isBindingElement=false;this.context.isAssignmentTarget=true;this.expect('.');var property=this.parseIdentifierName();expr=this.finalize(this.startNode(startToken),new Node.StaticMemberExpression(expr,property));}else if(this.match('(')){var asyncArrow=maybeAsync&&startToken.lineNumber===this.lookahead.lineNumber;this.context.isBindingElement=false;this.context.isAssignmentTarget=false;var args=asyncArrow?this.parseAsyncArguments():this.parseArguments();expr=this.finalize(this.startNode(startToken),new Node.CallExpression(expr,args));if(asyncArrow&&this.match('=>')){for(var i=0;i<args.length;++i){this.reinterpretExpressionAsPattern(args[i]);}expr={type:ArrowParameterPlaceHolder,params:args,async:true};}}else if(this.match('[')){this.context.isBindingElement=false;this.context.isAssignmentTarget=true;this.expect('[');var property=this.isolateCoverGrammar(this.parseExpression);this.expect(']');expr=this.finalize(this.startNode(startToken),new Node.ComputedMemberExpression(expr,property));}else if(this.lookahead.type===10/* Template */&&this.lookahead.head){var quasi=this.parseTemplateLiteral();expr=this.finalize(this.startNode(startToken),new Node.TaggedTemplateExpression(expr,quasi));}else{break;}}this.context.allowIn=previousAllowIn;return expr;};Parser.prototype.parseSuper=function(){var node=this.createNode();this.expectKeyword('super');if(!this.match('[')&&!this.match('.')){this.throwUnexpectedToken(this.lookahead);}return this.finalize(node,new Node.Super());};Parser.prototype.parseLeftHandSideExpression=function(){assert_1.assert(this.context.allowIn,'callee of new expression always allow in keyword.');var node=this.startNode(this.lookahead);var expr=this.matchKeyword('super')&&this.context.inFunctionBody?this.parseSuper():this.inheritCoverGrammar(this.matchKeyword('new')?this.parseNewExpression:this.parsePrimaryExpression);while(true){if(this.match('[')){this.context.isBindingElement=false;this.context.isAssignmentTarget=true;this.expect('[');var property=this.isolateCoverGrammar(this.parseExpression);this.expect(']');expr=this.finalize(node,new Node.ComputedMemberExpression(expr,property));}else if(this.match('.')){this.context.isBindingElement=false;this.context.isAssignmentTarget=true;this.expect('.');var property=this.parseIdentifierName();expr=this.finalize(node,new Node.StaticMemberExpression(expr,property));}else if(this.lookahead.type===10/* Template */&&this.lookahead.head){var quasi=this.parseTemplateLiteral();expr=this.finalize(node,new Node.TaggedTemplateExpression(expr,quasi));}else{break;}}return expr;};// https://tc39.github.io/ecma262/#sec-update-expressions
Parser.prototype.parseUpdateExpression=function(){var expr;var startToken=this.lookahead;if(this.match('++')||this.match('--')){var node=this.startNode(startToken);var token=this.nextToken();expr=this.inheritCoverGrammar(this.parseUnaryExpression);if(this.context.strict&&expr.type===syntax_1.Syntax.Identifier&&this.scanner.isRestrictedWord(expr.name)){this.tolerateError(messages_1.Messages.StrictLHSPrefix);}if(!this.context.isAssignmentTarget){this.tolerateError(messages_1.Messages.InvalidLHSInAssignment);}var prefix=true;expr=this.finalize(node,new Node.UpdateExpression(token.value,expr,prefix));this.context.isAssignmentTarget=false;this.context.isBindingElement=false;}else{expr=this.inheritCoverGrammar(this.parseLeftHandSideExpressionAllowCall);if(!this.hasLineTerminator&&this.lookahead.type===7/* Punctuator */){if(this.match('++')||this.match('--')){if(this.context.strict&&expr.type===syntax_1.Syntax.Identifier&&this.scanner.isRestrictedWord(expr.name)){this.tolerateError(messages_1.Messages.StrictLHSPostfix);}if(!this.context.isAssignmentTarget){this.tolerateError(messages_1.Messages.InvalidLHSInAssignment);}this.context.isAssignmentTarget=false;this.context.isBindingElement=false;var operator=this.nextToken().value;var prefix=false;expr=this.finalize(this.startNode(startToken),new Node.UpdateExpression(operator,expr,prefix));}}}return expr;};// https://tc39.github.io/ecma262/#sec-unary-operators
Parser.prototype.parseAwaitExpression=function(){var node=this.createNode();this.nextToken();var argument=this.parseUnaryExpression();return this.finalize(node,new Node.AwaitExpression(argument));};Parser.prototype.parseUnaryExpression=function(){var expr;if(this.match('+')||this.match('-')||this.match('~')||this.match('!')||this.matchKeyword('delete')||this.matchKeyword('void')||this.matchKeyword('typeof')){var node=this.startNode(this.lookahead);var token=this.nextToken();expr=this.inheritCoverGrammar(this.parseUnaryExpression);expr=this.finalize(node,new Node.UnaryExpression(token.value,expr));if(this.context.strict&&expr.operator==='delete'&&expr.argument.type===syntax_1.Syntax.Identifier){this.tolerateError(messages_1.Messages.StrictDelete);}this.context.isAssignmentTarget=false;this.context.isBindingElement=false;}else if(this.context.await&&this.matchContextualKeyword('await')){expr=this.parseAwaitExpression();}else{expr=this.parseUpdateExpression();}return expr;};Parser.prototype.parseExponentiationExpression=function(){var startToken=this.lookahead;var expr=this.inheritCoverGrammar(this.parseUnaryExpression);if(expr.type!==syntax_1.Syntax.UnaryExpression&&this.match('**')){this.nextToken();this.context.isAssignmentTarget=false;this.context.isBindingElement=false;var left=expr;var right=this.isolateCoverGrammar(this.parseExponentiationExpression);expr=this.finalize(this.startNode(startToken),new Node.BinaryExpression('**',left,right));}return expr;};// https://tc39.github.io/ecma262/#sec-exp-operator
// https://tc39.github.io/ecma262/#sec-multiplicative-operators
// https://tc39.github.io/ecma262/#sec-additive-operators
// https://tc39.github.io/ecma262/#sec-bitwise-shift-operators
// https://tc39.github.io/ecma262/#sec-relational-operators
// https://tc39.github.io/ecma262/#sec-equality-operators
// https://tc39.github.io/ecma262/#sec-binary-bitwise-operators
// https://tc39.github.io/ecma262/#sec-binary-logical-operators
Parser.prototype.binaryPrecedence=function(token){var op=token.value;var precedence;if(token.type===7/* Punctuator */){precedence=this.operatorPrecedence[op]||0;}else if(token.type===4/* Keyword */){precedence=op==='instanceof'||this.context.allowIn&&op==='in'?7:0;}else{precedence=0;}return precedence;};Parser.prototype.parseBinaryExpression=function(){var startToken=this.lookahead;var expr=this.inheritCoverGrammar(this.parseExponentiationExpression);var token=this.lookahead;var prec=this.binaryPrecedence(token);if(prec>0){this.nextToken();this.context.isAssignmentTarget=false;this.context.isBindingElement=false;var markers=[startToken,this.lookahead];var left=expr;var right=this.isolateCoverGrammar(this.parseExponentiationExpression);var stack=[left,token.value,right];var precedences=[prec];while(true){prec=this.binaryPrecedence(this.lookahead);if(prec<=0){break;}// Reduce: make a binary expression from the three topmost entries.
while(stack.length>2&&prec<=precedences[precedences.length-1]){right=stack.pop();var operator=stack.pop();precedences.pop();left=stack.pop();markers.pop();var node=this.startNode(markers[markers.length-1]);stack.push(this.finalize(node,new Node.BinaryExpression(operator,left,right)));}// Shift.
stack.push(this.nextToken().value);precedences.push(prec);markers.push(this.lookahead);stack.push(this.isolateCoverGrammar(this.parseExponentiationExpression));}// Final reduce to clean-up the stack.
var i=stack.length-1;expr=stack[i];var lastMarker=markers.pop();while(i>1){var marker=markers.pop();var lastLineStart=lastMarker&&lastMarker.lineStart;var node=this.startNode(marker,lastLineStart);var operator=stack[i-1];expr=this.finalize(node,new Node.BinaryExpression(operator,stack[i-2],expr));i-=2;lastMarker=marker;}}return expr;};// https://tc39.github.io/ecma262/#sec-conditional-operator
Parser.prototype.parseConditionalExpression=function(){var startToken=this.lookahead;var expr=this.inheritCoverGrammar(this.parseBinaryExpression);if(this.match('?')){this.nextToken();var previousAllowIn=this.context.allowIn;this.context.allowIn=true;var consequent=this.isolateCoverGrammar(this.parseAssignmentExpression);this.context.allowIn=previousAllowIn;this.expect(':');var alternate=this.isolateCoverGrammar(this.parseAssignmentExpression);expr=this.finalize(this.startNode(startToken),new Node.ConditionalExpression(expr,consequent,alternate));this.context.isAssignmentTarget=false;this.context.isBindingElement=false;}return expr;};// https://tc39.github.io/ecma262/#sec-assignment-operators
Parser.prototype.checkPatternParam=function(options,param){switch(param.type){case syntax_1.Syntax.Identifier:this.validateParam(options,param,param.name);break;case syntax_1.Syntax.RestElement:this.checkPatternParam(options,param.argument);break;case syntax_1.Syntax.AssignmentPattern:this.checkPatternParam(options,param.left);break;case syntax_1.Syntax.ArrayPattern:for(var i=0;i<param.elements.length;i++){if(param.elements[i]!==null){this.checkPatternParam(options,param.elements[i]);}}break;case syntax_1.Syntax.ObjectPattern:for(var i=0;i<param.properties.length;i++){this.checkPatternParam(options,param.properties[i].value);}break;default:break;}options.simple=options.simple&&param instanceof Node.Identifier;};Parser.prototype.reinterpretAsCoverFormalsList=function(expr){var params=[expr];var options;var asyncArrow=false;switch(expr.type){case syntax_1.Syntax.Identifier:break;case ArrowParameterPlaceHolder:params=expr.params;asyncArrow=expr.async;break;default:return null;}options={simple:true,paramSet:{}};for(var i=0;i<params.length;++i){var param=params[i];if(param.type===syntax_1.Syntax.AssignmentPattern){if(param.right.type===syntax_1.Syntax.YieldExpression){if(param.right.argument){this.throwUnexpectedToken(this.lookahead);}param.right.type=syntax_1.Syntax.Identifier;param.right.name='yield';delete param.right.argument;delete param.right.delegate;}}else if(asyncArrow&&param.type===syntax_1.Syntax.Identifier&&param.name==='await'){this.throwUnexpectedToken(this.lookahead);}this.checkPatternParam(options,param);params[i]=param;}if(this.context.strict||!this.context.allowYield){for(var i=0;i<params.length;++i){var param=params[i];if(param.type===syntax_1.Syntax.YieldExpression){this.throwUnexpectedToken(this.lookahead);}}}if(options.message===messages_1.Messages.StrictParamDupe){var token=this.context.strict?options.stricted:options.firstRestricted;this.throwUnexpectedToken(token,options.message);}return{simple:options.simple,params:params,stricted:options.stricted,firstRestricted:options.firstRestricted,message:options.message};};Parser.prototype.parseAssignmentExpression=function(){var expr;if(!this.context.allowYield&&this.matchKeyword('yield')){expr=this.parseYieldExpression();}else{var startToken=this.lookahead;var token=startToken;expr=this.parseConditionalExpression();if(token.type===3/* Identifier */&&token.lineNumber===this.lookahead.lineNumber&&token.value==='async'){if(this.lookahead.type===3/* Identifier */||this.matchKeyword('yield')){var arg=this.parsePrimaryExpression();this.reinterpretExpressionAsPattern(arg);expr={type:ArrowParameterPlaceHolder,params:[arg],async:true};}}if(expr.type===ArrowParameterPlaceHolder||this.match('=>')){// https://tc39.github.io/ecma262/#sec-arrow-function-definitions
this.context.isAssignmentTarget=false;this.context.isBindingElement=false;var isAsync=expr.async;var list=this.reinterpretAsCoverFormalsList(expr);if(list){if(this.hasLineTerminator){this.tolerateUnexpectedToken(this.lookahead);}this.context.firstCoverInitializedNameError=null;var previousStrict=this.context.strict;var previousAllowStrictDirective=this.context.allowStrictDirective;this.context.allowStrictDirective=list.simple;var previousAllowYield=this.context.allowYield;var previousAwait=this.context.await;this.context.allowYield=true;this.context.await=isAsync;var node=this.startNode(startToken);this.expect('=>');var body=void 0;if(this.match('{')){var previousAllowIn=this.context.allowIn;this.context.allowIn=true;body=this.parseFunctionSourceElements();this.context.allowIn=previousAllowIn;}else{body=this.isolateCoverGrammar(this.parseAssignmentExpression);}var expression=body.type!==syntax_1.Syntax.BlockStatement;if(this.context.strict&&list.firstRestricted){this.throwUnexpectedToken(list.firstRestricted,list.message);}if(this.context.strict&&list.stricted){this.tolerateUnexpectedToken(list.stricted,list.message);}expr=isAsync?this.finalize(node,new Node.AsyncArrowFunctionExpression(list.params,body,expression)):this.finalize(node,new Node.ArrowFunctionExpression(list.params,body,expression));this.context.strict=previousStrict;this.context.allowStrictDirective=previousAllowStrictDirective;this.context.allowYield=previousAllowYield;this.context.await=previousAwait;}}else{if(this.matchAssign()){if(!this.context.isAssignmentTarget){this.tolerateError(messages_1.Messages.InvalidLHSInAssignment);}if(this.context.strict&&expr.type===syntax_1.Syntax.Identifier){var id=expr;if(this.scanner.isRestrictedWord(id.name)){this.tolerateUnexpectedToken(token,messages_1.Messages.StrictLHSAssignment);}if(this.scanner.isStrictModeReservedWord(id.name)){this.tolerateUnexpectedToken(token,messages_1.Messages.StrictReservedWord);}}if(!this.match('=')){this.context.isAssignmentTarget=false;this.context.isBindingElement=false;}else{this.reinterpretExpressionAsPattern(expr);}token=this.nextToken();var operator=token.value;var right=this.isolateCoverGrammar(this.parseAssignmentExpression);expr=this.finalize(this.startNode(startToken),new Node.AssignmentExpression(operator,expr,right));this.context.firstCoverInitializedNameError=null;}}}return expr;};// https://tc39.github.io/ecma262/#sec-comma-operator
Parser.prototype.parseExpression=function(){var startToken=this.lookahead;var expr=this.isolateCoverGrammar(this.parseAssignmentExpression);if(this.match(',')){var expressions=[];expressions.push(expr);while(this.lookahead.type!==2/* EOF */){if(!this.match(',')){break;}this.nextToken();expressions.push(this.isolateCoverGrammar(this.parseAssignmentExpression));}expr=this.finalize(this.startNode(startToken),new Node.SequenceExpression(expressions));}return expr;};// https://tc39.github.io/ecma262/#sec-block
Parser.prototype.parseStatementListItem=function(){var statement;this.context.isAssignmentTarget=true;this.context.isBindingElement=true;if(this.lookahead.type===4/* Keyword */){switch(this.lookahead.value){case'export':if(!this.context.isModule){this.tolerateUnexpectedToken(this.lookahead,messages_1.Messages.IllegalExportDeclaration);}statement=this.parseExportDeclaration();break;case'import':if(!this.context.isModule){this.tolerateUnexpectedToken(this.lookahead,messages_1.Messages.IllegalImportDeclaration);}statement=this.parseImportDeclaration();break;case'const':statement=this.parseLexicalDeclaration({inFor:false});break;case'function':statement=this.parseFunctionDeclaration();break;case'class':statement=this.parseClassDeclaration();break;case'let':statement=this.isLexicalDeclaration()?this.parseLexicalDeclaration({inFor:false}):this.parseStatement();break;default:statement=this.parseStatement();break;}}else{statement=this.parseStatement();}return statement;};Parser.prototype.parseBlock=function(){var node=this.createNode();this.expect('{');var block=[];while(true){if(this.match('}')){break;}block.push(this.parseStatementListItem());}this.expect('}');return this.finalize(node,new Node.BlockStatement(block));};// https://tc39.github.io/ecma262/#sec-let-and-const-declarations
Parser.prototype.parseLexicalBinding=function(kind,options){var node=this.createNode();var params=[];var id=this.parsePattern(params,kind);if(this.context.strict&&id.type===syntax_1.Syntax.Identifier){if(this.scanner.isRestrictedWord(id.name)){this.tolerateError(messages_1.Messages.StrictVarName);}}var init=null;if(kind==='const'){if(!this.matchKeyword('in')&&!this.matchContextualKeyword('of')){if(this.match('=')){this.nextToken();init=this.isolateCoverGrammar(this.parseAssignmentExpression);}else{this.throwError(messages_1.Messages.DeclarationMissingInitializer,'const');}}}else if(!options.inFor&&id.type!==syntax_1.Syntax.Identifier||this.match('=')){this.expect('=');init=this.isolateCoverGrammar(this.parseAssignmentExpression);}return this.finalize(node,new Node.VariableDeclarator(id,init));};Parser.prototype.parseBindingList=function(kind,options){var list=[this.parseLexicalBinding(kind,options)];while(this.match(',')){this.nextToken();list.push(this.parseLexicalBinding(kind,options));}return list;};Parser.prototype.isLexicalDeclaration=function(){var state=this.scanner.saveState();this.scanner.scanComments();var next=this.scanner.lex();this.scanner.restoreState(state);return next.type===3/* Identifier */||next.type===7/* Punctuator */&&next.value==='['||next.type===7/* Punctuator */&&next.value==='{'||next.type===4/* Keyword */&&next.value==='let'||next.type===4/* Keyword */&&next.value==='yield';};Parser.prototype.parseLexicalDeclaration=function(options){var node=this.createNode();var kind=this.nextToken().value;assert_1.assert(kind==='let'||kind==='const','Lexical declaration must be either let or const');var declarations=this.parseBindingList(kind,options);this.consumeSemicolon();return this.finalize(node,new Node.VariableDeclaration(declarations,kind));};// https://tc39.github.io/ecma262/#sec-destructuring-binding-patterns
Parser.prototype.parseBindingRestElement=function(params,kind){var node=this.createNode();this.expect('...');var arg=this.parsePattern(params,kind);return this.finalize(node,new Node.RestElement(arg));};Parser.prototype.parseArrayPattern=function(params,kind){var node=this.createNode();this.expect('[');var elements=[];while(!this.match(']')){if(this.match(',')){this.nextToken();elements.push(null);}else{if(this.match('...')){elements.push(this.parseBindingRestElement(params,kind));break;}else{elements.push(this.parsePatternWithDefault(params,kind));}if(!this.match(']')){this.expect(',');}}}this.expect(']');return this.finalize(node,new Node.ArrayPattern(elements));};Parser.prototype.parsePropertyPattern=function(params,kind){var node=this.createNode();var computed=false;var shorthand=false;var method=false;var key;var value;if(this.lookahead.type===3/* Identifier */){var keyToken=this.lookahead;key=this.parseVariableIdentifier();var init=this.finalize(node,new Node.Identifier(keyToken.value));if(this.match('=')){params.push(keyToken);shorthand=true;this.nextToken();var expr=this.parseAssignmentExpression();value=this.finalize(this.startNode(keyToken),new Node.AssignmentPattern(init,expr));}else if(!this.match(':')){params.push(keyToken);shorthand=true;value=init;}else{this.expect(':');value=this.parsePatternWithDefault(params,kind);}}else{computed=this.match('[');key=this.parseObjectPropertyKey();this.expect(':');value=this.parsePatternWithDefault(params,kind);}return this.finalize(node,new Node.Property('init',key,computed,value,method,shorthand));};Parser.prototype.parseObjectPattern=function(params,kind){var node=this.createNode();var properties=[];this.expect('{');while(!this.match('}')){properties.push(this.parsePropertyPattern(params,kind));if(!this.match('}')){this.expect(',');}}this.expect('}');return this.finalize(node,new Node.ObjectPattern(properties));};Parser.prototype.parsePattern=function(params,kind){var pattern;if(this.match('[')){pattern=this.parseArrayPattern(params,kind);}else if(this.match('{')){pattern=this.parseObjectPattern(params,kind);}else{if(this.matchKeyword('let')&&(kind==='const'||kind==='let')){this.tolerateUnexpectedToken(this.lookahead,messages_1.Messages.LetInLexicalBinding);}params.push(this.lookahead);pattern=this.parseVariableIdentifier(kind);}return pattern;};Parser.prototype.parsePatternWithDefault=function(params,kind){var startToken=this.lookahead;var pattern=this.parsePattern(params,kind);if(this.match('=')){this.nextToken();var previousAllowYield=this.context.allowYield;this.context.allowYield=true;var right=this.isolateCoverGrammar(this.parseAssignmentExpression);this.context.allowYield=previousAllowYield;pattern=this.finalize(this.startNode(startToken),new Node.AssignmentPattern(pattern,right));}return pattern;};// https://tc39.github.io/ecma262/#sec-variable-statement
Parser.prototype.parseVariableIdentifier=function(kind){var node=this.createNode();var token=this.nextToken();if(token.type===4/* Keyword */&&token.value==='yield'){if(this.context.strict){this.tolerateUnexpectedToken(token,messages_1.Messages.StrictReservedWord);}else if(!this.context.allowYield){this.throwUnexpectedToken(token);}}else if(token.type!==3/* Identifier */){if(this.context.strict&&token.type===4/* Keyword */&&this.scanner.isStrictModeReservedWord(token.value)){this.tolerateUnexpectedToken(token,messages_1.Messages.StrictReservedWord);}else{if(this.context.strict||token.value!=='let'||kind!=='var'){this.throwUnexpectedToken(token);}}}else if((this.context.isModule||this.context.await)&&token.type===3/* Identifier */&&token.value==='await'){this.tolerateUnexpectedToken(token);}return this.finalize(node,new Node.Identifier(token.value));};Parser.prototype.parseVariableDeclaration=function(options){var node=this.createNode();var params=[];var id=this.parsePattern(params,'var');if(this.context.strict&&id.type===syntax_1.Syntax.Identifier){if(this.scanner.isRestrictedWord(id.name)){this.tolerateError(messages_1.Messages.StrictVarName);}}var init=null;if(this.match('=')){this.nextToken();init=this.isolateCoverGrammar(this.parseAssignmentExpression);}else if(id.type!==syntax_1.Syntax.Identifier&&!options.inFor){this.expect('=');}return this.finalize(node,new Node.VariableDeclarator(id,init));};Parser.prototype.parseVariableDeclarationList=function(options){var opt={inFor:options.inFor};var list=[];list.push(this.parseVariableDeclaration(opt));while(this.match(',')){this.nextToken();list.push(this.parseVariableDeclaration(opt));}return list;};Parser.prototype.parseVariableStatement=function(){var node=this.createNode();this.expectKeyword('var');var declarations=this.parseVariableDeclarationList({inFor:false});this.consumeSemicolon();return this.finalize(node,new Node.VariableDeclaration(declarations,'var'));};// https://tc39.github.io/ecma262/#sec-empty-statement
Parser.prototype.parseEmptyStatement=function(){var node=this.createNode();this.expect(';');return this.finalize(node,new Node.EmptyStatement());};// https://tc39.github.io/ecma262/#sec-expression-statement
Parser.prototype.parseExpressionStatement=function(){var node=this.createNode();var expr=this.parseExpression();this.consumeSemicolon();return this.finalize(node,new Node.ExpressionStatement(expr));};// https://tc39.github.io/ecma262/#sec-if-statement
Parser.prototype.parseIfClause=function(){if(this.context.strict&&this.matchKeyword('function')){this.tolerateError(messages_1.Messages.StrictFunction);}return this.parseStatement();};Parser.prototype.parseIfStatement=function(){var node=this.createNode();var consequent;var alternate=null;this.expectKeyword('if');this.expect('(');var test=this.parseExpression();if(!this.match(')')&&this.config.tolerant){this.tolerateUnexpectedToken(this.nextToken());consequent=this.finalize(this.createNode(),new Node.EmptyStatement());}else{this.expect(')');consequent=this.parseIfClause();if(this.matchKeyword('else')){this.nextToken();alternate=this.parseIfClause();}}return this.finalize(node,new Node.IfStatement(test,consequent,alternate));};// https://tc39.github.io/ecma262/#sec-do-while-statement
Parser.prototype.parseDoWhileStatement=function(){var node=this.createNode();this.expectKeyword('do');var previousInIteration=this.context.inIteration;this.context.inIteration=true;var body=this.parseStatement();this.context.inIteration=previousInIteration;this.expectKeyword('while');this.expect('(');var test=this.parseExpression();if(!this.match(')')&&this.config.tolerant){this.tolerateUnexpectedToken(this.nextToken());}else{this.expect(')');if(this.match(';')){this.nextToken();}}return this.finalize(node,new Node.DoWhileStatement(body,test));};// https://tc39.github.io/ecma262/#sec-while-statement
Parser.prototype.parseWhileStatement=function(){var node=this.createNode();var body;this.expectKeyword('while');this.expect('(');var test=this.parseExpression();if(!this.match(')')&&this.config.tolerant){this.tolerateUnexpectedToken(this.nextToken());body=this.finalize(this.createNode(),new Node.EmptyStatement());}else{this.expect(')');var previousInIteration=this.context.inIteration;this.context.inIteration=true;body=this.parseStatement();this.context.inIteration=previousInIteration;}return this.finalize(node,new Node.WhileStatement(test,body));};// https://tc39.github.io/ecma262/#sec-for-statement
// https://tc39.github.io/ecma262/#sec-for-in-and-for-of-statements
Parser.prototype.parseForStatement=function(){var init=null;var test=null;var update=null;var forIn=true;var left,right;var node=this.createNode();this.expectKeyword('for');this.expect('(');if(this.match(';')){this.nextToken();}else{if(this.matchKeyword('var')){init=this.createNode();this.nextToken();var previousAllowIn=this.context.allowIn;this.context.allowIn=false;var declarations=this.parseVariableDeclarationList({inFor:true});this.context.allowIn=previousAllowIn;if(declarations.length===1&&this.matchKeyword('in')){var decl=declarations[0];if(decl.init&&(decl.id.type===syntax_1.Syntax.ArrayPattern||decl.id.type===syntax_1.Syntax.ObjectPattern||this.context.strict)){this.tolerateError(messages_1.Messages.ForInOfLoopInitializer,'for-in');}init=this.finalize(init,new Node.VariableDeclaration(declarations,'var'));this.nextToken();left=init;right=this.parseExpression();init=null;}else if(declarations.length===1&&declarations[0].init===null&&this.matchContextualKeyword('of')){init=this.finalize(init,new Node.VariableDeclaration(declarations,'var'));this.nextToken();left=init;right=this.parseAssignmentExpression();init=null;forIn=false;}else{init=this.finalize(init,new Node.VariableDeclaration(declarations,'var'));this.expect(';');}}else if(this.matchKeyword('const')||this.matchKeyword('let')){init=this.createNode();var kind=this.nextToken().value;if(!this.context.strict&&this.lookahead.value==='in'){init=this.finalize(init,new Node.Identifier(kind));this.nextToken();left=init;right=this.parseExpression();init=null;}else{var previousAllowIn=this.context.allowIn;this.context.allowIn=false;var declarations=this.parseBindingList(kind,{inFor:true});this.context.allowIn=previousAllowIn;if(declarations.length===1&&declarations[0].init===null&&this.matchKeyword('in')){init=this.finalize(init,new Node.VariableDeclaration(declarations,kind));this.nextToken();left=init;right=this.parseExpression();init=null;}else if(declarations.length===1&&declarations[0].init===null&&this.matchContextualKeyword('of')){init=this.finalize(init,new Node.VariableDeclaration(declarations,kind));this.nextToken();left=init;right=this.parseAssignmentExpression();init=null;forIn=false;}else{this.consumeSemicolon();init=this.finalize(init,new Node.VariableDeclaration(declarations,kind));}}}else{var initStartToken=this.lookahead;var previousAllowIn=this.context.allowIn;this.context.allowIn=false;init=this.inheritCoverGrammar(this.parseAssignmentExpression);this.context.allowIn=previousAllowIn;if(this.matchKeyword('in')){if(!this.context.isAssignmentTarget||init.type===syntax_1.Syntax.AssignmentExpression){this.tolerateError(messages_1.Messages.InvalidLHSInForIn);}this.nextToken();this.reinterpretExpressionAsPattern(init);left=init;right=this.parseExpression();init=null;}else if(this.matchContextualKeyword('of')){if(!this.context.isAssignmentTarget||init.type===syntax_1.Syntax.AssignmentExpression){this.tolerateError(messages_1.Messages.InvalidLHSInForLoop);}this.nextToken();this.reinterpretExpressionAsPattern(init);left=init;right=this.parseAssignmentExpression();init=null;forIn=false;}else{if(this.match(',')){var initSeq=[init];while(this.match(',')){this.nextToken();initSeq.push(this.isolateCoverGrammar(this.parseAssignmentExpression));}init=this.finalize(this.startNode(initStartToken),new Node.SequenceExpression(initSeq));}this.expect(';');}}}if(typeof left==='undefined'){if(!this.match(';')){test=this.parseExpression();}this.expect(';');if(!this.match(')')){update=this.parseExpression();}}var body;if(!this.match(')')&&this.config.tolerant){this.tolerateUnexpectedToken(this.nextToken());body=this.finalize(this.createNode(),new Node.EmptyStatement());}else{this.expect(')');var previousInIteration=this.context.inIteration;this.context.inIteration=true;body=this.isolateCoverGrammar(this.parseStatement);this.context.inIteration=previousInIteration;}return typeof left==='undefined'?this.finalize(node,new Node.ForStatement(init,test,update,body)):forIn?this.finalize(node,new Node.ForInStatement(left,right,body)):this.finalize(node,new Node.ForOfStatement(left,right,body));};// https://tc39.github.io/ecma262/#sec-continue-statement
Parser.prototype.parseContinueStatement=function(){var node=this.createNode();this.expectKeyword('continue');var label=null;if(this.lookahead.type===3/* Identifier */&&!this.hasLineTerminator){var id=this.parseVariableIdentifier();label=id;var key='$'+id.name;if(!Object.prototype.hasOwnProperty.call(this.context.labelSet,key)){this.throwError(messages_1.Messages.UnknownLabel,id.name);}}this.consumeSemicolon();if(label===null&&!this.context.inIteration){this.throwError(messages_1.Messages.IllegalContinue);}return this.finalize(node,new Node.ContinueStatement(label));};// https://tc39.github.io/ecma262/#sec-break-statement
Parser.prototype.parseBreakStatement=function(){var node=this.createNode();this.expectKeyword('break');var label=null;if(this.lookahead.type===3/* Identifier */&&!this.hasLineTerminator){var id=this.parseVariableIdentifier();var key='$'+id.name;if(!Object.prototype.hasOwnProperty.call(this.context.labelSet,key)){this.throwError(messages_1.Messages.UnknownLabel,id.name);}label=id;}this.consumeSemicolon();if(label===null&&!this.context.inIteration&&!this.context.inSwitch){this.throwError(messages_1.Messages.IllegalBreak);}return this.finalize(node,new Node.BreakStatement(label));};// https://tc39.github.io/ecma262/#sec-return-statement
Parser.prototype.parseReturnStatement=function(){if(!this.context.inFunctionBody){this.tolerateError(messages_1.Messages.IllegalReturn);}var node=this.createNode();this.expectKeyword('return');var hasArgument=!this.match(';')&&!this.match('}')&&!this.hasLineTerminator&&this.lookahead.type!==2/* EOF */||this.lookahead.type===8/* StringLiteral */||this.lookahead.type===10/* Template */;var argument=hasArgument?this.parseExpression():null;this.consumeSemicolon();return this.finalize(node,new Node.ReturnStatement(argument));};// https://tc39.github.io/ecma262/#sec-with-statement
Parser.prototype.parseWithStatement=function(){if(this.context.strict){this.tolerateError(messages_1.Messages.StrictModeWith);}var node=this.createNode();var body;this.expectKeyword('with');this.expect('(');var object=this.parseExpression();if(!this.match(')')&&this.config.tolerant){this.tolerateUnexpectedToken(this.nextToken());body=this.finalize(this.createNode(),new Node.EmptyStatement());}else{this.expect(')');body=this.parseStatement();}return this.finalize(node,new Node.WithStatement(object,body));};// https://tc39.github.io/ecma262/#sec-switch-statement
Parser.prototype.parseSwitchCase=function(){var node=this.createNode();var test;if(this.matchKeyword('default')){this.nextToken();test=null;}else{this.expectKeyword('case');test=this.parseExpression();}this.expect(':');var consequent=[];while(true){if(this.match('}')||this.matchKeyword('default')||this.matchKeyword('case')){break;}consequent.push(this.parseStatementListItem());}return this.finalize(node,new Node.SwitchCase(test,consequent));};Parser.prototype.parseSwitchStatement=function(){var node=this.createNode();this.expectKeyword('switch');this.expect('(');var discriminant=this.parseExpression();this.expect(')');var previousInSwitch=this.context.inSwitch;this.context.inSwitch=true;var cases=[];var defaultFound=false;this.expect('{');while(true){if(this.match('}')){break;}var clause=this.parseSwitchCase();if(clause.test===null){if(defaultFound){this.throwError(messages_1.Messages.MultipleDefaultsInSwitch);}defaultFound=true;}cases.push(clause);}this.expect('}');this.context.inSwitch=previousInSwitch;return this.finalize(node,new Node.SwitchStatement(discriminant,cases));};// https://tc39.github.io/ecma262/#sec-labelled-statements
Parser.prototype.parseLabelledStatement=function(){var node=this.createNode();var expr=this.parseExpression();var statement;if(expr.type===syntax_1.Syntax.Identifier&&this.match(':')){this.nextToken();var id=expr;var key='$'+id.name;if(Object.prototype.hasOwnProperty.call(this.context.labelSet,key)){this.throwError(messages_1.Messages.Redeclaration,'Label',id.name);}this.context.labelSet[key]=true;var body=void 0;if(this.matchKeyword('class')){this.tolerateUnexpectedToken(this.lookahead);body=this.parseClassDeclaration();}else if(this.matchKeyword('function')){var token=this.lookahead;var declaration=this.parseFunctionDeclaration();if(this.context.strict){this.tolerateUnexpectedToken(token,messages_1.Messages.StrictFunction);}else if(declaration.generator){this.tolerateUnexpectedToken(token,messages_1.Messages.GeneratorInLegacyContext);}body=declaration;}else{body=this.parseStatement();}delete this.context.labelSet[key];statement=new Node.LabeledStatement(id,body);}else{this.consumeSemicolon();statement=new Node.ExpressionStatement(expr);}return this.finalize(node,statement);};// https://tc39.github.io/ecma262/#sec-throw-statement
Parser.prototype.parseThrowStatement=function(){var node=this.createNode();this.expectKeyword('throw');if(this.hasLineTerminator){this.throwError(messages_1.Messages.NewlineAfterThrow);}var argument=this.parseExpression();this.consumeSemicolon();return this.finalize(node,new Node.ThrowStatement(argument));};// https://tc39.github.io/ecma262/#sec-try-statement
Parser.prototype.parseCatchClause=function(){var node=this.createNode();this.expectKeyword('catch');this.expect('(');if(this.match(')')){this.throwUnexpectedToken(this.lookahead);}var params=[];var param=this.parsePattern(params);var paramMap={};for(var i=0;i<params.length;i++){var key='$'+params[i].value;if(Object.prototype.hasOwnProperty.call(paramMap,key)){this.tolerateError(messages_1.Messages.DuplicateBinding,params[i].value);}paramMap[key]=true;}if(this.context.strict&&param.type===syntax_1.Syntax.Identifier){if(this.scanner.isRestrictedWord(param.name)){this.tolerateError(messages_1.Messages.StrictCatchVariable);}}this.expect(')');var body=this.parseBlock();return this.finalize(node,new Node.CatchClause(param,body));};Parser.prototype.parseFinallyClause=function(){this.expectKeyword('finally');return this.parseBlock();};Parser.prototype.parseTryStatement=function(){var node=this.createNode();this.expectKeyword('try');var block=this.parseBlock();var handler=this.matchKeyword('catch')?this.parseCatchClause():null;var finalizer=this.matchKeyword('finally')?this.parseFinallyClause():null;if(!handler&&!finalizer){this.throwError(messages_1.Messages.NoCatchOrFinally);}return this.finalize(node,new Node.TryStatement(block,handler,finalizer));};// https://tc39.github.io/ecma262/#sec-debugger-statement
Parser.prototype.parseDebuggerStatement=function(){var node=this.createNode();this.expectKeyword('debugger');this.consumeSemicolon();return this.finalize(node,new Node.DebuggerStatement());};// https://tc39.github.io/ecma262/#sec-ecmascript-language-statements-and-declarations
Parser.prototype.parseStatement=function(){var statement;switch(this.lookahead.type){case 1/* BooleanLiteral */:case 5/* NullLiteral */:case 6/* NumericLiteral */:case 8/* StringLiteral */:case 10/* Template */:case 9/* RegularExpression */:statement=this.parseExpressionStatement();break;case 7/* Punctuator */:var value=this.lookahead.value;if(value==='{'){statement=this.parseBlock();}else if(value==='('){statement=this.parseExpressionStatement();}else if(value===';'){statement=this.parseEmptyStatement();}else{statement=this.parseExpressionStatement();}break;case 3/* Identifier */:statement=this.matchAsyncFunction()?this.parseFunctionDeclaration():this.parseLabelledStatement();break;case 4/* Keyword */:switch(this.lookahead.value){case'break':statement=this.parseBreakStatement();break;case'continue':statement=this.parseContinueStatement();break;case'debugger':statement=this.parseDebuggerStatement();break;case'do':statement=this.parseDoWhileStatement();break;case'for':statement=this.parseForStatement();break;case'function':statement=this.parseFunctionDeclaration();break;case'if':statement=this.parseIfStatement();break;case'return':statement=this.parseReturnStatement();break;case'switch':statement=this.parseSwitchStatement();break;case'throw':statement=this.parseThrowStatement();break;case'try':statement=this.parseTryStatement();break;case'var':statement=this.parseVariableStatement();break;case'while':statement=this.parseWhileStatement();break;case'with':statement=this.parseWithStatement();break;default:statement=this.parseExpressionStatement();break;}break;default:statement=this.throwUnexpectedToken(this.lookahead);}return statement;};// https://tc39.github.io/ecma262/#sec-function-definitions
Parser.prototype.parseFunctionSourceElements=function(){var node=this.createNode();this.expect('{');var body=this.parseDirectivePrologues();var previousLabelSet=this.context.labelSet;var previousInIteration=this.context.inIteration;var previousInSwitch=this.context.inSwitch;var previousInFunctionBody=this.context.inFunctionBody;this.context.labelSet={};this.context.inIteration=false;this.context.inSwitch=false;this.context.inFunctionBody=true;while(this.lookahead.type!==2/* EOF */){if(this.match('}')){break;}body.push(this.parseStatementListItem());}this.expect('}');this.context.labelSet=previousLabelSet;this.context.inIteration=previousInIteration;this.context.inSwitch=previousInSwitch;this.context.inFunctionBody=previousInFunctionBody;return this.finalize(node,new Node.BlockStatement(body));};Parser.prototype.validateParam=function(options,param,name){var key='$'+name;if(this.context.strict){if(this.scanner.isRestrictedWord(name)){options.stricted=param;options.message=messages_1.Messages.StrictParamName;}if(Object.prototype.hasOwnProperty.call(options.paramSet,key)){options.stricted=param;options.message=messages_1.Messages.StrictParamDupe;}}else if(!options.firstRestricted){if(this.scanner.isRestrictedWord(name)){options.firstRestricted=param;options.message=messages_1.Messages.StrictParamName;}else if(this.scanner.isStrictModeReservedWord(name)){options.firstRestricted=param;options.message=messages_1.Messages.StrictReservedWord;}else if(Object.prototype.hasOwnProperty.call(options.paramSet,key)){options.stricted=param;options.message=messages_1.Messages.StrictParamDupe;}}/* istanbul ignore next */if(typeof Object.defineProperty==='function'){Object.defineProperty(options.paramSet,key,{value:true,enumerable:true,writable:true,configurable:true});}else{options.paramSet[key]=true;}};Parser.prototype.parseRestElement=function(params){var node=this.createNode();this.expect('...');var arg=this.parsePattern(params);if(this.match('=')){this.throwError(messages_1.Messages.DefaultRestParameter);}if(!this.match(')')){this.throwError(messages_1.Messages.ParameterAfterRestParameter);}return this.finalize(node,new Node.RestElement(arg));};Parser.prototype.parseFormalParameter=function(options){var params=[];var param=this.match('...')?this.parseRestElement(params):this.parsePatternWithDefault(params);for(var i=0;i<params.length;i++){this.validateParam(options,params[i],params[i].value);}options.simple=options.simple&&param instanceof Node.Identifier;options.params.push(param);};Parser.prototype.parseFormalParameters=function(firstRestricted){var options;options={simple:true,params:[],firstRestricted:firstRestricted};this.expect('(');if(!this.match(')')){options.paramSet={};while(this.lookahead.type!==2/* EOF */){this.parseFormalParameter(options);if(this.match(')')){break;}this.expect(',');if(this.match(')')){break;}}}this.expect(')');return{simple:options.simple,params:options.params,stricted:options.stricted,firstRestricted:options.firstRestricted,message:options.message};};Parser.prototype.matchAsyncFunction=function(){var match=this.matchContextualKeyword('async');if(match){var state=this.scanner.saveState();this.scanner.scanComments();var next=this.scanner.lex();this.scanner.restoreState(state);match=state.lineNumber===next.lineNumber&&next.type===4/* Keyword */&&next.value==='function';}return match;};Parser.prototype.parseFunctionDeclaration=function(identifierIsOptional){var node=this.createNode();var isAsync=this.matchContextualKeyword('async');if(isAsync){this.nextToken();}this.expectKeyword('function');var isGenerator=isAsync?false:this.match('*');if(isGenerator){this.nextToken();}var message;var id=null;var firstRestricted=null;if(!identifierIsOptional||!this.match('(')){var token=this.lookahead;id=this.parseVariableIdentifier();if(this.context.strict){if(this.scanner.isRestrictedWord(token.value)){this.tolerateUnexpectedToken(token,messages_1.Messages.StrictFunctionName);}}else{if(this.scanner.isRestrictedWord(token.value)){firstRestricted=token;message=messages_1.Messages.StrictFunctionName;}else if(this.scanner.isStrictModeReservedWord(token.value)){firstRestricted=token;message=messages_1.Messages.StrictReservedWord;}}}var previousAllowAwait=this.context.await;var previousAllowYield=this.context.allowYield;this.context.await=isAsync;this.context.allowYield=!isGenerator;var formalParameters=this.parseFormalParameters(firstRestricted);var params=formalParameters.params;var stricted=formalParameters.stricted;firstRestricted=formalParameters.firstRestricted;if(formalParameters.message){message=formalParameters.message;}var previousStrict=this.context.strict;var previousAllowStrictDirective=this.context.allowStrictDirective;this.context.allowStrictDirective=formalParameters.simple;var body=this.parseFunctionSourceElements();if(this.context.strict&&firstRestricted){this.throwUnexpectedToken(firstRestricted,message);}if(this.context.strict&&stricted){this.tolerateUnexpectedToken(stricted,message);}this.context.strict=previousStrict;this.context.allowStrictDirective=previousAllowStrictDirective;this.context.await=previousAllowAwait;this.context.allowYield=previousAllowYield;return isAsync?this.finalize(node,new Node.AsyncFunctionDeclaration(id,params,body)):this.finalize(node,new Node.FunctionDeclaration(id,params,body,isGenerator));};Parser.prototype.parseFunctionExpression=function(){var node=this.createNode();var isAsync=this.matchContextualKeyword('async');if(isAsync){this.nextToken();}this.expectKeyword('function');var isGenerator=isAsync?false:this.match('*');if(isGenerator){this.nextToken();}var message;var id=null;var firstRestricted;var previousAllowAwait=this.context.await;var previousAllowYield=this.context.allowYield;this.context.await=isAsync;this.context.allowYield=!isGenerator;if(!this.match('(')){var token=this.lookahead;id=!this.context.strict&&!isGenerator&&this.matchKeyword('yield')?this.parseIdentifierName():this.parseVariableIdentifier();if(this.context.strict){if(this.scanner.isRestrictedWord(token.value)){this.tolerateUnexpectedToken(token,messages_1.Messages.StrictFunctionName);}}else{if(this.scanner.isRestrictedWord(token.value)){firstRestricted=token;message=messages_1.Messages.StrictFunctionName;}else if(this.scanner.isStrictModeReservedWord(token.value)){firstRestricted=token;message=messages_1.Messages.StrictReservedWord;}}}var formalParameters=this.parseFormalParameters(firstRestricted);var params=formalParameters.params;var stricted=formalParameters.stricted;firstRestricted=formalParameters.firstRestricted;if(formalParameters.message){message=formalParameters.message;}var previousStrict=this.context.strict;var previousAllowStrictDirective=this.context.allowStrictDirective;this.context.allowStrictDirective=formalParameters.simple;var body=this.parseFunctionSourceElements();if(this.context.strict&&firstRestricted){this.throwUnexpectedToken(firstRestricted,message);}if(this.context.strict&&stricted){this.tolerateUnexpectedToken(stricted,message);}this.context.strict=previousStrict;this.context.allowStrictDirective=previousAllowStrictDirective;this.context.await=previousAllowAwait;this.context.allowYield=previousAllowYield;return isAsync?this.finalize(node,new Node.AsyncFunctionExpression(id,params,body)):this.finalize(node,new Node.FunctionExpression(id,params,body,isGenerator));};// https://tc39.github.io/ecma262/#sec-directive-prologues-and-the-use-strict-directive
Parser.prototype.parseDirective=function(){var token=this.lookahead;var node=this.createNode();var expr=this.parseExpression();var directive=expr.type===syntax_1.Syntax.Literal?this.getTokenRaw(token).slice(1,-1):null;this.consumeSemicolon();return this.finalize(node,directive?new Node.Directive(expr,directive):new Node.ExpressionStatement(expr));};Parser.prototype.parseDirectivePrologues=function(){var firstRestricted=null;var body=[];while(true){var token=this.lookahead;if(token.type!==8/* StringLiteral */){break;}var statement=this.parseDirective();body.push(statement);var directive=statement.directive;if(typeof directive!=='string'){break;}if(directive==='use strict'){this.context.strict=true;if(firstRestricted){this.tolerateUnexpectedToken(firstRestricted,messages_1.Messages.StrictOctalLiteral);}if(!this.context.allowStrictDirective){this.tolerateUnexpectedToken(token,messages_1.Messages.IllegalLanguageModeDirective);}}else{if(!firstRestricted&&token.octal){firstRestricted=token;}}}return body;};// https://tc39.github.io/ecma262/#sec-method-definitions
Parser.prototype.qualifiedPropertyName=function(token){switch(token.type){case 3/* Identifier */:case 8/* StringLiteral */:case 1/* BooleanLiteral */:case 5/* NullLiteral */:case 6/* NumericLiteral */:case 4/* Keyword */:return true;case 7/* Punctuator */:return token.value==='[';default:break;}return false;};Parser.prototype.parseGetterMethod=function(){var node=this.createNode();var isGenerator=false;var previousAllowYield=this.context.allowYield;this.context.allowYield=!isGenerator;var formalParameters=this.parseFormalParameters();if(formalParameters.params.length>0){this.tolerateError(messages_1.Messages.BadGetterArity);}var method=this.parsePropertyMethod(formalParameters);this.context.allowYield=previousAllowYield;return this.finalize(node,new Node.FunctionExpression(null,formalParameters.params,method,isGenerator));};Parser.prototype.parseSetterMethod=function(){var node=this.createNode();var isGenerator=false;var previousAllowYield=this.context.allowYield;this.context.allowYield=!isGenerator;var formalParameters=this.parseFormalParameters();if(formalParameters.params.length!==1){this.tolerateError(messages_1.Messages.BadSetterArity);}else if(formalParameters.params[0]instanceof Node.RestElement){this.tolerateError(messages_1.Messages.BadSetterRestParameter);}var method=this.parsePropertyMethod(formalParameters);this.context.allowYield=previousAllowYield;return this.finalize(node,new Node.FunctionExpression(null,formalParameters.params,method,isGenerator));};Parser.prototype.parseGeneratorMethod=function(){var node=this.createNode();var isGenerator=true;var previousAllowYield=this.context.allowYield;this.context.allowYield=true;var params=this.parseFormalParameters();this.context.allowYield=false;var method=this.parsePropertyMethod(params);this.context.allowYield=previousAllowYield;return this.finalize(node,new Node.FunctionExpression(null,params.params,method,isGenerator));};// https://tc39.github.io/ecma262/#sec-generator-function-definitions
Parser.prototype.isStartOfExpression=function(){var start=true;var value=this.lookahead.value;switch(this.lookahead.type){case 7/* Punctuator */:start=value==='['||value==='('||value==='{'||value==='+'||value==='-'||value==='!'||value==='~'||value==='++'||value==='--'||value==='/'||value==='/=';// regular expression literal
break;case 4/* Keyword */:start=value==='class'||value==='delete'||value==='function'||value==='let'||value==='new'||value==='super'||value==='this'||value==='typeof'||value==='void'||value==='yield';break;default:break;}return start;};Parser.prototype.parseYieldExpression=function(){var node=this.createNode();this.expectKeyword('yield');var argument=null;var delegate=false;if(!this.hasLineTerminator){var previousAllowYield=this.context.allowYield;this.context.allowYield=false;delegate=this.match('*');if(delegate){this.nextToken();argument=this.parseAssignmentExpression();}else if(this.isStartOfExpression()){argument=this.parseAssignmentExpression();}this.context.allowYield=previousAllowYield;}return this.finalize(node,new Node.YieldExpression(argument,delegate));};// https://tc39.github.io/ecma262/#sec-class-definitions
Parser.prototype.parseClassElement=function(hasConstructor){var token=this.lookahead;var node=this.createNode();var kind='';var key=null;var value=null;var computed=false;var method=false;var isStatic=false;var isAsync=false;if(this.match('*')){this.nextToken();}else{computed=this.match('[');key=this.parseObjectPropertyKey();var id=key;if(id.name==='static'&&(this.qualifiedPropertyName(this.lookahead)||this.match('*'))){token=this.lookahead;isStatic=true;computed=this.match('[');if(this.match('*')){this.nextToken();}else{key=this.parseObjectPropertyKey();}}if(token.type===3/* Identifier */&&!this.hasLineTerminator&&token.value==='async'){var punctuator=this.lookahead.value;if(punctuator!==':'&&punctuator!=='('&&punctuator!=='*'){isAsync=true;token=this.lookahead;key=this.parseObjectPropertyKey();if(token.type===3/* Identifier */&&token.value==='constructor'){this.tolerateUnexpectedToken(token,messages_1.Messages.ConstructorIsAsync);}}}}var lookaheadPropertyKey=this.qualifiedPropertyName(this.lookahead);if(token.type===3/* Identifier */){if(token.value==='get'&&lookaheadPropertyKey){kind='get';computed=this.match('[');key=this.parseObjectPropertyKey();this.context.allowYield=false;value=this.parseGetterMethod();}else if(token.value==='set'&&lookaheadPropertyKey){kind='set';computed=this.match('[');key=this.parseObjectPropertyKey();value=this.parseSetterMethod();}}else if(token.type===7/* Punctuator */&&token.value==='*'&&lookaheadPropertyKey){kind='init';computed=this.match('[');key=this.parseObjectPropertyKey();value=this.parseGeneratorMethod();method=true;}if(!kind&&key&&this.match('(')){kind='init';value=isAsync?this.parsePropertyMethodAsyncFunction():this.parsePropertyMethodFunction();method=true;}if(!kind){this.throwUnexpectedToken(this.lookahead);}if(kind==='init'){kind='method';}if(!computed){if(isStatic&&this.isPropertyKey(key,'prototype')){this.throwUnexpectedToken(token,messages_1.Messages.StaticPrototype);}if(!isStatic&&this.isPropertyKey(key,'constructor')){if(kind!=='method'||!method||value&&value.generator){this.throwUnexpectedToken(token,messages_1.Messages.ConstructorSpecialMethod);}if(hasConstructor.value){this.throwUnexpectedToken(token,messages_1.Messages.DuplicateConstructor);}else{hasConstructor.value=true;}kind='constructor';}}return this.finalize(node,new Node.MethodDefinition(key,computed,value,kind,isStatic));};Parser.prototype.parseClassElementList=function(){var body=[];var hasConstructor={value:false};this.expect('{');while(!this.match('}')){if(this.match(';')){this.nextToken();}else{body.push(this.parseClassElement(hasConstructor));}}this.expect('}');return body;};Parser.prototype.parseClassBody=function(){var node=this.createNode();var elementList=this.parseClassElementList();return this.finalize(node,new Node.ClassBody(elementList));};Parser.prototype.parseClassDeclaration=function(identifierIsOptional){var node=this.createNode();var previousStrict=this.context.strict;this.context.strict=true;this.expectKeyword('class');var id=identifierIsOptional&&this.lookahead.type!==3/* Identifier */?null:this.parseVariableIdentifier();var superClass=null;if(this.matchKeyword('extends')){this.nextToken();superClass=this.isolateCoverGrammar(this.parseLeftHandSideExpressionAllowCall);}var classBody=this.parseClassBody();this.context.strict=previousStrict;return this.finalize(node,new Node.ClassDeclaration(id,superClass,classBody));};Parser.prototype.parseClassExpression=function(){var node=this.createNode();var previousStrict=this.context.strict;this.context.strict=true;this.expectKeyword('class');var id=this.lookahead.type===3/* Identifier */?this.parseVariableIdentifier():null;var superClass=null;if(this.matchKeyword('extends')){this.nextToken();superClass=this.isolateCoverGrammar(this.parseLeftHandSideExpressionAllowCall);}var classBody=this.parseClassBody();this.context.strict=previousStrict;return this.finalize(node,new Node.ClassExpression(id,superClass,classBody));};// https://tc39.github.io/ecma262/#sec-scripts
// https://tc39.github.io/ecma262/#sec-modules
Parser.prototype.parseModule=function(){this.context.strict=true;this.context.isModule=true;this.scanner.isModule=true;var node=this.createNode();var body=this.parseDirectivePrologues();while(this.lookahead.type!==2/* EOF */){body.push(this.parseStatementListItem());}return this.finalize(node,new Node.Module(body));};Parser.prototype.parseScript=function(){var node=this.createNode();var body=this.parseDirectivePrologues();while(this.lookahead.type!==2/* EOF */){body.push(this.parseStatementListItem());}return this.finalize(node,new Node.Script(body));};// https://tc39.github.io/ecma262/#sec-imports
Parser.prototype.parseModuleSpecifier=function(){var node=this.createNode();if(this.lookahead.type!==8/* StringLiteral */){this.throwError(messages_1.Messages.InvalidModuleSpecifier);}var token=this.nextToken();var raw=this.getTokenRaw(token);return this.finalize(node,new Node.Literal(token.value,raw));};// import {<foo as bar>} ...;
Parser.prototype.parseImportSpecifier=function(){var node=this.createNode();var imported;var local;if(this.lookahead.type===3/* Identifier */){imported=this.parseVariableIdentifier();local=imported;if(this.matchContextualKeyword('as')){this.nextToken();local=this.parseVariableIdentifier();}}else{imported=this.parseIdentifierName();local=imported;if(this.matchContextualKeyword('as')){this.nextToken();local=this.parseVariableIdentifier();}else{this.throwUnexpectedToken(this.nextToken());}}return this.finalize(node,new Node.ImportSpecifier(local,imported));};// {foo, bar as bas}
Parser.prototype.parseNamedImports=function(){this.expect('{');var specifiers=[];while(!this.match('}')){specifiers.push(this.parseImportSpecifier());if(!this.match('}')){this.expect(',');}}this.expect('}');return specifiers;};// import <foo> ...;
Parser.prototype.parseImportDefaultSpecifier=function(){var node=this.createNode();var local=this.parseIdentifierName();return this.finalize(node,new Node.ImportDefaultSpecifier(local));};// import <* as foo> ...;
Parser.prototype.parseImportNamespaceSpecifier=function(){var node=this.createNode();this.expect('*');if(!this.matchContextualKeyword('as')){this.throwError(messages_1.Messages.NoAsAfterImportNamespace);}this.nextToken();var local=this.parseIdentifierName();return this.finalize(node,new Node.ImportNamespaceSpecifier(local));};Parser.prototype.parseImportDeclaration=function(){if(this.context.inFunctionBody){this.throwError(messages_1.Messages.IllegalImportDeclaration);}var node=this.createNode();this.expectKeyword('import');var src;var specifiers=[];if(this.lookahead.type===8/* StringLiteral */){// import 'foo';
src=this.parseModuleSpecifier();}else{if(this.match('{')){// import {bar}
specifiers=specifiers.concat(this.parseNamedImports());}else if(this.match('*')){// import * as foo
specifiers.push(this.parseImportNamespaceSpecifier());}else if(this.isIdentifierName(this.lookahead)&&!this.matchKeyword('default')){// import foo
specifiers.push(this.parseImportDefaultSpecifier());if(this.match(',')){this.nextToken();if(this.match('*')){// import foo, * as foo
specifiers.push(this.parseImportNamespaceSpecifier());}else if(this.match('{')){// import foo, {bar}
specifiers=specifiers.concat(this.parseNamedImports());}else{this.throwUnexpectedToken(this.lookahead);}}}else{this.throwUnexpectedToken(this.nextToken());}if(!this.matchContextualKeyword('from')){var message=this.lookahead.value?messages_1.Messages.UnexpectedToken:messages_1.Messages.MissingFromClause;this.throwError(message,this.lookahead.value);}this.nextToken();src=this.parseModuleSpecifier();}this.consumeSemicolon();return this.finalize(node,new Node.ImportDeclaration(specifiers,src));};// https://tc39.github.io/ecma262/#sec-exports
Parser.prototype.parseExportSpecifier=function(){var node=this.createNode();var local=this.parseIdentifierName();var exported=local;if(this.matchContextualKeyword('as')){this.nextToken();exported=this.parseIdentifierName();}return this.finalize(node,new Node.ExportSpecifier(local,exported));};Parser.prototype.parseExportDeclaration=function(){if(this.context.inFunctionBody){this.throwError(messages_1.Messages.IllegalExportDeclaration);}var node=this.createNode();this.expectKeyword('export');var exportDeclaration;if(this.matchKeyword('default')){// export default ...
this.nextToken();if(this.matchKeyword('function')){// export default function foo () {}
// export default function () {}
var declaration=this.parseFunctionDeclaration(true);exportDeclaration=this.finalize(node,new Node.ExportDefaultDeclaration(declaration));}else if(this.matchKeyword('class')){// export default class foo {}
var declaration=this.parseClassDeclaration(true);exportDeclaration=this.finalize(node,new Node.ExportDefaultDeclaration(declaration));}else if(this.matchContextualKeyword('async')){// export default async function f () {}
// export default async function () {}
// export default async x => x
var declaration=this.matchAsyncFunction()?this.parseFunctionDeclaration(true):this.parseAssignmentExpression();exportDeclaration=this.finalize(node,new Node.ExportDefaultDeclaration(declaration));}else{if(this.matchContextualKeyword('from')){this.throwError(messages_1.Messages.UnexpectedToken,this.lookahead.value);}// export default {};
// export default [];
// export default (1 + 2);
var declaration=this.match('{')?this.parseObjectInitializer():this.match('[')?this.parseArrayInitializer():this.parseAssignmentExpression();this.consumeSemicolon();exportDeclaration=this.finalize(node,new Node.ExportDefaultDeclaration(declaration));}}else if(this.match('*')){// export * from 'foo';
this.nextToken();if(!this.matchContextualKeyword('from')){var message=this.lookahead.value?messages_1.Messages.UnexpectedToken:messages_1.Messages.MissingFromClause;this.throwError(message,this.lookahead.value);}this.nextToken();var src=this.parseModuleSpecifier();this.consumeSemicolon();exportDeclaration=this.finalize(node,new Node.ExportAllDeclaration(src));}else if(this.lookahead.type===4/* Keyword */){// export var f = 1;
var declaration=void 0;switch(this.lookahead.value){case'let':case'const':declaration=this.parseLexicalDeclaration({inFor:false});break;case'var':case'class':case'function':declaration=this.parseStatementListItem();break;default:this.throwUnexpectedToken(this.lookahead);}exportDeclaration=this.finalize(node,new Node.ExportNamedDeclaration(declaration,[],null));}else if(this.matchAsyncFunction()){var declaration=this.parseFunctionDeclaration();exportDeclaration=this.finalize(node,new Node.ExportNamedDeclaration(declaration,[],null));}else{var specifiers=[];var source=null;var isExportFromIdentifier=false;this.expect('{');while(!this.match('}')){isExportFromIdentifier=isExportFromIdentifier||this.matchKeyword('default');specifiers.push(this.parseExportSpecifier());if(!this.match('}')){this.expect(',');}}this.expect('}');if(this.matchContextualKeyword('from')){// export {default} from 'foo';
// export {foo} from 'foo';
this.nextToken();source=this.parseModuleSpecifier();this.consumeSemicolon();}else if(isExportFromIdentifier){// export {default}; // missing fromClause
var message=this.lookahead.value?messages_1.Messages.UnexpectedToken:messages_1.Messages.MissingFromClause;this.throwError(message,this.lookahead.value);}else{// export {foo};
this.consumeSemicolon();}exportDeclaration=this.finalize(node,new Node.ExportNamedDeclaration(null,specifiers,source));}return exportDeclaration;};return Parser;}();exports.Parser=Parser;/***/},/* 9 */ /***/function(module,exports){"use strict";// Ensure the condition is true, otherwise throw an error.
// This is only to have a better contract semantic, i.e. another safety net
// to catch a logic error. The condition shall be fulfilled in normal case.
// Do NOT use this to enforce a certain condition on any user input.
Object.defineProperty(exports,"__esModule",{value:true});function assert(condition,message){/* istanbul ignore if */if(!condition){throw new Error('ASSERT: '+message);}}exports.assert=assert;/***/},/* 10 */ /***/function(module,exports){"use strict";/* tslint:disable:max-classes-per-file */Object.defineProperty(exports,"__esModule",{value:true});var ErrorHandler=function(){function ErrorHandler(){this.errors=[];this.tolerant=false;}ErrorHandler.prototype.recordError=function(error){this.errors.push(error);};ErrorHandler.prototype.tolerate=function(error){if(this.tolerant){this.recordError(error);}else{throw error;}};ErrorHandler.prototype.constructError=function(msg,column){var error=new Error(msg);try{throw error;}catch(base){/* istanbul ignore else */if(Object.create&&Object.defineProperty){error=Object.create(base);Object.defineProperty(error,'column',{value:column});}}/* istanbul ignore next */return error;};ErrorHandler.prototype.createError=function(index,line,col,description){var msg='Line '+line+': '+description;var error=this.constructError(msg,col);error.index=index;error.lineNumber=line;error.description=description;return error;};ErrorHandler.prototype.throwError=function(index,line,col,description){throw this.createError(index,line,col,description);};ErrorHandler.prototype.tolerateError=function(index,line,col,description){var error=this.createError(index,line,col,description);if(this.tolerant){this.recordError(error);}else{throw error;}};return ErrorHandler;}();exports.ErrorHandler=ErrorHandler;/***/},/* 11 */ /***/function(module,exports){"use strict";Object.defineProperty(exports,"__esModule",{value:true});// Error messages should be identical to V8.
exports.Messages={BadGetterArity:'Getter must not have any formal parameters',BadSetterArity:'Setter must have exactly one formal parameter',BadSetterRestParameter:'Setter function argument must not be a rest parameter',ConstructorIsAsync:'Class constructor may not be an async method',ConstructorSpecialMethod:'Class constructor may not be an accessor',DeclarationMissingInitializer:'Missing initializer in %0 declaration',DefaultRestParameter:'Unexpected token =',DuplicateBinding:'Duplicate binding %0',DuplicateConstructor:'A class may only have one constructor',DuplicateProtoProperty:'Duplicate __proto__ fields are not allowed in object literals',ForInOfLoopInitializer:'%0 loop variable declaration may not have an initializer',GeneratorInLegacyContext:'Generator declarations are not allowed in legacy contexts',IllegalBreak:'Illegal break statement',IllegalContinue:'Illegal continue statement',IllegalExportDeclaration:'Unexpected token',IllegalImportDeclaration:'Unexpected token',IllegalLanguageModeDirective:'Illegal \'use strict\' directive in function with non-simple parameter list',IllegalReturn:'Illegal return statement',InvalidEscapedReservedWord:'Keyword must not contain escaped characters',InvalidHexEscapeSequence:'Invalid hexadecimal escape sequence',InvalidLHSInAssignment:'Invalid left-hand side in assignment',InvalidLHSInForIn:'Invalid left-hand side in for-in',InvalidLHSInForLoop:'Invalid left-hand side in for-loop',InvalidModuleSpecifier:'Unexpected token',InvalidRegExp:'Invalid regular expression',LetInLexicalBinding:'let is disallowed as a lexically bound name',MissingFromClause:'Unexpected token',MultipleDefaultsInSwitch:'More than one default clause in switch statement',NewlineAfterThrow:'Illegal newline after throw',NoAsAfterImportNamespace:'Unexpected token',NoCatchOrFinally:'Missing catch or finally after try',ParameterAfterRestParameter:'Rest parameter must be last formal parameter',Redeclaration:'%0 \'%1\' has already been declared',StaticPrototype:'Classes may not have static property named prototype',StrictCatchVariable:'Catch variable may not be eval or arguments in strict mode',StrictDelete:'Delete of an unqualified identifier in strict mode.',StrictFunction:'In strict mode code, functions can only be declared at top level or inside a block',StrictFunctionName:'Function name may not be eval or arguments in strict mode',StrictLHSAssignment:'Assignment to eval or arguments is not allowed in strict mode',StrictLHSPostfix:'Postfix increment/decrement may not have eval or arguments operand in strict mode',StrictLHSPrefix:'Prefix increment/decrement may not have eval or arguments operand in strict mode',StrictModeWith:'Strict mode code may not include a with statement',StrictOctalLiteral:'Octal literals are not allowed in strict mode.',StrictParamDupe:'Strict mode function may not have duplicate parameter names',StrictParamName:'Parameter name eval or arguments is not allowed in strict mode',StrictReservedWord:'Use of future reserved word in strict mode',StrictVarName:'Variable name may not be eval or arguments in strict mode',TemplateOctalLiteral:'Octal literals are not allowed in template strings.',UnexpectedEOS:'Unexpected end of input',UnexpectedIdentifier:'Unexpected identifier',UnexpectedNumber:'Unexpected number',UnexpectedReserved:'Unexpected reserved word',UnexpectedString:'Unexpected string',UnexpectedTemplate:'Unexpected quasi %0',UnexpectedToken:'Unexpected token %0',UnexpectedTokenIllegal:'Unexpected token ILLEGAL',UnknownLabel:'Undefined label \'%0\'',UnterminatedRegExp:'Invalid regular expression: missing /'};/***/},/* 12 */ /***/function(module,exports,__webpack_require__){"use strict";Object.defineProperty(exports,"__esModule",{value:true});var assert_1=__webpack_require__(9);var character_1=__webpack_require__(4);var messages_1=__webpack_require__(11);function hexValue(ch){return'0123456789abcdef'.indexOf(ch.toLowerCase());}function octalValue(ch){return'01234567'.indexOf(ch);}var Scanner=function(){function Scanner(code,handler){this.source=code;this.errorHandler=handler;this.trackComment=false;this.isModule=false;this.length=code.length;this.index=0;this.lineNumber=code.length>0?1:0;this.lineStart=0;this.curlyStack=[];}Scanner.prototype.saveState=function(){return{index:this.index,lineNumber:this.lineNumber,lineStart:this.lineStart};};Scanner.prototype.restoreState=function(state){this.index=state.index;this.lineNumber=state.lineNumber;this.lineStart=state.lineStart;};Scanner.prototype.eof=function(){return this.index>=this.length;};Scanner.prototype.throwUnexpectedToken=function(message){if(message===void 0){message=messages_1.Messages.UnexpectedTokenIllegal;}return this.errorHandler.throwError(this.index,this.lineNumber,this.index-this.lineStart+1,message);};Scanner.prototype.tolerateUnexpectedToken=function(message){if(message===void 0){message=messages_1.Messages.UnexpectedTokenIllegal;}this.errorHandler.tolerateError(this.index,this.lineNumber,this.index-this.lineStart+1,message);};// https://tc39.github.io/ecma262/#sec-comments
Scanner.prototype.skipSingleLineComment=function(offset){var comments=[];var start,loc;if(this.trackComment){comments=[];start=this.index-offset;loc={start:{line:this.lineNumber,column:this.index-this.lineStart-offset},end:{}};}while(!this.eof()){var ch=this.source.charCodeAt(this.index);++this.index;if(character_1.Character.isLineTerminator(ch)){if(this.trackComment){loc.end={line:this.lineNumber,column:this.index-this.lineStart-1};var entry={multiLine:false,slice:[start+offset,this.index-1],range:[start,this.index-1],loc:loc};comments.push(entry);}if(ch===13&&this.source.charCodeAt(this.index)===10){++this.index;}++this.lineNumber;this.lineStart=this.index;return comments;}}if(this.trackComment){loc.end={line:this.lineNumber,column:this.index-this.lineStart};var entry={multiLine:false,slice:[start+offset,this.index],range:[start,this.index],loc:loc};comments.push(entry);}return comments;};Scanner.prototype.skipMultiLineComment=function(){var comments=[];var start,loc;if(this.trackComment){comments=[];start=this.index-2;loc={start:{line:this.lineNumber,column:this.index-this.lineStart-2},end:{}};}while(!this.eof()){var ch=this.source.charCodeAt(this.index);if(character_1.Character.isLineTerminator(ch)){if(ch===0x0D&&this.source.charCodeAt(this.index+1)===0x0A){++this.index;}++this.lineNumber;++this.index;this.lineStart=this.index;}else if(ch===0x2A){// Block comment ends with '*/'.
if(this.source.charCodeAt(this.index+1)===0x2F){this.index+=2;if(this.trackComment){loc.end={line:this.lineNumber,column:this.index-this.lineStart};var entry={multiLine:true,slice:[start+2,this.index-2],range:[start,this.index],loc:loc};comments.push(entry);}return comments;}++this.index;}else{++this.index;}}// Ran off the end of the file - the whole thing is a comment
if(this.trackComment){loc.end={line:this.lineNumber,column:this.index-this.lineStart};var entry={multiLine:true,slice:[start+2,this.index],range:[start,this.index],loc:loc};comments.push(entry);}this.tolerateUnexpectedToken();return comments;};Scanner.prototype.scanComments=function(){var comments;if(this.trackComment){comments=[];}var start=this.index===0;while(!this.eof()){var ch=this.source.charCodeAt(this.index);if(character_1.Character.isWhiteSpace(ch)){++this.index;}else if(character_1.Character.isLineTerminator(ch)){++this.index;if(ch===0x0D&&this.source.charCodeAt(this.index)===0x0A){++this.index;}++this.lineNumber;this.lineStart=this.index;start=true;}else if(ch===0x2F){ch=this.source.charCodeAt(this.index+1);if(ch===0x2F){this.index+=2;var comment=this.skipSingleLineComment(2);if(this.trackComment){comments=comments.concat(comment);}start=true;}else if(ch===0x2A){this.index+=2;var comment=this.skipMultiLineComment();if(this.trackComment){comments=comments.concat(comment);}}else{break;}}else if(start&&ch===0x2D){// U+003E is '>'
if(this.source.charCodeAt(this.index+1)===0x2D&&this.source.charCodeAt(this.index+2)===0x3E){// '-->' is a single-line comment
this.index+=3;var comment=this.skipSingleLineComment(3);if(this.trackComment){comments=comments.concat(comment);}}else{break;}}else if(ch===0x3C&&!this.isModule){if(this.source.slice(this.index+1,this.index+4)==='!--'){this.index+=4;// `<!--`
var comment=this.skipSingleLineComment(4);if(this.trackComment){comments=comments.concat(comment);}}else{break;}}else{break;}}return comments;};// https://tc39.github.io/ecma262/#sec-future-reserved-words
Scanner.prototype.isFutureReservedWord=function(id){switch(id){case'enum':case'export':case'import':case'super':return true;default:return false;}};Scanner.prototype.isStrictModeReservedWord=function(id){switch(id){case'implements':case'interface':case'package':case'private':case'protected':case'public':case'static':case'yield':case'let':return true;default:return false;}};Scanner.prototype.isRestrictedWord=function(id){return id==='eval'||id==='arguments';};// https://tc39.github.io/ecma262/#sec-keywords
Scanner.prototype.isKeyword=function(id){switch(id.length){case 2:return id==='if'||id==='in'||id==='do';case 3:return id==='var'||id==='for'||id==='new'||id==='try'||id==='let';case 4:return id==='this'||id==='else'||id==='case'||id==='void'||id==='with'||id==='enum';case 5:return id==='while'||id==='break'||id==='catch'||id==='throw'||id==='const'||id==='yield'||id==='class'||id==='super';case 6:return id==='return'||id==='typeof'||id==='delete'||id==='switch'||id==='export'||id==='import';case 7:return id==='default'||id==='finally'||id==='extends';case 8:return id==='function'||id==='continue'||id==='debugger';case 10:return id==='instanceof';default:return false;}};Scanner.prototype.codePointAt=function(i){var cp=this.source.charCodeAt(i);if(cp>=0xD800&&cp<=0xDBFF){var second=this.source.charCodeAt(i+1);if(second>=0xDC00&&second<=0xDFFF){var first=cp;cp=(first-0xD800)*0x400+second-0xDC00+0x10000;}}return cp;};Scanner.prototype.scanHexEscape=function(prefix){var len=prefix==='u'?4:2;var code=0;for(var i=0;i<len;++i){if(!this.eof()&&character_1.Character.isHexDigit(this.source.charCodeAt(this.index))){code=code*16+hexValue(this.source[this.index++]);}else{return null;}}return String.fromCharCode(code);};Scanner.prototype.scanUnicodeCodePointEscape=function(){var ch=this.source[this.index];var code=0;// At least, one hex digit is required.
if(ch==='}'){this.throwUnexpectedToken();}while(!this.eof()){ch=this.source[this.index++];if(!character_1.Character.isHexDigit(ch.charCodeAt(0))){break;}code=code*16+hexValue(ch);}if(code>0x10FFFF||ch!=='}'){this.throwUnexpectedToken();}return character_1.Character.fromCodePoint(code);};Scanner.prototype.getIdentifier=function(){var start=this.index++;while(!this.eof()){var ch=this.source.charCodeAt(this.index);if(ch===0x5C){// Blackslash (U+005C) marks Unicode escape sequence.
this.index=start;return this.getComplexIdentifier();}else if(ch>=0xD800&&ch<0xDFFF){// Need to handle surrogate pairs.
this.index=start;return this.getComplexIdentifier();}if(character_1.Character.isIdentifierPart(ch)){++this.index;}else{break;}}return this.source.slice(start,this.index);};Scanner.prototype.getComplexIdentifier=function(){var cp=this.codePointAt(this.index);var id=character_1.Character.fromCodePoint(cp);this.index+=id.length;// '\u' (U+005C, U+0075) denotes an escaped character.
var ch;if(cp===0x5C){if(this.source.charCodeAt(this.index)!==0x75){this.throwUnexpectedToken();}++this.index;if(this.source[this.index]==='{'){++this.index;ch=this.scanUnicodeCodePointEscape();}else{ch=this.scanHexEscape('u');if(ch===null||ch==='\\'||!character_1.Character.isIdentifierStart(ch.charCodeAt(0))){this.throwUnexpectedToken();}}id=ch;}while(!this.eof()){cp=this.codePointAt(this.index);if(!character_1.Character.isIdentifierPart(cp)){break;}ch=character_1.Character.fromCodePoint(cp);id+=ch;this.index+=ch.length;// '\u' (U+005C, U+0075) denotes an escaped character.
if(cp===0x5C){id=id.substr(0,id.length-1);if(this.source.charCodeAt(this.index)!==0x75){this.throwUnexpectedToken();}++this.index;if(this.source[this.index]==='{'){++this.index;ch=this.scanUnicodeCodePointEscape();}else{ch=this.scanHexEscape('u');if(ch===null||ch==='\\'||!character_1.Character.isIdentifierPart(ch.charCodeAt(0))){this.throwUnexpectedToken();}}id+=ch;}}return id;};Scanner.prototype.octalToDecimal=function(ch){// \0 is not octal escape sequence
var octal=ch!=='0';var code=octalValue(ch);if(!this.eof()&&character_1.Character.isOctalDigit(this.source.charCodeAt(this.index))){octal=true;code=code*8+octalValue(this.source[this.index++]);// 3 digits are only allowed when string starts
// with 0, 1, 2, 3
if('0123'.indexOf(ch)>=0&&!this.eof()&&character_1.Character.isOctalDigit(this.source.charCodeAt(this.index))){code=code*8+octalValue(this.source[this.index++]);}}return{code:code,octal:octal};};// https://tc39.github.io/ecma262/#sec-names-and-keywords
Scanner.prototype.scanIdentifier=function(){var type;var start=this.index;// Backslash (U+005C) starts an escaped character.
var id=this.source.charCodeAt(start)===0x5C?this.getComplexIdentifier():this.getIdentifier();// There is no keyword or literal with only one character.
// Thus, it must be an identifier.
if(id.length===1){type=3/* Identifier */;}else if(this.isKeyword(id)){type=4/* Keyword */;}else if(id==='null'){type=5/* NullLiteral */;}else if(id==='true'||id==='false'){type=1/* BooleanLiteral */;}else{type=3/* Identifier */;}if(type!==3/* Identifier */&&start+id.length!==this.index){var restore=this.index;this.index=start;this.tolerateUnexpectedToken(messages_1.Messages.InvalidEscapedReservedWord);this.index=restore;}return{type:type,value:id,lineNumber:this.lineNumber,lineStart:this.lineStart,start:start,end:this.index};};// https://tc39.github.io/ecma262/#sec-punctuators
Scanner.prototype.scanPunctuator=function(){var start=this.index;// Check for most common single-character punctuators.
var str=this.source[this.index];switch(str){case'(':case'{':if(str==='{'){this.curlyStack.push('{');}++this.index;break;case'.':++this.index;if(this.source[this.index]==='.'&&this.source[this.index+1]==='.'){// Spread operator: ...
this.index+=2;str='...';}break;case'}':++this.index;this.curlyStack.pop();break;case')':case';':case',':case'[':case']':case':':case'?':case'~':++this.index;break;default:// 4-character punctuator.
str=this.source.substr(this.index,4);if(str==='>>>='){this.index+=4;}else{// 3-character punctuators.
str=str.substr(0,3);if(str==='==='||str==='!=='||str==='>>>'||str==='<<='||str==='>>='||str==='**='){this.index+=3;}else{// 2-character punctuators.
str=str.substr(0,2);if(str==='&&'||str==='||'||str==='=='||str==='!='||str==='+='||str==='-='||str==='*='||str==='/='||str==='++'||str==='--'||str==='<<'||str==='>>'||str==='&='||str==='|='||str==='^='||str==='%='||str==='<='||str==='>='||str==='=>'||str==='**'){this.index+=2;}else{// 1-character punctuators.
str=this.source[this.index];if('<>=!+-*%&|^/'.indexOf(str)>=0){++this.index;}}}}}if(this.index===start){this.throwUnexpectedToken();}return{type:7/* Punctuator */,value:str,lineNumber:this.lineNumber,lineStart:this.lineStart,start:start,end:this.index};};// https://tc39.github.io/ecma262/#sec-literals-numeric-literals
Scanner.prototype.scanHexLiteral=function(start){var num='';while(!this.eof()){if(!character_1.Character.isHexDigit(this.source.charCodeAt(this.index))){break;}num+=this.source[this.index++];}if(num.length===0){this.throwUnexpectedToken();}if(character_1.Character.isIdentifierStart(this.source.charCodeAt(this.index))){this.throwUnexpectedToken();}return{type:6/* NumericLiteral */,value:parseInt('0x'+num,16),lineNumber:this.lineNumber,lineStart:this.lineStart,start:start,end:this.index};};Scanner.prototype.scanBinaryLiteral=function(start){var num='';var ch;while(!this.eof()){ch=this.source[this.index];if(ch!=='0'&&ch!=='1'){break;}num+=this.source[this.index++];}if(num.length===0){// only 0b or 0B
this.throwUnexpectedToken();}if(!this.eof()){ch=this.source.charCodeAt(this.index);/* istanbul ignore else */if(character_1.Character.isIdentifierStart(ch)||character_1.Character.isDecimalDigit(ch)){this.throwUnexpectedToken();}}return{type:6/* NumericLiteral */,value:parseInt(num,2),lineNumber:this.lineNumber,lineStart:this.lineStart,start:start,end:this.index};};Scanner.prototype.scanOctalLiteral=function(prefix,start){var num='';var octal=false;if(character_1.Character.isOctalDigit(prefix.charCodeAt(0))){octal=true;num='0'+this.source[this.index++];}else{++this.index;}while(!this.eof()){if(!character_1.Character.isOctalDigit(this.source.charCodeAt(this.index))){break;}num+=this.source[this.index++];}if(!octal&&num.length===0){// only 0o or 0O
this.throwUnexpectedToken();}if(character_1.Character.isIdentifierStart(this.source.charCodeAt(this.index))||character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))){this.throwUnexpectedToken();}return{type:6/* NumericLiteral */,value:parseInt(num,8),octal:octal,lineNumber:this.lineNumber,lineStart:this.lineStart,start:start,end:this.index};};Scanner.prototype.isImplicitOctalLiteral=function(){// Implicit octal, unless there is a non-octal digit.
// (Annex B.1.1 on Numeric Literals)
for(var i=this.index+1;i<this.length;++i){var ch=this.source[i];if(ch==='8'||ch==='9'){return false;}if(!character_1.Character.isOctalDigit(ch.charCodeAt(0))){return true;}}return true;};Scanner.prototype.scanNumericLiteral=function(){var start=this.index;var ch=this.source[start];assert_1.assert(character_1.Character.isDecimalDigit(ch.charCodeAt(0))||ch==='.','Numeric literal must start with a decimal digit or a decimal point');var num='';if(ch!=='.'){num=this.source[this.index++];ch=this.source[this.index];// Hex number starts with '0x'.
// Octal number starts with '0'.
// Octal number in ES6 starts with '0o'.
// Binary number in ES6 starts with '0b'.
if(num==='0'){if(ch==='x'||ch==='X'){++this.index;return this.scanHexLiteral(start);}if(ch==='b'||ch==='B'){++this.index;return this.scanBinaryLiteral(start);}if(ch==='o'||ch==='O'){return this.scanOctalLiteral(ch,start);}if(ch&&character_1.Character.isOctalDigit(ch.charCodeAt(0))){if(this.isImplicitOctalLiteral()){return this.scanOctalLiteral(ch,start);}}}while(character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))){num+=this.source[this.index++];}ch=this.source[this.index];}if(ch==='.'){num+=this.source[this.index++];while(character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))){num+=this.source[this.index++];}ch=this.source[this.index];}if(ch==='e'||ch==='E'){num+=this.source[this.index++];ch=this.source[this.index];if(ch==='+'||ch==='-'){num+=this.source[this.index++];}if(character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))){while(character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))){num+=this.source[this.index++];}}else{this.throwUnexpectedToken();}}if(character_1.Character.isIdentifierStart(this.source.charCodeAt(this.index))){this.throwUnexpectedToken();}return{type:6/* NumericLiteral */,value:parseFloat(num),lineNumber:this.lineNumber,lineStart:this.lineStart,start:start,end:this.index};};// https://tc39.github.io/ecma262/#sec-literals-string-literals
Scanner.prototype.scanStringLiteral=function(){var start=this.index;var quote=this.source[start];assert_1.assert(quote==='\''||quote==='"','String literal must starts with a quote');++this.index;var octal=false;var str='';while(!this.eof()){var ch=this.source[this.index++];if(ch===quote){quote='';break;}else if(ch==='\\'){ch=this.source[this.index++];if(!ch||!character_1.Character.isLineTerminator(ch.charCodeAt(0))){switch(ch){case'u':if(this.source[this.index]==='{'){++this.index;str+=this.scanUnicodeCodePointEscape();}else{var unescaped_1=this.scanHexEscape(ch);if(unescaped_1===null){this.throwUnexpectedToken();}str+=unescaped_1;}break;case'x':var unescaped=this.scanHexEscape(ch);if(unescaped===null){this.throwUnexpectedToken(messages_1.Messages.InvalidHexEscapeSequence);}str+=unescaped;break;case'n':str+='\n';break;case'r':str+='\r';break;case't':str+='\t';break;case'b':str+='\b';break;case'f':str+='\f';break;case'v':str+='\x0B';break;case'8':case'9':str+=ch;this.tolerateUnexpectedToken();break;default:if(ch&&character_1.Character.isOctalDigit(ch.charCodeAt(0))){var octToDec=this.octalToDecimal(ch);octal=octToDec.octal||octal;str+=String.fromCharCode(octToDec.code);}else{str+=ch;}break;}}else{++this.lineNumber;if(ch==='\r'&&this.source[this.index]==='\n'){++this.index;}this.lineStart=this.index;}}else if(character_1.Character.isLineTerminator(ch.charCodeAt(0))){break;}else{str+=ch;}}if(quote!==''){this.index=start;this.throwUnexpectedToken();}return{type:8/* StringLiteral */,value:str,octal:octal,lineNumber:this.lineNumber,lineStart:this.lineStart,start:start,end:this.index};};// https://tc39.github.io/ecma262/#sec-template-literal-lexical-components
Scanner.prototype.scanTemplate=function(){var cooked='';var terminated=false;var start=this.index;var head=this.source[start]==='`';var tail=false;var rawOffset=2;++this.index;while(!this.eof()){var ch=this.source[this.index++];if(ch==='`'){rawOffset=1;tail=true;terminated=true;break;}else if(ch==='$'){if(this.source[this.index]==='{'){this.curlyStack.push('${');++this.index;terminated=true;break;}cooked+=ch;}else if(ch==='\\'){ch=this.source[this.index++];if(!character_1.Character.isLineTerminator(ch.charCodeAt(0))){switch(ch){case'n':cooked+='\n';break;case'r':cooked+='\r';break;case't':cooked+='\t';break;case'u':if(this.source[this.index]==='{'){++this.index;cooked+=this.scanUnicodeCodePointEscape();}else{var restore=this.index;var unescaped_2=this.scanHexEscape(ch);if(unescaped_2!==null){cooked+=unescaped_2;}else{this.index=restore;cooked+=ch;}}break;case'x':var unescaped=this.scanHexEscape(ch);if(unescaped===null){this.throwUnexpectedToken(messages_1.Messages.InvalidHexEscapeSequence);}cooked+=unescaped;break;case'b':cooked+='\b';break;case'f':cooked+='\f';break;case'v':cooked+='\v';break;default:if(ch==='0'){if(character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))){// Illegal: \01 \02 and so on
this.throwUnexpectedToken(messages_1.Messages.TemplateOctalLiteral);}cooked+='\0';}else if(character_1.Character.isOctalDigit(ch.charCodeAt(0))){// Illegal: \1 \2
this.throwUnexpectedToken(messages_1.Messages.TemplateOctalLiteral);}else{cooked+=ch;}break;}}else{++this.lineNumber;if(ch==='\r'&&this.source[this.index]==='\n'){++this.index;}this.lineStart=this.index;}}else if(character_1.Character.isLineTerminator(ch.charCodeAt(0))){++this.lineNumber;if(ch==='\r'&&this.source[this.index]==='\n'){++this.index;}this.lineStart=this.index;cooked+='\n';}else{cooked+=ch;}}if(!terminated){this.throwUnexpectedToken();}if(!head){this.curlyStack.pop();}return{type:10/* Template */,value:this.source.slice(start+1,this.index-rawOffset),cooked:cooked,head:head,tail:tail,lineNumber:this.lineNumber,lineStart:this.lineStart,start:start,end:this.index};};// https://tc39.github.io/ecma262/#sec-literals-regular-expression-literals
Scanner.prototype.testRegExp=function(pattern,flags){// The BMP character to use as a replacement for astral symbols when
// translating an ES6 "u"-flagged pattern to an ES5-compatible
// approximation.
// Note: replacing with '\uFFFF' enables false positives in unlikely
// scenarios. For example, `[\u{1044f}-\u{10440}]` is an invalid
// pattern that would not be detected by this substitution.
var astralSubstitute='\uFFFF';var tmp=pattern;var self=this;if(flags.indexOf('u')>=0){tmp=tmp.replace(/\\u\{([0-9a-fA-F]+)\}|\\u([a-fA-F0-9]{4})/g,function($0,$1,$2){var codePoint=parseInt($1||$2,16);if(codePoint>0x10FFFF){self.throwUnexpectedToken(messages_1.Messages.InvalidRegExp);}if(codePoint<=0xFFFF){return String.fromCharCode(codePoint);}return astralSubstitute;}).replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g,astralSubstitute);}// First, detect invalid regular expressions.
try{RegExp(tmp);}catch(e){this.throwUnexpectedToken(messages_1.Messages.InvalidRegExp);}// Return a regular expression object for this pattern-flag pair, or
// `null` in case the current environment doesn't support the flags it
// uses.
try{return new RegExp(pattern,flags);}catch(exception){/* istanbul ignore next */return null;}};Scanner.prototype.scanRegExpBody=function(){var ch=this.source[this.index];assert_1.assert(ch==='/','Regular expression literal must start with a slash');var str=this.source[this.index++];var classMarker=false;var terminated=false;while(!this.eof()){ch=this.source[this.index++];str+=ch;if(ch==='\\'){ch=this.source[this.index++];// https://tc39.github.io/ecma262/#sec-literals-regular-expression-literals
if(character_1.Character.isLineTerminator(ch.charCodeAt(0))){this.throwUnexpectedToken(messages_1.Messages.UnterminatedRegExp);}str+=ch;}else if(character_1.Character.isLineTerminator(ch.charCodeAt(0))){this.throwUnexpectedToken(messages_1.Messages.UnterminatedRegExp);}else if(classMarker){if(ch===']'){classMarker=false;}}else{if(ch==='/'){terminated=true;break;}else if(ch==='['){classMarker=true;}}}if(!terminated){this.throwUnexpectedToken(messages_1.Messages.UnterminatedRegExp);}// Exclude leading and trailing slash.
return str.substr(1,str.length-2);};Scanner.prototype.scanRegExpFlags=function(){var str='';var flags='';while(!this.eof()){var ch=this.source[this.index];if(!character_1.Character.isIdentifierPart(ch.charCodeAt(0))){break;}++this.index;if(ch==='\\'&&!this.eof()){ch=this.source[this.index];if(ch==='u'){++this.index;var restore=this.index;var char=this.scanHexEscape('u');if(char!==null){flags+=char;for(str+='\\u';restore<this.index;++restore){str+=this.source[restore];}}else{this.index=restore;flags+='u';str+='\\u';}this.tolerateUnexpectedToken();}else{str+='\\';this.tolerateUnexpectedToken();}}else{flags+=ch;str+=ch;}}return flags;};Scanner.prototype.scanRegExp=function(){var start=this.index;var pattern=this.scanRegExpBody();var flags=this.scanRegExpFlags();var value=this.testRegExp(pattern,flags);return{type:9/* RegularExpression */,value:'',pattern:pattern,flags:flags,regex:value,lineNumber:this.lineNumber,lineStart:this.lineStart,start:start,end:this.index};};Scanner.prototype.lex=function(){if(this.eof()){return{type:2/* EOF */,value:'',lineNumber:this.lineNumber,lineStart:this.lineStart,start:this.index,end:this.index};}var cp=this.source.charCodeAt(this.index);if(character_1.Character.isIdentifierStart(cp)){return this.scanIdentifier();}// Very common: ( and ) and ;
if(cp===0x28||cp===0x29||cp===0x3B){return this.scanPunctuator();}// String literal starts with single quote (U+0027) or double quote (U+0022).
if(cp===0x27||cp===0x22){return this.scanStringLiteral();}// Dot (.) U+002E can also start a floating-point number, hence the need
// to check the next character.
if(cp===0x2E){if(character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index+1))){return this.scanNumericLiteral();}return this.scanPunctuator();}if(character_1.Character.isDecimalDigit(cp)){return this.scanNumericLiteral();}// Template literals start with ` (U+0060) for template head
// or } (U+007D) for template middle or template tail.
if(cp===0x60||cp===0x7D&&this.curlyStack[this.curlyStack.length-1]==='${'){return this.scanTemplate();}// Possible identifier start in a surrogate pair.
if(cp>=0xD800&&cp<0xDFFF){if(character_1.Character.isIdentifierStart(this.codePointAt(this.index))){return this.scanIdentifier();}}return this.scanPunctuator();};return Scanner;}();exports.Scanner=Scanner;/***/},/* 13 */ /***/function(module,exports){"use strict";Object.defineProperty(exports,"__esModule",{value:true});exports.TokenName={};exports.TokenName[1/* BooleanLiteral */]='Boolean';exports.TokenName[2/* EOF */]='<end>';exports.TokenName[3/* Identifier */]='Identifier';exports.TokenName[4/* Keyword */]='Keyword';exports.TokenName[5/* NullLiteral */]='Null';exports.TokenName[6/* NumericLiteral */]='Numeric';exports.TokenName[7/* Punctuator */]='Punctuator';exports.TokenName[8/* StringLiteral */]='String';exports.TokenName[9/* RegularExpression */]='RegularExpression';exports.TokenName[10/* Template */]='Template';/***/},/* 14 */ /***/function(module,exports){"use strict";// Generated by generate-xhtml-entities.js. DO NOT MODIFY!
Object.defineProperty(exports,"__esModule",{value:true});exports.XHTMLEntities={quot:'\u0022',amp:'\u0026',apos:'\u0027',gt:'\u003E',nbsp:'\u00A0',iexcl:'\u00A1',cent:'\u00A2',pound:'\u00A3',curren:'\u00A4',yen:'\u00A5',brvbar:'\u00A6',sect:'\u00A7',uml:'\u00A8',copy:'\u00A9',ordf:'\u00AA',laquo:'\u00AB',not:'\u00AC',shy:'\u00AD',reg:'\u00AE',macr:'\u00AF',deg:'\u00B0',plusmn:'\u00B1',sup2:'\u00B2',sup3:'\u00B3',acute:'\u00B4',micro:'\u00B5',para:'\u00B6',middot:'\u00B7',cedil:'\u00B8',sup1:'\u00B9',ordm:'\u00BA',raquo:'\u00BB',frac14:'\u00BC',frac12:'\u00BD',frac34:'\u00BE',iquest:'\u00BF',Agrave:'\u00C0',Aacute:'\u00C1',Acirc:'\u00C2',Atilde:'\u00C3',Auml:'\u00C4',Aring:'\u00C5',AElig:'\u00C6',Ccedil:'\u00C7',Egrave:'\u00C8',Eacute:'\u00C9',Ecirc:'\u00CA',Euml:'\u00CB',Igrave:'\u00CC',Iacute:'\u00CD',Icirc:'\u00CE',Iuml:'\u00CF',ETH:'\u00D0',Ntilde:'\u00D1',Ograve:'\u00D2',Oacute:'\u00D3',Ocirc:'\u00D4',Otilde:'\u00D5',Ouml:'\u00D6',times:'\u00D7',Oslash:'\u00D8',Ugrave:'\u00D9',Uacute:'\u00DA',Ucirc:'\u00DB',Uuml:'\u00DC',Yacute:'\u00DD',THORN:'\u00DE',szlig:'\u00DF',agrave:'\u00E0',aacute:'\u00E1',acirc:'\u00E2',atilde:'\u00E3',auml:'\u00E4',aring:'\u00E5',aelig:'\u00E6',ccedil:'\u00E7',egrave:'\u00E8',eacute:'\u00E9',ecirc:'\u00EA',euml:'\u00EB',igrave:'\u00EC',iacute:'\u00ED',icirc:'\u00EE',iuml:'\u00EF',eth:'\u00F0',ntilde:'\u00F1',ograve:'\u00F2',oacute:'\u00F3',ocirc:'\u00F4',otilde:'\u00F5',ouml:'\u00F6',divide:'\u00F7',oslash:'\u00F8',ugrave:'\u00F9',uacute:'\u00FA',ucirc:'\u00FB',uuml:'\u00FC',yacute:'\u00FD',thorn:'\u00FE',yuml:'\u00FF',OElig:'\u0152',oelig:'\u0153',Scaron:'\u0160',scaron:'\u0161',Yuml:'\u0178',fnof:'\u0192',circ:'\u02C6',tilde:'\u02DC',Alpha:'\u0391',Beta:'\u0392',Gamma:'\u0393',Delta:'\u0394',Epsilon:'\u0395',Zeta:'\u0396',Eta:'\u0397',Theta:'\u0398',Iota:'\u0399',Kappa:'\u039A',Lambda:'\u039B',Mu:'\u039C',Nu:'\u039D',Xi:'\u039E',Omicron:'\u039F',Pi:'\u03A0',Rho:'\u03A1',Sigma:'\u03A3',Tau:'\u03A4',Upsilon:'\u03A5',Phi:'\u03A6',Chi:'\u03A7',Psi:'\u03A8',Omega:'\u03A9',alpha:'\u03B1',beta:'\u03B2',gamma:'\u03B3',delta:'\u03B4',epsilon:'\u03B5',zeta:'\u03B6',eta:'\u03B7',theta:'\u03B8',iota:'\u03B9',kappa:'\u03BA',lambda:'\u03BB',mu:'\u03BC',nu:'\u03BD',xi:'\u03BE',omicron:'\u03BF',pi:'\u03C0',rho:'\u03C1',sigmaf:'\u03C2',sigma:'\u03C3',tau:'\u03C4',upsilon:'\u03C5',phi:'\u03C6',chi:'\u03C7',psi:'\u03C8',omega:'\u03C9',thetasym:'\u03D1',upsih:'\u03D2',piv:'\u03D6',ensp:'\u2002',emsp:'\u2003',thinsp:'\u2009',zwnj:'\u200C',zwj:'\u200D',lrm:'\u200E',rlm:'\u200F',ndash:'\u2013',mdash:'\u2014',lsquo:'\u2018',rsquo:'\u2019',sbquo:'\u201A',ldquo:'\u201C',rdquo:'\u201D',bdquo:'\u201E',dagger:'\u2020',Dagger:'\u2021',bull:'\u2022',hellip:'\u2026',permil:'\u2030',prime:'\u2032',Prime:'\u2033',lsaquo:'\u2039',rsaquo:'\u203A',oline:'\u203E',frasl:'\u2044',euro:'\u20AC',image:'\u2111',weierp:'\u2118',real:'\u211C',trade:'\u2122',alefsym:'\u2135',larr:'\u2190',uarr:'\u2191',rarr:'\u2192',darr:'\u2193',harr:'\u2194',crarr:'\u21B5',lArr:'\u21D0',uArr:'\u21D1',rArr:'\u21D2',dArr:'\u21D3',hArr:'\u21D4',forall:'\u2200',part:'\u2202',exist:'\u2203',empty:'\u2205',nabla:'\u2207',isin:'\u2208',notin:'\u2209',ni:'\u220B',prod:'\u220F',sum:'\u2211',minus:'\u2212',lowast:'\u2217',radic:'\u221A',prop:'\u221D',infin:'\u221E',ang:'\u2220',and:'\u2227',or:'\u2228',cap:'\u2229',cup:'\u222A',int:'\u222B',there4:'\u2234',sim:'\u223C',cong:'\u2245',asymp:'\u2248',ne:'\u2260',equiv:'\u2261',le:'\u2264',ge:'\u2265',sub:'\u2282',sup:'\u2283',nsub:'\u2284',sube:'\u2286',supe:'\u2287',oplus:'\u2295',otimes:'\u2297',perp:'\u22A5',sdot:'\u22C5',lceil:'\u2308',rceil:'\u2309',lfloor:'\u230A',rfloor:'\u230B',loz:'\u25CA',spades:'\u2660',clubs:'\u2663',hearts:'\u2665',diams:'\u2666',lang:'\u27E8',rang:'\u27E9'};/***/},/* 15 */ /***/function(module,exports,__webpack_require__){"use strict";Object.defineProperty(exports,"__esModule",{value:true});var error_handler_1=__webpack_require__(10);var scanner_1=__webpack_require__(12);var token_1=__webpack_require__(13);var Reader=function(){function Reader(){this.values=[];this.curly=this.paren=-1;}// A function following one of those tokens is an expression.
Reader.prototype.beforeFunctionExpression=function(t){return['(','{','[','in','typeof','instanceof','new','return','case','delete','throw','void',// assignment operators
'=','+=','-=','*=','**=','/=','%=','<<=','>>=','>>>=','&=','|=','^=',',',// binary/unary operators
'+','-','*','**','/','%','++','--','<<','>>','>>>','&','|','^','!','~','&&','||','?',':','===','==','>=','<=','<','>','!=','!=='].indexOf(t)>=0;};// Determine if forward slash (/) is an operator or part of a regular expression
// https://github.com/mozilla/sweet.js/wiki/design
Reader.prototype.isRegexStart=function(){var previous=this.values[this.values.length-1];var regex=previous!==null;switch(previous){case'this':case']':regex=false;break;case')':var keyword=this.values[this.paren-1];regex=keyword==='if'||keyword==='while'||keyword==='for'||keyword==='with';break;case'}':// Dividing a function by anything makes little sense,
// but we have to check for that.
regex=false;if(this.values[this.curly-3]==='function'){// Anonymous function, e.g. function(){} /42
var check=this.values[this.curly-4];regex=check?!this.beforeFunctionExpression(check):false;}else if(this.values[this.curly-4]==='function'){// Named function, e.g. function f(){} /42/
var check=this.values[this.curly-5];regex=check?!this.beforeFunctionExpression(check):true;}break;default:break;}return regex;};Reader.prototype.push=function(token){if(token.type===7/* Punctuator */||token.type===4/* Keyword */){if(token.value==='{'){this.curly=this.values.length;}else if(token.value==='('){this.paren=this.values.length;}this.values.push(token.value);}else{this.values.push(null);}};return Reader;}();var Tokenizer=function(){function Tokenizer(code,config){this.errorHandler=new error_handler_1.ErrorHandler();this.errorHandler.tolerant=config?typeof config.tolerant==='boolean'&&config.tolerant:false;this.scanner=new scanner_1.Scanner(code,this.errorHandler);this.scanner.trackComment=config?typeof config.comment==='boolean'&&config.comment:false;this.trackRange=config?typeof config.range==='boolean'&&config.range:false;this.trackLoc=config?typeof config.loc==='boolean'&&config.loc:false;this.buffer=[];this.reader=new Reader();}Tokenizer.prototype.errors=function(){return this.errorHandler.errors;};Tokenizer.prototype.getNextToken=function(){if(this.buffer.length===0){var comments=this.scanner.scanComments();if(this.scanner.trackComment){for(var i=0;i<comments.length;++i){var e=comments[i];var value=this.scanner.source.slice(e.slice[0],e.slice[1]);var comment={type:e.multiLine?'BlockComment':'LineComment',value:value};if(this.trackRange){comment.range=e.range;}if(this.trackLoc){comment.loc=e.loc;}this.buffer.push(comment);}}if(!this.scanner.eof()){var loc=void 0;if(this.trackLoc){loc={start:{line:this.scanner.lineNumber,column:this.scanner.index-this.scanner.lineStart},end:{}};}var startRegex=this.scanner.source[this.scanner.index]==='/'&&this.reader.isRegexStart();var token=startRegex?this.scanner.scanRegExp():this.scanner.lex();this.reader.push(token);var entry={type:token_1.TokenName[token.type],value:this.scanner.source.slice(token.start,token.end)};if(this.trackRange){entry.range=[token.start,token.end];}if(this.trackLoc){loc.end={line:this.scanner.lineNumber,column:this.scanner.index-this.scanner.lineStart};entry.loc=loc;}if(token.type===9/* RegularExpression */){var pattern=token.pattern;var flags=token.flags;entry.regex={pattern:pattern,flags:flags};}this.buffer.push(entry);}}return this.buffer.shift();};return Tokenizer;}();exports.Tokenizer=Tokenizer;/***/}/******/]));});;

/***/ }),

/***/ "../../../node_modules/exenv/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var __WEBPACK_AMD_DEFINE_RESULT__;/*!
  Copyright (c) 2015 Jed Watson.
  Based on code that is Copyright 2013-2015, Facebook, Inc.
  All rights reserved.
*/ /* global define */(function(){'use strict';var canUseDOM=!!(typeof window!=='undefined'&&window.document&&window.document.createElement);var ExecutionEnvironment={canUseDOM:canUseDOM,canUseWorkers:typeof Worker!=='undefined',canUseEventListeners:canUseDOM&&!!(window.addEventListener||window.attachEvent),canUseViewport:canUseDOM&&!!window.screen};if(true){!(__WEBPACK_AMD_DEFINE_RESULT__ = (function(){return ExecutionEnvironment;}).call(exports, __webpack_require__, exports, module),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));}else if(typeof module!=='undefined'&&module.exports){module.exports=ExecutionEnvironment;}else{window.ExecutionEnvironment=ExecutionEnvironment;}})();

/***/ }),

/***/ "../../../node_modules/fuse.js/dist/fuse.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*!
 * Fuse.js v3.6.1 - Lightweight fuzzy-search (http://fusejs.io)
 * 
 * Copyright (c) 2012-2017 Kirollos Risk (http://kiro.me)
 * All Rights Reserved. Apache Software License 2.0
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 */!function(e,t){ true?module.exports=t():"function"==typeof define&&define.amd?define("Fuse",[],t):"object"==typeof exports?exports.Fuse=t():e.Fuse=t();}(void 0,function(){return function(e){var t={};function r(n){if(t[n])return t[n].exports;var o=t[n]={i:n,l:!1,exports:{}};return e[n].call(o.exports,o,o.exports,r),o.l=!0,o.exports;}return r.m=e,r.c=t,r.d=function(e,t,n){r.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:n});},r.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0});},r.t=function(e,t){if(1&t&&(e=r(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var n=Object.create(null);if(r.r(n),Object.defineProperty(n,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var o in e)r.d(n,o,function(t){return e[t];}.bind(null,o));return n;},r.n=function(e){var t=e&&e.__esModule?function(){return e.default;}:function(){return e;};return r.d(t,"a",t),t;},r.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t);},r.p="",r(r.s=0);}([function(e,t,r){function n(e){return(n="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e;}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e;})(e);}function o(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n);}}var i=r(1),a=r(7),s=a.get,c=(a.deepValue,a.isArray),h=function(){function e(t,r){var n=r.location,o=void 0===n?0:n,i=r.distance,a=void 0===i?100:i,c=r.threshold,h=void 0===c?.6:c,l=r.maxPatternLength,u=void 0===l?32:l,f=r.caseSensitive,v=void 0!==f&&f,p=r.tokenSeparator,d=void 0===p?/ +/g:p,g=r.findAllMatches,y=void 0!==g&&g,m=r.minMatchCharLength,k=void 0===m?1:m,b=r.id,S=void 0===b?null:b,x=r.keys,M=void 0===x?[]:x,_=r.shouldSort,w=void 0===_||_,L=r.getFn,A=void 0===L?s:L,O=r.sortFn,C=void 0===O?function(e,t){return e.score-t.score;}:O,j=r.tokenize,P=void 0!==j&&j,I=r.matchAllTokens,F=void 0!==I&&I,T=r.includeMatches,N=void 0!==T&&T,z=r.includeScore,E=void 0!==z&&z,W=r.verbose,K=void 0!==W&&W;!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function");}(this,e),this.options={location:o,distance:a,threshold:h,maxPatternLength:u,isCaseSensitive:v,tokenSeparator:d,findAllMatches:y,minMatchCharLength:k,id:S,keys:M,includeMatches:N,includeScore:E,shouldSort:w,getFn:A,sortFn:C,verbose:K,tokenize:P,matchAllTokens:F},this.setCollection(t),this._processKeys(M);}var t,r,a;return t=e,(r=[{key:"setCollection",value:function(e){return this.list=e,e;}},{key:"_processKeys",value:function(e){if(this._keyWeights={},this._keyNames=[],e.length&&"string"==typeof e[0])for(var t=0,r=e.length;t<r;t+=1){var n=e[t];this._keyWeights[n]=1,this._keyNames.push(n);}else{for(var o=null,i=null,a=0,s=0,c=e.length;s<c;s+=1){var h=e[s];if(!h.hasOwnProperty("name"))throw new Error('Missing "name" property in key object');var l=h.name;if(this._keyNames.push(l),!h.hasOwnProperty("weight"))throw new Error('Missing "weight" property in key object');var u=h.weight;if(u<0||u>1)throw new Error('"weight" property in key must bein the range of [0, 1)');i=null==i?u:Math.max(i,u),o=null==o?u:Math.min(o,u),this._keyWeights[l]=u,a+=u;}if(a>1)throw new Error("Total of weights cannot exceed 1");}}},{key:"search",value:function(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{limit:!1};this._log('---------\nSearch pattern: "'.concat(e,'"'));var r=this._prepareSearchers(e),n=r.tokenSearchers,o=r.fullSearcher,i=this._search(n,o);return this._computeScore(i),this.options.shouldSort&&this._sort(i),t.limit&&"number"==typeof t.limit&&(i=i.slice(0,t.limit)),this._format(i);}},{key:"_prepareSearchers",value:function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"",t=[];if(this.options.tokenize)for(var r=e.split(this.options.tokenSeparator),n=0,o=r.length;n<o;n+=1)t.push(new i(r[n],this.options));return{tokenSearchers:t,fullSearcher:new i(e,this.options)};}},{key:"_search",value:function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:[],t=arguments.length>1?arguments[1]:void 0,r=this.list,n={},o=[];if("string"==typeof r[0]){for(var i=0,a=r.length;i<a;i+=1)this._analyze({key:"",value:r[i],record:i,index:i},{resultMap:n,results:o,tokenSearchers:e,fullSearcher:t});return o;}for(var s=0,c=r.length;s<c;s+=1)for(var h=r[s],l=0,u=this._keyNames.length;l<u;l+=1){var f=this._keyNames[l];this._analyze({key:f,value:this.options.getFn(h,f),record:h,index:s},{resultMap:n,results:o,tokenSearchers:e,fullSearcher:t});}return o;}},{key:"_analyze",value:function(e,t){var r=this,n=e.key,o=e.arrayIndex,i=void 0===o?-1:o,a=e.value,s=e.record,h=e.index,l=t.tokenSearchers,u=void 0===l?[]:l,f=t.fullSearcher,v=t.resultMap,p=void 0===v?{}:v,d=t.results,g=void 0===d?[]:d;!function e(t,o,i,a){if(null!=o)if("string"==typeof o){var s=!1,h=-1,l=0;r._log("\nKey: ".concat(""===n?"--":n));var v=f.search(o);if(r._log('Full text: "'.concat(o,'", score: ').concat(v.score)),r.options.tokenize){for(var d=o.split(r.options.tokenSeparator),y=d.length,m=[],k=0,b=u.length;k<b;k+=1){var S=u[k];r._log('\nPattern: "'.concat(S.pattern,'"'));for(var x=!1,M=0;M<y;M+=1){var _=d[M],w=S.search(_),L={};w.isMatch?(L[_]=w.score,s=!0,x=!0,m.push(w.score)):(L[_]=1,r.options.matchAllTokens||m.push(1)),r._log('Token: "'.concat(_,'", score: ').concat(L[_]));}x&&(l+=1);}h=m[0];for(var A=m.length,O=1;O<A;O+=1)h+=m[O];h/=A,r._log("Token score average:",h);}var C=v.score;h>-1&&(C=(C+h)/2),r._log("Score average:",C);var j=!r.options.tokenize||!r.options.matchAllTokens||l>=u.length;if(r._log("\nCheck Matches: ".concat(j)),(s||v.isMatch)&&j){var P={key:n,arrayIndex:t,value:o,score:C};r.options.includeMatches&&(P.matchedIndices=v.matchedIndices);var I=p[a];I?I.output.push(P):(p[a]={item:i,output:[P]},g.push(p[a]));}}else if(c(o))for(var F=0,T=o.length;F<T;F+=1)e(F,o[F],i,a);}(i,a,s,h);}},{key:"_computeScore",value:function(e){this._log("\n\nComputing score:\n");for(var t=this._keyWeights,r=!!Object.keys(t).length,n=0,o=e.length;n<o;n+=1){for(var i=e[n],a=i.output,s=a.length,c=1,h=0;h<s;h+=1){var l=a[h],u=l.key,f=r?t[u]:1,v=0===l.score&&t&&t[u]>0?Number.EPSILON:l.score;c*=Math.pow(v,f);}i.score=c,this._log(i);}}},{key:"_sort",value:function(e){this._log("\n\nSorting...."),e.sort(this.options.sortFn);}},{key:"_format",value:function(e){var t=[];if(this.options.verbose){var r=[];this._log("\n\nOutput:\n\n",JSON.stringify(e,function(e,t){if("object"===n(t)&&null!==t){if(-1!==r.indexOf(t))return;r.push(t);}return t;},2)),r=null;}var o=[];this.options.includeMatches&&o.push(function(e,t){var r=e.output;t.matches=[];for(var n=0,o=r.length;n<o;n+=1){var i=r[n];if(0!==i.matchedIndices.length){var a={indices:i.matchedIndices,value:i.value};i.key&&(a.key=i.key),i.hasOwnProperty("arrayIndex")&&i.arrayIndex>-1&&(a.arrayIndex=i.arrayIndex),t.matches.push(a);}}}),this.options.includeScore&&o.push(function(e,t){t.score=e.score;});for(var i=0,a=e.length;i<a;i+=1){var s=e[i];if(this.options.id&&(s.item=this.options.getFn(s.item,this.options.id)[0]),o.length){for(var c={item:s.item},h=0,l=o.length;h<l;h+=1)o[h](s,c);t.push(c);}else t.push(s.item);}return t;}},{key:"_log",value:function(){var e;this.options.verbose&&(e=console).log.apply(e,arguments);}}])&&o(t.prototype,r),a&&o(t,a),e;}();e.exports=h;},function(e,t,r){function n(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n);}}var o=r(2),i=r(3),a=r(6),s=function(){function e(t,r){var n=r.location,o=void 0===n?0:n,i=r.distance,s=void 0===i?100:i,c=r.threshold,h=void 0===c?.6:c,l=r.maxPatternLength,u=void 0===l?32:l,f=r.isCaseSensitive,v=void 0!==f&&f,p=r.tokenSeparator,d=void 0===p?/ +/g:p,g=r.findAllMatches,y=void 0!==g&&g,m=r.minMatchCharLength,k=void 0===m?1:m,b=r.includeMatches,S=void 0!==b&&b;!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function");}(this,e),this.options={location:o,distance:s,threshold:h,maxPatternLength:u,isCaseSensitive:v,tokenSeparator:d,findAllMatches:y,includeMatches:S,minMatchCharLength:k},this.pattern=v?t:t.toLowerCase(),this.pattern.length<=u&&(this.patternAlphabet=a(this.pattern));}var t,r,s;return t=e,(r=[{key:"search",value:function(e){var t=this.options,r=t.isCaseSensitive,n=t.includeMatches;if(r||(e=e.toLowerCase()),this.pattern===e){var a={isMatch:!0,score:0};return n&&(a.matchedIndices=[[0,e.length-1]]),a;}var s=this.options,c=s.maxPatternLength,h=s.tokenSeparator;if(this.pattern.length>c)return o(e,this.pattern,h);var l=this.options,u=l.location,f=l.distance,v=l.threshold,p=l.findAllMatches,d=l.minMatchCharLength;return i(e,this.pattern,this.patternAlphabet,{location:u,distance:f,threshold:v,findAllMatches:p,minMatchCharLength:d,includeMatches:n});}}])&&n(t.prototype,r),s&&n(t,s),e;}();e.exports=s;},function(e,t){var r=/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g;e.exports=function(e,t){var n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:/ +/g,o=new RegExp(t.replace(r,"\\$&").replace(n,"|")),i=e.match(o),a=!!i,s=[];if(a)for(var c=0,h=i.length;c<h;c+=1){var l=i[c];s.push([e.indexOf(l),l.length-1]);}return{score:a?.5:1,isMatch:a,matchedIndices:s};};},function(e,t,r){var n=r(4),o=r(5);e.exports=function(e,t,r,i){for(var a=i.location,s=void 0===a?0:a,c=i.distance,h=void 0===c?100:c,l=i.threshold,u=void 0===l?.6:l,f=i.findAllMatches,v=void 0!==f&&f,p=i.minMatchCharLength,d=void 0===p?1:p,g=i.includeMatches,y=void 0!==g&&g,m=s,k=e.length,b=u,S=e.indexOf(t,m),x=t.length,M=[],_=0;_<k;_+=1)M[_]=0;if(-1!==S){var w=n(t,{errors:0,currentLocation:S,expectedLocation:m,distance:h});if(b=Math.min(w,b),-1!==(S=e.lastIndexOf(t,m+x))){var L=n(t,{errors:0,currentLocation:S,expectedLocation:m,distance:h});b=Math.min(L,b);}}S=-1;for(var A=[],O=1,C=x+k,j=1<<(x<=31?x-1:30),P=0;P<x;P+=1){for(var I=0,F=C;I<F;){n(t,{errors:P,currentLocation:m+F,expectedLocation:m,distance:h})<=b?I=F:C=F,F=Math.floor((C-I)/2+I);}C=F;var T=Math.max(1,m-F+1),N=v?k:Math.min(m+F,k)+x,z=Array(N+2);z[N+1]=(1<<P)-1;for(var E=N;E>=T;E-=1){var W=E-1,K=r[e.charAt(W)];if(K&&(M[W]=1),z[E]=(z[E+1]<<1|1)&K,0!==P&&(z[E]|=(A[E+1]|A[E])<<1|1|A[E+1]),z[E]&j&&(O=n(t,{errors:P,currentLocation:W,expectedLocation:m,distance:h}))<=b){if(b=O,(S=W)<=m)break;T=Math.max(1,2*m-S);}}if(n(t,{errors:P+1,currentLocation:m,expectedLocation:m,distance:h})>b)break;A=z;}var $={isMatch:S>=0,score:0===O?.001:O};return y&&($.matchedIndices=o(M,d)),$;};},function(e,t){e.exports=function(e,t){var r=t.errors,n=void 0===r?0:r,o=t.currentLocation,i=void 0===o?0:o,a=t.expectedLocation,s=void 0===a?0:a,c=t.distance,h=void 0===c?100:c,l=n/e.length,u=Math.abs(s-i);return h?l+u/h:u?1:l;};},function(e,t){e.exports=function(){for(var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:[],t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:1,r=[],n=-1,o=-1,i=0,a=e.length;i<a;i+=1){var s=e[i];s&&-1===n?n=i:s||-1===n||((o=i-1)-n+1>=t&&r.push([n,o]),n=-1);}return e[i-1]&&i-n>=t&&r.push([n,i-1]),r;};},function(e,t){e.exports=function(e){for(var t={},r=e.length,n=0;n<r;n+=1)t[e.charAt(n)]=0;for(var o=0;o<r;o+=1)t[e.charAt(o)]|=1<<r-o-1;return t;};},function(e,t){var r=function(e){return Array.isArray?Array.isArray(e):"[object Array]"===Object.prototype.toString.call(e);},n=function(e){return null==e?"":function(e){if("string"==typeof e)return e;var t=e+"";return"0"==t&&1/e==-1/0?"-0":t;}(e);},o=function(e){return"string"==typeof e;},i=function(e){return"number"==typeof e;};e.exports={get:function(e,t){var a=[];return function e(t,s){if(s){var c=s.indexOf("."),h=s,l=null;-1!==c&&(h=s.slice(0,c),l=s.slice(c+1));var u=t[h];if(null!=u)if(l||!o(u)&&!i(u)){if(r(u))for(var f=0,v=u.length;f<v;f+=1)e(u[f],l);else l&&e(u,l);}else a.push(n(u));}else a.push(t);}(e,t),a;},isArray:r,isString:o,isNum:i,toString:n};}]);});

/***/ }),

/***/ "../../../node_modules/ieee754/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
exports.read=function(buffer,offset,isLE,mLen,nBytes){var e,m;var eLen=nBytes*8-mLen-1;var eMax=(1<<eLen)-1;var eBias=eMax>>1;var nBits=-7;var i=isLE?nBytes-1:0;var d=isLE?-1:1;var s=buffer[offset+i];i+=d;e=s&(1<<-nBits)-1;s>>=-nBits;nBits+=eLen;for(;nBits>0;e=e*256+buffer[offset+i],i+=d,nBits-=8){}m=e&(1<<-nBits)-1;e>>=-nBits;nBits+=mLen;for(;nBits>0;m=m*256+buffer[offset+i],i+=d,nBits-=8){}if(e===0){e=1-eBias;}else if(e===eMax){return m?NaN:(s?-1:1)*Infinity;}else{m=m+Math.pow(2,mLen);e=e-eBias;}return(s?-1:1)*m*Math.pow(2,e-mLen);};exports.write=function(buffer,value,offset,isLE,mLen,nBytes){var e,m,c;var eLen=nBytes*8-mLen-1;var eMax=(1<<eLen)-1;var eBias=eMax>>1;var rt=mLen===23?Math.pow(2,-24)-Math.pow(2,-77):0;var i=isLE?0:nBytes-1;var d=isLE?1:-1;var s=value<0||value===0&&1/value<0?1:0;value=Math.abs(value);if(isNaN(value)||value===Infinity){m=isNaN(value)?1:0;e=eMax;}else{e=Math.floor(Math.log(value)/Math.LN2);if(value*(c=Math.pow(2,-e))<1){e--;c*=2;}if(e+eBias>=1){value+=rt/c;}else{value+=rt*Math.pow(2,1-eBias);}if(value*c>=2){e++;c/=2;}if(e+eBias>=eMax){m=0;e=eMax;}else if(e+eBias>=1){m=(value*c-1)*Math.pow(2,mLen);e=e+eBias;}else{m=value*Math.pow(2,eBias-1)*Math.pow(2,mLen);e=0;}}for(;mLen>=8;buffer[offset+i]=m&0xff,i+=d,m/=256,mLen-=8){}e=e<<mLen|m;eLen+=mLen;for(;eLen>0;buffer[offset+i]=e&0xff,i+=d,e/=256,eLen-=8){}buffer[offset+i-d]|=s*128;};

/***/ }),

/***/ "../../../node_modules/isarray/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var toString={}.toString;module.exports=Array.isArray||function(arr){return toString.call(arr)=='[object Array]';};

/***/ }),

/***/ "../../../node_modules/js-yaml/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var yaml=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml.js");module.exports=yaml;

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var loader=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/loader.js");var dumper=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/dumper.js");function deprecated(name){return function(){throw new Error('Function '+name+' is deprecated and cannot be used.');};}module.exports.Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");module.exports.Schema=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema.js");module.exports.FAILSAFE_SCHEMA=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/failsafe.js");module.exports.JSON_SCHEMA=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/json.js");module.exports.CORE_SCHEMA=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/core.js");module.exports.DEFAULT_SAFE_SCHEMA=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/default_safe.js");module.exports.DEFAULT_FULL_SCHEMA=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/default_full.js");module.exports.load=loader.load;module.exports.loadAll=loader.loadAll;module.exports.safeLoad=loader.safeLoad;module.exports.safeLoadAll=loader.safeLoadAll;module.exports.dump=dumper.dump;module.exports.safeDump=dumper.safeDump;module.exports.YAMLException=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/exception.js");// Deprecated schema names from JS-YAML 2.0.x
module.exports.MINIMAL_SCHEMA=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/failsafe.js");module.exports.SAFE_SCHEMA=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/default_safe.js");module.exports.DEFAULT_SCHEMA=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/default_full.js");// Deprecated functions from JS-YAML 1.x.x
module.exports.scan=deprecated('scan');module.exports.parse=deprecated('parse');module.exports.compose=deprecated('compose');module.exports.addConstructor=deprecated('addConstructor');

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/common.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
function isNothing(subject){return typeof subject==='undefined'||subject===null;}function isObject(subject){return typeof subject==='object'&&subject!==null;}function toArray(sequence){if(Array.isArray(sequence))return sequence;else if(isNothing(sequence))return[];return[sequence];}function extend(target,source){var index,length,key,sourceKeys;if(source){sourceKeys=Object.keys(source);for(index=0,length=sourceKeys.length;index<length;index+=1){key=sourceKeys[index];target[key]=source[key];}}return target;}function repeat(string,count){var result='',cycle;for(cycle=0;cycle<count;cycle+=1){result+=string;}return result;}function isNegativeZero(number){return number===0&&Number.NEGATIVE_INFINITY===1/number;}module.exports.isNothing=isNothing;module.exports.isObject=isObject;module.exports.toArray=toArray;module.exports.repeat=repeat;module.exports.isNegativeZero=isNegativeZero;module.exports.extend=extend;

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/dumper.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*eslint-disable no-use-before-define*/var common=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/common.js");var YAMLException=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/exception.js");var DEFAULT_FULL_SCHEMA=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/default_full.js");var DEFAULT_SAFE_SCHEMA=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/default_safe.js");var _toString=Object.prototype.toString;var _hasOwnProperty=Object.prototype.hasOwnProperty;var CHAR_TAB=0x09;/* Tab */var CHAR_LINE_FEED=0x0A;/* LF */var CHAR_SPACE=0x20;/* Space */var CHAR_EXCLAMATION=0x21;/* ! */var CHAR_DOUBLE_QUOTE=0x22;/* " */var CHAR_SHARP=0x23;/* # */var CHAR_PERCENT=0x25;/* % */var CHAR_AMPERSAND=0x26;/* & */var CHAR_SINGLE_QUOTE=0x27;/* ' */var CHAR_ASTERISK=0x2A;/* * */var CHAR_COMMA=0x2C;/* , */var CHAR_MINUS=0x2D;/* - */var CHAR_COLON=0x3A;/* : */var CHAR_GREATER_THAN=0x3E;/* > */var CHAR_QUESTION=0x3F;/* ? */var CHAR_COMMERCIAL_AT=0x40;/* @ */var CHAR_LEFT_SQUARE_BRACKET=0x5B;/* [ */var CHAR_RIGHT_SQUARE_BRACKET=0x5D;/* ] */var CHAR_GRAVE_ACCENT=0x60;/* ` */var CHAR_LEFT_CURLY_BRACKET=0x7B;/* { */var CHAR_VERTICAL_LINE=0x7C;/* | */var CHAR_RIGHT_CURLY_BRACKET=0x7D;/* } */var ESCAPE_SEQUENCES={};ESCAPE_SEQUENCES[0x00]='\\0';ESCAPE_SEQUENCES[0x07]='\\a';ESCAPE_SEQUENCES[0x08]='\\b';ESCAPE_SEQUENCES[0x09]='\\t';ESCAPE_SEQUENCES[0x0A]='\\n';ESCAPE_SEQUENCES[0x0B]='\\v';ESCAPE_SEQUENCES[0x0C]='\\f';ESCAPE_SEQUENCES[0x0D]='\\r';ESCAPE_SEQUENCES[0x1B]='\\e';ESCAPE_SEQUENCES[0x22]='\\"';ESCAPE_SEQUENCES[0x5C]='\\\\';ESCAPE_SEQUENCES[0x85]='\\N';ESCAPE_SEQUENCES[0xA0]='\\_';ESCAPE_SEQUENCES[0x2028]='\\L';ESCAPE_SEQUENCES[0x2029]='\\P';var DEPRECATED_BOOLEANS_SYNTAX=['y','Y','yes','Yes','YES','on','On','ON','n','N','no','No','NO','off','Off','OFF'];function compileStyleMap(schema,map){var result,keys,index,length,tag,style,type;if(map===null)return{};result={};keys=Object.keys(map);for(index=0,length=keys.length;index<length;index+=1){tag=keys[index];style=String(map[tag]);if(tag.slice(0,2)==='!!'){tag='tag:yaml.org,2002:'+tag.slice(2);}type=schema.compiledTypeMap['fallback'][tag];if(type&&_hasOwnProperty.call(type.styleAliases,style)){style=type.styleAliases[style];}result[tag]=style;}return result;}function encodeHex(character){var string,handle,length;string=character.toString(16).toUpperCase();if(character<=0xFF){handle='x';length=2;}else if(character<=0xFFFF){handle='u';length=4;}else if(character<=0xFFFFFFFF){handle='U';length=8;}else{throw new YAMLException('code point within a string may not be greater than 0xFFFFFFFF');}return'\\'+handle+common.repeat('0',length-string.length)+string;}function State(options){this.schema=options['schema']||DEFAULT_FULL_SCHEMA;this.indent=Math.max(1,options['indent']||2);this.noArrayIndent=options['noArrayIndent']||false;this.skipInvalid=options['skipInvalid']||false;this.flowLevel=common.isNothing(options['flowLevel'])?-1:options['flowLevel'];this.styleMap=compileStyleMap(this.schema,options['styles']||null);this.sortKeys=options['sortKeys']||false;this.lineWidth=options['lineWidth']||80;this.noRefs=options['noRefs']||false;this.noCompatMode=options['noCompatMode']||false;this.condenseFlow=options['condenseFlow']||false;this.implicitTypes=this.schema.compiledImplicit;this.explicitTypes=this.schema.compiledExplicit;this.tag=null;this.result='';this.duplicates=[];this.usedDuplicates=null;}// Indents every line in a string. Empty lines (\n only) are not indented.
function indentString(string,spaces){var ind=common.repeat(' ',spaces),position=0,next=-1,result='',line,length=string.length;while(position<length){next=string.indexOf('\n',position);if(next===-1){line=string.slice(position);position=length;}else{line=string.slice(position,next+1);position=next+1;}if(line.length&&line!=='\n')result+=ind;result+=line;}return result;}function generateNextLine(state,level){return'\n'+common.repeat(' ',state.indent*level);}function testImplicitResolving(state,str){var index,length,type;for(index=0,length=state.implicitTypes.length;index<length;index+=1){type=state.implicitTypes[index];if(type.resolve(str)){return true;}}return false;}// [33] s-white ::= s-space | s-tab
function isWhitespace(c){return c===CHAR_SPACE||c===CHAR_TAB;}// Returns true if the character can be printed without escaping.
// From YAML 1.2: "any allowed characters known to be non-printable
// should also be escaped. [However,] This isn’t mandatory"
// Derived from nb-char - \t - #x85 - #xA0 - #x2028 - #x2029.
function isPrintable(c){return 0x00020<=c&&c<=0x00007E||0x000A1<=c&&c<=0x00D7FF&&c!==0x2028&&c!==0x2029||0x0E000<=c&&c<=0x00FFFD&&c!==0xFEFF/* BOM */||0x10000<=c&&c<=0x10FFFF;}// Simplified test for values allowed after the first character in plain style.
function isPlainSafe(c){// Uses a subset of nb-char - c-flow-indicator - ":" - "#"
// where nb-char ::= c-printable - b-char - c-byte-order-mark.
return isPrintable(c)&&c!==0xFEFF// - c-flow-indicator
&&c!==CHAR_COMMA&&c!==CHAR_LEFT_SQUARE_BRACKET&&c!==CHAR_RIGHT_SQUARE_BRACKET&&c!==CHAR_LEFT_CURLY_BRACKET&&c!==CHAR_RIGHT_CURLY_BRACKET// - ":" - "#"
&&c!==CHAR_COLON&&c!==CHAR_SHARP;}// Simplified test for values allowed as the first character in plain style.
function isPlainSafeFirst(c){// Uses a subset of ns-char - c-indicator
// where ns-char = nb-char - s-white.
return isPrintable(c)&&c!==0xFEFF&&!isWhitespace(c)// - s-white
// - (c-indicator ::=
// “-” | “?” | “:” | “,” | “[” | “]” | “{” | “}”
&&c!==CHAR_MINUS&&c!==CHAR_QUESTION&&c!==CHAR_COLON&&c!==CHAR_COMMA&&c!==CHAR_LEFT_SQUARE_BRACKET&&c!==CHAR_RIGHT_SQUARE_BRACKET&&c!==CHAR_LEFT_CURLY_BRACKET&&c!==CHAR_RIGHT_CURLY_BRACKET// | “#” | “&” | “*” | “!” | “|” | “>” | “'” | “"”
&&c!==CHAR_SHARP&&c!==CHAR_AMPERSAND&&c!==CHAR_ASTERISK&&c!==CHAR_EXCLAMATION&&c!==CHAR_VERTICAL_LINE&&c!==CHAR_GREATER_THAN&&c!==CHAR_SINGLE_QUOTE&&c!==CHAR_DOUBLE_QUOTE// | “%” | “@” | “`”)
&&c!==CHAR_PERCENT&&c!==CHAR_COMMERCIAL_AT&&c!==CHAR_GRAVE_ACCENT;}// Determines whether block indentation indicator is required.
function needIndentIndicator(string){var leadingSpaceRe=/^\n* /;return leadingSpaceRe.test(string);}var STYLE_PLAIN=1,STYLE_SINGLE=2,STYLE_LITERAL=3,STYLE_FOLDED=4,STYLE_DOUBLE=5;// Determines which scalar styles are possible and returns the preferred style.
// lineWidth = -1 => no limit.
// Pre-conditions: str.length > 0.
// Post-conditions:
//    STYLE_PLAIN or STYLE_SINGLE => no \n are in the string.
//    STYLE_LITERAL => no lines are suitable for folding (or lineWidth is -1).
//    STYLE_FOLDED => a line > lineWidth and can be folded (and lineWidth != -1).
function chooseScalarStyle(string,singleLineOnly,indentPerLevel,lineWidth,testAmbiguousType){var i;var char;var hasLineBreak=false;var hasFoldableLine=false;// only checked if shouldTrackWidth
var shouldTrackWidth=lineWidth!==-1;var previousLineBreak=-1;// count the first line correctly
var plain=isPlainSafeFirst(string.charCodeAt(0))&&!isWhitespace(string.charCodeAt(string.length-1));if(singleLineOnly){// Case: no block styles.
// Check for disallowed characters to rule out plain and single.
for(i=0;i<string.length;i++){char=string.charCodeAt(i);if(!isPrintable(char)){return STYLE_DOUBLE;}plain=plain&&isPlainSafe(char);}}else{// Case: block styles permitted.
for(i=0;i<string.length;i++){char=string.charCodeAt(i);if(char===CHAR_LINE_FEED){hasLineBreak=true;// Check if any line can be folded.
if(shouldTrackWidth){hasFoldableLine=hasFoldableLine||// Foldable line = too long, and not more-indented.
i-previousLineBreak-1>lineWidth&&string[previousLineBreak+1]!==' ';previousLineBreak=i;}}else if(!isPrintable(char)){return STYLE_DOUBLE;}plain=plain&&isPlainSafe(char);}// in case the end is missing a \n
hasFoldableLine=hasFoldableLine||shouldTrackWidth&&i-previousLineBreak-1>lineWidth&&string[previousLineBreak+1]!==' ';}// Although every style can represent \n without escaping, prefer block styles
// for multiline, since they're more readable and they don't add empty lines.
// Also prefer folding a super-long line.
if(!hasLineBreak&&!hasFoldableLine){// Strings interpretable as another type have to be quoted;
// e.g. the string 'true' vs. the boolean true.
return plain&&!testAmbiguousType(string)?STYLE_PLAIN:STYLE_SINGLE;}// Edge case: block indentation indicator can only have one digit.
if(indentPerLevel>9&&needIndentIndicator(string)){return STYLE_DOUBLE;}// At this point we know block styles are valid.
// Prefer literal style unless we want to fold.
return hasFoldableLine?STYLE_FOLDED:STYLE_LITERAL;}// Note: line breaking/folding is implemented for only the folded style.
// NB. We drop the last trailing newline (if any) of a returned block scalar
//  since the dumper adds its own newline. This always works:
//    • No ending newline => unaffected; already using strip "-" chomping.
//    • Ending newline    => removed then restored.
//  Importantly, this keeps the "+" chomp indicator from gaining an extra line.
function writeScalar(state,string,level,iskey){state.dump=function(){if(string.length===0){return"''";}if(!state.noCompatMode&&DEPRECATED_BOOLEANS_SYNTAX.indexOf(string)!==-1){return"'"+string+"'";}var indent=state.indent*Math.max(1,level);// no 0-indent scalars
// As indentation gets deeper, let the width decrease monotonically
// to the lower bound min(state.lineWidth, 40).
// Note that this implies
//  state.lineWidth ≤ 40 + state.indent: width is fixed at the lower bound.
//  state.lineWidth > 40 + state.indent: width decreases until the lower bound.
// This behaves better than a constant minimum width which disallows narrower options,
// or an indent threshold which causes the width to suddenly increase.
var lineWidth=state.lineWidth===-1?-1:Math.max(Math.min(state.lineWidth,40),state.lineWidth-indent);// Without knowing if keys are implicit/explicit, assume implicit for safety.
var singleLineOnly=iskey// No block styles in flow mode.
||state.flowLevel>-1&&level>=state.flowLevel;function testAmbiguity(string){return testImplicitResolving(state,string);}switch(chooseScalarStyle(string,singleLineOnly,state.indent,lineWidth,testAmbiguity)){case STYLE_PLAIN:return string;case STYLE_SINGLE:return"'"+string.replace(/'/g,"''")+"'";case STYLE_LITERAL:return'|'+blockHeader(string,state.indent)+dropEndingNewline(indentString(string,indent));case STYLE_FOLDED:return'>'+blockHeader(string,state.indent)+dropEndingNewline(indentString(foldString(string,lineWidth),indent));case STYLE_DOUBLE:return'"'+escapeString(string,lineWidth)+'"';default:throw new YAMLException('impossible error: invalid scalar style');}}();}// Pre-conditions: string is valid for a block scalar, 1 <= indentPerLevel <= 9.
function blockHeader(string,indentPerLevel){var indentIndicator=needIndentIndicator(string)?String(indentPerLevel):'';// note the special case: the string '\n' counts as a "trailing" empty line.
var clip=string[string.length-1]==='\n';var keep=clip&&(string[string.length-2]==='\n'||string==='\n');var chomp=keep?'+':clip?'':'-';return indentIndicator+chomp+'\n';}// (See the note for writeScalar.)
function dropEndingNewline(string){return string[string.length-1]==='\n'?string.slice(0,-1):string;}// Note: a long line without a suitable break point will exceed the width limit.
// Pre-conditions: every char in str isPrintable, str.length > 0, width > 0.
function foldString(string,width){// In folded style, $k$ consecutive newlines output as $k+1$ newlines—
// unless they're before or after a more-indented line, or at the very
// beginning or end, in which case $k$ maps to $k$.
// Therefore, parse each chunk as newline(s) followed by a content line.
var lineRe=/(\n+)([^\n]*)/g;// first line (possibly an empty line)
var result=function(){var nextLF=string.indexOf('\n');nextLF=nextLF!==-1?nextLF:string.length;lineRe.lastIndex=nextLF;return foldLine(string.slice(0,nextLF),width);}();// If we haven't reached the first content line yet, don't add an extra \n.
var prevMoreIndented=string[0]==='\n'||string[0]===' ';var moreIndented;// rest of the lines
var match;while(match=lineRe.exec(string)){var prefix=match[1],line=match[2];moreIndented=line[0]===' ';result+=prefix+(!prevMoreIndented&&!moreIndented&&line!==''?'\n':'')+foldLine(line,width);prevMoreIndented=moreIndented;}return result;}// Greedy line breaking.
// Picks the longest line under the limit each time,
// otherwise settles for the shortest line over the limit.
// NB. More-indented lines *cannot* be folded, as that would add an extra \n.
function foldLine(line,width){if(line===''||line[0]===' ')return line;// Since a more-indented line adds a \n, breaks can't be followed by a space.
var breakRe=/ [^ ]/g;// note: the match index will always be <= length-2.
var match;// start is an inclusive index. end, curr, and next are exclusive.
var start=0,end,curr=0,next=0;var result='';// Invariants: 0 <= start <= length-1.
//   0 <= curr <= next <= max(0, length-2). curr - start <= width.
// Inside the loop:
//   A match implies length >= 2, so curr and next are <= length-2.
while(match=breakRe.exec(line)){next=match.index;// maintain invariant: curr - start <= width
if(next-start>width){end=curr>start?curr:next;// derive end <= length-2
result+='\n'+line.slice(start,end);// skip the space that was output as \n
start=end+1;// derive start <= length-1
}curr=next;}// By the invariants, start <= length-1, so there is something left over.
// It is either the whole string or a part starting from non-whitespace.
result+='\n';// Insert a break if the remainder is too long and there is a break available.
if(line.length-start>width&&curr>start){result+=line.slice(start,curr)+'\n'+line.slice(curr+1);}else{result+=line.slice(start);}return result.slice(1);// drop extra \n joiner
}// Escapes a double-quoted string.
function escapeString(string){var result='';var char,nextChar;var escapeSeq;for(var i=0;i<string.length;i++){char=string.charCodeAt(i);// Check for surrogate pairs (reference Unicode 3.0 section "3.7 Surrogates").
if(char>=0xD800&&char<=0xDBFF/* high surrogate */){nextChar=string.charCodeAt(i+1);if(nextChar>=0xDC00&&nextChar<=0xDFFF/* low surrogate */){// Combine the surrogate pair and store it escaped.
result+=encodeHex((char-0xD800)*0x400+nextChar-0xDC00+0x10000);// Advance index one extra since we already used that char here.
i++;continue;}}escapeSeq=ESCAPE_SEQUENCES[char];result+=!escapeSeq&&isPrintable(char)?string[i]:escapeSeq||encodeHex(char);}return result;}function writeFlowSequence(state,level,object){var _result='',_tag=state.tag,index,length;for(index=0,length=object.length;index<length;index+=1){// Write only valid elements.
if(writeNode(state,level,object[index],false,false)){if(index!==0)_result+=','+(!state.condenseFlow?' ':'');_result+=state.dump;}}state.tag=_tag;state.dump='['+_result+']';}function writeBlockSequence(state,level,object,compact){var _result='',_tag=state.tag,index,length;for(index=0,length=object.length;index<length;index+=1){// Write only valid elements.
if(writeNode(state,level+1,object[index],true,true)){if(!compact||index!==0){_result+=generateNextLine(state,level);}if(state.dump&&CHAR_LINE_FEED===state.dump.charCodeAt(0)){_result+='-';}else{_result+='- ';}_result+=state.dump;}}state.tag=_tag;state.dump=_result||'[]';// Empty sequence if no valid values.
}function writeFlowMapping(state,level,object){var _result='',_tag=state.tag,objectKeyList=Object.keys(object),index,length,objectKey,objectValue,pairBuffer;for(index=0,length=objectKeyList.length;index<length;index+=1){pairBuffer=state.condenseFlow?'"':'';if(index!==0)pairBuffer+=', ';objectKey=objectKeyList[index];objectValue=object[objectKey];if(!writeNode(state,level,objectKey,false,false)){continue;// Skip this pair because of invalid key;
}if(state.dump.length>1024)pairBuffer+='? ';pairBuffer+=state.dump+(state.condenseFlow?'"':'')+':'+(state.condenseFlow?'':' ');if(!writeNode(state,level,objectValue,false,false)){continue;// Skip this pair because of invalid value.
}pairBuffer+=state.dump;// Both key and value are valid.
_result+=pairBuffer;}state.tag=_tag;state.dump='{'+_result+'}';}function writeBlockMapping(state,level,object,compact){var _result='',_tag=state.tag,objectKeyList=Object.keys(object),index,length,objectKey,objectValue,explicitPair,pairBuffer;// Allow sorting keys so that the output file is deterministic
if(state.sortKeys===true){// Default sorting
objectKeyList.sort();}else if(typeof state.sortKeys==='function'){// Custom sort function
objectKeyList.sort(state.sortKeys);}else if(state.sortKeys){// Something is wrong
throw new YAMLException('sortKeys must be a boolean or a function');}for(index=0,length=objectKeyList.length;index<length;index+=1){pairBuffer='';if(!compact||index!==0){pairBuffer+=generateNextLine(state,level);}objectKey=objectKeyList[index];objectValue=object[objectKey];if(!writeNode(state,level+1,objectKey,true,true,true)){continue;// Skip this pair because of invalid key.
}explicitPair=state.tag!==null&&state.tag!=='?'||state.dump&&state.dump.length>1024;if(explicitPair){if(state.dump&&CHAR_LINE_FEED===state.dump.charCodeAt(0)){pairBuffer+='?';}else{pairBuffer+='? ';}}pairBuffer+=state.dump;if(explicitPair){pairBuffer+=generateNextLine(state,level);}if(!writeNode(state,level+1,objectValue,true,explicitPair)){continue;// Skip this pair because of invalid value.
}if(state.dump&&CHAR_LINE_FEED===state.dump.charCodeAt(0)){pairBuffer+=':';}else{pairBuffer+=': ';}pairBuffer+=state.dump;// Both key and value are valid.
_result+=pairBuffer;}state.tag=_tag;state.dump=_result||'{}';// Empty mapping if no valid pairs.
}function detectType(state,object,explicit){var _result,typeList,index,length,type,style;typeList=explicit?state.explicitTypes:state.implicitTypes;for(index=0,length=typeList.length;index<length;index+=1){type=typeList[index];if((type.instanceOf||type.predicate)&&(!type.instanceOf||typeof object==='object'&&object instanceof type.instanceOf)&&(!type.predicate||type.predicate(object))){state.tag=explicit?type.tag:'?';if(type.represent){style=state.styleMap[type.tag]||type.defaultStyle;if(_toString.call(type.represent)==='[object Function]'){_result=type.represent(object,style);}else if(_hasOwnProperty.call(type.represent,style)){_result=type.represent[style](object,style);}else{throw new YAMLException('!<'+type.tag+'> tag resolver accepts not "'+style+'" style');}state.dump=_result;}return true;}}return false;}// Serializes `object` and writes it to global `result`.
// Returns true on success, or false on invalid object.
//
function writeNode(state,level,object,block,compact,iskey){state.tag=null;state.dump=object;if(!detectType(state,object,false)){detectType(state,object,true);}var type=_toString.call(state.dump);if(block){block=state.flowLevel<0||state.flowLevel>level;}var objectOrArray=type==='[object Object]'||type==='[object Array]',duplicateIndex,duplicate;if(objectOrArray){duplicateIndex=state.duplicates.indexOf(object);duplicate=duplicateIndex!==-1;}if(state.tag!==null&&state.tag!=='?'||duplicate||state.indent!==2&&level>0){compact=false;}if(duplicate&&state.usedDuplicates[duplicateIndex]){state.dump='*ref_'+duplicateIndex;}else{if(objectOrArray&&duplicate&&!state.usedDuplicates[duplicateIndex]){state.usedDuplicates[duplicateIndex]=true;}if(type==='[object Object]'){if(block&&Object.keys(state.dump).length!==0){writeBlockMapping(state,level,state.dump,compact);if(duplicate){state.dump='&ref_'+duplicateIndex+state.dump;}}else{writeFlowMapping(state,level,state.dump);if(duplicate){state.dump='&ref_'+duplicateIndex+' '+state.dump;}}}else if(type==='[object Array]'){var arrayLevel=state.noArrayIndent&&level>0?level-1:level;if(block&&state.dump.length!==0){writeBlockSequence(state,arrayLevel,state.dump,compact);if(duplicate){state.dump='&ref_'+duplicateIndex+state.dump;}}else{writeFlowSequence(state,arrayLevel,state.dump);if(duplicate){state.dump='&ref_'+duplicateIndex+' '+state.dump;}}}else if(type==='[object String]'){if(state.tag!=='?'){writeScalar(state,state.dump,level,iskey);}}else{if(state.skipInvalid)return false;throw new YAMLException('unacceptable kind of an object to dump '+type);}if(state.tag!==null&&state.tag!=='?'){state.dump='!<'+state.tag+'> '+state.dump;}}return true;}function getDuplicateReferences(object,state){var objects=[],duplicatesIndexes=[],index,length;inspectNode(object,objects,duplicatesIndexes);for(index=0,length=duplicatesIndexes.length;index<length;index+=1){state.duplicates.push(objects[duplicatesIndexes[index]]);}state.usedDuplicates=new Array(length);}function inspectNode(object,objects,duplicatesIndexes){var objectKeyList,index,length;if(object!==null&&typeof object==='object'){index=objects.indexOf(object);if(index!==-1){if(duplicatesIndexes.indexOf(index)===-1){duplicatesIndexes.push(index);}}else{objects.push(object);if(Array.isArray(object)){for(index=0,length=object.length;index<length;index+=1){inspectNode(object[index],objects,duplicatesIndexes);}}else{objectKeyList=Object.keys(object);for(index=0,length=objectKeyList.length;index<length;index+=1){inspectNode(object[objectKeyList[index]],objects,duplicatesIndexes);}}}}}function dump(input,options){options=options||{};var state=new State(options);if(!state.noRefs)getDuplicateReferences(input,state);if(writeNode(state,0,input,true,true))return state.dump+'\n';return'';}function safeDump(input,options){return dump(input,common.extend({schema:DEFAULT_SAFE_SCHEMA},options));}module.exports.dump=dump;module.exports.safeDump=safeDump;

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/exception.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// YAML error class. http://stackoverflow.com/questions/8458984
//
function YAMLException(reason,mark){// Super constructor
Error.call(this);this.name='YAMLException';this.reason=reason;this.mark=mark;this.message=(this.reason||'(unknown reason)')+(this.mark?' '+this.mark.toString():'');// Include stack trace in error object
if(Error.captureStackTrace){// Chrome and NodeJS
Error.captureStackTrace(this,this.constructor);}else{// FF, IE 10+ and Safari 6+. Fallback for others
this.stack=new Error().stack||'';}}// Inherit from Error
YAMLException.prototype=Object.create(Error.prototype);YAMLException.prototype.constructor=YAMLException;YAMLException.prototype.toString=function toString(compact){var result=this.name+': ';result+=this.reason||'(unknown reason)';if(!compact&&this.mark){result+=' '+this.mark.toString();}return result;};module.exports=YAMLException;

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/loader.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*eslint-disable max-len,no-use-before-define*/var common=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/common.js");var YAMLException=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/exception.js");var Mark=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/mark.js");var DEFAULT_SAFE_SCHEMA=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/default_safe.js");var DEFAULT_FULL_SCHEMA=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/default_full.js");var _hasOwnProperty=Object.prototype.hasOwnProperty;var CONTEXT_FLOW_IN=1;var CONTEXT_FLOW_OUT=2;var CONTEXT_BLOCK_IN=3;var CONTEXT_BLOCK_OUT=4;var CHOMPING_CLIP=1;var CHOMPING_STRIP=2;var CHOMPING_KEEP=3;var PATTERN_NON_PRINTABLE=/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/;var PATTERN_NON_ASCII_LINE_BREAKS=/[\x85\u2028\u2029]/;var PATTERN_FLOW_INDICATORS=/[,\[\]\{\}]/;var PATTERN_TAG_HANDLE=/^(?:!|!!|![a-z\-]+!)$/i;var PATTERN_TAG_URI=/^(?:!|[^,\[\]\{\}])(?:%[0-9a-f]{2}|[0-9a-z\-#;\/\?:@&=\+\$,_\.!~\*'\(\)\[\]])*$/i;function _class(obj){return Object.prototype.toString.call(obj);}function is_EOL(c){return c===0x0A/* LF */||c===0x0D/* CR */;}function is_WHITE_SPACE(c){return c===0x09/* Tab */||c===0x20/* Space */;}function is_WS_OR_EOL(c){return c===0x09/* Tab */||c===0x20/* Space */||c===0x0A/* LF */||c===0x0D/* CR */;}function is_FLOW_INDICATOR(c){return c===0x2C/* , */||c===0x5B/* [ */||c===0x5D/* ] */||c===0x7B/* { */||c===0x7D/* } */;}function fromHexCode(c){var lc;if(0x30/* 0 */<=c&&c<=0x39/* 9 */){return c-0x30;}/*eslint-disable no-bitwise*/lc=c|0x20;if(0x61/* a */<=lc&&lc<=0x66/* f */){return lc-0x61+10;}return-1;}function escapedHexLen(c){if(c===0x78/* x */){return 2;}if(c===0x75/* u */){return 4;}if(c===0x55/* U */){return 8;}return 0;}function fromDecimalCode(c){if(0x30/* 0 */<=c&&c<=0x39/* 9 */){return c-0x30;}return-1;}function simpleEscapeSequence(c){/* eslint-disable indent */return c===0x30/* 0 */?'\x00':c===0x61/* a */?'\x07':c===0x62/* b */?'\x08':c===0x74/* t */?'\x09':c===0x09/* Tab */?'\x09':c===0x6E/* n */?'\x0A':c===0x76/* v */?'\x0B':c===0x66/* f */?'\x0C':c===0x72/* r */?'\x0D':c===0x65/* e */?'\x1B':c===0x20/* Space */?' ':c===0x22/* " */?'\x22':c===0x2F/* / */?'/':c===0x5C/* \ */?'\x5C':c===0x4E/* N */?'\x85':c===0x5F/* _ */?'\xA0':c===0x4C/* L */?'\u2028':c===0x50/* P */?'\u2029':'';}function charFromCodepoint(c){if(c<=0xFFFF){return String.fromCharCode(c);}// Encode UTF-16 surrogate pair
// https://en.wikipedia.org/wiki/UTF-16#Code_points_U.2B010000_to_U.2B10FFFF
return String.fromCharCode((c-0x010000>>10)+0xD800,(c-0x010000&0x03FF)+0xDC00);}var simpleEscapeCheck=new Array(256);// integer, for fast access
var simpleEscapeMap=new Array(256);for(var i=0;i<256;i++){simpleEscapeCheck[i]=simpleEscapeSequence(i)?1:0;simpleEscapeMap[i]=simpleEscapeSequence(i);}function State(input,options){this.input=input;this.filename=options['filename']||null;this.schema=options['schema']||DEFAULT_FULL_SCHEMA;this.onWarning=options['onWarning']||null;this.legacy=options['legacy']||false;this.json=options['json']||false;this.listener=options['listener']||null;this.implicitTypes=this.schema.compiledImplicit;this.typeMap=this.schema.compiledTypeMap;this.length=input.length;this.position=0;this.line=0;this.lineStart=0;this.lineIndent=0;this.documents=[];/*
  this.version;
  this.checkLineBreaks;
  this.tagMap;
  this.anchorMap;
  this.tag;
  this.anchor;
  this.kind;
  this.result;*/}function generateError(state,message){return new YAMLException(message,new Mark(state.filename,state.input,state.position,state.line,state.position-state.lineStart));}function throwError(state,message){throw generateError(state,message);}function throwWarning(state,message){if(state.onWarning){state.onWarning.call(null,generateError(state,message));}}var directiveHandlers={YAML:function handleYamlDirective(state,name,args){var match,major,minor;if(state.version!==null){throwError(state,'duplication of %YAML directive');}if(args.length!==1){throwError(state,'YAML directive accepts exactly one argument');}match=/^([0-9]+)\.([0-9]+)$/.exec(args[0]);if(match===null){throwError(state,'ill-formed argument of the YAML directive');}major=parseInt(match[1],10);minor=parseInt(match[2],10);if(major!==1){throwError(state,'unacceptable YAML version of the document');}state.version=args[0];state.checkLineBreaks=minor<2;if(minor!==1&&minor!==2){throwWarning(state,'unsupported YAML version of the document');}},TAG:function handleTagDirective(state,name,args){var handle,prefix;if(args.length!==2){throwError(state,'TAG directive accepts exactly two arguments');}handle=args[0];prefix=args[1];if(!PATTERN_TAG_HANDLE.test(handle)){throwError(state,'ill-formed tag handle (first argument) of the TAG directive');}if(_hasOwnProperty.call(state.tagMap,handle)){throwError(state,'there is a previously declared suffix for "'+handle+'" tag handle');}if(!PATTERN_TAG_URI.test(prefix)){throwError(state,'ill-formed tag prefix (second argument) of the TAG directive');}state.tagMap[handle]=prefix;}};function captureSegment(state,start,end,checkJson){var _position,_length,_character,_result;if(start<end){_result=state.input.slice(start,end);if(checkJson){for(_position=0,_length=_result.length;_position<_length;_position+=1){_character=_result.charCodeAt(_position);if(!(_character===0x09||0x20<=_character&&_character<=0x10FFFF)){throwError(state,'expected valid JSON character');}}}else if(PATTERN_NON_PRINTABLE.test(_result)){throwError(state,'the stream contains non-printable characters');}state.result+=_result;}}function mergeMappings(state,destination,source,overridableKeys){var sourceKeys,key,index,quantity;if(!common.isObject(source)){throwError(state,'cannot merge mappings; the provided source object is unacceptable');}sourceKeys=Object.keys(source);for(index=0,quantity=sourceKeys.length;index<quantity;index+=1){key=sourceKeys[index];if(!_hasOwnProperty.call(destination,key)){destination[key]=source[key];overridableKeys[key]=true;}}}function storeMappingPair(state,_result,overridableKeys,keyTag,keyNode,valueNode,startLine,startPos){var index,quantity;// The output is a plain object here, so keys can only be strings.
// We need to convert keyNode to a string, but doing so can hang the process
// (deeply nested arrays that explode exponentially using aliases).
if(Array.isArray(keyNode)){keyNode=Array.prototype.slice.call(keyNode);for(index=0,quantity=keyNode.length;index<quantity;index+=1){if(Array.isArray(keyNode[index])){throwError(state,'nested arrays are not supported inside keys');}if(typeof keyNode==='object'&&_class(keyNode[index])==='[object Object]'){keyNode[index]='[object Object]';}}}// Avoid code execution in load() via toString property
// (still use its own toString for arrays, timestamps,
// and whatever user schema extensions happen to have @@toStringTag)
if(typeof keyNode==='object'&&_class(keyNode)==='[object Object]'){keyNode='[object Object]';}keyNode=String(keyNode);if(_result===null){_result={};}if(keyTag==='tag:yaml.org,2002:merge'){if(Array.isArray(valueNode)){for(index=0,quantity=valueNode.length;index<quantity;index+=1){mergeMappings(state,_result,valueNode[index],overridableKeys);}}else{mergeMappings(state,_result,valueNode,overridableKeys);}}else{if(!state.json&&!_hasOwnProperty.call(overridableKeys,keyNode)&&_hasOwnProperty.call(_result,keyNode)){state.line=startLine||state.line;state.position=startPos||state.position;throwError(state,'duplicated mapping key');}_result[keyNode]=valueNode;delete overridableKeys[keyNode];}return _result;}function readLineBreak(state){var ch;ch=state.input.charCodeAt(state.position);if(ch===0x0A/* LF */){state.position++;}else if(ch===0x0D/* CR */){state.position++;if(state.input.charCodeAt(state.position)===0x0A/* LF */){state.position++;}}else{throwError(state,'a line break is expected');}state.line+=1;state.lineStart=state.position;}function skipSeparationSpace(state,allowComments,checkIndent){var lineBreaks=0,ch=state.input.charCodeAt(state.position);while(ch!==0){while(is_WHITE_SPACE(ch)){ch=state.input.charCodeAt(++state.position);}if(allowComments&&ch===0x23/* # */){do{ch=state.input.charCodeAt(++state.position);}while(ch!==0x0A/* LF */&&ch!==0x0D/* CR */&&ch!==0);}if(is_EOL(ch)){readLineBreak(state);ch=state.input.charCodeAt(state.position);lineBreaks++;state.lineIndent=0;while(ch===0x20/* Space */){state.lineIndent++;ch=state.input.charCodeAt(++state.position);}}else{break;}}if(checkIndent!==-1&&lineBreaks!==0&&state.lineIndent<checkIndent){throwWarning(state,'deficient indentation');}return lineBreaks;}function testDocumentSeparator(state){var _position=state.position,ch;ch=state.input.charCodeAt(_position);// Condition state.position === state.lineStart is tested
// in parent on each call, for efficiency. No needs to test here again.
if((ch===0x2D/* - */||ch===0x2E/* . */)&&ch===state.input.charCodeAt(_position+1)&&ch===state.input.charCodeAt(_position+2)){_position+=3;ch=state.input.charCodeAt(_position);if(ch===0||is_WS_OR_EOL(ch)){return true;}}return false;}function writeFoldedLines(state,count){if(count===1){state.result+=' ';}else if(count>1){state.result+=common.repeat('\n',count-1);}}function readPlainScalar(state,nodeIndent,withinFlowCollection){var preceding,following,captureStart,captureEnd,hasPendingContent,_line,_lineStart,_lineIndent,_kind=state.kind,_result=state.result,ch;ch=state.input.charCodeAt(state.position);if(is_WS_OR_EOL(ch)||is_FLOW_INDICATOR(ch)||ch===0x23/* # */||ch===0x26/* & */||ch===0x2A/* * */||ch===0x21/* ! */||ch===0x7C/* | */||ch===0x3E/* > */||ch===0x27/* ' */||ch===0x22/* " */||ch===0x25/* % */||ch===0x40/* @ */||ch===0x60/* ` */){return false;}if(ch===0x3F/* ? */||ch===0x2D/* - */){following=state.input.charCodeAt(state.position+1);if(is_WS_OR_EOL(following)||withinFlowCollection&&is_FLOW_INDICATOR(following)){return false;}}state.kind='scalar';state.result='';captureStart=captureEnd=state.position;hasPendingContent=false;while(ch!==0){if(ch===0x3A/* : */){following=state.input.charCodeAt(state.position+1);if(is_WS_OR_EOL(following)||withinFlowCollection&&is_FLOW_INDICATOR(following)){break;}}else if(ch===0x23/* # */){preceding=state.input.charCodeAt(state.position-1);if(is_WS_OR_EOL(preceding)){break;}}else if(state.position===state.lineStart&&testDocumentSeparator(state)||withinFlowCollection&&is_FLOW_INDICATOR(ch)){break;}else if(is_EOL(ch)){_line=state.line;_lineStart=state.lineStart;_lineIndent=state.lineIndent;skipSeparationSpace(state,false,-1);if(state.lineIndent>=nodeIndent){hasPendingContent=true;ch=state.input.charCodeAt(state.position);continue;}else{state.position=captureEnd;state.line=_line;state.lineStart=_lineStart;state.lineIndent=_lineIndent;break;}}if(hasPendingContent){captureSegment(state,captureStart,captureEnd,false);writeFoldedLines(state,state.line-_line);captureStart=captureEnd=state.position;hasPendingContent=false;}if(!is_WHITE_SPACE(ch)){captureEnd=state.position+1;}ch=state.input.charCodeAt(++state.position);}captureSegment(state,captureStart,captureEnd,false);if(state.result){return true;}state.kind=_kind;state.result=_result;return false;}function readSingleQuotedScalar(state,nodeIndent){var ch,captureStart,captureEnd;ch=state.input.charCodeAt(state.position);if(ch!==0x27/* ' */){return false;}state.kind='scalar';state.result='';state.position++;captureStart=captureEnd=state.position;while((ch=state.input.charCodeAt(state.position))!==0){if(ch===0x27/* ' */){captureSegment(state,captureStart,state.position,true);ch=state.input.charCodeAt(++state.position);if(ch===0x27/* ' */){captureStart=state.position;state.position++;captureEnd=state.position;}else{return true;}}else if(is_EOL(ch)){captureSegment(state,captureStart,captureEnd,true);writeFoldedLines(state,skipSeparationSpace(state,false,nodeIndent));captureStart=captureEnd=state.position;}else if(state.position===state.lineStart&&testDocumentSeparator(state)){throwError(state,'unexpected end of the document within a single quoted scalar');}else{state.position++;captureEnd=state.position;}}throwError(state,'unexpected end of the stream within a single quoted scalar');}function readDoubleQuotedScalar(state,nodeIndent){var captureStart,captureEnd,hexLength,hexResult,tmp,ch;ch=state.input.charCodeAt(state.position);if(ch!==0x22/* " */){return false;}state.kind='scalar';state.result='';state.position++;captureStart=captureEnd=state.position;while((ch=state.input.charCodeAt(state.position))!==0){if(ch===0x22/* " */){captureSegment(state,captureStart,state.position,true);state.position++;return true;}else if(ch===0x5C/* \ */){captureSegment(state,captureStart,state.position,true);ch=state.input.charCodeAt(++state.position);if(is_EOL(ch)){skipSeparationSpace(state,false,nodeIndent);// TODO: rework to inline fn with no type cast?
}else if(ch<256&&simpleEscapeCheck[ch]){state.result+=simpleEscapeMap[ch];state.position++;}else if((tmp=escapedHexLen(ch))>0){hexLength=tmp;hexResult=0;for(;hexLength>0;hexLength--){ch=state.input.charCodeAt(++state.position);if((tmp=fromHexCode(ch))>=0){hexResult=(hexResult<<4)+tmp;}else{throwError(state,'expected hexadecimal character');}}state.result+=charFromCodepoint(hexResult);state.position++;}else{throwError(state,'unknown escape sequence');}captureStart=captureEnd=state.position;}else if(is_EOL(ch)){captureSegment(state,captureStart,captureEnd,true);writeFoldedLines(state,skipSeparationSpace(state,false,nodeIndent));captureStart=captureEnd=state.position;}else if(state.position===state.lineStart&&testDocumentSeparator(state)){throwError(state,'unexpected end of the document within a double quoted scalar');}else{state.position++;captureEnd=state.position;}}throwError(state,'unexpected end of the stream within a double quoted scalar');}function readFlowCollection(state,nodeIndent){var readNext=true,_line,_tag=state.tag,_result,_anchor=state.anchor,following,terminator,isPair,isExplicitPair,isMapping,overridableKeys={},keyNode,keyTag,valueNode,ch;ch=state.input.charCodeAt(state.position);if(ch===0x5B/* [ */){terminator=0x5D;/* ] */isMapping=false;_result=[];}else if(ch===0x7B/* { */){terminator=0x7D;/* } */isMapping=true;_result={};}else{return false;}if(state.anchor!==null){state.anchorMap[state.anchor]=_result;}ch=state.input.charCodeAt(++state.position);while(ch!==0){skipSeparationSpace(state,true,nodeIndent);ch=state.input.charCodeAt(state.position);if(ch===terminator){state.position++;state.tag=_tag;state.anchor=_anchor;state.kind=isMapping?'mapping':'sequence';state.result=_result;return true;}else if(!readNext){throwError(state,'missed comma between flow collection entries');}keyTag=keyNode=valueNode=null;isPair=isExplicitPair=false;if(ch===0x3F/* ? */){following=state.input.charCodeAt(state.position+1);if(is_WS_OR_EOL(following)){isPair=isExplicitPair=true;state.position++;skipSeparationSpace(state,true,nodeIndent);}}_line=state.line;composeNode(state,nodeIndent,CONTEXT_FLOW_IN,false,true);keyTag=state.tag;keyNode=state.result;skipSeparationSpace(state,true,nodeIndent);ch=state.input.charCodeAt(state.position);if((isExplicitPair||state.line===_line)&&ch===0x3A/* : */){isPair=true;ch=state.input.charCodeAt(++state.position);skipSeparationSpace(state,true,nodeIndent);composeNode(state,nodeIndent,CONTEXT_FLOW_IN,false,true);valueNode=state.result;}if(isMapping){storeMappingPair(state,_result,overridableKeys,keyTag,keyNode,valueNode);}else if(isPair){_result.push(storeMappingPair(state,null,overridableKeys,keyTag,keyNode,valueNode));}else{_result.push(keyNode);}skipSeparationSpace(state,true,nodeIndent);ch=state.input.charCodeAt(state.position);if(ch===0x2C/* , */){readNext=true;ch=state.input.charCodeAt(++state.position);}else{readNext=false;}}throwError(state,'unexpected end of the stream within a flow collection');}function readBlockScalar(state,nodeIndent){var captureStart,folding,chomping=CHOMPING_CLIP,didReadContent=false,detectedIndent=false,textIndent=nodeIndent,emptyLines=0,atMoreIndented=false,tmp,ch;ch=state.input.charCodeAt(state.position);if(ch===0x7C/* | */){folding=false;}else if(ch===0x3E/* > */){folding=true;}else{return false;}state.kind='scalar';state.result='';while(ch!==0){ch=state.input.charCodeAt(++state.position);if(ch===0x2B/* + */||ch===0x2D/* - */){if(CHOMPING_CLIP===chomping){chomping=ch===0x2B/* + */?CHOMPING_KEEP:CHOMPING_STRIP;}else{throwError(state,'repeat of a chomping mode identifier');}}else if((tmp=fromDecimalCode(ch))>=0){if(tmp===0){throwError(state,'bad explicit indentation width of a block scalar; it cannot be less than one');}else if(!detectedIndent){textIndent=nodeIndent+tmp-1;detectedIndent=true;}else{throwError(state,'repeat of an indentation width identifier');}}else{break;}}if(is_WHITE_SPACE(ch)){do{ch=state.input.charCodeAt(++state.position);}while(is_WHITE_SPACE(ch));if(ch===0x23/* # */){do{ch=state.input.charCodeAt(++state.position);}while(!is_EOL(ch)&&ch!==0);}}while(ch!==0){readLineBreak(state);state.lineIndent=0;ch=state.input.charCodeAt(state.position);while((!detectedIndent||state.lineIndent<textIndent)&&ch===0x20/* Space */){state.lineIndent++;ch=state.input.charCodeAt(++state.position);}if(!detectedIndent&&state.lineIndent>textIndent){textIndent=state.lineIndent;}if(is_EOL(ch)){emptyLines++;continue;}// End of the scalar.
if(state.lineIndent<textIndent){// Perform the chomping.
if(chomping===CHOMPING_KEEP){state.result+=common.repeat('\n',didReadContent?1+emptyLines:emptyLines);}else if(chomping===CHOMPING_CLIP){if(didReadContent){// i.e. only if the scalar is not empty.
state.result+='\n';}}// Break this `while` cycle and go to the funciton's epilogue.
break;}// Folded style: use fancy rules to handle line breaks.
if(folding){// Lines starting with white space characters (more-indented lines) are not folded.
if(is_WHITE_SPACE(ch)){atMoreIndented=true;// except for the first content line (cf. Example 8.1)
state.result+=common.repeat('\n',didReadContent?1+emptyLines:emptyLines);// End of more-indented block.
}else if(atMoreIndented){atMoreIndented=false;state.result+=common.repeat('\n',emptyLines+1);// Just one line break - perceive as the same line.
}else if(emptyLines===0){if(didReadContent){// i.e. only if we have already read some scalar content.
state.result+=' ';}// Several line breaks - perceive as different lines.
}else{state.result+=common.repeat('\n',emptyLines);}// Literal style: just add exact number of line breaks between content lines.
}else{// Keep all line breaks except the header line break.
state.result+=common.repeat('\n',didReadContent?1+emptyLines:emptyLines);}didReadContent=true;detectedIndent=true;emptyLines=0;captureStart=state.position;while(!is_EOL(ch)&&ch!==0){ch=state.input.charCodeAt(++state.position);}captureSegment(state,captureStart,state.position,false);}return true;}function readBlockSequence(state,nodeIndent){var _line,_tag=state.tag,_anchor=state.anchor,_result=[],following,detected=false,ch;if(state.anchor!==null){state.anchorMap[state.anchor]=_result;}ch=state.input.charCodeAt(state.position);while(ch!==0){if(ch!==0x2D/* - */){break;}following=state.input.charCodeAt(state.position+1);if(!is_WS_OR_EOL(following)){break;}detected=true;state.position++;if(skipSeparationSpace(state,true,-1)){if(state.lineIndent<=nodeIndent){_result.push(null);ch=state.input.charCodeAt(state.position);continue;}}_line=state.line;composeNode(state,nodeIndent,CONTEXT_BLOCK_IN,false,true);_result.push(state.result);skipSeparationSpace(state,true,-1);ch=state.input.charCodeAt(state.position);if((state.line===_line||state.lineIndent>nodeIndent)&&ch!==0){throwError(state,'bad indentation of a sequence entry');}else if(state.lineIndent<nodeIndent){break;}}if(detected){state.tag=_tag;state.anchor=_anchor;state.kind='sequence';state.result=_result;return true;}return false;}function readBlockMapping(state,nodeIndent,flowIndent){var following,allowCompact,_line,_pos,_tag=state.tag,_anchor=state.anchor,_result={},overridableKeys={},keyTag=null,keyNode=null,valueNode=null,atExplicitKey=false,detected=false,ch;if(state.anchor!==null){state.anchorMap[state.anchor]=_result;}ch=state.input.charCodeAt(state.position);while(ch!==0){following=state.input.charCodeAt(state.position+1);_line=state.line;// Save the current line.
_pos=state.position;//
// Explicit notation case. There are two separate blocks:
// first for the key (denoted by "?") and second for the value (denoted by ":")
//
if((ch===0x3F/* ? */||ch===0x3A/* : */)&&is_WS_OR_EOL(following)){if(ch===0x3F/* ? */){if(atExplicitKey){storeMappingPair(state,_result,overridableKeys,keyTag,keyNode,null);keyTag=keyNode=valueNode=null;}detected=true;atExplicitKey=true;allowCompact=true;}else if(atExplicitKey){// i.e. 0x3A/* : */ === character after the explicit key.
atExplicitKey=false;allowCompact=true;}else{throwError(state,'incomplete explicit mapping pair; a key node is missed; or followed by a non-tabulated empty line');}state.position+=1;ch=following;//
// Implicit notation case. Flow-style node as the key first, then ":", and the value.
//
}else if(composeNode(state,flowIndent,CONTEXT_FLOW_OUT,false,true)){if(state.line===_line){ch=state.input.charCodeAt(state.position);while(is_WHITE_SPACE(ch)){ch=state.input.charCodeAt(++state.position);}if(ch===0x3A/* : */){ch=state.input.charCodeAt(++state.position);if(!is_WS_OR_EOL(ch)){throwError(state,'a whitespace character is expected after the key-value separator within a block mapping');}if(atExplicitKey){storeMappingPair(state,_result,overridableKeys,keyTag,keyNode,null);keyTag=keyNode=valueNode=null;}detected=true;atExplicitKey=false;allowCompact=false;keyTag=state.tag;keyNode=state.result;}else if(detected){throwError(state,'can not read an implicit mapping pair; a colon is missed');}else{state.tag=_tag;state.anchor=_anchor;return true;// Keep the result of `composeNode`.
}}else if(detected){throwError(state,'can not read a block mapping entry; a multiline key may not be an implicit key');}else{state.tag=_tag;state.anchor=_anchor;return true;// Keep the result of `composeNode`.
}}else{break;// Reading is done. Go to the epilogue.
}//
// Common reading code for both explicit and implicit notations.
//
if(state.line===_line||state.lineIndent>nodeIndent){if(composeNode(state,nodeIndent,CONTEXT_BLOCK_OUT,true,allowCompact)){if(atExplicitKey){keyNode=state.result;}else{valueNode=state.result;}}if(!atExplicitKey){storeMappingPair(state,_result,overridableKeys,keyTag,keyNode,valueNode,_line,_pos);keyTag=keyNode=valueNode=null;}skipSeparationSpace(state,true,-1);ch=state.input.charCodeAt(state.position);}if(state.lineIndent>nodeIndent&&ch!==0){throwError(state,'bad indentation of a mapping entry');}else if(state.lineIndent<nodeIndent){break;}}//
// Epilogue.
//
// Special case: last mapping's node contains only the key in explicit notation.
if(atExplicitKey){storeMappingPair(state,_result,overridableKeys,keyTag,keyNode,null);}// Expose the resulting mapping.
if(detected){state.tag=_tag;state.anchor=_anchor;state.kind='mapping';state.result=_result;}return detected;}function readTagProperty(state){var _position,isVerbatim=false,isNamed=false,tagHandle,tagName,ch;ch=state.input.charCodeAt(state.position);if(ch!==0x21/* ! */)return false;if(state.tag!==null){throwError(state,'duplication of a tag property');}ch=state.input.charCodeAt(++state.position);if(ch===0x3C/* < */){isVerbatim=true;ch=state.input.charCodeAt(++state.position);}else if(ch===0x21/* ! */){isNamed=true;tagHandle='!!';ch=state.input.charCodeAt(++state.position);}else{tagHandle='!';}_position=state.position;if(isVerbatim){do{ch=state.input.charCodeAt(++state.position);}while(ch!==0&&ch!==0x3E/* > */);if(state.position<state.length){tagName=state.input.slice(_position,state.position);ch=state.input.charCodeAt(++state.position);}else{throwError(state,'unexpected end of the stream within a verbatim tag');}}else{while(ch!==0&&!is_WS_OR_EOL(ch)){if(ch===0x21/* ! */){if(!isNamed){tagHandle=state.input.slice(_position-1,state.position+1);if(!PATTERN_TAG_HANDLE.test(tagHandle)){throwError(state,'named tag handle cannot contain such characters');}isNamed=true;_position=state.position+1;}else{throwError(state,'tag suffix cannot contain exclamation marks');}}ch=state.input.charCodeAt(++state.position);}tagName=state.input.slice(_position,state.position);if(PATTERN_FLOW_INDICATORS.test(tagName)){throwError(state,'tag suffix cannot contain flow indicator characters');}}if(tagName&&!PATTERN_TAG_URI.test(tagName)){throwError(state,'tag name cannot contain such characters: '+tagName);}if(isVerbatim){state.tag=tagName;}else if(_hasOwnProperty.call(state.tagMap,tagHandle)){state.tag=state.tagMap[tagHandle]+tagName;}else if(tagHandle==='!'){state.tag='!'+tagName;}else if(tagHandle==='!!'){state.tag='tag:yaml.org,2002:'+tagName;}else{throwError(state,'undeclared tag handle "'+tagHandle+'"');}return true;}function readAnchorProperty(state){var _position,ch;ch=state.input.charCodeAt(state.position);if(ch!==0x26/* & */)return false;if(state.anchor!==null){throwError(state,'duplication of an anchor property');}ch=state.input.charCodeAt(++state.position);_position=state.position;while(ch!==0&&!is_WS_OR_EOL(ch)&&!is_FLOW_INDICATOR(ch)){ch=state.input.charCodeAt(++state.position);}if(state.position===_position){throwError(state,'name of an anchor node must contain at least one character');}state.anchor=state.input.slice(_position,state.position);return true;}function readAlias(state){var _position,alias,ch;ch=state.input.charCodeAt(state.position);if(ch!==0x2A/* * */)return false;ch=state.input.charCodeAt(++state.position);_position=state.position;while(ch!==0&&!is_WS_OR_EOL(ch)&&!is_FLOW_INDICATOR(ch)){ch=state.input.charCodeAt(++state.position);}if(state.position===_position){throwError(state,'name of an alias node must contain at least one character');}alias=state.input.slice(_position,state.position);if(!state.anchorMap.hasOwnProperty(alias)){throwError(state,'unidentified alias "'+alias+'"');}state.result=state.anchorMap[alias];skipSeparationSpace(state,true,-1);return true;}function composeNode(state,parentIndent,nodeContext,allowToSeek,allowCompact){var allowBlockStyles,allowBlockScalars,allowBlockCollections,indentStatus=1,// 1: this>parent, 0: this=parent, -1: this<parent
atNewLine=false,hasContent=false,typeIndex,typeQuantity,type,flowIndent,blockIndent;if(state.listener!==null){state.listener('open',state);}state.tag=null;state.anchor=null;state.kind=null;state.result=null;allowBlockStyles=allowBlockScalars=allowBlockCollections=CONTEXT_BLOCK_OUT===nodeContext||CONTEXT_BLOCK_IN===nodeContext;if(allowToSeek){if(skipSeparationSpace(state,true,-1)){atNewLine=true;if(state.lineIndent>parentIndent){indentStatus=1;}else if(state.lineIndent===parentIndent){indentStatus=0;}else if(state.lineIndent<parentIndent){indentStatus=-1;}}}if(indentStatus===1){while(readTagProperty(state)||readAnchorProperty(state)){if(skipSeparationSpace(state,true,-1)){atNewLine=true;allowBlockCollections=allowBlockStyles;if(state.lineIndent>parentIndent){indentStatus=1;}else if(state.lineIndent===parentIndent){indentStatus=0;}else if(state.lineIndent<parentIndent){indentStatus=-1;}}else{allowBlockCollections=false;}}}if(allowBlockCollections){allowBlockCollections=atNewLine||allowCompact;}if(indentStatus===1||CONTEXT_BLOCK_OUT===nodeContext){if(CONTEXT_FLOW_IN===nodeContext||CONTEXT_FLOW_OUT===nodeContext){flowIndent=parentIndent;}else{flowIndent=parentIndent+1;}blockIndent=state.position-state.lineStart;if(indentStatus===1){if(allowBlockCollections&&(readBlockSequence(state,blockIndent)||readBlockMapping(state,blockIndent,flowIndent))||readFlowCollection(state,flowIndent)){hasContent=true;}else{if(allowBlockScalars&&readBlockScalar(state,flowIndent)||readSingleQuotedScalar(state,flowIndent)||readDoubleQuotedScalar(state,flowIndent)){hasContent=true;}else if(readAlias(state)){hasContent=true;if(state.tag!==null||state.anchor!==null){throwError(state,'alias node should not have any properties');}}else if(readPlainScalar(state,flowIndent,CONTEXT_FLOW_IN===nodeContext)){hasContent=true;if(state.tag===null){state.tag='?';}}if(state.anchor!==null){state.anchorMap[state.anchor]=state.result;}}}else if(indentStatus===0){// Special case: block sequences are allowed to have same indentation level as the parent.
// http://www.yaml.org/spec/1.2/spec.html#id2799784
hasContent=allowBlockCollections&&readBlockSequence(state,blockIndent);}}if(state.tag!==null&&state.tag!=='!'){if(state.tag==='?'){for(typeIndex=0,typeQuantity=state.implicitTypes.length;typeIndex<typeQuantity;typeIndex+=1){type=state.implicitTypes[typeIndex];// Implicit resolving is not allowed for non-scalar types, and '?'
// non-specific tag is only assigned to plain scalars. So, it isn't
// needed to check for 'kind' conformity.
if(type.resolve(state.result)){// `state.result` updated in resolver if matched
state.result=type.construct(state.result);state.tag=type.tag;if(state.anchor!==null){state.anchorMap[state.anchor]=state.result;}break;}}}else if(_hasOwnProperty.call(state.typeMap[state.kind||'fallback'],state.tag)){type=state.typeMap[state.kind||'fallback'][state.tag];if(state.result!==null&&type.kind!==state.kind){throwError(state,'unacceptable node kind for !<'+state.tag+'> tag; it should be "'+type.kind+'", not "'+state.kind+'"');}if(!type.resolve(state.result)){// `state.result` updated in resolver if matched
throwError(state,'cannot resolve a node with !<'+state.tag+'> explicit tag');}else{state.result=type.construct(state.result);if(state.anchor!==null){state.anchorMap[state.anchor]=state.result;}}}else{throwError(state,'unknown tag !<'+state.tag+'>');}}if(state.listener!==null){state.listener('close',state);}return state.tag!==null||state.anchor!==null||hasContent;}function readDocument(state){var documentStart=state.position,_position,directiveName,directiveArgs,hasDirectives=false,ch;state.version=null;state.checkLineBreaks=state.legacy;state.tagMap={};state.anchorMap={};while((ch=state.input.charCodeAt(state.position))!==0){skipSeparationSpace(state,true,-1);ch=state.input.charCodeAt(state.position);if(state.lineIndent>0||ch!==0x25/* % */){break;}hasDirectives=true;ch=state.input.charCodeAt(++state.position);_position=state.position;while(ch!==0&&!is_WS_OR_EOL(ch)){ch=state.input.charCodeAt(++state.position);}directiveName=state.input.slice(_position,state.position);directiveArgs=[];if(directiveName.length<1){throwError(state,'directive name must not be less than one character in length');}while(ch!==0){while(is_WHITE_SPACE(ch)){ch=state.input.charCodeAt(++state.position);}if(ch===0x23/* # */){do{ch=state.input.charCodeAt(++state.position);}while(ch!==0&&!is_EOL(ch));break;}if(is_EOL(ch))break;_position=state.position;while(ch!==0&&!is_WS_OR_EOL(ch)){ch=state.input.charCodeAt(++state.position);}directiveArgs.push(state.input.slice(_position,state.position));}if(ch!==0)readLineBreak(state);if(_hasOwnProperty.call(directiveHandlers,directiveName)){directiveHandlers[directiveName](state,directiveName,directiveArgs);}else{throwWarning(state,'unknown document directive "'+directiveName+'"');}}skipSeparationSpace(state,true,-1);if(state.lineIndent===0&&state.input.charCodeAt(state.position)===0x2D/* - */&&state.input.charCodeAt(state.position+1)===0x2D/* - */&&state.input.charCodeAt(state.position+2)===0x2D/* - */){state.position+=3;skipSeparationSpace(state,true,-1);}else if(hasDirectives){throwError(state,'directives end mark is expected');}composeNode(state,state.lineIndent-1,CONTEXT_BLOCK_OUT,false,true);skipSeparationSpace(state,true,-1);if(state.checkLineBreaks&&PATTERN_NON_ASCII_LINE_BREAKS.test(state.input.slice(documentStart,state.position))){throwWarning(state,'non-ASCII line breaks are interpreted as content');}state.documents.push(state.result);if(state.position===state.lineStart&&testDocumentSeparator(state)){if(state.input.charCodeAt(state.position)===0x2E/* . */){state.position+=3;skipSeparationSpace(state,true,-1);}return;}if(state.position<state.length-1){throwError(state,'end of the stream or a document separator is expected');}else{return;}}function loadDocuments(input,options){input=String(input);options=options||{};if(input.length!==0){// Add tailing `\n` if not exists
if(input.charCodeAt(input.length-1)!==0x0A/* LF */&&input.charCodeAt(input.length-1)!==0x0D/* CR */){input+='\n';}// Strip BOM
if(input.charCodeAt(0)===0xFEFF){input=input.slice(1);}}var state=new State(input,options);// Use 0 as string terminator. That significantly simplifies bounds check.
state.input+='\0';while(state.input.charCodeAt(state.position)===0x20/* Space */){state.lineIndent+=1;state.position+=1;}while(state.position<state.length-1){readDocument(state);}return state.documents;}function loadAll(input,iterator,options){var documents=loadDocuments(input,options),index,length;if(typeof iterator!=='function'){return documents;}for(index=0,length=documents.length;index<length;index+=1){iterator(documents[index]);}}function load(input,options){var documents=loadDocuments(input,options);if(documents.length===0){/*eslint-disable no-undefined*/return undefined;}else if(documents.length===1){return documents[0];}throw new YAMLException('expected a single document in the stream, but found more');}function safeLoadAll(input,output,options){if(typeof output==='function'){loadAll(input,output,common.extend({schema:DEFAULT_SAFE_SCHEMA},options));}else{return loadAll(input,common.extend({schema:DEFAULT_SAFE_SCHEMA},options));}}function safeLoad(input,options){return load(input,common.extend({schema:DEFAULT_SAFE_SCHEMA},options));}module.exports.loadAll=loadAll;module.exports.load=load;module.exports.safeLoadAll=safeLoadAll;module.exports.safeLoad=safeLoad;

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/mark.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var common=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/common.js");function Mark(name,buffer,position,line,column){this.name=name;this.buffer=buffer;this.position=position;this.line=line;this.column=column;}Mark.prototype.getSnippet=function getSnippet(indent,maxLength){var head,start,tail,end,snippet;if(!this.buffer)return null;indent=indent||4;maxLength=maxLength||75;head='';start=this.position;while(start>0&&'\x00\r\n\x85\u2028\u2029'.indexOf(this.buffer.charAt(start-1))===-1){start-=1;if(this.position-start>maxLength/2-1){head=' ... ';start+=5;break;}}tail='';end=this.position;while(end<this.buffer.length&&'\x00\r\n\x85\u2028\u2029'.indexOf(this.buffer.charAt(end))===-1){end+=1;if(end-this.position>maxLength/2-1){tail=' ... ';end-=5;break;}}snippet=this.buffer.slice(start,end);return common.repeat(' ',indent)+head+snippet+tail+'\n'+common.repeat(' ',indent+this.position-start+head.length)+'^';};Mark.prototype.toString=function toString(compact){var snippet,where='';if(this.name){where+='in "'+this.name+'" ';}where+='at line '+(this.line+1)+', column '+(this.column+1);if(!compact){snippet=this.getSnippet();if(snippet){where+=':\n'+snippet;}}return where;};module.exports=Mark;

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/schema.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*eslint-disable max-len*/var common=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/common.js");var YAMLException=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/exception.js");var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");function compileList(schema,name,result){var exclude=[];schema.include.forEach(function(includedSchema){result=compileList(includedSchema,name,result);});schema[name].forEach(function(currentType){result.forEach(function(previousType,previousIndex){if(previousType.tag===currentType.tag&&previousType.kind===currentType.kind){exclude.push(previousIndex);}});result.push(currentType);});return result.filter(function(type,index){return exclude.indexOf(index)===-1;});}function compileMap()/* lists... */{var result={scalar:{},sequence:{},mapping:{},fallback:{}},index,length;function collectType(type){result[type.kind][type.tag]=result['fallback'][type.tag]=type;}for(index=0,length=arguments.length;index<length;index+=1){arguments[index].forEach(collectType);}return result;}function Schema(definition){this.include=definition.include||[];this.implicit=definition.implicit||[];this.explicit=definition.explicit||[];this.implicit.forEach(function(type){if(type.loadKind&&type.loadKind!=='scalar'){throw new YAMLException('There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported.');}});this.compiledImplicit=compileList(this,'implicit',[]);this.compiledExplicit=compileList(this,'explicit',[]);this.compiledTypeMap=compileMap(this.compiledImplicit,this.compiledExplicit);}Schema.DEFAULT=null;Schema.create=function createSchema(){var schemas,types;switch(arguments.length){case 1:schemas=Schema.DEFAULT;types=arguments[0];break;case 2:schemas=arguments[0];types=arguments[1];break;default:throw new YAMLException('Wrong number of arguments for Schema.create function');}schemas=common.toArray(schemas);types=common.toArray(types);if(!schemas.every(function(schema){return schema instanceof Schema;})){throw new YAMLException('Specified list of super schemas (or a single Schema object) contains a non-Schema object.');}if(!types.every(function(type){return type instanceof Type;})){throw new YAMLException('Specified list of YAML types (or a single Type object) contains a non-Type object.');}return new Schema({include:schemas,explicit:types});};module.exports=Schema;

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/schema/core.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// Standard YAML's Core schema.
// http://www.yaml.org/spec/1.2/spec.html#id2804923
//
// NOTE: JS-YAML does not support schema-specific tag resolution restrictions.
// So, Core schema has no distinctions from JSON schema is JS-YAML.
var Schema=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema.js");module.exports=new Schema({include:[__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/json.js")]});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/schema/default_full.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// JS-YAML's default schema for `load` function.
// It is not described in the YAML specification.
//
// This schema is based on JS-YAML's default safe schema and includes
// JavaScript-specific types: !!js/undefined, !!js/regexp and !!js/function.
//
// Also this schema is used as default base schema at `Schema.create` function.
var Schema=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema.js");module.exports=Schema.DEFAULT=new Schema({include:[__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/default_safe.js")],explicit:[__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/js/undefined.js"),__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/js/regexp.js"),__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/js/function.js")]});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/schema/default_safe.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// JS-YAML's default schema for `safeLoad` function.
// It is not described in the YAML specification.
//
// This schema is based on standard YAML's Core schema and includes most of
// extra types described at YAML tag repository. (http://yaml.org/type/)
var Schema=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema.js");module.exports=new Schema({include:[__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/core.js")],implicit:[__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/timestamp.js"),__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/merge.js")],explicit:[__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/binary.js"),__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/omap.js"),__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/pairs.js"),__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/set.js")]});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/schema/failsafe.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// Standard YAML's Failsafe schema.
// http://www.yaml.org/spec/1.2/spec.html#id2802346
var Schema=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema.js");module.exports=new Schema({explicit:[__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/str.js"),__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/seq.js"),__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/map.js")]});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/schema/json.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// Standard YAML's JSON schema.
// http://www.yaml.org/spec/1.2/spec.html#id2803231
//
// NOTE: JS-YAML does not support schema-specific tag resolution restrictions.
// So, this schema is not such strict as defined in the YAML specification.
// It allows numbers in binary notaion, use `Null` and `NULL` as `null`, etc.
var Schema=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema.js");module.exports=new Schema({include:[__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/schema/failsafe.js")],implicit:[__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/null.js"),__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/bool.js"),__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/int.js"),__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type/float.js")]});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var YAMLException=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/exception.js");var TYPE_CONSTRUCTOR_OPTIONS=['kind','resolve','construct','instanceOf','predicate','represent','defaultStyle','styleAliases'];var YAML_NODE_KINDS=['scalar','sequence','mapping'];function compileStyleAliases(map){var result={};if(map!==null){Object.keys(map).forEach(function(style){map[style].forEach(function(alias){result[String(alias)]=style;});});}return result;}function Type(tag,options){options=options||{};Object.keys(options).forEach(function(name){if(TYPE_CONSTRUCTOR_OPTIONS.indexOf(name)===-1){throw new YAMLException('Unknown option "'+name+'" is met in definition of "'+tag+'" YAML type.');}});// TODO: Add tag format check.
this.tag=tag;this.kind=options['kind']||null;this.resolve=options['resolve']||function(){return true;};this.construct=options['construct']||function(data){return data;};this.instanceOf=options['instanceOf']||null;this.predicate=options['predicate']||null;this.represent=options['represent']||null;this.defaultStyle=options['defaultStyle']||null;this.styleAliases=compileStyleAliases(options['styleAliases']||null);if(YAML_NODE_KINDS.indexOf(this.kind)===-1){throw new YAMLException('Unknown kind "'+this.kind+'" is specified for "'+tag+'" YAML type.');}}module.exports=Type;

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/binary.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var require;/*eslint-disable no-bitwise*/var NodeBuffer;try{// A trick for browserified version, to not include `Buffer` shim
var _require=require;NodeBuffer=__webpack_require__("../../../node_modules/node-libs-browser/node_modules/buffer/index.js").Buffer;}catch(__){}var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");// [ 64, 65, 66 ] -> [ padding, CR, LF ]
var BASE64_MAP='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=\n\r';function resolveYamlBinary(data){if(data===null)return false;var code,idx,bitlen=0,max=data.length,map=BASE64_MAP;// Convert one by one.
for(idx=0;idx<max;idx++){code=map.indexOf(data.charAt(idx));// Skip CR/LF
if(code>64)continue;// Fail on illegal characters
if(code<0)return false;bitlen+=6;}// If there are any bits left, source was corrupted
return bitlen%8===0;}function constructYamlBinary(data){var idx,tailbits,input=data.replace(/[\r\n=]/g,''),// remove CR/LF & padding to simplify scan
max=input.length,map=BASE64_MAP,bits=0,result=[];// Collect by 6*4 bits (3 bytes)
for(idx=0;idx<max;idx++){if(idx%4===0&&idx){result.push(bits>>16&0xFF);result.push(bits>>8&0xFF);result.push(bits&0xFF);}bits=bits<<6|map.indexOf(input.charAt(idx));}// Dump tail
tailbits=max%4*6;if(tailbits===0){result.push(bits>>16&0xFF);result.push(bits>>8&0xFF);result.push(bits&0xFF);}else if(tailbits===18){result.push(bits>>10&0xFF);result.push(bits>>2&0xFF);}else if(tailbits===12){result.push(bits>>4&0xFF);}// Wrap into Buffer for NodeJS and leave Array for browser
if(NodeBuffer){// Support node 6.+ Buffer API when available
return NodeBuffer.from?NodeBuffer.from(result):new NodeBuffer(result);}return result;}function representYamlBinary(object/*, style*/){var result='',bits=0,idx,tail,max=object.length,map=BASE64_MAP;// Convert every three bytes to 4 ASCII characters.
for(idx=0;idx<max;idx++){if(idx%3===0&&idx){result+=map[bits>>18&0x3F];result+=map[bits>>12&0x3F];result+=map[bits>>6&0x3F];result+=map[bits&0x3F];}bits=(bits<<8)+object[idx];}// Dump tail
tail=max%3;if(tail===0){result+=map[bits>>18&0x3F];result+=map[bits>>12&0x3F];result+=map[bits>>6&0x3F];result+=map[bits&0x3F];}else if(tail===2){result+=map[bits>>10&0x3F];result+=map[bits>>4&0x3F];result+=map[bits<<2&0x3F];result+=map[64];}else if(tail===1){result+=map[bits>>2&0x3F];result+=map[bits<<4&0x3F];result+=map[64];result+=map[64];}return result;}function isBinary(object){return NodeBuffer&&NodeBuffer.isBuffer(object);}module.exports=new Type('tag:yaml.org,2002:binary',{kind:'scalar',resolve:resolveYamlBinary,construct:constructYamlBinary,predicate:isBinary,represent:representYamlBinary});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/bool.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");function resolveYamlBoolean(data){if(data===null)return false;var max=data.length;return max===4&&(data==='true'||data==='True'||data==='TRUE')||max===5&&(data==='false'||data==='False'||data==='FALSE');}function constructYamlBoolean(data){return data==='true'||data==='True'||data==='TRUE';}function isBoolean(object){return Object.prototype.toString.call(object)==='[object Boolean]';}module.exports=new Type('tag:yaml.org,2002:bool',{kind:'scalar',resolve:resolveYamlBoolean,construct:constructYamlBoolean,predicate:isBoolean,represent:{lowercase:function(object){return object?'true':'false';},uppercase:function(object){return object?'TRUE':'FALSE';},camelcase:function(object){return object?'True':'False';}},defaultStyle:'lowercase'});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/float.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var common=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/common.js");var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");var YAML_FLOAT_PATTERN=new RegExp(// 2.5e4, 2.5 and integers
'^(?:[-+]?(?:0|[1-9][0-9_]*)(?:\\.[0-9_]*)?(?:[eE][-+]?[0-9]+)?'+// .2e4, .2
// special case, seems not from spec
'|\\.[0-9_]+(?:[eE][-+]?[0-9]+)?'+// 20:59
'|[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\\.[0-9_]*'+// .inf
'|[-+]?\\.(?:inf|Inf|INF)'+// .nan
'|\\.(?:nan|NaN|NAN))$');function resolveYamlFloat(data){if(data===null)return false;if(!YAML_FLOAT_PATTERN.test(data)||// Quick hack to not allow integers end with `_`
// Probably should update regexp & check speed
data[data.length-1]==='_'){return false;}return true;}function constructYamlFloat(data){var value,sign,base,digits;value=data.replace(/_/g,'').toLowerCase();sign=value[0]==='-'?-1:1;digits=[];if('+-'.indexOf(value[0])>=0){value=value.slice(1);}if(value==='.inf'){return sign===1?Number.POSITIVE_INFINITY:Number.NEGATIVE_INFINITY;}else if(value==='.nan'){return NaN;}else if(value.indexOf(':')>=0){value.split(':').forEach(function(v){digits.unshift(parseFloat(v,10));});value=0.0;base=1;digits.forEach(function(d){value+=d*base;base*=60;});return sign*value;}return sign*parseFloat(value,10);}var SCIENTIFIC_WITHOUT_DOT=/^[-+]?[0-9]+e/;function representYamlFloat(object,style){var res;if(isNaN(object)){switch(style){case'lowercase':return'.nan';case'uppercase':return'.NAN';case'camelcase':return'.NaN';}}else if(Number.POSITIVE_INFINITY===object){switch(style){case'lowercase':return'.inf';case'uppercase':return'.INF';case'camelcase':return'.Inf';}}else if(Number.NEGATIVE_INFINITY===object){switch(style){case'lowercase':return'-.inf';case'uppercase':return'-.INF';case'camelcase':return'-.Inf';}}else if(common.isNegativeZero(object)){return'-0.0';}res=object.toString(10);// JS stringifier can build scientific format without dots: 5e-100,
// while YAML requres dot: 5.e-100. Fix it with simple hack
return SCIENTIFIC_WITHOUT_DOT.test(res)?res.replace('e','.e'):res;}function isFloat(object){return Object.prototype.toString.call(object)==='[object Number]'&&(object%1!==0||common.isNegativeZero(object));}module.exports=new Type('tag:yaml.org,2002:float',{kind:'scalar',resolve:resolveYamlFloat,construct:constructYamlFloat,predicate:isFloat,represent:representYamlFloat,defaultStyle:'lowercase'});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/int.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var common=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/common.js");var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");function isHexCode(c){return 0x30/* 0 */<=c&&c<=0x39/* 9 */||0x41/* A */<=c&&c<=0x46/* F */||0x61/* a */<=c&&c<=0x66/* f */;}function isOctCode(c){return 0x30/* 0 */<=c&&c<=0x37/* 7 */;}function isDecCode(c){return 0x30/* 0 */<=c&&c<=0x39/* 9 */;}function resolveYamlInteger(data){if(data===null)return false;var max=data.length,index=0,hasDigits=false,ch;if(!max)return false;ch=data[index];// sign
if(ch==='-'||ch==='+'){ch=data[++index];}if(ch==='0'){// 0
if(index+1===max)return true;ch=data[++index];// base 2, base 8, base 16
if(ch==='b'){// base 2
index++;for(;index<max;index++){ch=data[index];if(ch==='_')continue;if(ch!=='0'&&ch!=='1')return false;hasDigits=true;}return hasDigits&&ch!=='_';}if(ch==='x'){// base 16
index++;for(;index<max;index++){ch=data[index];if(ch==='_')continue;if(!isHexCode(data.charCodeAt(index)))return false;hasDigits=true;}return hasDigits&&ch!=='_';}// base 8
for(;index<max;index++){ch=data[index];if(ch==='_')continue;if(!isOctCode(data.charCodeAt(index)))return false;hasDigits=true;}return hasDigits&&ch!=='_';}// base 10 (except 0) or base 60
// value should not start with `_`;
if(ch==='_')return false;for(;index<max;index++){ch=data[index];if(ch==='_')continue;if(ch===':')break;if(!isDecCode(data.charCodeAt(index))){return false;}hasDigits=true;}// Should have digits and should not end with `_`
if(!hasDigits||ch==='_')return false;// if !base60 - done;
if(ch!==':')return true;// base60 almost not used, no needs to optimize
return /^(:[0-5]?[0-9])+$/.test(data.slice(index));}function constructYamlInteger(data){var value=data,sign=1,ch,base,digits=[];if(value.indexOf('_')!==-1){value=value.replace(/_/g,'');}ch=value[0];if(ch==='-'||ch==='+'){if(ch==='-')sign=-1;value=value.slice(1);ch=value[0];}if(value==='0')return 0;if(ch==='0'){if(value[1]==='b')return sign*parseInt(value.slice(2),2);if(value[1]==='x')return sign*parseInt(value,16);return sign*parseInt(value,8);}if(value.indexOf(':')!==-1){value.split(':').forEach(function(v){digits.unshift(parseInt(v,10));});value=0;base=1;digits.forEach(function(d){value+=d*base;base*=60;});return sign*value;}return sign*parseInt(value,10);}function isInteger(object){return Object.prototype.toString.call(object)==='[object Number]'&&object%1===0&&!common.isNegativeZero(object);}module.exports=new Type('tag:yaml.org,2002:int',{kind:'scalar',resolve:resolveYamlInteger,construct:constructYamlInteger,predicate:isInteger,represent:{binary:function(obj){return obj>=0?'0b'+obj.toString(2):'-0b'+obj.toString(2).slice(1);},octal:function(obj){return obj>=0?'0'+obj.toString(8):'-0'+obj.toString(8).slice(1);},decimal:function(obj){return obj.toString(10);},/* eslint-disable max-len */hexadecimal:function(obj){return obj>=0?'0x'+obj.toString(16).toUpperCase():'-0x'+obj.toString(16).toUpperCase().slice(1);}},defaultStyle:'decimal',styleAliases:{binary:[2,'bin'],octal:[8,'oct'],decimal:[10,'dec'],hexadecimal:[16,'hex']}});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/js/function.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var require;var esprima;// Browserified version does not have esprima
//
// 1. For node.js just require module as deps
// 2. For browser try to require mudule via external AMD system.
//    If not found - try to fallback to window.esprima. If not
//    found too - then fail to parse.
//
try{// workaround to exclude package from browserify list.
var _require=require;esprima=__webpack_require__("../../../node_modules/esprima/dist/esprima.js");}catch(_){/*global window */if(typeof window!=='undefined')esprima=window.esprima;}var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");function resolveJavascriptFunction(data){if(data===null)return false;try{var source='('+data+')',ast=esprima.parse(source,{range:true});if(ast.type!=='Program'||ast.body.length!==1||ast.body[0].type!=='ExpressionStatement'||ast.body[0].expression.type!=='ArrowFunctionExpression'&&ast.body[0].expression.type!=='FunctionExpression'){return false;}return true;}catch(err){return false;}}function constructJavascriptFunction(data){/*jslint evil:true*/var source='('+data+')',ast=esprima.parse(source,{range:true}),params=[],body;if(ast.type!=='Program'||ast.body.length!==1||ast.body[0].type!=='ExpressionStatement'||ast.body[0].expression.type!=='ArrowFunctionExpression'&&ast.body[0].expression.type!=='FunctionExpression'){throw new Error('Failed to resolve function');}ast.body[0].expression.params.forEach(function(param){params.push(param.name);});body=ast.body[0].expression.body.range;// Esprima's ranges include the first '{' and the last '}' characters on
// function expressions. So cut them out.
if(ast.body[0].expression.body.type==='BlockStatement'){/*eslint-disable no-new-func*/return new Function(params,source.slice(body[0]+1,body[1]-1));}// ES6 arrow functions can omit the BlockStatement. In that case, just return
// the body.
/*eslint-disable no-new-func*/return new Function(params,'return '+source.slice(body[0],body[1]));}function representJavascriptFunction(object/*, style*/){return object.toString();}function isFunction(object){return Object.prototype.toString.call(object)==='[object Function]';}module.exports=new Type('tag:yaml.org,2002:js/function',{kind:'scalar',resolve:resolveJavascriptFunction,construct:constructJavascriptFunction,predicate:isFunction,represent:representJavascriptFunction});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/js/regexp.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");function resolveJavascriptRegExp(data){if(data===null)return false;if(data.length===0)return false;var regexp=data,tail=/\/([gim]*)$/.exec(data),modifiers='';// if regexp starts with '/' it can have modifiers and must be properly closed
// `/foo/gim` - modifiers tail can be maximum 3 chars
if(regexp[0]==='/'){if(tail)modifiers=tail[1];if(modifiers.length>3)return false;// if expression starts with /, is should be properly terminated
if(regexp[regexp.length-modifiers.length-1]!=='/')return false;}return true;}function constructJavascriptRegExp(data){var regexp=data,tail=/\/([gim]*)$/.exec(data),modifiers='';// `/foo/gim` - tail can be maximum 4 chars
if(regexp[0]==='/'){if(tail)modifiers=tail[1];regexp=regexp.slice(1,regexp.length-modifiers.length-1);}return new RegExp(regexp,modifiers);}function representJavascriptRegExp(object/*, style*/){var result='/'+object.source+'/';if(object.global)result+='g';if(object.multiline)result+='m';if(object.ignoreCase)result+='i';return result;}function isRegExp(object){return Object.prototype.toString.call(object)==='[object RegExp]';}module.exports=new Type('tag:yaml.org,2002:js/regexp',{kind:'scalar',resolve:resolveJavascriptRegExp,construct:constructJavascriptRegExp,predicate:isRegExp,represent:representJavascriptRegExp});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/js/undefined.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");function resolveJavascriptUndefined(){return true;}function constructJavascriptUndefined(){/*eslint-disable no-undefined*/return undefined;}function representJavascriptUndefined(){return'';}function isUndefined(object){return typeof object==='undefined';}module.exports=new Type('tag:yaml.org,2002:js/undefined',{kind:'scalar',resolve:resolveJavascriptUndefined,construct:constructJavascriptUndefined,predicate:isUndefined,represent:representJavascriptUndefined});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/map.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");module.exports=new Type('tag:yaml.org,2002:map',{kind:'mapping',construct:function(data){return data!==null?data:{};}});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/merge.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");function resolveYamlMerge(data){return data==='<<'||data===null;}module.exports=new Type('tag:yaml.org,2002:merge',{kind:'scalar',resolve:resolveYamlMerge});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/null.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");function resolveYamlNull(data){if(data===null)return true;var max=data.length;return max===1&&data==='~'||max===4&&(data==='null'||data==='Null'||data==='NULL');}function constructYamlNull(){return null;}function isNull(object){return object===null;}module.exports=new Type('tag:yaml.org,2002:null',{kind:'scalar',resolve:resolveYamlNull,construct:constructYamlNull,predicate:isNull,represent:{canonical:function(){return'~';},lowercase:function(){return'null';},uppercase:function(){return'NULL';},camelcase:function(){return'Null';}},defaultStyle:'lowercase'});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/omap.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");var _hasOwnProperty=Object.prototype.hasOwnProperty;var _toString=Object.prototype.toString;function resolveYamlOmap(data){if(data===null)return true;var objectKeys=[],index,length,pair,pairKey,pairHasKey,object=data;for(index=0,length=object.length;index<length;index+=1){pair=object[index];pairHasKey=false;if(_toString.call(pair)!=='[object Object]')return false;for(pairKey in pair){if(_hasOwnProperty.call(pair,pairKey)){if(!pairHasKey)pairHasKey=true;else return false;}}if(!pairHasKey)return false;if(objectKeys.indexOf(pairKey)===-1)objectKeys.push(pairKey);else return false;}return true;}function constructYamlOmap(data){return data!==null?data:[];}module.exports=new Type('tag:yaml.org,2002:omap',{kind:'sequence',resolve:resolveYamlOmap,construct:constructYamlOmap});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/pairs.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");var _toString=Object.prototype.toString;function resolveYamlPairs(data){if(data===null)return true;var index,length,pair,keys,result,object=data;result=new Array(object.length);for(index=0,length=object.length;index<length;index+=1){pair=object[index];if(_toString.call(pair)!=='[object Object]')return false;keys=Object.keys(pair);if(keys.length!==1)return false;result[index]=[keys[0],pair[keys[0]]];}return true;}function constructYamlPairs(data){if(data===null)return[];var index,length,pair,keys,result,object=data;result=new Array(object.length);for(index=0,length=object.length;index<length;index+=1){pair=object[index];keys=Object.keys(pair);result[index]=[keys[0],pair[keys[0]]];}return result;}module.exports=new Type('tag:yaml.org,2002:pairs',{kind:'sequence',resolve:resolveYamlPairs,construct:constructYamlPairs});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/seq.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");module.exports=new Type('tag:yaml.org,2002:seq',{kind:'sequence',construct:function(data){return data!==null?data:[];}});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/set.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");var _hasOwnProperty=Object.prototype.hasOwnProperty;function resolveYamlSet(data){if(data===null)return true;var key,object=data;for(key in object){if(_hasOwnProperty.call(object,key)){if(object[key]!==null)return false;}}return true;}function constructYamlSet(data){return data!==null?data:{};}module.exports=new Type('tag:yaml.org,2002:set',{kind:'mapping',resolve:resolveYamlSet,construct:constructYamlSet});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/str.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");module.exports=new Type('tag:yaml.org,2002:str',{kind:'scalar',construct:function(data){return data!==null?data:'';}});

/***/ }),

/***/ "../../../node_modules/js-yaml/lib/js-yaml/type/timestamp.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var Type=__webpack_require__("../../../node_modules/js-yaml/lib/js-yaml/type.js");var YAML_DATE_REGEXP=new RegExp('^([0-9][0-9][0-9][0-9])'+// [1] year
'-([0-9][0-9])'+// [2] month
'-([0-9][0-9])$');// [3] day
var YAML_TIMESTAMP_REGEXP=new RegExp('^([0-9][0-9][0-9][0-9])'+// [1] year
'-([0-9][0-9]?)'+// [2] month
'-([0-9][0-9]?)'+// [3] day
'(?:[Tt]|[ \\t]+)'+// ...
'([0-9][0-9]?)'+// [4] hour
':([0-9][0-9])'+// [5] minute
':([0-9][0-9])'+// [6] second
'(?:\\.([0-9]*))?'+// [7] fraction
'(?:[ \\t]*(Z|([-+])([0-9][0-9]?)'+// [8] tz [9] tz_sign [10] tz_hour
'(?::([0-9][0-9]))?))?$');// [11] tz_minute
function resolveYamlTimestamp(data){if(data===null)return false;if(YAML_DATE_REGEXP.exec(data)!==null)return true;if(YAML_TIMESTAMP_REGEXP.exec(data)!==null)return true;return false;}function constructYamlTimestamp(data){var match,year,month,day,hour,minute,second,fraction=0,delta=null,tz_hour,tz_minute,date;match=YAML_DATE_REGEXP.exec(data);if(match===null)match=YAML_TIMESTAMP_REGEXP.exec(data);if(match===null)throw new Error('Date resolve error');// match: [1] year [2] month [3] day
year=+match[1];month=+match[2]-1;// JS month starts with 0
day=+match[3];if(!match[4]){// no hour
return new Date(Date.UTC(year,month,day));}// match: [4] hour [5] minute [6] second [7] fraction
hour=+match[4];minute=+match[5];second=+match[6];if(match[7]){fraction=match[7].slice(0,3);while(fraction.length<3){// milli-seconds
fraction+='0';}fraction=+fraction;}// match: [8] tz [9] tz_sign [10] tz_hour [11] tz_minute
if(match[9]){tz_hour=+match[10];tz_minute=+(match[11]||0);delta=(tz_hour*60+tz_minute)*60000;// delta in mili-seconds
if(match[9]==='-')delta=-delta;}date=new Date(Date.UTC(year,month,day,hour,minute,second,fraction));if(delta)date.setTime(date.getTime()-delta);return date;}function representYamlTimestamp(object/*, style*/){return object.toISOString();}module.exports=new Type('tag:yaml.org,2002:timestamp',{kind:'scalar',resolve:resolveYamlTimestamp,construct:constructYamlTimestamp,instanceOf:Date,represent:representYamlTimestamp});

/***/ }),

/***/ "../../../node_modules/node-libs-browser/node_modules/buffer/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <http://feross.org>
 * @license  MIT
 */ /* eslint-disable no-proto */var base64=__webpack_require__("../../../node_modules/base64-js/index.js");var ieee754=__webpack_require__("../../../node_modules/ieee754/index.js");var isArray=__webpack_require__("../../../node_modules/isarray/index.js");exports.Buffer=Buffer;exports.SlowBuffer=SlowBuffer;exports.INSPECT_MAX_BYTES=50;/**
 * If `Buffer.TYPED_ARRAY_SUPPORT`:
 *   === true    Use Uint8Array implementation (fastest)
 *   === false   Use Object implementation (most compatible, even IE6)
 *
 * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
 * Opera 11.6+, iOS 4.2+.
 *
 * Due to various browser bugs, sometimes the Object implementation will be used even
 * when the browser supports typed arrays.
 *
 * Note:
 *
 *   - Firefox 4-29 lacks support for adding new properties to `Uint8Array` instances,
 *     See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438.
 *
 *   - Chrome 9-10 is missing the `TypedArray.prototype.subarray` function.
 *
 *   - IE10 has a broken `TypedArray.prototype.subarray` function which returns arrays of
 *     incorrect length in some situations.

 * We detect these buggy browsers and set `Buffer.TYPED_ARRAY_SUPPORT` to `false` so they
 * get the Object implementation, which is slower but behaves correctly.
 */Buffer.TYPED_ARRAY_SUPPORT=global.TYPED_ARRAY_SUPPORT!==undefined?global.TYPED_ARRAY_SUPPORT:typedArraySupport();/*
 * Export kMaxLength after typed array support is determined.
 */exports.kMaxLength=kMaxLength();function typedArraySupport(){try{var arr=new Uint8Array(1);arr.__proto__={__proto__:Uint8Array.prototype,foo:function(){return 42;}};return arr.foo()===42&&// typed array instances can be augmented
typeof arr.subarray==='function'&&// chrome 9-10 lack `subarray`
arr.subarray(1,1).byteLength===0;// ie10 has broken `subarray`
}catch(e){return false;}}function kMaxLength(){return Buffer.TYPED_ARRAY_SUPPORT?0x7fffffff:0x3fffffff;}function createBuffer(that,length){if(kMaxLength()<length){throw new RangeError('Invalid typed array length');}if(Buffer.TYPED_ARRAY_SUPPORT){// Return an augmented `Uint8Array` instance, for best performance
that=new Uint8Array(length);that.__proto__=Buffer.prototype;}else{// Fallback: Return an object instance of the Buffer class
if(that===null){that=new Buffer(length);}that.length=length;}return that;}/**
 * The Buffer constructor returns instances of `Uint8Array` that have their
 * prototype changed to `Buffer.prototype`. Furthermore, `Buffer` is a subclass of
 * `Uint8Array`, so the returned instances will have all the node `Buffer` methods
 * and the `Uint8Array` methods. Square bracket notation works as expected -- it
 * returns a single octet.
 *
 * The `Uint8Array` prototype remains unmodified.
 */function Buffer(arg,encodingOrOffset,length){if(!Buffer.TYPED_ARRAY_SUPPORT&&!(this instanceof Buffer)){return new Buffer(arg,encodingOrOffset,length);}// Common case.
if(typeof arg==='number'){if(typeof encodingOrOffset==='string'){throw new Error('If encoding is specified then the first argument must be a string');}return allocUnsafe(this,arg);}return from(this,arg,encodingOrOffset,length);}Buffer.poolSize=8192;// not used by this implementation
// TODO: Legacy, not needed anymore. Remove in next major version.
Buffer._augment=function(arr){arr.__proto__=Buffer.prototype;return arr;};function from(that,value,encodingOrOffset,length){if(typeof value==='number'){throw new TypeError('"value" argument must not be a number');}if(typeof ArrayBuffer!=='undefined'&&value instanceof ArrayBuffer){return fromArrayBuffer(that,value,encodingOrOffset,length);}if(typeof value==='string'){return fromString(that,value,encodingOrOffset);}return fromObject(that,value);}/**
 * Functionally equivalent to Buffer(arg, encoding) but throws a TypeError
 * if value is a number.
 * Buffer.from(str[, encoding])
 * Buffer.from(array)
 * Buffer.from(buffer)
 * Buffer.from(arrayBuffer[, byteOffset[, length]])
 **/Buffer.from=function(value,encodingOrOffset,length){return from(null,value,encodingOrOffset,length);};if(Buffer.TYPED_ARRAY_SUPPORT){Buffer.prototype.__proto__=Uint8Array.prototype;Buffer.__proto__=Uint8Array;if(typeof Symbol!=='undefined'&&Symbol.species&&Buffer[Symbol.species]===Buffer){// Fix subarray() in ES2016. See: https://github.com/feross/buffer/pull/97
Object.defineProperty(Buffer,Symbol.species,{value:null,configurable:true});}}function assertSize(size){if(typeof size!=='number'){throw new TypeError('"size" argument must be a number');}else if(size<0){throw new RangeError('"size" argument must not be negative');}}function alloc(that,size,fill,encoding){assertSize(size);if(size<=0){return createBuffer(that,size);}if(fill!==undefined){// Only pay attention to encoding if it's a string. This
// prevents accidentally sending in a number that would
// be interpretted as a start offset.
return typeof encoding==='string'?createBuffer(that,size).fill(fill,encoding):createBuffer(that,size).fill(fill);}return createBuffer(that,size);}/**
 * Creates a new filled Buffer instance.
 * alloc(size[, fill[, encoding]])
 **/Buffer.alloc=function(size,fill,encoding){return alloc(null,size,fill,encoding);};function allocUnsafe(that,size){assertSize(size);that=createBuffer(that,size<0?0:checked(size)|0);if(!Buffer.TYPED_ARRAY_SUPPORT){for(var i=0;i<size;++i){that[i]=0;}}return that;}/**
 * Equivalent to Buffer(num), by default creates a non-zero-filled Buffer instance.
 * */Buffer.allocUnsafe=function(size){return allocUnsafe(null,size);};/**
 * Equivalent to SlowBuffer(num), by default creates a non-zero-filled Buffer instance.
 */Buffer.allocUnsafeSlow=function(size){return allocUnsafe(null,size);};function fromString(that,string,encoding){if(typeof encoding!=='string'||encoding===''){encoding='utf8';}if(!Buffer.isEncoding(encoding)){throw new TypeError('"encoding" must be a valid string encoding');}var length=byteLength(string,encoding)|0;that=createBuffer(that,length);var actual=that.write(string,encoding);if(actual!==length){// Writing a hex string, for example, that contains invalid characters will
// cause everything after the first invalid character to be ignored. (e.g.
// 'abxxcd' will be treated as 'ab')
that=that.slice(0,actual);}return that;}function fromArrayLike(that,array){var length=array.length<0?0:checked(array.length)|0;that=createBuffer(that,length);for(var i=0;i<length;i+=1){that[i]=array[i]&255;}return that;}function fromArrayBuffer(that,array,byteOffset,length){array.byteLength;// this throws if `array` is not a valid ArrayBuffer
if(byteOffset<0||array.byteLength<byteOffset){throw new RangeError('\'offset\' is out of bounds');}if(array.byteLength<byteOffset+(length||0)){throw new RangeError('\'length\' is out of bounds');}if(byteOffset===undefined&&length===undefined){array=new Uint8Array(array);}else if(length===undefined){array=new Uint8Array(array,byteOffset);}else{array=new Uint8Array(array,byteOffset,length);}if(Buffer.TYPED_ARRAY_SUPPORT){// Return an augmented `Uint8Array` instance, for best performance
that=array;that.__proto__=Buffer.prototype;}else{// Fallback: Return an object instance of the Buffer class
that=fromArrayLike(that,array);}return that;}function fromObject(that,obj){if(Buffer.isBuffer(obj)){var len=checked(obj.length)|0;that=createBuffer(that,len);if(that.length===0){return that;}obj.copy(that,0,0,len);return that;}if(obj){if(typeof ArrayBuffer!=='undefined'&&obj.buffer instanceof ArrayBuffer||'length'in obj){if(typeof obj.length!=='number'||isnan(obj.length)){return createBuffer(that,0);}return fromArrayLike(that,obj);}if(obj.type==='Buffer'&&isArray(obj.data)){return fromArrayLike(that,obj.data);}}throw new TypeError('First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.');}function checked(length){// Note: cannot use `length < kMaxLength()` here because that fails when
// length is NaN (which is otherwise coerced to zero.)
if(length>=kMaxLength()){throw new RangeError('Attempt to allocate Buffer larger than maximum '+'size: 0x'+kMaxLength().toString(16)+' bytes');}return length|0;}function SlowBuffer(length){if(+length!=length){// eslint-disable-line eqeqeq
length=0;}return Buffer.alloc(+length);}Buffer.isBuffer=function isBuffer(b){return!!(b!=null&&b._isBuffer);};Buffer.compare=function compare(a,b){if(!Buffer.isBuffer(a)||!Buffer.isBuffer(b)){throw new TypeError('Arguments must be Buffers');}if(a===b)return 0;var x=a.length;var y=b.length;for(var i=0,len=Math.min(x,y);i<len;++i){if(a[i]!==b[i]){x=a[i];y=b[i];break;}}if(x<y)return-1;if(y<x)return 1;return 0;};Buffer.isEncoding=function isEncoding(encoding){switch(String(encoding).toLowerCase()){case'hex':case'utf8':case'utf-8':case'ascii':case'latin1':case'binary':case'base64':case'ucs2':case'ucs-2':case'utf16le':case'utf-16le':return true;default:return false;}};Buffer.concat=function concat(list,length){if(!isArray(list)){throw new TypeError('"list" argument must be an Array of Buffers');}if(list.length===0){return Buffer.alloc(0);}var i;if(length===undefined){length=0;for(i=0;i<list.length;++i){length+=list[i].length;}}var buffer=Buffer.allocUnsafe(length);var pos=0;for(i=0;i<list.length;++i){var buf=list[i];if(!Buffer.isBuffer(buf)){throw new TypeError('"list" argument must be an Array of Buffers');}buf.copy(buffer,pos);pos+=buf.length;}return buffer;};function byteLength(string,encoding){if(Buffer.isBuffer(string)){return string.length;}if(typeof ArrayBuffer!=='undefined'&&typeof ArrayBuffer.isView==='function'&&(ArrayBuffer.isView(string)||string instanceof ArrayBuffer)){return string.byteLength;}if(typeof string!=='string'){string=''+string;}var len=string.length;if(len===0)return 0;// Use a for loop to avoid recursion
var loweredCase=false;for(;;){switch(encoding){case'ascii':case'latin1':case'binary':return len;case'utf8':case'utf-8':case undefined:return utf8ToBytes(string).length;case'ucs2':case'ucs-2':case'utf16le':case'utf-16le':return len*2;case'hex':return len>>>1;case'base64':return base64ToBytes(string).length;default:if(loweredCase)return utf8ToBytes(string).length;// assume utf8
encoding=(''+encoding).toLowerCase();loweredCase=true;}}}Buffer.byteLength=byteLength;function slowToString(encoding,start,end){var loweredCase=false;// No need to verify that "this.length <= MAX_UINT32" since it's a read-only
// property of a typed array.
// This behaves neither like String nor Uint8Array in that we set start/end
// to their upper/lower bounds if the value passed is out of range.
// undefined is handled specially as per ECMA-262 6th Edition,
// Section 13.3.3.7 Runtime Semantics: KeyedBindingInitialization.
if(start===undefined||start<0){start=0;}// Return early if start > this.length. Done here to prevent potential uint32
// coercion fail below.
if(start>this.length){return'';}if(end===undefined||end>this.length){end=this.length;}if(end<=0){return'';}// Force coersion to uint32. This will also coerce falsey/NaN values to 0.
end>>>=0;start>>>=0;if(end<=start){return'';}if(!encoding)encoding='utf8';while(true){switch(encoding){case'hex':return hexSlice(this,start,end);case'utf8':case'utf-8':return utf8Slice(this,start,end);case'ascii':return asciiSlice(this,start,end);case'latin1':case'binary':return latin1Slice(this,start,end);case'base64':return base64Slice(this,start,end);case'ucs2':case'ucs-2':case'utf16le':case'utf-16le':return utf16leSlice(this,start,end);default:if(loweredCase)throw new TypeError('Unknown encoding: '+encoding);encoding=(encoding+'').toLowerCase();loweredCase=true;}}}// The property is used by `Buffer.isBuffer` and `is-buffer` (in Safari 5-7) to detect
// Buffer instances.
Buffer.prototype._isBuffer=true;function swap(b,n,m){var i=b[n];b[n]=b[m];b[m]=i;}Buffer.prototype.swap16=function swap16(){var len=this.length;if(len%2!==0){throw new RangeError('Buffer size must be a multiple of 16-bits');}for(var i=0;i<len;i+=2){swap(this,i,i+1);}return this;};Buffer.prototype.swap32=function swap32(){var len=this.length;if(len%4!==0){throw new RangeError('Buffer size must be a multiple of 32-bits');}for(var i=0;i<len;i+=4){swap(this,i,i+3);swap(this,i+1,i+2);}return this;};Buffer.prototype.swap64=function swap64(){var len=this.length;if(len%8!==0){throw new RangeError('Buffer size must be a multiple of 64-bits');}for(var i=0;i<len;i+=8){swap(this,i,i+7);swap(this,i+1,i+6);swap(this,i+2,i+5);swap(this,i+3,i+4);}return this;};Buffer.prototype.toString=function toString(){var length=this.length|0;if(length===0)return'';if(arguments.length===0)return utf8Slice(this,0,length);return slowToString.apply(this,arguments);};Buffer.prototype.equals=function equals(b){if(!Buffer.isBuffer(b))throw new TypeError('Argument must be a Buffer');if(this===b)return true;return Buffer.compare(this,b)===0;};Buffer.prototype.inspect=function inspect(){var str='';var max=exports.INSPECT_MAX_BYTES;if(this.length>0){str=this.toString('hex',0,max).match(/.{2}/g).join(' ');if(this.length>max)str+=' ... ';}return'<Buffer '+str+'>';};Buffer.prototype.compare=function compare(target,start,end,thisStart,thisEnd){if(!Buffer.isBuffer(target)){throw new TypeError('Argument must be a Buffer');}if(start===undefined){start=0;}if(end===undefined){end=target?target.length:0;}if(thisStart===undefined){thisStart=0;}if(thisEnd===undefined){thisEnd=this.length;}if(start<0||end>target.length||thisStart<0||thisEnd>this.length){throw new RangeError('out of range index');}if(thisStart>=thisEnd&&start>=end){return 0;}if(thisStart>=thisEnd){return-1;}if(start>=end){return 1;}start>>>=0;end>>>=0;thisStart>>>=0;thisEnd>>>=0;if(this===target)return 0;var x=thisEnd-thisStart;var y=end-start;var len=Math.min(x,y);var thisCopy=this.slice(thisStart,thisEnd);var targetCopy=target.slice(start,end);for(var i=0;i<len;++i){if(thisCopy[i]!==targetCopy[i]){x=thisCopy[i];y=targetCopy[i];break;}}if(x<y)return-1;if(y<x)return 1;return 0;};// Finds either the first index of `val` in `buffer` at offset >= `byteOffset`,
// OR the last index of `val` in `buffer` at offset <= `byteOffset`.
//
// Arguments:
// - buffer - a Buffer to search
// - val - a string, Buffer, or number
// - byteOffset - an index into `buffer`; will be clamped to an int32
// - encoding - an optional encoding, relevant is val is a string
// - dir - true for indexOf, false for lastIndexOf
function bidirectionalIndexOf(buffer,val,byteOffset,encoding,dir){// Empty buffer means no match
if(buffer.length===0)return-1;// Normalize byteOffset
if(typeof byteOffset==='string'){encoding=byteOffset;byteOffset=0;}else if(byteOffset>0x7fffffff){byteOffset=0x7fffffff;}else if(byteOffset<-0x80000000){byteOffset=-0x80000000;}byteOffset=+byteOffset;// Coerce to Number.
if(isNaN(byteOffset)){// byteOffset: it it's undefined, null, NaN, "foo", etc, search whole buffer
byteOffset=dir?0:buffer.length-1;}// Normalize byteOffset: negative offsets start from the end of the buffer
if(byteOffset<0)byteOffset=buffer.length+byteOffset;if(byteOffset>=buffer.length){if(dir)return-1;else byteOffset=buffer.length-1;}else if(byteOffset<0){if(dir)byteOffset=0;else return-1;}// Normalize val
if(typeof val==='string'){val=Buffer.from(val,encoding);}// Finally, search either indexOf (if dir is true) or lastIndexOf
if(Buffer.isBuffer(val)){// Special case: looking for empty string/buffer always fails
if(val.length===0){return-1;}return arrayIndexOf(buffer,val,byteOffset,encoding,dir);}else if(typeof val==='number'){val=val&0xFF;// Search for a byte value [0-255]
if(Buffer.TYPED_ARRAY_SUPPORT&&typeof Uint8Array.prototype.indexOf==='function'){if(dir){return Uint8Array.prototype.indexOf.call(buffer,val,byteOffset);}else{return Uint8Array.prototype.lastIndexOf.call(buffer,val,byteOffset);}}return arrayIndexOf(buffer,[val],byteOffset,encoding,dir);}throw new TypeError('val must be string, number or Buffer');}function arrayIndexOf(arr,val,byteOffset,encoding,dir){var indexSize=1;var arrLength=arr.length;var valLength=val.length;if(encoding!==undefined){encoding=String(encoding).toLowerCase();if(encoding==='ucs2'||encoding==='ucs-2'||encoding==='utf16le'||encoding==='utf-16le'){if(arr.length<2||val.length<2){return-1;}indexSize=2;arrLength/=2;valLength/=2;byteOffset/=2;}}function read(buf,i){if(indexSize===1){return buf[i];}else{return buf.readUInt16BE(i*indexSize);}}var i;if(dir){var foundIndex=-1;for(i=byteOffset;i<arrLength;i++){if(read(arr,i)===read(val,foundIndex===-1?0:i-foundIndex)){if(foundIndex===-1)foundIndex=i;if(i-foundIndex+1===valLength)return foundIndex*indexSize;}else{if(foundIndex!==-1)i-=i-foundIndex;foundIndex=-1;}}}else{if(byteOffset+valLength>arrLength)byteOffset=arrLength-valLength;for(i=byteOffset;i>=0;i--){var found=true;for(var j=0;j<valLength;j++){if(read(arr,i+j)!==read(val,j)){found=false;break;}}if(found)return i;}}return-1;}Buffer.prototype.includes=function includes(val,byteOffset,encoding){return this.indexOf(val,byteOffset,encoding)!==-1;};Buffer.prototype.indexOf=function indexOf(val,byteOffset,encoding){return bidirectionalIndexOf(this,val,byteOffset,encoding,true);};Buffer.prototype.lastIndexOf=function lastIndexOf(val,byteOffset,encoding){return bidirectionalIndexOf(this,val,byteOffset,encoding,false);};function hexWrite(buf,string,offset,length){offset=Number(offset)||0;var remaining=buf.length-offset;if(!length){length=remaining;}else{length=Number(length);if(length>remaining){length=remaining;}}// must be an even number of digits
var strLen=string.length;if(strLen%2!==0)throw new TypeError('Invalid hex string');if(length>strLen/2){length=strLen/2;}for(var i=0;i<length;++i){var parsed=parseInt(string.substr(i*2,2),16);if(isNaN(parsed))return i;buf[offset+i]=parsed;}return i;}function utf8Write(buf,string,offset,length){return blitBuffer(utf8ToBytes(string,buf.length-offset),buf,offset,length);}function asciiWrite(buf,string,offset,length){return blitBuffer(asciiToBytes(string),buf,offset,length);}function latin1Write(buf,string,offset,length){return asciiWrite(buf,string,offset,length);}function base64Write(buf,string,offset,length){return blitBuffer(base64ToBytes(string),buf,offset,length);}function ucs2Write(buf,string,offset,length){return blitBuffer(utf16leToBytes(string,buf.length-offset),buf,offset,length);}Buffer.prototype.write=function write(string,offset,length,encoding){// Buffer#write(string)
if(offset===undefined){encoding='utf8';length=this.length;offset=0;// Buffer#write(string, encoding)
}else if(length===undefined&&typeof offset==='string'){encoding=offset;length=this.length;offset=0;// Buffer#write(string, offset[, length][, encoding])
}else if(isFinite(offset)){offset=offset|0;if(isFinite(length)){length=length|0;if(encoding===undefined)encoding='utf8';}else{encoding=length;length=undefined;}// legacy write(string, encoding, offset, length) - remove in v0.13
}else{throw new Error('Buffer.write(string, encoding, offset[, length]) is no longer supported');}var remaining=this.length-offset;if(length===undefined||length>remaining)length=remaining;if(string.length>0&&(length<0||offset<0)||offset>this.length){throw new RangeError('Attempt to write outside buffer bounds');}if(!encoding)encoding='utf8';var loweredCase=false;for(;;){switch(encoding){case'hex':return hexWrite(this,string,offset,length);case'utf8':case'utf-8':return utf8Write(this,string,offset,length);case'ascii':return asciiWrite(this,string,offset,length);case'latin1':case'binary':return latin1Write(this,string,offset,length);case'base64':// Warning: maxLength not taken into account in base64Write
return base64Write(this,string,offset,length);case'ucs2':case'ucs-2':case'utf16le':case'utf-16le':return ucs2Write(this,string,offset,length);default:if(loweredCase)throw new TypeError('Unknown encoding: '+encoding);encoding=(''+encoding).toLowerCase();loweredCase=true;}}};Buffer.prototype.toJSON=function toJSON(){return{type:'Buffer',data:Array.prototype.slice.call(this._arr||this,0)};};function base64Slice(buf,start,end){if(start===0&&end===buf.length){return base64.fromByteArray(buf);}else{return base64.fromByteArray(buf.slice(start,end));}}function utf8Slice(buf,start,end){end=Math.min(buf.length,end);var res=[];var i=start;while(i<end){var firstByte=buf[i];var codePoint=null;var bytesPerSequence=firstByte>0xEF?4:firstByte>0xDF?3:firstByte>0xBF?2:1;if(i+bytesPerSequence<=end){var secondByte,thirdByte,fourthByte,tempCodePoint;switch(bytesPerSequence){case 1:if(firstByte<0x80){codePoint=firstByte;}break;case 2:secondByte=buf[i+1];if((secondByte&0xC0)===0x80){tempCodePoint=(firstByte&0x1F)<<0x6|secondByte&0x3F;if(tempCodePoint>0x7F){codePoint=tempCodePoint;}}break;case 3:secondByte=buf[i+1];thirdByte=buf[i+2];if((secondByte&0xC0)===0x80&&(thirdByte&0xC0)===0x80){tempCodePoint=(firstByte&0xF)<<0xC|(secondByte&0x3F)<<0x6|thirdByte&0x3F;if(tempCodePoint>0x7FF&&(tempCodePoint<0xD800||tempCodePoint>0xDFFF)){codePoint=tempCodePoint;}}break;case 4:secondByte=buf[i+1];thirdByte=buf[i+2];fourthByte=buf[i+3];if((secondByte&0xC0)===0x80&&(thirdByte&0xC0)===0x80&&(fourthByte&0xC0)===0x80){tempCodePoint=(firstByte&0xF)<<0x12|(secondByte&0x3F)<<0xC|(thirdByte&0x3F)<<0x6|fourthByte&0x3F;if(tempCodePoint>0xFFFF&&tempCodePoint<0x110000){codePoint=tempCodePoint;}}}}if(codePoint===null){// we did not generate a valid codePoint so insert a
// replacement char (U+FFFD) and advance only 1 byte
codePoint=0xFFFD;bytesPerSequence=1;}else if(codePoint>0xFFFF){// encode to utf16 (surrogate pair dance)
codePoint-=0x10000;res.push(codePoint>>>10&0x3FF|0xD800);codePoint=0xDC00|codePoint&0x3FF;}res.push(codePoint);i+=bytesPerSequence;}return decodeCodePointsArray(res);}// Based on http://stackoverflow.com/a/22747272/680742, the browser with
// the lowest limit is Chrome, with 0x10000 args.
// We go 1 magnitude less, for safety
var MAX_ARGUMENTS_LENGTH=0x1000;function decodeCodePointsArray(codePoints){var len=codePoints.length;if(len<=MAX_ARGUMENTS_LENGTH){return String.fromCharCode.apply(String,codePoints);// avoid extra slice()
}// Decode in chunks to avoid "call stack size exceeded".
var res='';var i=0;while(i<len){res+=String.fromCharCode.apply(String,codePoints.slice(i,i+=MAX_ARGUMENTS_LENGTH));}return res;}function asciiSlice(buf,start,end){var ret='';end=Math.min(buf.length,end);for(var i=start;i<end;++i){ret+=String.fromCharCode(buf[i]&0x7F);}return ret;}function latin1Slice(buf,start,end){var ret='';end=Math.min(buf.length,end);for(var i=start;i<end;++i){ret+=String.fromCharCode(buf[i]);}return ret;}function hexSlice(buf,start,end){var len=buf.length;if(!start||start<0)start=0;if(!end||end<0||end>len)end=len;var out='';for(var i=start;i<end;++i){out+=toHex(buf[i]);}return out;}function utf16leSlice(buf,start,end){var bytes=buf.slice(start,end);var res='';for(var i=0;i<bytes.length;i+=2){res+=String.fromCharCode(bytes[i]+bytes[i+1]*256);}return res;}Buffer.prototype.slice=function slice(start,end){var len=this.length;start=~~start;end=end===undefined?len:~~end;if(start<0){start+=len;if(start<0)start=0;}else if(start>len){start=len;}if(end<0){end+=len;if(end<0)end=0;}else if(end>len){end=len;}if(end<start)end=start;var newBuf;if(Buffer.TYPED_ARRAY_SUPPORT){newBuf=this.subarray(start,end);newBuf.__proto__=Buffer.prototype;}else{var sliceLen=end-start;newBuf=new Buffer(sliceLen,undefined);for(var i=0;i<sliceLen;++i){newBuf[i]=this[i+start];}}return newBuf;};/*
 * Need to make sure that buffer isn't trying to write out of bounds.
 */function checkOffset(offset,ext,length){if(offset%1!==0||offset<0)throw new RangeError('offset is not uint');if(offset+ext>length)throw new RangeError('Trying to access beyond buffer length');}Buffer.prototype.readUIntLE=function readUIntLE(offset,byteLength,noAssert){offset=offset|0;byteLength=byteLength|0;if(!noAssert)checkOffset(offset,byteLength,this.length);var val=this[offset];var mul=1;var i=0;while(++i<byteLength&&(mul*=0x100)){val+=this[offset+i]*mul;}return val;};Buffer.prototype.readUIntBE=function readUIntBE(offset,byteLength,noAssert){offset=offset|0;byteLength=byteLength|0;if(!noAssert){checkOffset(offset,byteLength,this.length);}var val=this[offset+--byteLength];var mul=1;while(byteLength>0&&(mul*=0x100)){val+=this[offset+--byteLength]*mul;}return val;};Buffer.prototype.readUInt8=function readUInt8(offset,noAssert){if(!noAssert)checkOffset(offset,1,this.length);return this[offset];};Buffer.prototype.readUInt16LE=function readUInt16LE(offset,noAssert){if(!noAssert)checkOffset(offset,2,this.length);return this[offset]|this[offset+1]<<8;};Buffer.prototype.readUInt16BE=function readUInt16BE(offset,noAssert){if(!noAssert)checkOffset(offset,2,this.length);return this[offset]<<8|this[offset+1];};Buffer.prototype.readUInt32LE=function readUInt32LE(offset,noAssert){if(!noAssert)checkOffset(offset,4,this.length);return(this[offset]|this[offset+1]<<8|this[offset+2]<<16)+this[offset+3]*0x1000000;};Buffer.prototype.readUInt32BE=function readUInt32BE(offset,noAssert){if(!noAssert)checkOffset(offset,4,this.length);return this[offset]*0x1000000+(this[offset+1]<<16|this[offset+2]<<8|this[offset+3]);};Buffer.prototype.readIntLE=function readIntLE(offset,byteLength,noAssert){offset=offset|0;byteLength=byteLength|0;if(!noAssert)checkOffset(offset,byteLength,this.length);var val=this[offset];var mul=1;var i=0;while(++i<byteLength&&(mul*=0x100)){val+=this[offset+i]*mul;}mul*=0x80;if(val>=mul)val-=Math.pow(2,8*byteLength);return val;};Buffer.prototype.readIntBE=function readIntBE(offset,byteLength,noAssert){offset=offset|0;byteLength=byteLength|0;if(!noAssert)checkOffset(offset,byteLength,this.length);var i=byteLength;var mul=1;var val=this[offset+--i];while(i>0&&(mul*=0x100)){val+=this[offset+--i]*mul;}mul*=0x80;if(val>=mul)val-=Math.pow(2,8*byteLength);return val;};Buffer.prototype.readInt8=function readInt8(offset,noAssert){if(!noAssert)checkOffset(offset,1,this.length);if(!(this[offset]&0x80))return this[offset];return(0xff-this[offset]+1)*-1;};Buffer.prototype.readInt16LE=function readInt16LE(offset,noAssert){if(!noAssert)checkOffset(offset,2,this.length);var val=this[offset]|this[offset+1]<<8;return val&0x8000?val|0xFFFF0000:val;};Buffer.prototype.readInt16BE=function readInt16BE(offset,noAssert){if(!noAssert)checkOffset(offset,2,this.length);var val=this[offset+1]|this[offset]<<8;return val&0x8000?val|0xFFFF0000:val;};Buffer.prototype.readInt32LE=function readInt32LE(offset,noAssert){if(!noAssert)checkOffset(offset,4,this.length);return this[offset]|this[offset+1]<<8|this[offset+2]<<16|this[offset+3]<<24;};Buffer.prototype.readInt32BE=function readInt32BE(offset,noAssert){if(!noAssert)checkOffset(offset,4,this.length);return this[offset]<<24|this[offset+1]<<16|this[offset+2]<<8|this[offset+3];};Buffer.prototype.readFloatLE=function readFloatLE(offset,noAssert){if(!noAssert)checkOffset(offset,4,this.length);return ieee754.read(this,offset,true,23,4);};Buffer.prototype.readFloatBE=function readFloatBE(offset,noAssert){if(!noAssert)checkOffset(offset,4,this.length);return ieee754.read(this,offset,false,23,4);};Buffer.prototype.readDoubleLE=function readDoubleLE(offset,noAssert){if(!noAssert)checkOffset(offset,8,this.length);return ieee754.read(this,offset,true,52,8);};Buffer.prototype.readDoubleBE=function readDoubleBE(offset,noAssert){if(!noAssert)checkOffset(offset,8,this.length);return ieee754.read(this,offset,false,52,8);};function checkInt(buf,value,offset,ext,max,min){if(!Buffer.isBuffer(buf))throw new TypeError('"buffer" argument must be a Buffer instance');if(value>max||value<min)throw new RangeError('"value" argument is out of bounds');if(offset+ext>buf.length)throw new RangeError('Index out of range');}Buffer.prototype.writeUIntLE=function writeUIntLE(value,offset,byteLength,noAssert){value=+value;offset=offset|0;byteLength=byteLength|0;if(!noAssert){var maxBytes=Math.pow(2,8*byteLength)-1;checkInt(this,value,offset,byteLength,maxBytes,0);}var mul=1;var i=0;this[offset]=value&0xFF;while(++i<byteLength&&(mul*=0x100)){this[offset+i]=value/mul&0xFF;}return offset+byteLength;};Buffer.prototype.writeUIntBE=function writeUIntBE(value,offset,byteLength,noAssert){value=+value;offset=offset|0;byteLength=byteLength|0;if(!noAssert){var maxBytes=Math.pow(2,8*byteLength)-1;checkInt(this,value,offset,byteLength,maxBytes,0);}var i=byteLength-1;var mul=1;this[offset+i]=value&0xFF;while(--i>=0&&(mul*=0x100)){this[offset+i]=value/mul&0xFF;}return offset+byteLength;};Buffer.prototype.writeUInt8=function writeUInt8(value,offset,noAssert){value=+value;offset=offset|0;if(!noAssert)checkInt(this,value,offset,1,0xff,0);if(!Buffer.TYPED_ARRAY_SUPPORT)value=Math.floor(value);this[offset]=value&0xff;return offset+1;};function objectWriteUInt16(buf,value,offset,littleEndian){if(value<0)value=0xffff+value+1;for(var i=0,j=Math.min(buf.length-offset,2);i<j;++i){buf[offset+i]=(value&0xff<<8*(littleEndian?i:1-i))>>>(littleEndian?i:1-i)*8;}}Buffer.prototype.writeUInt16LE=function writeUInt16LE(value,offset,noAssert){value=+value;offset=offset|0;if(!noAssert)checkInt(this,value,offset,2,0xffff,0);if(Buffer.TYPED_ARRAY_SUPPORT){this[offset]=value&0xff;this[offset+1]=value>>>8;}else{objectWriteUInt16(this,value,offset,true);}return offset+2;};Buffer.prototype.writeUInt16BE=function writeUInt16BE(value,offset,noAssert){value=+value;offset=offset|0;if(!noAssert)checkInt(this,value,offset,2,0xffff,0);if(Buffer.TYPED_ARRAY_SUPPORT){this[offset]=value>>>8;this[offset+1]=value&0xff;}else{objectWriteUInt16(this,value,offset,false);}return offset+2;};function objectWriteUInt32(buf,value,offset,littleEndian){if(value<0)value=0xffffffff+value+1;for(var i=0,j=Math.min(buf.length-offset,4);i<j;++i){buf[offset+i]=value>>>(littleEndian?i:3-i)*8&0xff;}}Buffer.prototype.writeUInt32LE=function writeUInt32LE(value,offset,noAssert){value=+value;offset=offset|0;if(!noAssert)checkInt(this,value,offset,4,0xffffffff,0);if(Buffer.TYPED_ARRAY_SUPPORT){this[offset+3]=value>>>24;this[offset+2]=value>>>16;this[offset+1]=value>>>8;this[offset]=value&0xff;}else{objectWriteUInt32(this,value,offset,true);}return offset+4;};Buffer.prototype.writeUInt32BE=function writeUInt32BE(value,offset,noAssert){value=+value;offset=offset|0;if(!noAssert)checkInt(this,value,offset,4,0xffffffff,0);if(Buffer.TYPED_ARRAY_SUPPORT){this[offset]=value>>>24;this[offset+1]=value>>>16;this[offset+2]=value>>>8;this[offset+3]=value&0xff;}else{objectWriteUInt32(this,value,offset,false);}return offset+4;};Buffer.prototype.writeIntLE=function writeIntLE(value,offset,byteLength,noAssert){value=+value;offset=offset|0;if(!noAssert){var limit=Math.pow(2,8*byteLength-1);checkInt(this,value,offset,byteLength,limit-1,-limit);}var i=0;var mul=1;var sub=0;this[offset]=value&0xFF;while(++i<byteLength&&(mul*=0x100)){if(value<0&&sub===0&&this[offset+i-1]!==0){sub=1;}this[offset+i]=(value/mul>>0)-sub&0xFF;}return offset+byteLength;};Buffer.prototype.writeIntBE=function writeIntBE(value,offset,byteLength,noAssert){value=+value;offset=offset|0;if(!noAssert){var limit=Math.pow(2,8*byteLength-1);checkInt(this,value,offset,byteLength,limit-1,-limit);}var i=byteLength-1;var mul=1;var sub=0;this[offset+i]=value&0xFF;while(--i>=0&&(mul*=0x100)){if(value<0&&sub===0&&this[offset+i+1]!==0){sub=1;}this[offset+i]=(value/mul>>0)-sub&0xFF;}return offset+byteLength;};Buffer.prototype.writeInt8=function writeInt8(value,offset,noAssert){value=+value;offset=offset|0;if(!noAssert)checkInt(this,value,offset,1,0x7f,-0x80);if(!Buffer.TYPED_ARRAY_SUPPORT)value=Math.floor(value);if(value<0)value=0xff+value+1;this[offset]=value&0xff;return offset+1;};Buffer.prototype.writeInt16LE=function writeInt16LE(value,offset,noAssert){value=+value;offset=offset|0;if(!noAssert)checkInt(this,value,offset,2,0x7fff,-0x8000);if(Buffer.TYPED_ARRAY_SUPPORT){this[offset]=value&0xff;this[offset+1]=value>>>8;}else{objectWriteUInt16(this,value,offset,true);}return offset+2;};Buffer.prototype.writeInt16BE=function writeInt16BE(value,offset,noAssert){value=+value;offset=offset|0;if(!noAssert)checkInt(this,value,offset,2,0x7fff,-0x8000);if(Buffer.TYPED_ARRAY_SUPPORT){this[offset]=value>>>8;this[offset+1]=value&0xff;}else{objectWriteUInt16(this,value,offset,false);}return offset+2;};Buffer.prototype.writeInt32LE=function writeInt32LE(value,offset,noAssert){value=+value;offset=offset|0;if(!noAssert)checkInt(this,value,offset,4,0x7fffffff,-0x80000000);if(Buffer.TYPED_ARRAY_SUPPORT){this[offset]=value&0xff;this[offset+1]=value>>>8;this[offset+2]=value>>>16;this[offset+3]=value>>>24;}else{objectWriteUInt32(this,value,offset,true);}return offset+4;};Buffer.prototype.writeInt32BE=function writeInt32BE(value,offset,noAssert){value=+value;offset=offset|0;if(!noAssert)checkInt(this,value,offset,4,0x7fffffff,-0x80000000);if(value<0)value=0xffffffff+value+1;if(Buffer.TYPED_ARRAY_SUPPORT){this[offset]=value>>>24;this[offset+1]=value>>>16;this[offset+2]=value>>>8;this[offset+3]=value&0xff;}else{objectWriteUInt32(this,value,offset,false);}return offset+4;};function checkIEEE754(buf,value,offset,ext,max,min){if(offset+ext>buf.length)throw new RangeError('Index out of range');if(offset<0)throw new RangeError('Index out of range');}function writeFloat(buf,value,offset,littleEndian,noAssert){if(!noAssert){checkIEEE754(buf,value,offset,4,3.4028234663852886e+38,-3.4028234663852886e+38);}ieee754.write(buf,value,offset,littleEndian,23,4);return offset+4;}Buffer.prototype.writeFloatLE=function writeFloatLE(value,offset,noAssert){return writeFloat(this,value,offset,true,noAssert);};Buffer.prototype.writeFloatBE=function writeFloatBE(value,offset,noAssert){return writeFloat(this,value,offset,false,noAssert);};function writeDouble(buf,value,offset,littleEndian,noAssert){if(!noAssert){checkIEEE754(buf,value,offset,8,1.7976931348623157E+308,-1.7976931348623157E+308);}ieee754.write(buf,value,offset,littleEndian,52,8);return offset+8;}Buffer.prototype.writeDoubleLE=function writeDoubleLE(value,offset,noAssert){return writeDouble(this,value,offset,true,noAssert);};Buffer.prototype.writeDoubleBE=function writeDoubleBE(value,offset,noAssert){return writeDouble(this,value,offset,false,noAssert);};// copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
Buffer.prototype.copy=function copy(target,targetStart,start,end){if(!start)start=0;if(!end&&end!==0)end=this.length;if(targetStart>=target.length)targetStart=target.length;if(!targetStart)targetStart=0;if(end>0&&end<start)end=start;// Copy 0 bytes; we're done
if(end===start)return 0;if(target.length===0||this.length===0)return 0;// Fatal error conditions
if(targetStart<0){throw new RangeError('targetStart out of bounds');}if(start<0||start>=this.length)throw new RangeError('sourceStart out of bounds');if(end<0)throw new RangeError('sourceEnd out of bounds');// Are we oob?
if(end>this.length)end=this.length;if(target.length-targetStart<end-start){end=target.length-targetStart+start;}var len=end-start;var i;if(this===target&&start<targetStart&&targetStart<end){// descending copy from end
for(i=len-1;i>=0;--i){target[i+targetStart]=this[i+start];}}else if(len<1000||!Buffer.TYPED_ARRAY_SUPPORT){// ascending copy from start
for(i=0;i<len;++i){target[i+targetStart]=this[i+start];}}else{Uint8Array.prototype.set.call(target,this.subarray(start,start+len),targetStart);}return len;};// Usage:
//    buffer.fill(number[, offset[, end]])
//    buffer.fill(buffer[, offset[, end]])
//    buffer.fill(string[, offset[, end]][, encoding])
Buffer.prototype.fill=function fill(val,start,end,encoding){// Handle string cases:
if(typeof val==='string'){if(typeof start==='string'){encoding=start;start=0;end=this.length;}else if(typeof end==='string'){encoding=end;end=this.length;}if(val.length===1){var code=val.charCodeAt(0);if(code<256){val=code;}}if(encoding!==undefined&&typeof encoding!=='string'){throw new TypeError('encoding must be a string');}if(typeof encoding==='string'&&!Buffer.isEncoding(encoding)){throw new TypeError('Unknown encoding: '+encoding);}}else if(typeof val==='number'){val=val&255;}// Invalid ranges are not set to a default, so can range check early.
if(start<0||this.length<start||this.length<end){throw new RangeError('Out of range index');}if(end<=start){return this;}start=start>>>0;end=end===undefined?this.length:end>>>0;if(!val)val=0;var i;if(typeof val==='number'){for(i=start;i<end;++i){this[i]=val;}}else{var bytes=Buffer.isBuffer(val)?val:utf8ToBytes(new Buffer(val,encoding).toString());var len=bytes.length;for(i=0;i<end-start;++i){this[i+start]=bytes[i%len];}}return this;};// HELPER FUNCTIONS
// ================
var INVALID_BASE64_RE=/[^+\/0-9A-Za-z-_]/g;function base64clean(str){// Node strips out invalid characters like \n and \t from the string, base64-js does not
str=stringtrim(str).replace(INVALID_BASE64_RE,'');// Node converts strings with length < 2 to ''
if(str.length<2)return'';// Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
while(str.length%4!==0){str=str+'=';}return str;}function stringtrim(str){if(str.trim)return str.trim();return str.replace(/^\s+|\s+$/g,'');}function toHex(n){if(n<16)return'0'+n.toString(16);return n.toString(16);}function utf8ToBytes(string,units){units=units||Infinity;var codePoint;var length=string.length;var leadSurrogate=null;var bytes=[];for(var i=0;i<length;++i){codePoint=string.charCodeAt(i);// is surrogate component
if(codePoint>0xD7FF&&codePoint<0xE000){// last char was a lead
if(!leadSurrogate){// no lead yet
if(codePoint>0xDBFF){// unexpected trail
if((units-=3)>-1)bytes.push(0xEF,0xBF,0xBD);continue;}else if(i+1===length){// unpaired lead
if((units-=3)>-1)bytes.push(0xEF,0xBF,0xBD);continue;}// valid lead
leadSurrogate=codePoint;continue;}// 2 leads in a row
if(codePoint<0xDC00){if((units-=3)>-1)bytes.push(0xEF,0xBF,0xBD);leadSurrogate=codePoint;continue;}// valid surrogate pair
codePoint=(leadSurrogate-0xD800<<10|codePoint-0xDC00)+0x10000;}else if(leadSurrogate){// valid bmp char, but last char was a lead
if((units-=3)>-1)bytes.push(0xEF,0xBF,0xBD);}leadSurrogate=null;// encode utf8
if(codePoint<0x80){if((units-=1)<0)break;bytes.push(codePoint);}else if(codePoint<0x800){if((units-=2)<0)break;bytes.push(codePoint>>0x6|0xC0,codePoint&0x3F|0x80);}else if(codePoint<0x10000){if((units-=3)<0)break;bytes.push(codePoint>>0xC|0xE0,codePoint>>0x6&0x3F|0x80,codePoint&0x3F|0x80);}else if(codePoint<0x110000){if((units-=4)<0)break;bytes.push(codePoint>>0x12|0xF0,codePoint>>0xC&0x3F|0x80,codePoint>>0x6&0x3F|0x80,codePoint&0x3F|0x80);}else{throw new Error('Invalid code point');}}return bytes;}function asciiToBytes(str){var byteArray=[];for(var i=0;i<str.length;++i){// Node's code seems to be doing this and not & 0x7F..
byteArray.push(str.charCodeAt(i)&0xFF);}return byteArray;}function utf16leToBytes(str,units){var c,hi,lo;var byteArray=[];for(var i=0;i<str.length;++i){if((units-=2)<0)break;c=str.charCodeAt(i);hi=c>>8;lo=c%256;byteArray.push(lo);byteArray.push(hi);}return byteArray;}function base64ToBytes(str){return base64.toByteArray(base64clean(str));}function blitBuffer(src,dst,offset,length){for(var i=0;i<length;++i){if(i+offset>=dst.length||i>=src.length)break;dst[i+offset]=src[i];}return i;}function isnan(val){return val!==val;// eslint-disable-line no-self-compare
}
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__("../node_modules/webpack/buildin/global.js")))

/***/ }),

/***/ "../../../node_modules/object-assign/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*
object-assign
(c) Sindre Sorhus
@license MIT
*//* eslint-disable no-unused-vars */var getOwnPropertySymbols=Object.getOwnPropertySymbols;var hasOwnProperty=Object.prototype.hasOwnProperty;var propIsEnumerable=Object.prototype.propertyIsEnumerable;function toObject(val){if(val===null||val===undefined){throw new TypeError('Object.assign cannot be called with null or undefined');}return Object(val);}function shouldUseNative(){try{if(!Object.assign){return false;}// Detect buggy property enumeration order in older V8 versions.
// https://bugs.chromium.org/p/v8/issues/detail?id=4118
var test1=new String('abc');// eslint-disable-line no-new-wrappers
test1[5]='de';if(Object.getOwnPropertyNames(test1)[0]==='5'){return false;}// https://bugs.chromium.org/p/v8/issues/detail?id=3056
var test2={};for(var i=0;i<10;i++){test2['_'+String.fromCharCode(i)]=i;}var order2=Object.getOwnPropertyNames(test2).map(function(n){return test2[n];});if(order2.join('')!=='0123456789'){return false;}// https://bugs.chromium.org/p/v8/issues/detail?id=3056
var test3={};'abcdefghijklmnopqrst'.split('').forEach(function(letter){test3[letter]=letter;});if(Object.keys(Object.assign({},test3)).join('')!=='abcdefghijklmnopqrst'){return false;}return true;}catch(err){// We don't expect any of the above to throw, but better to be safe.
return false;}}module.exports=shouldUseNative()?Object.assign:function(target,source){var from;var to=toObject(target);var symbols;for(var s=1;s<arguments.length;s++){from=Object(arguments[s]);for(var key in from){if(hasOwnProperty.call(from,key)){to[key]=from[key];}}if(getOwnPropertySymbols){symbols=getOwnPropertySymbols(from);for(var i=0;i<symbols.length;i++){if(propIsEnumerable.call(from,symbols[i])){to[symbols[i]]=from[symbols[i]];}}}}return to;};

/***/ }),

/***/ "../../../node_modules/prop-types/factoryWithThrowingShims.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var ReactPropTypesSecret=__webpack_require__("../../../node_modules/prop-types/lib/ReactPropTypesSecret.js");function emptyFunction(){}function emptyFunctionWithReset(){}emptyFunctionWithReset.resetWarningCache=emptyFunction;module.exports=function(){function shim(props,propName,componentName,location,propFullName,secret){if(secret===ReactPropTypesSecret){// It is still safe when called from React.
return;}var err=new Error('Calling PropTypes validators directly is not supported by the `prop-types` package. '+'Use PropTypes.checkPropTypes() to call them. '+'Read more at http://fb.me/use-check-prop-types');err.name='Invariant Violation';throw err;};shim.isRequired=shim;function getShim(){return shim;};// Important!
// Keep this list in sync with production version in `./factoryWithTypeCheckers.js`.
var ReactPropTypes={array:shim,bool:shim,func:shim,number:shim,object:shim,string:shim,symbol:shim,any:shim,arrayOf:getShim,element:shim,elementType:shim,instanceOf:getShim,node:shim,objectOf:getShim,oneOf:getShim,oneOfType:getShim,shape:getShim,exact:getShim,checkPropTypes:emptyFunctionWithReset,resetWarningCache:emptyFunction};ReactPropTypes.PropTypes=ReactPropTypes;return ReactPropTypes;};

/***/ }),

/***/ "../../../node_modules/prop-types/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */if(false){var ReactIs=require('react-is');// By explicitly using `prop-types` you are opting into new development behavior.
// http://fb.me/prop-types-in-prod
var throwOnDirectAccess=true;module.exports=require('./factoryWithTypeCheckers')(ReactIs.isElement,throwOnDirectAccess);}else{// By explicitly using `prop-types` you are opting into new production behavior.
// http://fb.me/prop-types-in-prod
module.exports=__webpack_require__("../../../node_modules/prop-types/factoryWithThrowingShims.js")();}

/***/ }),

/***/ "../../../node_modules/prop-types/lib/ReactPropTypesSecret.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var ReactPropTypesSecret='SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';module.exports=ReactPropTypesSecret;

/***/ }),

/***/ "../../../node_modules/react-dom/cjs/react-dom.production.min.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/** @license React v16.13.1
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ /*
 Modernizr 3.0.0pre (Custom Build) | MIT
*/var aa=__webpack_require__("../../../node_modules/react/index.js"),n=__webpack_require__("../../../node_modules/object-assign/index.js"),r=__webpack_require__("../../../node_modules/scheduler/index.js");function u(a){for(var b="https://reactjs.org/docs/error-decoder.html?invariant="+a,c=1;c<arguments.length;c++)b+="&args[]="+encodeURIComponent(arguments[c]);return"Minified React error #"+a+"; visit "+b+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";}if(!aa)throw Error(u(227));function ba(a,b,c,d,e,f,g,h,k){var l=Array.prototype.slice.call(arguments,3);try{b.apply(c,l);}catch(m){this.onError(m);}}var da=!1,ea=null,fa=!1,ha=null,ia={onError:function(a){da=!0;ea=a;}};function ja(a,b,c,d,e,f,g,h,k){da=!1;ea=null;ba.apply(ia,arguments);}function ka(a,b,c,d,e,f,g,h,k){ja.apply(this,arguments);if(da){if(da){var l=ea;da=!1;ea=null;}else throw Error(u(198));fa||(fa=!0,ha=l);}}var la=null,ma=null,na=null;function oa(a,b,c){var d=a.type||"unknown-event";a.currentTarget=na(c);ka(d,b,void 0,a);a.currentTarget=null;}var pa=null,qa={};function ra(){if(pa)for(var a in qa){var b=qa[a],c=pa.indexOf(a);if(!(-1<c))throw Error(u(96,a));if(!sa[c]){if(!b.extractEvents)throw Error(u(97,a));sa[c]=b;c=b.eventTypes;for(var d in c){var e=void 0;var f=c[d],g=b,h=d;if(ta.hasOwnProperty(h))throw Error(u(99,h));ta[h]=f;var k=f.phasedRegistrationNames;if(k){for(e in k)k.hasOwnProperty(e)&&ua(k[e],g,h);e=!0;}else f.registrationName?(ua(f.registrationName,g,h),e=!0):e=!1;if(!e)throw Error(u(98,d,a));}}}}function ua(a,b,c){if(va[a])throw Error(u(100,a));va[a]=b;wa[a]=b.eventTypes[c].dependencies;}var sa=[],ta={},va={},wa={};function xa(a){var b=!1,c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];if(!qa.hasOwnProperty(c)||qa[c]!==d){if(qa[c])throw Error(u(102,c));qa[c]=d;b=!0;}}b&&ra();}var ya=!("undefined"===typeof window||"undefined"===typeof window.document||"undefined"===typeof window.document.createElement),za=null,Aa=null,Ba=null;function Ca(a){if(a=ma(a)){if("function"!==typeof za)throw Error(u(280));var b=a.stateNode;b&&(b=la(b),za(a.stateNode,a.type,b));}}function Da(a){Aa?Ba?Ba.push(a):Ba=[a]:Aa=a;}function Ea(){if(Aa){var a=Aa,b=Ba;Ba=Aa=null;Ca(a);if(b)for(a=0;a<b.length;a++)Ca(b[a]);}}function Fa(a,b){return a(b);}function Ga(a,b,c,d,e){return a(b,c,d,e);}function Ha(){}var Ia=Fa,Ja=!1,Ka=!1;function La(){if(null!==Aa||null!==Ba)Ha(),Ea();}function Ma(a,b,c){if(Ka)return a(b,c);Ka=!0;try{return Ia(a,b,c);}finally{Ka=!1,La();}}var Na=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,Oa=Object.prototype.hasOwnProperty,Pa={},Qa={};function Ra(a){if(Oa.call(Qa,a))return!0;if(Oa.call(Pa,a))return!1;if(Na.test(a))return Qa[a]=!0;Pa[a]=!0;return!1;}function Sa(a,b,c,d){if(null!==c&&0===c.type)return!1;switch(typeof b){case"function":case"symbol":return!0;case"boolean":if(d)return!1;if(null!==c)return!c.acceptsBooleans;a=a.toLowerCase().slice(0,5);return"data-"!==a&&"aria-"!==a;default:return!1;}}function Ta(a,b,c,d){if(null===b||"undefined"===typeof b||Sa(a,b,c,d))return!0;if(d)return!1;if(null!==c)switch(c.type){case 3:return!b;case 4:return!1===b;case 5:return isNaN(b);case 6:return isNaN(b)||1>b;}return!1;}function v(a,b,c,d,e,f){this.acceptsBooleans=2===b||3===b||4===b;this.attributeName=d;this.attributeNamespace=e;this.mustUseProperty=c;this.propertyName=a;this.type=b;this.sanitizeURL=f;}var C={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a){C[a]=new v(a,0,!1,a,null,!1);});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(a){var b=a[0];C[b]=new v(b,1,!1,a[1],null,!1);});["contentEditable","draggable","spellCheck","value"].forEach(function(a){C[a]=new v(a,2,!1,a.toLowerCase(),null,!1);});["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(a){C[a]=new v(a,2,!1,a,null,!1);});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a){C[a]=new v(a,3,!1,a.toLowerCase(),null,!1);});["checked","multiple","muted","selected"].forEach(function(a){C[a]=new v(a,3,!0,a,null,!1);});["capture","download"].forEach(function(a){C[a]=new v(a,4,!1,a,null,!1);});["cols","rows","size","span"].forEach(function(a){C[a]=new v(a,6,!1,a,null,!1);});["rowSpan","start"].forEach(function(a){C[a]=new v(a,5,!1,a.toLowerCase(),null,!1);});var Ua=/[\-:]([a-z])/g;function Va(a){return a[1].toUpperCase();}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a){var b=a.replace(Ua,Va);C[b]=new v(b,1,!1,a,null,!1);});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a){var b=a.replace(Ua,Va);C[b]=new v(b,1,!1,a,"http://www.w3.org/1999/xlink",!1);});["xml:base","xml:lang","xml:space"].forEach(function(a){var b=a.replace(Ua,Va);C[b]=new v(b,1,!1,a,"http://www.w3.org/XML/1998/namespace",!1);});["tabIndex","crossOrigin"].forEach(function(a){C[a]=new v(a,1,!1,a.toLowerCase(),null,!1);});C.xlinkHref=new v("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0);["src","href","action","formAction"].forEach(function(a){C[a]=new v(a,1,!1,a.toLowerCase(),null,!0);});var Wa=aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;Wa.hasOwnProperty("ReactCurrentDispatcher")||(Wa.ReactCurrentDispatcher={current:null});Wa.hasOwnProperty("ReactCurrentBatchConfig")||(Wa.ReactCurrentBatchConfig={suspense:null});function Xa(a,b,c,d){var e=C.hasOwnProperty(b)?C[b]:null;var f=null!==e?0===e.type:d?!1:!(2<b.length)||"o"!==b[0]&&"O"!==b[0]||"n"!==b[1]&&"N"!==b[1]?!1:!0;f||(Ta(b,c,e,d)&&(c=null),d||null===e?Ra(b)&&(null===c?a.removeAttribute(b):a.setAttribute(b,""+c)):e.mustUseProperty?a[e.propertyName]=null===c?3===e.type?!1:"":c:(b=e.attributeName,d=e.attributeNamespace,null===c?a.removeAttribute(b):(e=e.type,c=3===e||4===e&&!0===c?"":""+c,d?a.setAttributeNS(d,b,c):a.setAttribute(b,c))));}var Ya=/^(.*)[\\\/]/,E="function"===typeof Symbol&&Symbol.for,Za=E?Symbol.for("react.element"):60103,$a=E?Symbol.for("react.portal"):60106,ab=E?Symbol.for("react.fragment"):60107,bb=E?Symbol.for("react.strict_mode"):60108,cb=E?Symbol.for("react.profiler"):60114,db=E?Symbol.for("react.provider"):60109,eb=E?Symbol.for("react.context"):60110,fb=E?Symbol.for("react.concurrent_mode"):60111,gb=E?Symbol.for("react.forward_ref"):60112,hb=E?Symbol.for("react.suspense"):60113,ib=E?Symbol.for("react.suspense_list"):60120,jb=E?Symbol.for("react.memo"):60115,kb=E?Symbol.for("react.lazy"):60116,lb=E?Symbol.for("react.block"):60121,mb="function"===typeof Symbol&&Symbol.iterator;function nb(a){if(null===a||"object"!==typeof a)return null;a=mb&&a[mb]||a["@@iterator"];return"function"===typeof a?a:null;}function ob(a){if(-1===a._status){a._status=0;var b=a._ctor;b=b();a._result=b;b.then(function(b){0===a._status&&(b=b.default,a._status=1,a._result=b);},function(b){0===a._status&&(a._status=2,a._result=b);});}}function pb(a){if(null==a)return null;if("function"===typeof a)return a.displayName||a.name||null;if("string"===typeof a)return a;switch(a){case ab:return"Fragment";case $a:return"Portal";case cb:return"Profiler";case bb:return"StrictMode";case hb:return"Suspense";case ib:return"SuspenseList";}if("object"===typeof a)switch(a.$$typeof){case eb:return"Context.Consumer";case db:return"Context.Provider";case gb:var b=a.render;b=b.displayName||b.name||"";return a.displayName||(""!==b?"ForwardRef("+b+")":"ForwardRef");case jb:return pb(a.type);case lb:return pb(a.render);case kb:if(a=1===a._status?a._result:null)return pb(a);}return null;}function qb(a){var b="";do{a:switch(a.tag){case 3:case 4:case 6:case 7:case 10:case 9:var c="";break a;default:var d=a._debugOwner,e=a._debugSource,f=pb(a.type);c=null;d&&(c=pb(d.type));d=f;f="";e?f=" (at "+e.fileName.replace(Ya,"")+":"+e.lineNumber+")":c&&(f=" (created by "+c+")");c="\n    in "+(d||"Unknown")+f;}b+=c;a=a.return;}while(a);return b;}function rb(a){switch(typeof a){case"boolean":case"number":case"object":case"string":case"undefined":return a;default:return"";}}function sb(a){var b=a.type;return(a=a.nodeName)&&"input"===a.toLowerCase()&&("checkbox"===b||"radio"===b);}function tb(a){var b=sb(a)?"checked":"value",c=Object.getOwnPropertyDescriptor(a.constructor.prototype,b),d=""+a[b];if(!a.hasOwnProperty(b)&&"undefined"!==typeof c&&"function"===typeof c.get&&"function"===typeof c.set){var e=c.get,f=c.set;Object.defineProperty(a,b,{configurable:!0,get:function(){return e.call(this);},set:function(a){d=""+a;f.call(this,a);}});Object.defineProperty(a,b,{enumerable:c.enumerable});return{getValue:function(){return d;},setValue:function(a){d=""+a;},stopTracking:function(){a._valueTracker=null;delete a[b];}};}}function xb(a){a._valueTracker||(a._valueTracker=tb(a));}function yb(a){if(!a)return!1;var b=a._valueTracker;if(!b)return!0;var c=b.getValue();var d="";a&&(d=sb(a)?a.checked?"true":"false":a.value);a=d;return a!==c?(b.setValue(a),!0):!1;}function zb(a,b){var c=b.checked;return n({},b,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:null!=c?c:a._wrapperState.initialChecked});}function Ab(a,b){var c=null==b.defaultValue?"":b.defaultValue,d=null!=b.checked?b.checked:b.defaultChecked;c=rb(null!=b.value?b.value:c);a._wrapperState={initialChecked:d,initialValue:c,controlled:"checkbox"===b.type||"radio"===b.type?null!=b.checked:null!=b.value};}function Bb(a,b){b=b.checked;null!=b&&Xa(a,"checked",b,!1);}function Cb(a,b){Bb(a,b);var c=rb(b.value),d=b.type;if(null!=c){if("number"===d){if(0===c&&""===a.value||a.value!=c)a.value=""+c;}else a.value!==""+c&&(a.value=""+c);}else if("submit"===d||"reset"===d){a.removeAttribute("value");return;}b.hasOwnProperty("value")?Db(a,b.type,c):b.hasOwnProperty("defaultValue")&&Db(a,b.type,rb(b.defaultValue));null==b.checked&&null!=b.defaultChecked&&(a.defaultChecked=!!b.defaultChecked);}function Eb(a,b,c){if(b.hasOwnProperty("value")||b.hasOwnProperty("defaultValue")){var d=b.type;if(!("submit"!==d&&"reset"!==d||void 0!==b.value&&null!==b.value))return;b=""+a._wrapperState.initialValue;c||b===a.value||(a.value=b);a.defaultValue=b;}c=a.name;""!==c&&(a.name="");a.defaultChecked=!!a._wrapperState.initialChecked;""!==c&&(a.name=c);}function Db(a,b,c){if("number"!==b||a.ownerDocument.activeElement!==a)null==c?a.defaultValue=""+a._wrapperState.initialValue:a.defaultValue!==""+c&&(a.defaultValue=""+c);}function Fb(a){var b="";aa.Children.forEach(a,function(a){null!=a&&(b+=a);});return b;}function Gb(a,b){a=n({children:void 0},b);if(b=Fb(b.children))a.children=b;return a;}function Hb(a,b,c,d){a=a.options;if(b){b={};for(var e=0;e<c.length;e++)b["$"+c[e]]=!0;for(c=0;c<a.length;c++)e=b.hasOwnProperty("$"+a[c].value),a[c].selected!==e&&(a[c].selected=e),e&&d&&(a[c].defaultSelected=!0);}else{c=""+rb(c);b=null;for(e=0;e<a.length;e++){if(a[e].value===c){a[e].selected=!0;d&&(a[e].defaultSelected=!0);return;}null!==b||a[e].disabled||(b=a[e]);}null!==b&&(b.selected=!0);}}function Ib(a,b){if(null!=b.dangerouslySetInnerHTML)throw Error(u(91));return n({},b,{value:void 0,defaultValue:void 0,children:""+a._wrapperState.initialValue});}function Jb(a,b){var c=b.value;if(null==c){c=b.children;b=b.defaultValue;if(null!=c){if(null!=b)throw Error(u(92));if(Array.isArray(c)){if(!(1>=c.length))throw Error(u(93));c=c[0];}b=c;}null==b&&(b="");c=b;}a._wrapperState={initialValue:rb(c)};}function Kb(a,b){var c=rb(b.value),d=rb(b.defaultValue);null!=c&&(c=""+c,c!==a.value&&(a.value=c),null==b.defaultValue&&a.defaultValue!==c&&(a.defaultValue=c));null!=d&&(a.defaultValue=""+d);}function Lb(a){var b=a.textContent;b===a._wrapperState.initialValue&&""!==b&&null!==b&&(a.value=b);}var Mb={html:"http://www.w3.org/1999/xhtml",mathml:"http://www.w3.org/1998/Math/MathML",svg:"http://www.w3.org/2000/svg"};function Nb(a){switch(a){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml";}}function Ob(a,b){return null==a||"http://www.w3.org/1999/xhtml"===a?Nb(b):"http://www.w3.org/2000/svg"===a&&"foreignObject"===b?"http://www.w3.org/1999/xhtml":a;}var Pb,Qb=function(a){return"undefined"!==typeof MSApp&&MSApp.execUnsafeLocalFunction?function(b,c,d,e){MSApp.execUnsafeLocalFunction(function(){return a(b,c,d,e);});}:a;}(function(a,b){if(a.namespaceURI!==Mb.svg||"innerHTML"in a)a.innerHTML=b;else{Pb=Pb||document.createElement("div");Pb.innerHTML="<svg>"+b.valueOf().toString()+"</svg>";for(b=Pb.firstChild;a.firstChild;)a.removeChild(a.firstChild);for(;b.firstChild;)a.appendChild(b.firstChild);}});function Rb(a,b){if(b){var c=a.firstChild;if(c&&c===a.lastChild&&3===c.nodeType){c.nodeValue=b;return;}}a.textContent=b;}function Sb(a,b){var c={};c[a.toLowerCase()]=b.toLowerCase();c["Webkit"+a]="webkit"+b;c["Moz"+a]="moz"+b;return c;}var Tb={animationend:Sb("Animation","AnimationEnd"),animationiteration:Sb("Animation","AnimationIteration"),animationstart:Sb("Animation","AnimationStart"),transitionend:Sb("Transition","TransitionEnd")},Ub={},Vb={};ya&&(Vb=document.createElement("div").style,"AnimationEvent"in window||(delete Tb.animationend.animation,delete Tb.animationiteration.animation,delete Tb.animationstart.animation),"TransitionEvent"in window||delete Tb.transitionend.transition);function Wb(a){if(Ub[a])return Ub[a];if(!Tb[a])return a;var b=Tb[a],c;for(c in b)if(b.hasOwnProperty(c)&&c in Vb)return Ub[a]=b[c];return a;}var Xb=Wb("animationend"),Yb=Wb("animationiteration"),Zb=Wb("animationstart"),$b=Wb("transitionend"),ac="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),bc=new("function"===typeof WeakMap?WeakMap:Map)();function cc(a){var b=bc.get(a);void 0===b&&(b=new Map(),bc.set(a,b));return b;}function dc(a){var b=a,c=a;if(a.alternate)for(;b.return;)b=b.return;else{a=b;do b=a,0!==(b.effectTag&1026)&&(c=b.return),a=b.return;while(a);}return 3===b.tag?c:null;}function ec(a){if(13===a.tag){var b=a.memoizedState;null===b&&(a=a.alternate,null!==a&&(b=a.memoizedState));if(null!==b)return b.dehydrated;}return null;}function fc(a){if(dc(a)!==a)throw Error(u(188));}function gc(a){var b=a.alternate;if(!b){b=dc(a);if(null===b)throw Error(u(188));return b!==a?null:a;}for(var c=a,d=b;;){var e=c.return;if(null===e)break;var f=e.alternate;if(null===f){d=e.return;if(null!==d){c=d;continue;}break;}if(e.child===f.child){for(f=e.child;f;){if(f===c)return fc(e),a;if(f===d)return fc(e),b;f=f.sibling;}throw Error(u(188));}if(c.return!==d.return)c=e,d=f;else{for(var g=!1,h=e.child;h;){if(h===c){g=!0;c=e;d=f;break;}if(h===d){g=!0;d=e;c=f;break;}h=h.sibling;}if(!g){for(h=f.child;h;){if(h===c){g=!0;c=f;d=e;break;}if(h===d){g=!0;d=f;c=e;break;}h=h.sibling;}if(!g)throw Error(u(189));}}if(c.alternate!==d)throw Error(u(190));}if(3!==c.tag)throw Error(u(188));return c.stateNode.current===c?a:b;}function hc(a){a=gc(a);if(!a)return null;for(var b=a;;){if(5===b.tag||6===b.tag)return b;if(b.child)b.child.return=b,b=b.child;else{if(b===a)break;for(;!b.sibling;){if(!b.return||b.return===a)return null;b=b.return;}b.sibling.return=b.return;b=b.sibling;}}return null;}function ic(a,b){if(null==b)throw Error(u(30));if(null==a)return b;if(Array.isArray(a)){if(Array.isArray(b))return a.push.apply(a,b),a;a.push(b);return a;}return Array.isArray(b)?[a].concat(b):[a,b];}function jc(a,b,c){Array.isArray(a)?a.forEach(b,c):a&&b.call(c,a);}var kc=null;function lc(a){if(a){var b=a._dispatchListeners,c=a._dispatchInstances;if(Array.isArray(b))for(var d=0;d<b.length&&!a.isPropagationStopped();d++)oa(a,b[d],c[d]);else b&&oa(a,b,c);a._dispatchListeners=null;a._dispatchInstances=null;a.isPersistent()||a.constructor.release(a);}}function mc(a){null!==a&&(kc=ic(kc,a));a=kc;kc=null;if(a){jc(a,lc);if(kc)throw Error(u(95));if(fa)throw a=ha,fa=!1,ha=null,a;}}function nc(a){a=a.target||a.srcElement||window;a.correspondingUseElement&&(a=a.correspondingUseElement);return 3===a.nodeType?a.parentNode:a;}function oc(a){if(!ya)return!1;a="on"+a;var b=(a in document);b||(b=document.createElement("div"),b.setAttribute(a,"return;"),b="function"===typeof b[a]);return b;}var pc=[];function qc(a){a.topLevelType=null;a.nativeEvent=null;a.targetInst=null;a.ancestors.length=0;10>pc.length&&pc.push(a);}function rc(a,b,c,d){if(pc.length){var e=pc.pop();e.topLevelType=a;e.eventSystemFlags=d;e.nativeEvent=b;e.targetInst=c;return e;}return{topLevelType:a,eventSystemFlags:d,nativeEvent:b,targetInst:c,ancestors:[]};}function sc(a){var b=a.targetInst,c=b;do{if(!c){a.ancestors.push(c);break;}var d=c;if(3===d.tag)d=d.stateNode.containerInfo;else{for(;d.return;)d=d.return;d=3!==d.tag?null:d.stateNode.containerInfo;}if(!d)break;b=c.tag;5!==b&&6!==b||a.ancestors.push(c);c=tc(d);}while(c);for(c=0;c<a.ancestors.length;c++){b=a.ancestors[c];var e=nc(a.nativeEvent);d=a.topLevelType;var f=a.nativeEvent,g=a.eventSystemFlags;0===c&&(g|=64);for(var h=null,k=0;k<sa.length;k++){var l=sa[k];l&&(l=l.extractEvents(d,b,f,e,g))&&(h=ic(h,l));}mc(h);}}function uc(a,b,c){if(!c.has(a)){switch(a){case"scroll":vc(b,"scroll",!0);break;case"focus":case"blur":vc(b,"focus",!0);vc(b,"blur",!0);c.set("blur",null);c.set("focus",null);break;case"cancel":case"close":oc(a)&&vc(b,a,!0);break;case"invalid":case"submit":case"reset":break;default:-1===ac.indexOf(a)&&F(a,b);}c.set(a,null);}}var wc,xc,yc,zc=!1,Ac=[],Bc=null,Cc=null,Dc=null,Ec=new Map(),Fc=new Map(),Gc=[],Hc="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput close cancel copy cut paste click change contextmenu reset submit".split(" "),Ic="focus blur dragenter dragleave mouseover mouseout pointerover pointerout gotpointercapture lostpointercapture".split(" ");function Jc(a,b){var c=cc(b);Hc.forEach(function(a){uc(a,b,c);});Ic.forEach(function(a){uc(a,b,c);});}function Kc(a,b,c,d,e){return{blockedOn:a,topLevelType:b,eventSystemFlags:c|32,nativeEvent:e,container:d};}function Lc(a,b){switch(a){case"focus":case"blur":Bc=null;break;case"dragenter":case"dragleave":Cc=null;break;case"mouseover":case"mouseout":Dc=null;break;case"pointerover":case"pointerout":Ec.delete(b.pointerId);break;case"gotpointercapture":case"lostpointercapture":Fc.delete(b.pointerId);}}function Mc(a,b,c,d,e,f){if(null===a||a.nativeEvent!==f)return a=Kc(b,c,d,e,f),null!==b&&(b=Nc(b),null!==b&&xc(b)),a;a.eventSystemFlags|=d;return a;}function Oc(a,b,c,d,e){switch(b){case"focus":return Bc=Mc(Bc,a,b,c,d,e),!0;case"dragenter":return Cc=Mc(Cc,a,b,c,d,e),!0;case"mouseover":return Dc=Mc(Dc,a,b,c,d,e),!0;case"pointerover":var f=e.pointerId;Ec.set(f,Mc(Ec.get(f)||null,a,b,c,d,e));return!0;case"gotpointercapture":return f=e.pointerId,Fc.set(f,Mc(Fc.get(f)||null,a,b,c,d,e)),!0;}return!1;}function Pc(a){var b=tc(a.target);if(null!==b){var c=dc(b);if(null!==c)if(b=c.tag,13===b){if(b=ec(c),null!==b){a.blockedOn=b;r.unstable_runWithPriority(a.priority,function(){yc(c);});return;}}else if(3===b&&c.stateNode.hydrate){a.blockedOn=3===c.tag?c.stateNode.containerInfo:null;return;}}a.blockedOn=null;}function Qc(a){if(null!==a.blockedOn)return!1;var b=Rc(a.topLevelType,a.eventSystemFlags,a.container,a.nativeEvent);if(null!==b){var c=Nc(b);null!==c&&xc(c);a.blockedOn=b;return!1;}return!0;}function Sc(a,b,c){Qc(a)&&c.delete(b);}function Tc(){for(zc=!1;0<Ac.length;){var a=Ac[0];if(null!==a.blockedOn){a=Nc(a.blockedOn);null!==a&&wc(a);break;}var b=Rc(a.topLevelType,a.eventSystemFlags,a.container,a.nativeEvent);null!==b?a.blockedOn=b:Ac.shift();}null!==Bc&&Qc(Bc)&&(Bc=null);null!==Cc&&Qc(Cc)&&(Cc=null);null!==Dc&&Qc(Dc)&&(Dc=null);Ec.forEach(Sc);Fc.forEach(Sc);}function Uc(a,b){a.blockedOn===b&&(a.blockedOn=null,zc||(zc=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,Tc)));}function Vc(a){function b(b){return Uc(b,a);}if(0<Ac.length){Uc(Ac[0],a);for(var c=1;c<Ac.length;c++){var d=Ac[c];d.blockedOn===a&&(d.blockedOn=null);}}null!==Bc&&Uc(Bc,a);null!==Cc&&Uc(Cc,a);null!==Dc&&Uc(Dc,a);Ec.forEach(b);Fc.forEach(b);for(c=0;c<Gc.length;c++)d=Gc[c],d.blockedOn===a&&(d.blockedOn=null);for(;0<Gc.length&&(c=Gc[0],null===c.blockedOn);)Pc(c),null===c.blockedOn&&Gc.shift();}var Wc={},Yc=new Map(),Zc=new Map(),$c=["abort","abort",Xb,"animationEnd",Yb,"animationIteration",Zb,"animationStart","canplay","canPlay","canplaythrough","canPlayThrough","durationchange","durationChange","emptied","emptied","encrypted","encrypted","ended","ended","error","error","gotpointercapture","gotPointerCapture","load","load","loadeddata","loadedData","loadedmetadata","loadedMetadata","loadstart","loadStart","lostpointercapture","lostPointerCapture","playing","playing","progress","progress","seeking","seeking","stalled","stalled","suspend","suspend","timeupdate","timeUpdate",$b,"transitionEnd","waiting","waiting"];function ad(a,b){for(var c=0;c<a.length;c+=2){var d=a[c],e=a[c+1],f="on"+(e[0].toUpperCase()+e.slice(1));f={phasedRegistrationNames:{bubbled:f,captured:f+"Capture"},dependencies:[d],eventPriority:b};Zc.set(d,b);Yc.set(d,f);Wc[e]=f;}}ad("blur blur cancel cancel click click close close contextmenu contextMenu copy copy cut cut auxclick auxClick dblclick doubleClick dragend dragEnd dragstart dragStart drop drop focus focus input input invalid invalid keydown keyDown keypress keyPress keyup keyUp mousedown mouseDown mouseup mouseUp paste paste pause pause play play pointercancel pointerCancel pointerdown pointerDown pointerup pointerUp ratechange rateChange reset reset seeked seeked submit submit touchcancel touchCancel touchend touchEnd touchstart touchStart volumechange volumeChange".split(" "),0);ad("drag drag dragenter dragEnter dragexit dragExit dragleave dragLeave dragover dragOver mousemove mouseMove mouseout mouseOut mouseover mouseOver pointermove pointerMove pointerout pointerOut pointerover pointerOver scroll scroll toggle toggle touchmove touchMove wheel wheel".split(" "),1);ad($c,2);for(var bd="change selectionchange textInput compositionstart compositionend compositionupdate".split(" "),cd=0;cd<bd.length;cd++)Zc.set(bd[cd],0);var dd=r.unstable_UserBlockingPriority,ed=r.unstable_runWithPriority,fd=!0;function F(a,b){vc(b,a,!1);}function vc(a,b,c){var d=Zc.get(b);switch(void 0===d?2:d){case 0:d=gd.bind(null,b,1,a);break;case 1:d=hd.bind(null,b,1,a);break;default:d=id.bind(null,b,1,a);}c?a.addEventListener(b,d,!0):a.addEventListener(b,d,!1);}function gd(a,b,c,d){Ja||Ha();var e=id,f=Ja;Ja=!0;try{Ga(e,a,b,c,d);}finally{(Ja=f)||La();}}function hd(a,b,c,d){ed(dd,id.bind(null,a,b,c,d));}function id(a,b,c,d){if(fd)if(0<Ac.length&&-1<Hc.indexOf(a))a=Kc(null,a,b,c,d),Ac.push(a);else{var e=Rc(a,b,c,d);if(null===e)Lc(a,d);else if(-1<Hc.indexOf(a))a=Kc(e,a,b,c,d),Ac.push(a);else if(!Oc(e,a,b,c,d)){Lc(a,d);a=rc(a,d,null,b);try{Ma(sc,a);}finally{qc(a);}}}}function Rc(a,b,c,d){c=nc(d);c=tc(c);if(null!==c){var e=dc(c);if(null===e)c=null;else{var f=e.tag;if(13===f){c=ec(e);if(null!==c)return c;c=null;}else if(3===f){if(e.stateNode.hydrate)return 3===e.tag?e.stateNode.containerInfo:null;c=null;}else e!==c&&(c=null);}}a=rc(a,d,c,b);try{Ma(sc,a);}finally{qc(a);}return null;}var jd={animationIterationCount:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},kd=["Webkit","ms","Moz","O"];Object.keys(jd).forEach(function(a){kd.forEach(function(b){b=b+a.charAt(0).toUpperCase()+a.substring(1);jd[b]=jd[a];});});function ld(a,b,c){return null==b||"boolean"===typeof b||""===b?"":c||"number"!==typeof b||0===b||jd.hasOwnProperty(a)&&jd[a]?(""+b).trim():b+"px";}function md(a,b){a=a.style;for(var c in b)if(b.hasOwnProperty(c)){var d=0===c.indexOf("--"),e=ld(c,b[c],d);"float"===c&&(c="cssFloat");d?a.setProperty(c,e):a[c]=e;}}var nd=n({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function od(a,b){if(b){if(nd[a]&&(null!=b.children||null!=b.dangerouslySetInnerHTML))throw Error(u(137,a,""));if(null!=b.dangerouslySetInnerHTML){if(null!=b.children)throw Error(u(60));if(!("object"===typeof b.dangerouslySetInnerHTML&&"__html"in b.dangerouslySetInnerHTML))throw Error(u(61));}if(null!=b.style&&"object"!==typeof b.style)throw Error(u(62,""));}}function pd(a,b){if(-1===a.indexOf("-"))return"string"===typeof b.is;switch(a){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0;}}var qd=Mb.html;function rd(a,b){a=9===a.nodeType||11===a.nodeType?a:a.ownerDocument;var c=cc(a);b=wa[b];for(var d=0;d<b.length;d++)uc(b[d],a,c);}function sd(){}function td(a){a=a||("undefined"!==typeof document?document:void 0);if("undefined"===typeof a)return null;try{return a.activeElement||a.body;}catch(b){return a.body;}}function ud(a){for(;a&&a.firstChild;)a=a.firstChild;return a;}function vd(a,b){var c=ud(a);a=0;for(var d;c;){if(3===c.nodeType){d=a+c.textContent.length;if(a<=b&&d>=b)return{node:c,offset:b-a};a=d;}a:{for(;c;){if(c.nextSibling){c=c.nextSibling;break a;}c=c.parentNode;}c=void 0;}c=ud(c);}}function wd(a,b){return a&&b?a===b?!0:a&&3===a.nodeType?!1:b&&3===b.nodeType?wd(a,b.parentNode):"contains"in a?a.contains(b):a.compareDocumentPosition?!!(a.compareDocumentPosition(b)&16):!1:!1;}function xd(){for(var a=window,b=td();b instanceof a.HTMLIFrameElement;){try{var c="string"===typeof b.contentWindow.location.href;}catch(d){c=!1;}if(c)a=b.contentWindow;else break;b=td(a.document);}return b;}function yd(a){var b=a&&a.nodeName&&a.nodeName.toLowerCase();return b&&("input"===b&&("text"===a.type||"search"===a.type||"tel"===a.type||"url"===a.type||"password"===a.type)||"textarea"===b||"true"===a.contentEditable);}var zd="$",Ad="/$",Bd="$?",Cd="$!",Dd=null,Ed=null;function Fd(a,b){switch(a){case"button":case"input":case"select":case"textarea":return!!b.autoFocus;}return!1;}function Gd(a,b){return"textarea"===a||"option"===a||"noscript"===a||"string"===typeof b.children||"number"===typeof b.children||"object"===typeof b.dangerouslySetInnerHTML&&null!==b.dangerouslySetInnerHTML&&null!=b.dangerouslySetInnerHTML.__html;}var Hd="function"===typeof setTimeout?setTimeout:void 0,Id="function"===typeof clearTimeout?clearTimeout:void 0;function Jd(a){for(;null!=a;a=a.nextSibling){var b=a.nodeType;if(1===b||3===b)break;}return a;}function Kd(a){a=a.previousSibling;for(var b=0;a;){if(8===a.nodeType){var c=a.data;if(c===zd||c===Cd||c===Bd){if(0===b)return a;b--;}else c===Ad&&b++;}a=a.previousSibling;}return null;}var Ld=Math.random().toString(36).slice(2),Md="__reactInternalInstance$"+Ld,Nd="__reactEventHandlers$"+Ld,Od="__reactContainere$"+Ld;function tc(a){var b=a[Md];if(b)return b;for(var c=a.parentNode;c;){if(b=c[Od]||c[Md]){c=b.alternate;if(null!==b.child||null!==c&&null!==c.child)for(a=Kd(a);null!==a;){if(c=a[Md])return c;a=Kd(a);}return b;}a=c;c=a.parentNode;}return null;}function Nc(a){a=a[Md]||a[Od];return!a||5!==a.tag&&6!==a.tag&&13!==a.tag&&3!==a.tag?null:a;}function Pd(a){if(5===a.tag||6===a.tag)return a.stateNode;throw Error(u(33));}function Qd(a){return a[Nd]||null;}function Rd(a){do a=a.return;while(a&&5!==a.tag);return a?a:null;}function Sd(a,b){var c=a.stateNode;if(!c)return null;var d=la(c);if(!d)return null;c=d[b];a:switch(b){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(d=!d.disabled)||(a=a.type,d=!("button"===a||"input"===a||"select"===a||"textarea"===a));a=!d;break a;default:a=!1;}if(a)return null;if(c&&"function"!==typeof c)throw Error(u(231,b,typeof c));return c;}function Td(a,b,c){if(b=Sd(a,c.dispatchConfig.phasedRegistrationNames[b]))c._dispatchListeners=ic(c._dispatchListeners,b),c._dispatchInstances=ic(c._dispatchInstances,a);}function Ud(a){if(a&&a.dispatchConfig.phasedRegistrationNames){for(var b=a._targetInst,c=[];b;)c.push(b),b=Rd(b);for(b=c.length;0<b--;)Td(c[b],"captured",a);for(b=0;b<c.length;b++)Td(c[b],"bubbled",a);}}function Vd(a,b,c){a&&c&&c.dispatchConfig.registrationName&&(b=Sd(a,c.dispatchConfig.registrationName))&&(c._dispatchListeners=ic(c._dispatchListeners,b),c._dispatchInstances=ic(c._dispatchInstances,a));}function Wd(a){a&&a.dispatchConfig.registrationName&&Vd(a._targetInst,null,a);}function Xd(a){jc(a,Ud);}var Yd=null,Zd=null,$d=null;function ae(){if($d)return $d;var a,b=Zd,c=b.length,d,e="value"in Yd?Yd.value:Yd.textContent,f=e.length;for(a=0;a<c&&b[a]===e[a];a++);var g=c-a;for(d=1;d<=g&&b[c-d]===e[f-d];d++);return $d=e.slice(a,1<d?1-d:void 0);}function be(){return!0;}function ce(){return!1;}function G(a,b,c,d){this.dispatchConfig=a;this._targetInst=b;this.nativeEvent=c;a=this.constructor.Interface;for(var e in a)a.hasOwnProperty(e)&&((b=a[e])?this[e]=b(c):"target"===e?this.target=d:this[e]=c[e]);this.isDefaultPrevented=(null!=c.defaultPrevented?c.defaultPrevented:!1===c.returnValue)?be:ce;this.isPropagationStopped=ce;return this;}n(G.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():"unknown"!==typeof a.returnValue&&(a.returnValue=!1),this.isDefaultPrevented=be);},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():"unknown"!==typeof a.cancelBubble&&(a.cancelBubble=!0),this.isPropagationStopped=be);},persist:function(){this.isPersistent=be;},isPersistent:ce,destructor:function(){var a=this.constructor.Interface,b;for(b in a)this[b]=null;this.nativeEvent=this._targetInst=this.dispatchConfig=null;this.isPropagationStopped=this.isDefaultPrevented=ce;this._dispatchInstances=this._dispatchListeners=null;}});G.Interface={type:null,target:null,currentTarget:function(){return null;},eventPhase:null,bubbles:null,cancelable:null,timeStamp:function(a){return a.timeStamp||Date.now();},defaultPrevented:null,isTrusted:null};G.extend=function(a){function b(){}function c(){return d.apply(this,arguments);}var d=this;b.prototype=d.prototype;var e=new b();n(e,c.prototype);c.prototype=e;c.prototype.constructor=c;c.Interface=n({},d.Interface,a);c.extend=d.extend;de(c);return c;};de(G);function ee(a,b,c,d){if(this.eventPool.length){var e=this.eventPool.pop();this.call(e,a,b,c,d);return e;}return new this(a,b,c,d);}function fe(a){if(!(a instanceof this))throw Error(u(279));a.destructor();10>this.eventPool.length&&this.eventPool.push(a);}function de(a){a.eventPool=[];a.getPooled=ee;a.release=fe;}var ge=G.extend({data:null}),he=G.extend({data:null}),ie=[9,13,27,32],je=ya&&"CompositionEvent"in window,ke=null;ya&&"documentMode"in document&&(ke=document.documentMode);var le=ya&&"TextEvent"in window&&!ke,me=ya&&(!je||ke&&8<ke&&11>=ke),ne=String.fromCharCode(32),oe={beforeInput:{phasedRegistrationNames:{bubbled:"onBeforeInput",captured:"onBeforeInputCapture"},dependencies:["compositionend","keypress","textInput","paste"]},compositionEnd:{phasedRegistrationNames:{bubbled:"onCompositionEnd",captured:"onCompositionEndCapture"},dependencies:"blur compositionend keydown keypress keyup mousedown".split(" ")},compositionStart:{phasedRegistrationNames:{bubbled:"onCompositionStart",captured:"onCompositionStartCapture"},dependencies:"blur compositionstart keydown keypress keyup mousedown".split(" ")},compositionUpdate:{phasedRegistrationNames:{bubbled:"onCompositionUpdate",captured:"onCompositionUpdateCapture"},dependencies:"blur compositionupdate keydown keypress keyup mousedown".split(" ")}},pe=!1;function qe(a,b){switch(a){case"keyup":return-1!==ie.indexOf(b.keyCode);case"keydown":return 229!==b.keyCode;case"keypress":case"mousedown":case"blur":return!0;default:return!1;}}function re(a){a=a.detail;return"object"===typeof a&&"data"in a?a.data:null;}var se=!1;function te(a,b){switch(a){case"compositionend":return re(b);case"keypress":if(32!==b.which)return null;pe=!0;return ne;case"textInput":return a=b.data,a===ne&&pe?null:a;default:return null;}}function ue(a,b){if(se)return"compositionend"===a||!je&&qe(a,b)?(a=ae(),$d=Zd=Yd=null,se=!1,a):null;switch(a){case"paste":return null;case"keypress":if(!(b.ctrlKey||b.altKey||b.metaKey)||b.ctrlKey&&b.altKey){if(b.char&&1<b.char.length)return b.char;if(b.which)return String.fromCharCode(b.which);}return null;case"compositionend":return me&&"ko"!==b.locale?null:b.data;default:return null;}}var ve={eventTypes:oe,extractEvents:function(a,b,c,d){var e;if(je)b:{switch(a){case"compositionstart":var f=oe.compositionStart;break b;case"compositionend":f=oe.compositionEnd;break b;case"compositionupdate":f=oe.compositionUpdate;break b;}f=void 0;}else se?qe(a,c)&&(f=oe.compositionEnd):"keydown"===a&&229===c.keyCode&&(f=oe.compositionStart);f?(me&&"ko"!==c.locale&&(se||f!==oe.compositionStart?f===oe.compositionEnd&&se&&(e=ae()):(Yd=d,Zd="value"in Yd?Yd.value:Yd.textContent,se=!0)),f=ge.getPooled(f,b,c,d),e?f.data=e:(e=re(c),null!==e&&(f.data=e)),Xd(f),e=f):e=null;(a=le?te(a,c):ue(a,c))?(b=he.getPooled(oe.beforeInput,b,c,d),b.data=a,Xd(b)):b=null;return null===e?b:null===b?e:[e,b];}},we={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function xe(a){var b=a&&a.nodeName&&a.nodeName.toLowerCase();return"input"===b?!!we[a.type]:"textarea"===b?!0:!1;}var ye={change:{phasedRegistrationNames:{bubbled:"onChange",captured:"onChangeCapture"},dependencies:"blur change click focus input keydown keyup selectionchange".split(" ")}};function ze(a,b,c){a=G.getPooled(ye.change,a,b,c);a.type="change";Da(c);Xd(a);return a;}var Ae=null,Be=null;function Ce(a){mc(a);}function De(a){var b=Pd(a);if(yb(b))return a;}function Ee(a,b){if("change"===a)return b;}var Fe=!1;ya&&(Fe=oc("input")&&(!document.documentMode||9<document.documentMode));function Ge(){Ae&&(Ae.detachEvent("onpropertychange",He),Be=Ae=null);}function He(a){if("value"===a.propertyName&&De(Be))if(a=ze(Be,a,nc(a)),Ja)mc(a);else{Ja=!0;try{Fa(Ce,a);}finally{Ja=!1,La();}}}function Ie(a,b,c){"focus"===a?(Ge(),Ae=b,Be=c,Ae.attachEvent("onpropertychange",He)):"blur"===a&&Ge();}function Je(a){if("selectionchange"===a||"keyup"===a||"keydown"===a)return De(Be);}function Ke(a,b){if("click"===a)return De(b);}function Le(a,b){if("input"===a||"change"===a)return De(b);}var Me={eventTypes:ye,_isInputEventSupported:Fe,extractEvents:function(a,b,c,d){var e=b?Pd(b):window,f=e.nodeName&&e.nodeName.toLowerCase();if("select"===f||"input"===f&&"file"===e.type)var g=Ee;else if(xe(e)){if(Fe)g=Le;else{g=Je;var h=Ie;}}else(f=e.nodeName)&&"input"===f.toLowerCase()&&("checkbox"===e.type||"radio"===e.type)&&(g=Ke);if(g&&(g=g(a,b)))return ze(g,c,d);h&&h(a,e,b);"blur"===a&&(a=e._wrapperState)&&a.controlled&&"number"===e.type&&Db(e,"number",e.value);}},Ne=G.extend({view:null,detail:null}),Oe={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Pe(a){var b=this.nativeEvent;return b.getModifierState?b.getModifierState(a):(a=Oe[a])?!!b[a]:!1;}function Qe(){return Pe;}var Re=0,Se=0,Te=!1,Ue=!1,Ve=Ne.extend({screenX:null,screenY:null,clientX:null,clientY:null,pageX:null,pageY:null,ctrlKey:null,shiftKey:null,altKey:null,metaKey:null,getModifierState:Qe,button:null,buttons:null,relatedTarget:function(a){return a.relatedTarget||(a.fromElement===a.srcElement?a.toElement:a.fromElement);},movementX:function(a){if("movementX"in a)return a.movementX;var b=Re;Re=a.screenX;return Te?"mousemove"===a.type?a.screenX-b:0:(Te=!0,0);},movementY:function(a){if("movementY"in a)return a.movementY;var b=Se;Se=a.screenY;return Ue?"mousemove"===a.type?a.screenY-b:0:(Ue=!0,0);}}),We=Ve.extend({pointerId:null,width:null,height:null,pressure:null,tangentialPressure:null,tiltX:null,tiltY:null,twist:null,pointerType:null,isPrimary:null}),Xe={mouseEnter:{registrationName:"onMouseEnter",dependencies:["mouseout","mouseover"]},mouseLeave:{registrationName:"onMouseLeave",dependencies:["mouseout","mouseover"]},pointerEnter:{registrationName:"onPointerEnter",dependencies:["pointerout","pointerover"]},pointerLeave:{registrationName:"onPointerLeave",dependencies:["pointerout","pointerover"]}},Ye={eventTypes:Xe,extractEvents:function(a,b,c,d,e){var f="mouseover"===a||"pointerover"===a,g="mouseout"===a||"pointerout"===a;if(f&&0===(e&32)&&(c.relatedTarget||c.fromElement)||!g&&!f)return null;f=d.window===d?d:(f=d.ownerDocument)?f.defaultView||f.parentWindow:window;if(g){if(g=b,b=(b=c.relatedTarget||c.toElement)?tc(b):null,null!==b){var h=dc(b);if(b!==h||5!==b.tag&&6!==b.tag)b=null;}}else g=null;if(g===b)return null;if("mouseout"===a||"mouseover"===a){var k=Ve;var l=Xe.mouseLeave;var m=Xe.mouseEnter;var p="mouse";}else if("pointerout"===a||"pointerover"===a)k=We,l=Xe.pointerLeave,m=Xe.pointerEnter,p="pointer";a=null==g?f:Pd(g);f=null==b?f:Pd(b);l=k.getPooled(l,g,c,d);l.type=p+"leave";l.target=a;l.relatedTarget=f;c=k.getPooled(m,b,c,d);c.type=p+"enter";c.target=f;c.relatedTarget=a;d=g;p=b;if(d&&p)a:{k=d;m=p;g=0;for(a=k;a;a=Rd(a))g++;a=0;for(b=m;b;b=Rd(b))a++;for(;0<g-a;)k=Rd(k),g--;for(;0<a-g;)m=Rd(m),a--;for(;g--;){if(k===m||k===m.alternate)break a;k=Rd(k);m=Rd(m);}k=null;}else k=null;m=k;for(k=[];d&&d!==m;){g=d.alternate;if(null!==g&&g===m)break;k.push(d);d=Rd(d);}for(d=[];p&&p!==m;){g=p.alternate;if(null!==g&&g===m)break;d.push(p);p=Rd(p);}for(p=0;p<k.length;p++)Vd(k[p],"bubbled",l);for(p=d.length;0<p--;)Vd(d[p],"captured",c);return 0===(e&64)?[l]:[l,c];}};function Ze(a,b){return a===b&&(0!==a||1/a===1/b)||a!==a&&b!==b;}var $e="function"===typeof Object.is?Object.is:Ze,af=Object.prototype.hasOwnProperty;function bf(a,b){if($e(a,b))return!0;if("object"!==typeof a||null===a||"object"!==typeof b||null===b)return!1;var c=Object.keys(a),d=Object.keys(b);if(c.length!==d.length)return!1;for(d=0;d<c.length;d++)if(!af.call(b,c[d])||!$e(a[c[d]],b[c[d]]))return!1;return!0;}var cf=ya&&"documentMode"in document&&11>=document.documentMode,df={select:{phasedRegistrationNames:{bubbled:"onSelect",captured:"onSelectCapture"},dependencies:"blur contextmenu dragend focus keydown keyup mousedown mouseup selectionchange".split(" ")}},ef=null,ff=null,gf=null,hf=!1;function jf(a,b){var c=b.window===b?b.document:9===b.nodeType?b:b.ownerDocument;if(hf||null==ef||ef!==td(c))return null;c=ef;"selectionStart"in c&&yd(c)?c={start:c.selectionStart,end:c.selectionEnd}:(c=(c.ownerDocument&&c.ownerDocument.defaultView||window).getSelection(),c={anchorNode:c.anchorNode,anchorOffset:c.anchorOffset,focusNode:c.focusNode,focusOffset:c.focusOffset});return gf&&bf(gf,c)?null:(gf=c,a=G.getPooled(df.select,ff,a,b),a.type="select",a.target=ef,Xd(a),a);}var kf={eventTypes:df,extractEvents:function(a,b,c,d,e,f){e=f||(d.window===d?d.document:9===d.nodeType?d:d.ownerDocument);if(!(f=!e)){a:{e=cc(e);f=wa.onSelect;for(var g=0;g<f.length;g++)if(!e.has(f[g])){e=!1;break a;}e=!0;}f=!e;}if(f)return null;e=b?Pd(b):window;switch(a){case"focus":if(xe(e)||"true"===e.contentEditable)ef=e,ff=b,gf=null;break;case"blur":gf=ff=ef=null;break;case"mousedown":hf=!0;break;case"contextmenu":case"mouseup":case"dragend":return hf=!1,jf(c,d);case"selectionchange":if(cf)break;case"keydown":case"keyup":return jf(c,d);}return null;}},lf=G.extend({animationName:null,elapsedTime:null,pseudoElement:null}),mf=G.extend({clipboardData:function(a){return"clipboardData"in a?a.clipboardData:window.clipboardData;}}),nf=Ne.extend({relatedTarget:null});function of(a){var b=a.keyCode;"charCode"in a?(a=a.charCode,0===a&&13===b&&(a=13)):a=b;10===a&&(a=13);return 32<=a||13===a?a:0;}var pf={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},qf={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},rf=Ne.extend({key:function(a){if(a.key){var b=pf[a.key]||a.key;if("Unidentified"!==b)return b;}return"keypress"===a.type?(a=of(a),13===a?"Enter":String.fromCharCode(a)):"keydown"===a.type||"keyup"===a.type?qf[a.keyCode]||"Unidentified":"";},location:null,ctrlKey:null,shiftKey:null,altKey:null,metaKey:null,repeat:null,locale:null,getModifierState:Qe,charCode:function(a){return"keypress"===a.type?of(a):0;},keyCode:function(a){return"keydown"===a.type||"keyup"===a.type?a.keyCode:0;},which:function(a){return"keypress"===a.type?of(a):"keydown"===a.type||"keyup"===a.type?a.keyCode:0;}}),sf=Ve.extend({dataTransfer:null}),tf=Ne.extend({touches:null,targetTouches:null,changedTouches:null,altKey:null,metaKey:null,ctrlKey:null,shiftKey:null,getModifierState:Qe}),uf=G.extend({propertyName:null,elapsedTime:null,pseudoElement:null}),vf=Ve.extend({deltaX:function(a){return"deltaX"in a?a.deltaX:"wheelDeltaX"in a?-a.wheelDeltaX:0;},deltaY:function(a){return"deltaY"in a?a.deltaY:"wheelDeltaY"in a?-a.wheelDeltaY:"wheelDelta"in a?-a.wheelDelta:0;},deltaZ:null,deltaMode:null}),wf={eventTypes:Wc,extractEvents:function(a,b,c,d){var e=Yc.get(a);if(!e)return null;switch(a){case"keypress":if(0===of(c))return null;case"keydown":case"keyup":a=rf;break;case"blur":case"focus":a=nf;break;case"click":if(2===c.button)return null;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":a=Ve;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":a=sf;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":a=tf;break;case Xb:case Yb:case Zb:a=lf;break;case $b:a=uf;break;case"scroll":a=Ne;break;case"wheel":a=vf;break;case"copy":case"cut":case"paste":a=mf;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":a=We;break;default:a=G;}b=a.getPooled(e,b,c,d);Xd(b);return b;}};if(pa)throw Error(u(101));pa=Array.prototype.slice.call("ResponderEventPlugin SimpleEventPlugin EnterLeaveEventPlugin ChangeEventPlugin SelectEventPlugin BeforeInputEventPlugin".split(" "));ra();var xf=Nc;la=Qd;ma=xf;na=Pd;xa({SimpleEventPlugin:wf,EnterLeaveEventPlugin:Ye,ChangeEventPlugin:Me,SelectEventPlugin:kf,BeforeInputEventPlugin:ve});var yf=[],zf=-1;function H(a){0>zf||(a.current=yf[zf],yf[zf]=null,zf--);}function I(a,b){zf++;yf[zf]=a.current;a.current=b;}var Af={},J={current:Af},K={current:!1},Bf=Af;function Cf(a,b){var c=a.type.contextTypes;if(!c)return Af;var d=a.stateNode;if(d&&d.__reactInternalMemoizedUnmaskedChildContext===b)return d.__reactInternalMemoizedMaskedChildContext;var e={},f;for(f in c)e[f]=b[f];d&&(a=a.stateNode,a.__reactInternalMemoizedUnmaskedChildContext=b,a.__reactInternalMemoizedMaskedChildContext=e);return e;}function L(a){a=a.childContextTypes;return null!==a&&void 0!==a;}function Df(){H(K);H(J);}function Ef(a,b,c){if(J.current!==Af)throw Error(u(168));I(J,b);I(K,c);}function Ff(a,b,c){var d=a.stateNode;a=b.childContextTypes;if("function"!==typeof d.getChildContext)return c;d=d.getChildContext();for(var e in d)if(!(e in a))throw Error(u(108,pb(b)||"Unknown",e));return n({},c,{},d);}function Gf(a){a=(a=a.stateNode)&&a.__reactInternalMemoizedMergedChildContext||Af;Bf=J.current;I(J,a);I(K,K.current);return!0;}function Hf(a,b,c){var d=a.stateNode;if(!d)throw Error(u(169));c?(a=Ff(a,b,Bf),d.__reactInternalMemoizedMergedChildContext=a,H(K),H(J),I(J,a)):H(K);I(K,c);}var If=r.unstable_runWithPriority,Jf=r.unstable_scheduleCallback,Kf=r.unstable_cancelCallback,Lf=r.unstable_requestPaint,Mf=r.unstable_now,Nf=r.unstable_getCurrentPriorityLevel,Of=r.unstable_ImmediatePriority,Pf=r.unstable_UserBlockingPriority,Qf=r.unstable_NormalPriority,Rf=r.unstable_LowPriority,Sf=r.unstable_IdlePriority,Tf={},Uf=r.unstable_shouldYield,Vf=void 0!==Lf?Lf:function(){},Wf=null,Xf=null,Yf=!1,Zf=Mf(),$f=1E4>Zf?Mf:function(){return Mf()-Zf;};function ag(){switch(Nf()){case Of:return 99;case Pf:return 98;case Qf:return 97;case Rf:return 96;case Sf:return 95;default:throw Error(u(332));}}function bg(a){switch(a){case 99:return Of;case 98:return Pf;case 97:return Qf;case 96:return Rf;case 95:return Sf;default:throw Error(u(332));}}function cg(a,b){a=bg(a);return If(a,b);}function dg(a,b,c){a=bg(a);return Jf(a,b,c);}function eg(a){null===Wf?(Wf=[a],Xf=Jf(Of,fg)):Wf.push(a);return Tf;}function gg(){if(null!==Xf){var a=Xf;Xf=null;Kf(a);}fg();}function fg(){if(!Yf&&null!==Wf){Yf=!0;var a=0;try{var b=Wf;cg(99,function(){for(;a<b.length;a++){var c=b[a];do c=c(!0);while(null!==c);}});Wf=null;}catch(c){throw null!==Wf&&(Wf=Wf.slice(a+1)),Jf(Of,gg),c;}finally{Yf=!1;}}}function hg(a,b,c){c/=10;return 1073741821-(((1073741821-a+b/10)/c|0)+1)*c;}function ig(a,b){if(a&&a.defaultProps){b=n({},b);a=a.defaultProps;for(var c in a)void 0===b[c]&&(b[c]=a[c]);}return b;}var jg={current:null},kg=null,lg=null,mg=null;function ng(){mg=lg=kg=null;}function og(a){var b=jg.current;H(jg);a.type._context._currentValue=b;}function pg(a,b){for(;null!==a;){var c=a.alternate;if(a.childExpirationTime<b)a.childExpirationTime=b,null!==c&&c.childExpirationTime<b&&(c.childExpirationTime=b);else if(null!==c&&c.childExpirationTime<b)c.childExpirationTime=b;else break;a=a.return;}}function qg(a,b){kg=a;mg=lg=null;a=a.dependencies;null!==a&&null!==a.firstContext&&(a.expirationTime>=b&&(rg=!0),a.firstContext=null);}function sg(a,b){if(mg!==a&&!1!==b&&0!==b){if("number"!==typeof b||1073741823===b)mg=a,b=1073741823;b={context:a,observedBits:b,next:null};if(null===lg){if(null===kg)throw Error(u(308));lg=b;kg.dependencies={expirationTime:0,firstContext:b,responders:null};}else lg=lg.next=b;}return a._currentValue;}var tg=!1;function ug(a){a.updateQueue={baseState:a.memoizedState,baseQueue:null,shared:{pending:null},effects:null};}function vg(a,b){a=a.updateQueue;b.updateQueue===a&&(b.updateQueue={baseState:a.baseState,baseQueue:a.baseQueue,shared:a.shared,effects:a.effects});}function wg(a,b){a={expirationTime:a,suspenseConfig:b,tag:0,payload:null,callback:null,next:null};return a.next=a;}function xg(a,b){a=a.updateQueue;if(null!==a){a=a.shared;var c=a.pending;null===c?b.next=b:(b.next=c.next,c.next=b);a.pending=b;}}function yg(a,b){var c=a.alternate;null!==c&&vg(c,a);a=a.updateQueue;c=a.baseQueue;null===c?(a.baseQueue=b.next=b,b.next=b):(b.next=c.next,c.next=b);}function zg(a,b,c,d){var e=a.updateQueue;tg=!1;var f=e.baseQueue,g=e.shared.pending;if(null!==g){if(null!==f){var h=f.next;f.next=g.next;g.next=h;}f=g;e.shared.pending=null;h=a.alternate;null!==h&&(h=h.updateQueue,null!==h&&(h.baseQueue=g));}if(null!==f){h=f.next;var k=e.baseState,l=0,m=null,p=null,x=null;if(null!==h){var z=h;do{g=z.expirationTime;if(g<d){var ca={expirationTime:z.expirationTime,suspenseConfig:z.suspenseConfig,tag:z.tag,payload:z.payload,callback:z.callback,next:null};null===x?(p=x=ca,m=k):x=x.next=ca;g>l&&(l=g);}else{null!==x&&(x=x.next={expirationTime:1073741823,suspenseConfig:z.suspenseConfig,tag:z.tag,payload:z.payload,callback:z.callback,next:null});Ag(g,z.suspenseConfig);a:{var D=a,t=z;g=b;ca=c;switch(t.tag){case 1:D=t.payload;if("function"===typeof D){k=D.call(ca,k,g);break a;}k=D;break a;case 3:D.effectTag=D.effectTag&-4097|64;case 0:D=t.payload;g="function"===typeof D?D.call(ca,k,g):D;if(null===g||void 0===g)break a;k=n({},k,g);break a;case 2:tg=!0;}}null!==z.callback&&(a.effectTag|=32,g=e.effects,null===g?e.effects=[z]:g.push(z));}z=z.next;if(null===z||z===h)if(g=e.shared.pending,null===g)break;else z=f.next=g.next,g.next=h,e.baseQueue=f=g,e.shared.pending=null;}while(1);}null===x?m=k:x.next=p;e.baseState=m;e.baseQueue=x;Bg(l);a.expirationTime=l;a.memoizedState=k;}}function Cg(a,b,c){a=b.effects;b.effects=null;if(null!==a)for(b=0;b<a.length;b++){var d=a[b],e=d.callback;if(null!==e){d.callback=null;d=e;e=c;if("function"!==typeof d)throw Error(u(191,d));d.call(e);}}}var Dg=Wa.ReactCurrentBatchConfig,Eg=new aa.Component().refs;function Fg(a,b,c,d){b=a.memoizedState;c=c(d,b);c=null===c||void 0===c?b:n({},b,c);a.memoizedState=c;0===a.expirationTime&&(a.updateQueue.baseState=c);}var Jg={isMounted:function(a){return(a=a._reactInternalFiber)?dc(a)===a:!1;},enqueueSetState:function(a,b,c){a=a._reactInternalFiber;var d=Gg(),e=Dg.suspense;d=Hg(d,a,e);e=wg(d,e);e.payload=b;void 0!==c&&null!==c&&(e.callback=c);xg(a,e);Ig(a,d);},enqueueReplaceState:function(a,b,c){a=a._reactInternalFiber;var d=Gg(),e=Dg.suspense;d=Hg(d,a,e);e=wg(d,e);e.tag=1;e.payload=b;void 0!==c&&null!==c&&(e.callback=c);xg(a,e);Ig(a,d);},enqueueForceUpdate:function(a,b){a=a._reactInternalFiber;var c=Gg(),d=Dg.suspense;c=Hg(c,a,d);d=wg(c,d);d.tag=2;void 0!==b&&null!==b&&(d.callback=b);xg(a,d);Ig(a,c);}};function Kg(a,b,c,d,e,f,g){a=a.stateNode;return"function"===typeof a.shouldComponentUpdate?a.shouldComponentUpdate(d,f,g):b.prototype&&b.prototype.isPureReactComponent?!bf(c,d)||!bf(e,f):!0;}function Lg(a,b,c){var d=!1,e=Af;var f=b.contextType;"object"===typeof f&&null!==f?f=sg(f):(e=L(b)?Bf:J.current,d=b.contextTypes,f=(d=null!==d&&void 0!==d)?Cf(a,e):Af);b=new b(c,f);a.memoizedState=null!==b.state&&void 0!==b.state?b.state:null;b.updater=Jg;a.stateNode=b;b._reactInternalFiber=a;d&&(a=a.stateNode,a.__reactInternalMemoizedUnmaskedChildContext=e,a.__reactInternalMemoizedMaskedChildContext=f);return b;}function Mg(a,b,c,d){a=b.state;"function"===typeof b.componentWillReceiveProps&&b.componentWillReceiveProps(c,d);"function"===typeof b.UNSAFE_componentWillReceiveProps&&b.UNSAFE_componentWillReceiveProps(c,d);b.state!==a&&Jg.enqueueReplaceState(b,b.state,null);}function Ng(a,b,c,d){var e=a.stateNode;e.props=c;e.state=a.memoizedState;e.refs=Eg;ug(a);var f=b.contextType;"object"===typeof f&&null!==f?e.context=sg(f):(f=L(b)?Bf:J.current,e.context=Cf(a,f));zg(a,c,e,d);e.state=a.memoizedState;f=b.getDerivedStateFromProps;"function"===typeof f&&(Fg(a,b,f,c),e.state=a.memoizedState);"function"===typeof b.getDerivedStateFromProps||"function"===typeof e.getSnapshotBeforeUpdate||"function"!==typeof e.UNSAFE_componentWillMount&&"function"!==typeof e.componentWillMount||(b=e.state,"function"===typeof e.componentWillMount&&e.componentWillMount(),"function"===typeof e.UNSAFE_componentWillMount&&e.UNSAFE_componentWillMount(),b!==e.state&&Jg.enqueueReplaceState(e,e.state,null),zg(a,c,e,d),e.state=a.memoizedState);"function"===typeof e.componentDidMount&&(a.effectTag|=4);}var Og=Array.isArray;function Pg(a,b,c){a=c.ref;if(null!==a&&"function"!==typeof a&&"object"!==typeof a){if(c._owner){c=c._owner;if(c){if(1!==c.tag)throw Error(u(309));var d=c.stateNode;}if(!d)throw Error(u(147,a));var e=""+a;if(null!==b&&null!==b.ref&&"function"===typeof b.ref&&b.ref._stringRef===e)return b.ref;b=function(a){var b=d.refs;b===Eg&&(b=d.refs={});null===a?delete b[e]:b[e]=a;};b._stringRef=e;return b;}if("string"!==typeof a)throw Error(u(284));if(!c._owner)throw Error(u(290,a));}return a;}function Qg(a,b){if("textarea"!==a.type)throw Error(u(31,"[object Object]"===Object.prototype.toString.call(b)?"object with keys {"+Object.keys(b).join(", ")+"}":b,""));}function Rg(a){function b(b,c){if(a){var d=b.lastEffect;null!==d?(d.nextEffect=c,b.lastEffect=c):b.firstEffect=b.lastEffect=c;c.nextEffect=null;c.effectTag=8;}}function c(c,d){if(!a)return null;for(;null!==d;)b(c,d),d=d.sibling;return null;}function d(a,b){for(a=new Map();null!==b;)null!==b.key?a.set(b.key,b):a.set(b.index,b),b=b.sibling;return a;}function e(a,b){a=Sg(a,b);a.index=0;a.sibling=null;return a;}function f(b,c,d){b.index=d;if(!a)return c;d=b.alternate;if(null!==d)return d=d.index,d<c?(b.effectTag=2,c):d;b.effectTag=2;return c;}function g(b){a&&null===b.alternate&&(b.effectTag=2);return b;}function h(a,b,c,d){if(null===b||6!==b.tag)return b=Tg(c,a.mode,d),b.return=a,b;b=e(b,c);b.return=a;return b;}function k(a,b,c,d){if(null!==b&&b.elementType===c.type)return d=e(b,c.props),d.ref=Pg(a,b,c),d.return=a,d;d=Ug(c.type,c.key,c.props,null,a.mode,d);d.ref=Pg(a,b,c);d.return=a;return d;}function l(a,b,c,d){if(null===b||4!==b.tag||b.stateNode.containerInfo!==c.containerInfo||b.stateNode.implementation!==c.implementation)return b=Vg(c,a.mode,d),b.return=a,b;b=e(b,c.children||[]);b.return=a;return b;}function m(a,b,c,d,f){if(null===b||7!==b.tag)return b=Wg(c,a.mode,d,f),b.return=a,b;b=e(b,c);b.return=a;return b;}function p(a,b,c){if("string"===typeof b||"number"===typeof b)return b=Tg(""+b,a.mode,c),b.return=a,b;if("object"===typeof b&&null!==b){switch(b.$$typeof){case Za:return c=Ug(b.type,b.key,b.props,null,a.mode,c),c.ref=Pg(a,null,b),c.return=a,c;case $a:return b=Vg(b,a.mode,c),b.return=a,b;}if(Og(b)||nb(b))return b=Wg(b,a.mode,c,null),b.return=a,b;Qg(a,b);}return null;}function x(a,b,c,d){var e=null!==b?b.key:null;if("string"===typeof c||"number"===typeof c)return null!==e?null:h(a,b,""+c,d);if("object"===typeof c&&null!==c){switch(c.$$typeof){case Za:return c.key===e?c.type===ab?m(a,b,c.props.children,d,e):k(a,b,c,d):null;case $a:return c.key===e?l(a,b,c,d):null;}if(Og(c)||nb(c))return null!==e?null:m(a,b,c,d,null);Qg(a,c);}return null;}function z(a,b,c,d,e){if("string"===typeof d||"number"===typeof d)return a=a.get(c)||null,h(b,a,""+d,e);if("object"===typeof d&&null!==d){switch(d.$$typeof){case Za:return a=a.get(null===d.key?c:d.key)||null,d.type===ab?m(b,a,d.props.children,e,d.key):k(b,a,d,e);case $a:return a=a.get(null===d.key?c:d.key)||null,l(b,a,d,e);}if(Og(d)||nb(d))return a=a.get(c)||null,m(b,a,d,e,null);Qg(b,d);}return null;}function ca(e,g,h,k){for(var l=null,t=null,m=g,y=g=0,A=null;null!==m&&y<h.length;y++){m.index>y?(A=m,m=null):A=m.sibling;var q=x(e,m,h[y],k);if(null===q){null===m&&(m=A);break;}a&&m&&null===q.alternate&&b(e,m);g=f(q,g,y);null===t?l=q:t.sibling=q;t=q;m=A;}if(y===h.length)return c(e,m),l;if(null===m){for(;y<h.length;y++)m=p(e,h[y],k),null!==m&&(g=f(m,g,y),null===t?l=m:t.sibling=m,t=m);return l;}for(m=d(e,m);y<h.length;y++)A=z(m,e,y,h[y],k),null!==A&&(a&&null!==A.alternate&&m.delete(null===A.key?y:A.key),g=f(A,g,y),null===t?l=A:t.sibling=A,t=A);a&&m.forEach(function(a){return b(e,a);});return l;}function D(e,g,h,l){var k=nb(h);if("function"!==typeof k)throw Error(u(150));h=k.call(h);if(null==h)throw Error(u(151));for(var m=k=null,t=g,y=g=0,A=null,q=h.next();null!==t&&!q.done;y++,q=h.next()){t.index>y?(A=t,t=null):A=t.sibling;var D=x(e,t,q.value,l);if(null===D){null===t&&(t=A);break;}a&&t&&null===D.alternate&&b(e,t);g=f(D,g,y);null===m?k=D:m.sibling=D;m=D;t=A;}if(q.done)return c(e,t),k;if(null===t){for(;!q.done;y++,q=h.next())q=p(e,q.value,l),null!==q&&(g=f(q,g,y),null===m?k=q:m.sibling=q,m=q);return k;}for(t=d(e,t);!q.done;y++,q=h.next())q=z(t,e,y,q.value,l),null!==q&&(a&&null!==q.alternate&&t.delete(null===q.key?y:q.key),g=f(q,g,y),null===m?k=q:m.sibling=q,m=q);a&&t.forEach(function(a){return b(e,a);});return k;}return function(a,d,f,h){var k="object"===typeof f&&null!==f&&f.type===ab&&null===f.key;k&&(f=f.props.children);var l="object"===typeof f&&null!==f;if(l)switch(f.$$typeof){case Za:a:{l=f.key;for(k=d;null!==k;){if(k.key===l){switch(k.tag){case 7:if(f.type===ab){c(a,k.sibling);d=e(k,f.props.children);d.return=a;a=d;break a;}break;default:if(k.elementType===f.type){c(a,k.sibling);d=e(k,f.props);d.ref=Pg(a,k,f);d.return=a;a=d;break a;}}c(a,k);break;}else b(a,k);k=k.sibling;}f.type===ab?(d=Wg(f.props.children,a.mode,h,f.key),d.return=a,a=d):(h=Ug(f.type,f.key,f.props,null,a.mode,h),h.ref=Pg(a,d,f),h.return=a,a=h);}return g(a);case $a:a:{for(k=f.key;null!==d;){if(d.key===k){if(4===d.tag&&d.stateNode.containerInfo===f.containerInfo&&d.stateNode.implementation===f.implementation){c(a,d.sibling);d=e(d,f.children||[]);d.return=a;a=d;break a;}else{c(a,d);break;}}else b(a,d);d=d.sibling;}d=Vg(f,a.mode,h);d.return=a;a=d;}return g(a);}if("string"===typeof f||"number"===typeof f)return f=""+f,null!==d&&6===d.tag?(c(a,d.sibling),d=e(d,f),d.return=a,a=d):(c(a,d),d=Tg(f,a.mode,h),d.return=a,a=d),g(a);if(Og(f))return ca(a,d,f,h);if(nb(f))return D(a,d,f,h);l&&Qg(a,f);if("undefined"===typeof f&&!k)switch(a.tag){case 1:case 0:throw a=a.type,Error(u(152,a.displayName||a.name||"Component"));}return c(a,d);};}var Xg=Rg(!0),Yg=Rg(!1),Zg={},$g={current:Zg},ah={current:Zg},bh={current:Zg};function ch(a){if(a===Zg)throw Error(u(174));return a;}function dh(a,b){I(bh,b);I(ah,a);I($g,Zg);a=b.nodeType;switch(a){case 9:case 11:b=(b=b.documentElement)?b.namespaceURI:Ob(null,"");break;default:a=8===a?b.parentNode:b,b=a.namespaceURI||null,a=a.tagName,b=Ob(b,a);}H($g);I($g,b);}function eh(){H($g);H(ah);H(bh);}function fh(a){ch(bh.current);var b=ch($g.current);var c=Ob(b,a.type);b!==c&&(I(ah,a),I($g,c));}function gh(a){ah.current===a&&(H($g),H(ah));}var M={current:0};function hh(a){for(var b=a;null!==b;){if(13===b.tag){var c=b.memoizedState;if(null!==c&&(c=c.dehydrated,null===c||c.data===Bd||c.data===Cd))return b;}else if(19===b.tag&&void 0!==b.memoizedProps.revealOrder){if(0!==(b.effectTag&64))return b;}else if(null!==b.child){b.child.return=b;b=b.child;continue;}if(b===a)break;for(;null===b.sibling;){if(null===b.return||b.return===a)return null;b=b.return;}b.sibling.return=b.return;b=b.sibling;}return null;}function ih(a,b){return{responder:a,props:b};}var jh=Wa.ReactCurrentDispatcher,kh=Wa.ReactCurrentBatchConfig,lh=0,N=null,O=null,P=null,mh=!1;function Q(){throw Error(u(321));}function nh(a,b){if(null===b)return!1;for(var c=0;c<b.length&&c<a.length;c++)if(!$e(a[c],b[c]))return!1;return!0;}function oh(a,b,c,d,e,f){lh=f;N=b;b.memoizedState=null;b.updateQueue=null;b.expirationTime=0;jh.current=null===a||null===a.memoizedState?ph:qh;a=c(d,e);if(b.expirationTime===lh){f=0;do{b.expirationTime=0;if(!(25>f))throw Error(u(301));f+=1;P=O=null;b.updateQueue=null;jh.current=rh;a=c(d,e);}while(b.expirationTime===lh);}jh.current=sh;b=null!==O&&null!==O.next;lh=0;P=O=N=null;mh=!1;if(b)throw Error(u(300));return a;}function th(){var a={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};null===P?N.memoizedState=P=a:P=P.next=a;return P;}function uh(){if(null===O){var a=N.alternate;a=null!==a?a.memoizedState:null;}else a=O.next;var b=null===P?N.memoizedState:P.next;if(null!==b)P=b,O=a;else{if(null===a)throw Error(u(310));O=a;a={memoizedState:O.memoizedState,baseState:O.baseState,baseQueue:O.baseQueue,queue:O.queue,next:null};null===P?N.memoizedState=P=a:P=P.next=a;}return P;}function vh(a,b){return"function"===typeof b?b(a):b;}function wh(a){var b=uh(),c=b.queue;if(null===c)throw Error(u(311));c.lastRenderedReducer=a;var d=O,e=d.baseQueue,f=c.pending;if(null!==f){if(null!==e){var g=e.next;e.next=f.next;f.next=g;}d.baseQueue=e=f;c.pending=null;}if(null!==e){e=e.next;d=d.baseState;var h=g=f=null,k=e;do{var l=k.expirationTime;if(l<lh){var m={expirationTime:k.expirationTime,suspenseConfig:k.suspenseConfig,action:k.action,eagerReducer:k.eagerReducer,eagerState:k.eagerState,next:null};null===h?(g=h=m,f=d):h=h.next=m;l>N.expirationTime&&(N.expirationTime=l,Bg(l));}else null!==h&&(h=h.next={expirationTime:1073741823,suspenseConfig:k.suspenseConfig,action:k.action,eagerReducer:k.eagerReducer,eagerState:k.eagerState,next:null}),Ag(l,k.suspenseConfig),d=k.eagerReducer===a?k.eagerState:a(d,k.action);k=k.next;}while(null!==k&&k!==e);null===h?f=d:h.next=g;$e(d,b.memoizedState)||(rg=!0);b.memoizedState=d;b.baseState=f;b.baseQueue=h;c.lastRenderedState=d;}return[b.memoizedState,c.dispatch];}function xh(a){var b=uh(),c=b.queue;if(null===c)throw Error(u(311));c.lastRenderedReducer=a;var d=c.dispatch,e=c.pending,f=b.memoizedState;if(null!==e){c.pending=null;var g=e=e.next;do f=a(f,g.action),g=g.next;while(g!==e);$e(f,b.memoizedState)||(rg=!0);b.memoizedState=f;null===b.baseQueue&&(b.baseState=f);c.lastRenderedState=f;}return[f,d];}function yh(a){var b=th();"function"===typeof a&&(a=a());b.memoizedState=b.baseState=a;a=b.queue={pending:null,dispatch:null,lastRenderedReducer:vh,lastRenderedState:a};a=a.dispatch=zh.bind(null,N,a);return[b.memoizedState,a];}function Ah(a,b,c,d){a={tag:a,create:b,destroy:c,deps:d,next:null};b=N.updateQueue;null===b?(b={lastEffect:null},N.updateQueue=b,b.lastEffect=a.next=a):(c=b.lastEffect,null===c?b.lastEffect=a.next=a:(d=c.next,c.next=a,a.next=d,b.lastEffect=a));return a;}function Bh(){return uh().memoizedState;}function Ch(a,b,c,d){var e=th();N.effectTag|=a;e.memoizedState=Ah(1|b,c,void 0,void 0===d?null:d);}function Dh(a,b,c,d){var e=uh();d=void 0===d?null:d;var f=void 0;if(null!==O){var g=O.memoizedState;f=g.destroy;if(null!==d&&nh(d,g.deps)){Ah(b,c,f,d);return;}}N.effectTag|=a;e.memoizedState=Ah(1|b,c,f,d);}function Eh(a,b){return Ch(516,4,a,b);}function Fh(a,b){return Dh(516,4,a,b);}function Gh(a,b){return Dh(4,2,a,b);}function Hh(a,b){if("function"===typeof b)return a=a(),b(a),function(){b(null);};if(null!==b&&void 0!==b)return a=a(),b.current=a,function(){b.current=null;};}function Ih(a,b,c){c=null!==c&&void 0!==c?c.concat([a]):null;return Dh(4,2,Hh.bind(null,b,a),c);}function Jh(){}function Kh(a,b){th().memoizedState=[a,void 0===b?null:b];return a;}function Lh(a,b){var c=uh();b=void 0===b?null:b;var d=c.memoizedState;if(null!==d&&null!==b&&nh(b,d[1]))return d[0];c.memoizedState=[a,b];return a;}function Mh(a,b){var c=uh();b=void 0===b?null:b;var d=c.memoizedState;if(null!==d&&null!==b&&nh(b,d[1]))return d[0];a=a();c.memoizedState=[a,b];return a;}function Nh(a,b,c){var d=ag();cg(98>d?98:d,function(){a(!0);});cg(97<d?97:d,function(){var d=kh.suspense;kh.suspense=void 0===b?null:b;try{a(!1),c();}finally{kh.suspense=d;}});}function zh(a,b,c){var d=Gg(),e=Dg.suspense;d=Hg(d,a,e);e={expirationTime:d,suspenseConfig:e,action:c,eagerReducer:null,eagerState:null,next:null};var f=b.pending;null===f?e.next=e:(e.next=f.next,f.next=e);b.pending=e;f=a.alternate;if(a===N||null!==f&&f===N)mh=!0,e.expirationTime=lh,N.expirationTime=lh;else{if(0===a.expirationTime&&(null===f||0===f.expirationTime)&&(f=b.lastRenderedReducer,null!==f))try{var g=b.lastRenderedState,h=f(g,c);e.eagerReducer=f;e.eagerState=h;if($e(h,g))return;}catch(k){}finally{}Ig(a,d);}}var sh={readContext:sg,useCallback:Q,useContext:Q,useEffect:Q,useImperativeHandle:Q,useLayoutEffect:Q,useMemo:Q,useReducer:Q,useRef:Q,useState:Q,useDebugValue:Q,useResponder:Q,useDeferredValue:Q,useTransition:Q},ph={readContext:sg,useCallback:Kh,useContext:sg,useEffect:Eh,useImperativeHandle:function(a,b,c){c=null!==c&&void 0!==c?c.concat([a]):null;return Ch(4,2,Hh.bind(null,b,a),c);},useLayoutEffect:function(a,b){return Ch(4,2,a,b);},useMemo:function(a,b){var c=th();b=void 0===b?null:b;a=a();c.memoizedState=[a,b];return a;},useReducer:function(a,b,c){var d=th();b=void 0!==c?c(b):b;d.memoizedState=d.baseState=b;a=d.queue={pending:null,dispatch:null,lastRenderedReducer:a,lastRenderedState:b};a=a.dispatch=zh.bind(null,N,a);return[d.memoizedState,a];},useRef:function(a){var b=th();a={current:a};return b.memoizedState=a;},useState:yh,useDebugValue:Jh,useResponder:ih,useDeferredValue:function(a,b){var c=yh(a),d=c[0],e=c[1];Eh(function(){var c=kh.suspense;kh.suspense=void 0===b?null:b;try{e(a);}finally{kh.suspense=c;}},[a,b]);return d;},useTransition:function(a){var b=yh(!1),c=b[0];b=b[1];return[Kh(Nh.bind(null,b,a),[b,a]),c];}},qh={readContext:sg,useCallback:Lh,useContext:sg,useEffect:Fh,useImperativeHandle:Ih,useLayoutEffect:Gh,useMemo:Mh,useReducer:wh,useRef:Bh,useState:function(){return wh(vh);},useDebugValue:Jh,useResponder:ih,useDeferredValue:function(a,b){var c=wh(vh),d=c[0],e=c[1];Fh(function(){var c=kh.suspense;kh.suspense=void 0===b?null:b;try{e(a);}finally{kh.suspense=c;}},[a,b]);return d;},useTransition:function(a){var b=wh(vh),c=b[0];b=b[1];return[Lh(Nh.bind(null,b,a),[b,a]),c];}},rh={readContext:sg,useCallback:Lh,useContext:sg,useEffect:Fh,useImperativeHandle:Ih,useLayoutEffect:Gh,useMemo:Mh,useReducer:xh,useRef:Bh,useState:function(){return xh(vh);},useDebugValue:Jh,useResponder:ih,useDeferredValue:function(a,b){var c=xh(vh),d=c[0],e=c[1];Fh(function(){var c=kh.suspense;kh.suspense=void 0===b?null:b;try{e(a);}finally{kh.suspense=c;}},[a,b]);return d;},useTransition:function(a){var b=xh(vh),c=b[0];b=b[1];return[Lh(Nh.bind(null,b,a),[b,a]),c];}},Oh=null,Ph=null,Qh=!1;function Rh(a,b){var c=Sh(5,null,null,0);c.elementType="DELETED";c.type="DELETED";c.stateNode=b;c.return=a;c.effectTag=8;null!==a.lastEffect?(a.lastEffect.nextEffect=c,a.lastEffect=c):a.firstEffect=a.lastEffect=c;}function Th(a,b){switch(a.tag){case 5:var c=a.type;b=1!==b.nodeType||c.toLowerCase()!==b.nodeName.toLowerCase()?null:b;return null!==b?(a.stateNode=b,!0):!1;case 6:return b=""===a.pendingProps||3!==b.nodeType?null:b,null!==b?(a.stateNode=b,!0):!1;case 13:return!1;default:return!1;}}function Uh(a){if(Qh){var b=Ph;if(b){var c=b;if(!Th(a,b)){b=Jd(c.nextSibling);if(!b||!Th(a,b)){a.effectTag=a.effectTag&-1025|2;Qh=!1;Oh=a;return;}Rh(Oh,c);}Oh=a;Ph=Jd(b.firstChild);}else a.effectTag=a.effectTag&-1025|2,Qh=!1,Oh=a;}}function Vh(a){for(a=a.return;null!==a&&5!==a.tag&&3!==a.tag&&13!==a.tag;)a=a.return;Oh=a;}function Wh(a){if(a!==Oh)return!1;if(!Qh)return Vh(a),Qh=!0,!1;var b=a.type;if(5!==a.tag||"head"!==b&&"body"!==b&&!Gd(b,a.memoizedProps))for(b=Ph;b;)Rh(a,b),b=Jd(b.nextSibling);Vh(a);if(13===a.tag){a=a.memoizedState;a=null!==a?a.dehydrated:null;if(!a)throw Error(u(317));a:{a=a.nextSibling;for(b=0;a;){if(8===a.nodeType){var c=a.data;if(c===Ad){if(0===b){Ph=Jd(a.nextSibling);break a;}b--;}else c!==zd&&c!==Cd&&c!==Bd||b++;}a=a.nextSibling;}Ph=null;}}else Ph=Oh?Jd(a.stateNode.nextSibling):null;return!0;}function Xh(){Ph=Oh=null;Qh=!1;}var Yh=Wa.ReactCurrentOwner,rg=!1;function R(a,b,c,d){b.child=null===a?Yg(b,null,c,d):Xg(b,a.child,c,d);}function Zh(a,b,c,d,e){c=c.render;var f=b.ref;qg(b,e);d=oh(a,b,c,d,f,e);if(null!==a&&!rg)return b.updateQueue=a.updateQueue,b.effectTag&=-517,a.expirationTime<=e&&(a.expirationTime=0),$h(a,b,e);b.effectTag|=1;R(a,b,d,e);return b.child;}function ai(a,b,c,d,e,f){if(null===a){var g=c.type;if("function"===typeof g&&!bi(g)&&void 0===g.defaultProps&&null===c.compare&&void 0===c.defaultProps)return b.tag=15,b.type=g,ci(a,b,g,d,e,f);a=Ug(c.type,null,d,null,b.mode,f);a.ref=b.ref;a.return=b;return b.child=a;}g=a.child;if(e<f&&(e=g.memoizedProps,c=c.compare,c=null!==c?c:bf,c(e,d)&&a.ref===b.ref))return $h(a,b,f);b.effectTag|=1;a=Sg(g,d);a.ref=b.ref;a.return=b;return b.child=a;}function ci(a,b,c,d,e,f){return null!==a&&bf(a.memoizedProps,d)&&a.ref===b.ref&&(rg=!1,e<f)?(b.expirationTime=a.expirationTime,$h(a,b,f)):di(a,b,c,d,f);}function ei(a,b){var c=b.ref;if(null===a&&null!==c||null!==a&&a.ref!==c)b.effectTag|=128;}function di(a,b,c,d,e){var f=L(c)?Bf:J.current;f=Cf(b,f);qg(b,e);c=oh(a,b,c,d,f,e);if(null!==a&&!rg)return b.updateQueue=a.updateQueue,b.effectTag&=-517,a.expirationTime<=e&&(a.expirationTime=0),$h(a,b,e);b.effectTag|=1;R(a,b,c,e);return b.child;}function fi(a,b,c,d,e){if(L(c)){var f=!0;Gf(b);}else f=!1;qg(b,e);if(null===b.stateNode)null!==a&&(a.alternate=null,b.alternate=null,b.effectTag|=2),Lg(b,c,d),Ng(b,c,d,e),d=!0;else if(null===a){var g=b.stateNode,h=b.memoizedProps;g.props=h;var k=g.context,l=c.contextType;"object"===typeof l&&null!==l?l=sg(l):(l=L(c)?Bf:J.current,l=Cf(b,l));var m=c.getDerivedStateFromProps,p="function"===typeof m||"function"===typeof g.getSnapshotBeforeUpdate;p||"function"!==typeof g.UNSAFE_componentWillReceiveProps&&"function"!==typeof g.componentWillReceiveProps||(h!==d||k!==l)&&Mg(b,g,d,l);tg=!1;var x=b.memoizedState;g.state=x;zg(b,d,g,e);k=b.memoizedState;h!==d||x!==k||K.current||tg?("function"===typeof m&&(Fg(b,c,m,d),k=b.memoizedState),(h=tg||Kg(b,c,h,d,x,k,l))?(p||"function"!==typeof g.UNSAFE_componentWillMount&&"function"!==typeof g.componentWillMount||("function"===typeof g.componentWillMount&&g.componentWillMount(),"function"===typeof g.UNSAFE_componentWillMount&&g.UNSAFE_componentWillMount()),"function"===typeof g.componentDidMount&&(b.effectTag|=4)):("function"===typeof g.componentDidMount&&(b.effectTag|=4),b.memoizedProps=d,b.memoizedState=k),g.props=d,g.state=k,g.context=l,d=h):("function"===typeof g.componentDidMount&&(b.effectTag|=4),d=!1);}else g=b.stateNode,vg(a,b),h=b.memoizedProps,g.props=b.type===b.elementType?h:ig(b.type,h),k=g.context,l=c.contextType,"object"===typeof l&&null!==l?l=sg(l):(l=L(c)?Bf:J.current,l=Cf(b,l)),m=c.getDerivedStateFromProps,(p="function"===typeof m||"function"===typeof g.getSnapshotBeforeUpdate)||"function"!==typeof g.UNSAFE_componentWillReceiveProps&&"function"!==typeof g.componentWillReceiveProps||(h!==d||k!==l)&&Mg(b,g,d,l),tg=!1,k=b.memoizedState,g.state=k,zg(b,d,g,e),x=b.memoizedState,h!==d||k!==x||K.current||tg?("function"===typeof m&&(Fg(b,c,m,d),x=b.memoizedState),(m=tg||Kg(b,c,h,d,k,x,l))?(p||"function"!==typeof g.UNSAFE_componentWillUpdate&&"function"!==typeof g.componentWillUpdate||("function"===typeof g.componentWillUpdate&&g.componentWillUpdate(d,x,l),"function"===typeof g.UNSAFE_componentWillUpdate&&g.UNSAFE_componentWillUpdate(d,x,l)),"function"===typeof g.componentDidUpdate&&(b.effectTag|=4),"function"===typeof g.getSnapshotBeforeUpdate&&(b.effectTag|=256)):("function"!==typeof g.componentDidUpdate||h===a.memoizedProps&&k===a.memoizedState||(b.effectTag|=4),"function"!==typeof g.getSnapshotBeforeUpdate||h===a.memoizedProps&&k===a.memoizedState||(b.effectTag|=256),b.memoizedProps=d,b.memoizedState=x),g.props=d,g.state=x,g.context=l,d=m):("function"!==typeof g.componentDidUpdate||h===a.memoizedProps&&k===a.memoizedState||(b.effectTag|=4),"function"!==typeof g.getSnapshotBeforeUpdate||h===a.memoizedProps&&k===a.memoizedState||(b.effectTag|=256),d=!1);return gi(a,b,c,d,f,e);}function gi(a,b,c,d,e,f){ei(a,b);var g=0!==(b.effectTag&64);if(!d&&!g)return e&&Hf(b,c,!1),$h(a,b,f);d=b.stateNode;Yh.current=b;var h=g&&"function"!==typeof c.getDerivedStateFromError?null:d.render();b.effectTag|=1;null!==a&&g?(b.child=Xg(b,a.child,null,f),b.child=Xg(b,null,h,f)):R(a,b,h,f);b.memoizedState=d.state;e&&Hf(b,c,!0);return b.child;}function hi(a){var b=a.stateNode;b.pendingContext?Ef(a,b.pendingContext,b.pendingContext!==b.context):b.context&&Ef(a,b.context,!1);dh(a,b.containerInfo);}var ii={dehydrated:null,retryTime:0};function ji(a,b,c){var d=b.mode,e=b.pendingProps,f=M.current,g=!1,h;(h=0!==(b.effectTag&64))||(h=0!==(f&2)&&(null===a||null!==a.memoizedState));h?(g=!0,b.effectTag&=-65):null!==a&&null===a.memoizedState||void 0===e.fallback||!0===e.unstable_avoidThisFallback||(f|=1);I(M,f&1);if(null===a){void 0!==e.fallback&&Uh(b);if(g){g=e.fallback;e=Wg(null,d,0,null);e.return=b;if(0===(b.mode&2))for(a=null!==b.memoizedState?b.child.child:b.child,e.child=a;null!==a;)a.return=e,a=a.sibling;c=Wg(g,d,c,null);c.return=b;e.sibling=c;b.memoizedState=ii;b.child=e;return c;}d=e.children;b.memoizedState=null;return b.child=Yg(b,null,d,c);}if(null!==a.memoizedState){a=a.child;d=a.sibling;if(g){e=e.fallback;c=Sg(a,a.pendingProps);c.return=b;if(0===(b.mode&2)&&(g=null!==b.memoizedState?b.child.child:b.child,g!==a.child))for(c.child=g;null!==g;)g.return=c,g=g.sibling;d=Sg(d,e);d.return=b;c.sibling=d;c.childExpirationTime=0;b.memoizedState=ii;b.child=c;return d;}c=Xg(b,a.child,e.children,c);b.memoizedState=null;return b.child=c;}a=a.child;if(g){g=e.fallback;e=Wg(null,d,0,null);e.return=b;e.child=a;null!==a&&(a.return=e);if(0===(b.mode&2))for(a=null!==b.memoizedState?b.child.child:b.child,e.child=a;null!==a;)a.return=e,a=a.sibling;c=Wg(g,d,c,null);c.return=b;e.sibling=c;c.effectTag|=2;e.childExpirationTime=0;b.memoizedState=ii;b.child=e;return c;}b.memoizedState=null;return b.child=Xg(b,a,e.children,c);}function ki(a,b){a.expirationTime<b&&(a.expirationTime=b);var c=a.alternate;null!==c&&c.expirationTime<b&&(c.expirationTime=b);pg(a.return,b);}function li(a,b,c,d,e,f){var g=a.memoizedState;null===g?a.memoizedState={isBackwards:b,rendering:null,renderingStartTime:0,last:d,tail:c,tailExpiration:0,tailMode:e,lastEffect:f}:(g.isBackwards=b,g.rendering=null,g.renderingStartTime=0,g.last=d,g.tail=c,g.tailExpiration=0,g.tailMode=e,g.lastEffect=f);}function mi(a,b,c){var d=b.pendingProps,e=d.revealOrder,f=d.tail;R(a,b,d.children,c);d=M.current;if(0!==(d&2))d=d&1|2,b.effectTag|=64;else{if(null!==a&&0!==(a.effectTag&64))a:for(a=b.child;null!==a;){if(13===a.tag)null!==a.memoizedState&&ki(a,c);else if(19===a.tag)ki(a,c);else if(null!==a.child){a.child.return=a;a=a.child;continue;}if(a===b)break a;for(;null===a.sibling;){if(null===a.return||a.return===b)break a;a=a.return;}a.sibling.return=a.return;a=a.sibling;}d&=1;}I(M,d);if(0===(b.mode&2))b.memoizedState=null;else switch(e){case"forwards":c=b.child;for(e=null;null!==c;)a=c.alternate,null!==a&&null===hh(a)&&(e=c),c=c.sibling;c=e;null===c?(e=b.child,b.child=null):(e=c.sibling,c.sibling=null);li(b,!1,e,c,f,b.lastEffect);break;case"backwards":c=null;e=b.child;for(b.child=null;null!==e;){a=e.alternate;if(null!==a&&null===hh(a)){b.child=e;break;}a=e.sibling;e.sibling=c;c=e;e=a;}li(b,!0,c,null,f,b.lastEffect);break;case"together":li(b,!1,null,null,void 0,b.lastEffect);break;default:b.memoizedState=null;}return b.child;}function $h(a,b,c){null!==a&&(b.dependencies=a.dependencies);var d=b.expirationTime;0!==d&&Bg(d);if(b.childExpirationTime<c)return null;if(null!==a&&b.child!==a.child)throw Error(u(153));if(null!==b.child){a=b.child;c=Sg(a,a.pendingProps);b.child=c;for(c.return=b;null!==a.sibling;)a=a.sibling,c=c.sibling=Sg(a,a.pendingProps),c.return=b;c.sibling=null;}return b.child;}var ni,oi,pi,qi;ni=function(a,b){for(var c=b.child;null!==c;){if(5===c.tag||6===c.tag)a.appendChild(c.stateNode);else if(4!==c.tag&&null!==c.child){c.child.return=c;c=c.child;continue;}if(c===b)break;for(;null===c.sibling;){if(null===c.return||c.return===b)return;c=c.return;}c.sibling.return=c.return;c=c.sibling;}};oi=function(){};pi=function(a,b,c,d,e){var f=a.memoizedProps;if(f!==d){var g=b.stateNode;ch($g.current);a=null;switch(c){case"input":f=zb(g,f);d=zb(g,d);a=[];break;case"option":f=Gb(g,f);d=Gb(g,d);a=[];break;case"select":f=n({},f,{value:void 0});d=n({},d,{value:void 0});a=[];break;case"textarea":f=Ib(g,f);d=Ib(g,d);a=[];break;default:"function"!==typeof f.onClick&&"function"===typeof d.onClick&&(g.onclick=sd);}od(c,d);var h,k;c=null;for(h in f)if(!d.hasOwnProperty(h)&&f.hasOwnProperty(h)&&null!=f[h])if("style"===h)for(k in g=f[h],g)g.hasOwnProperty(k)&&(c||(c={}),c[k]="");else"dangerouslySetInnerHTML"!==h&&"children"!==h&&"suppressContentEditableWarning"!==h&&"suppressHydrationWarning"!==h&&"autoFocus"!==h&&(va.hasOwnProperty(h)?a||(a=[]):(a=a||[]).push(h,null));for(h in d){var l=d[h];g=null!=f?f[h]:void 0;if(d.hasOwnProperty(h)&&l!==g&&(null!=l||null!=g))if("style"===h){if(g){for(k in g)!g.hasOwnProperty(k)||l&&l.hasOwnProperty(k)||(c||(c={}),c[k]="");for(k in l)l.hasOwnProperty(k)&&g[k]!==l[k]&&(c||(c={}),c[k]=l[k]);}else c||(a||(a=[]),a.push(h,c)),c=l;}else"dangerouslySetInnerHTML"===h?(l=l?l.__html:void 0,g=g?g.__html:void 0,null!=l&&g!==l&&(a=a||[]).push(h,l)):"children"===h?g===l||"string"!==typeof l&&"number"!==typeof l||(a=a||[]).push(h,""+l):"suppressContentEditableWarning"!==h&&"suppressHydrationWarning"!==h&&(va.hasOwnProperty(h)?(null!=l&&rd(e,h),a||g===l||(a=[])):(a=a||[]).push(h,l));}c&&(a=a||[]).push("style",c);e=a;if(b.updateQueue=e)b.effectTag|=4;}};qi=function(a,b,c,d){c!==d&&(b.effectTag|=4);};function ri(a,b){switch(a.tailMode){case"hidden":b=a.tail;for(var c=null;null!==b;)null!==b.alternate&&(c=b),b=b.sibling;null===c?a.tail=null:c.sibling=null;break;case"collapsed":c=a.tail;for(var d=null;null!==c;)null!==c.alternate&&(d=c),c=c.sibling;null===d?b||null===a.tail?a.tail=null:a.tail.sibling=null:d.sibling=null;}}function si(a,b,c){var d=b.pendingProps;switch(b.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return null;case 1:return L(b.type)&&Df(),null;case 3:return eh(),H(K),H(J),c=b.stateNode,c.pendingContext&&(c.context=c.pendingContext,c.pendingContext=null),null!==a&&null!==a.child||!Wh(b)||(b.effectTag|=4),oi(b),null;case 5:gh(b);c=ch(bh.current);var e=b.type;if(null!==a&&null!=b.stateNode)pi(a,b,e,d,c),a.ref!==b.ref&&(b.effectTag|=128);else{if(!d){if(null===b.stateNode)throw Error(u(166));return null;}a=ch($g.current);if(Wh(b)){d=b.stateNode;e=b.type;var f=b.memoizedProps;d[Md]=b;d[Nd]=f;switch(e){case"iframe":case"object":case"embed":F("load",d);break;case"video":case"audio":for(a=0;a<ac.length;a++)F(ac[a],d);break;case"source":F("error",d);break;case"img":case"image":case"link":F("error",d);F("load",d);break;case"form":F("reset",d);F("submit",d);break;case"details":F("toggle",d);break;case"input":Ab(d,f);F("invalid",d);rd(c,"onChange");break;case"select":d._wrapperState={wasMultiple:!!f.multiple};F("invalid",d);rd(c,"onChange");break;case"textarea":Jb(d,f),F("invalid",d),rd(c,"onChange");}od(e,f);a=null;for(var g in f)if(f.hasOwnProperty(g)){var h=f[g];"children"===g?"string"===typeof h?d.textContent!==h&&(a=["children",h]):"number"===typeof h&&d.textContent!==""+h&&(a=["children",""+h]):va.hasOwnProperty(g)&&null!=h&&rd(c,g);}switch(e){case"input":xb(d);Eb(d,f,!0);break;case"textarea":xb(d);Lb(d);break;case"select":case"option":break;default:"function"===typeof f.onClick&&(d.onclick=sd);}c=a;b.updateQueue=c;null!==c&&(b.effectTag|=4);}else{g=9===c.nodeType?c:c.ownerDocument;a===qd&&(a=Nb(e));a===qd?"script"===e?(a=g.createElement("div"),a.innerHTML="<script>\x3c/script>",a=a.removeChild(a.firstChild)):"string"===typeof d.is?a=g.createElement(e,{is:d.is}):(a=g.createElement(e),"select"===e&&(g=a,d.multiple?g.multiple=!0:d.size&&(g.size=d.size))):a=g.createElementNS(a,e);a[Md]=b;a[Nd]=d;ni(a,b,!1,!1);b.stateNode=a;g=pd(e,d);switch(e){case"iframe":case"object":case"embed":F("load",a);h=d;break;case"video":case"audio":for(h=0;h<ac.length;h++)F(ac[h],a);h=d;break;case"source":F("error",a);h=d;break;case"img":case"image":case"link":F("error",a);F("load",a);h=d;break;case"form":F("reset",a);F("submit",a);h=d;break;case"details":F("toggle",a);h=d;break;case"input":Ab(a,d);h=zb(a,d);F("invalid",a);rd(c,"onChange");break;case"option":h=Gb(a,d);break;case"select":a._wrapperState={wasMultiple:!!d.multiple};h=n({},d,{value:void 0});F("invalid",a);rd(c,"onChange");break;case"textarea":Jb(a,d);h=Ib(a,d);F("invalid",a);rd(c,"onChange");break;default:h=d;}od(e,h);var k=h;for(f in k)if(k.hasOwnProperty(f)){var l=k[f];"style"===f?md(a,l):"dangerouslySetInnerHTML"===f?(l=l?l.__html:void 0,null!=l&&Qb(a,l)):"children"===f?"string"===typeof l?("textarea"!==e||""!==l)&&Rb(a,l):"number"===typeof l&&Rb(a,""+l):"suppressContentEditableWarning"!==f&&"suppressHydrationWarning"!==f&&"autoFocus"!==f&&(va.hasOwnProperty(f)?null!=l&&rd(c,f):null!=l&&Xa(a,f,l,g));}switch(e){case"input":xb(a);Eb(a,d,!1);break;case"textarea":xb(a);Lb(a);break;case"option":null!=d.value&&a.setAttribute("value",""+rb(d.value));break;case"select":a.multiple=!!d.multiple;c=d.value;null!=c?Hb(a,!!d.multiple,c,!1):null!=d.defaultValue&&Hb(a,!!d.multiple,d.defaultValue,!0);break;default:"function"===typeof h.onClick&&(a.onclick=sd);}Fd(e,d)&&(b.effectTag|=4);}null!==b.ref&&(b.effectTag|=128);}return null;case 6:if(a&&null!=b.stateNode)qi(a,b,a.memoizedProps,d);else{if("string"!==typeof d&&null===b.stateNode)throw Error(u(166));c=ch(bh.current);ch($g.current);Wh(b)?(c=b.stateNode,d=b.memoizedProps,c[Md]=b,c.nodeValue!==d&&(b.effectTag|=4)):(c=(9===c.nodeType?c:c.ownerDocument).createTextNode(d),c[Md]=b,b.stateNode=c);}return null;case 13:H(M);d=b.memoizedState;if(0!==(b.effectTag&64))return b.expirationTime=c,b;c=null!==d;d=!1;null===a?void 0!==b.memoizedProps.fallback&&Wh(b):(e=a.memoizedState,d=null!==e,c||null===e||(e=a.child.sibling,null!==e&&(f=b.firstEffect,null!==f?(b.firstEffect=e,e.nextEffect=f):(b.firstEffect=b.lastEffect=e,e.nextEffect=null),e.effectTag=8)));if(c&&!d&&0!==(b.mode&2))if(null===a&&!0!==b.memoizedProps.unstable_avoidThisFallback||0!==(M.current&1))S===ti&&(S=ui);else{if(S===ti||S===ui)S=vi;0!==wi&&null!==T&&(xi(T,U),yi(T,wi));}if(c||d)b.effectTag|=4;return null;case 4:return eh(),oi(b),null;case 10:return og(b),null;case 17:return L(b.type)&&Df(),null;case 19:H(M);d=b.memoizedState;if(null===d)return null;e=0!==(b.effectTag&64);f=d.rendering;if(null===f){if(e)ri(d,!1);else{if(S!==ti||null!==a&&0!==(a.effectTag&64))for(f=b.child;null!==f;){a=hh(f);if(null!==a){b.effectTag|=64;ri(d,!1);e=a.updateQueue;null!==e&&(b.updateQueue=e,b.effectTag|=4);null===d.lastEffect&&(b.firstEffect=null);b.lastEffect=d.lastEffect;for(d=b.child;null!==d;)e=d,f=c,e.effectTag&=2,e.nextEffect=null,e.firstEffect=null,e.lastEffect=null,a=e.alternate,null===a?(e.childExpirationTime=0,e.expirationTime=f,e.child=null,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null):(e.childExpirationTime=a.childExpirationTime,e.expirationTime=a.expirationTime,e.child=a.child,e.memoizedProps=a.memoizedProps,e.memoizedState=a.memoizedState,e.updateQueue=a.updateQueue,f=a.dependencies,e.dependencies=null===f?null:{expirationTime:f.expirationTime,firstContext:f.firstContext,responders:f.responders}),d=d.sibling;I(M,M.current&1|2);return b.child;}f=f.sibling;}}}else{if(!e)if(a=hh(f),null!==a){if(b.effectTag|=64,e=!0,c=a.updateQueue,null!==c&&(b.updateQueue=c,b.effectTag|=4),ri(d,!0),null===d.tail&&"hidden"===d.tailMode&&!f.alternate)return b=b.lastEffect=d.lastEffect,null!==b&&(b.nextEffect=null),null;}else 2*$f()-d.renderingStartTime>d.tailExpiration&&1<c&&(b.effectTag|=64,e=!0,ri(d,!1),b.expirationTime=b.childExpirationTime=c-1);d.isBackwards?(f.sibling=b.child,b.child=f):(c=d.last,null!==c?c.sibling=f:b.child=f,d.last=f);}return null!==d.tail?(0===d.tailExpiration&&(d.tailExpiration=$f()+500),c=d.tail,d.rendering=c,d.tail=c.sibling,d.lastEffect=b.lastEffect,d.renderingStartTime=$f(),c.sibling=null,b=M.current,I(M,e?b&1|2:b&1),c):null;}throw Error(u(156,b.tag));}function zi(a){switch(a.tag){case 1:L(a.type)&&Df();var b=a.effectTag;return b&4096?(a.effectTag=b&-4097|64,a):null;case 3:eh();H(K);H(J);b=a.effectTag;if(0!==(b&64))throw Error(u(285));a.effectTag=b&-4097|64;return a;case 5:return gh(a),null;case 13:return H(M),b=a.effectTag,b&4096?(a.effectTag=b&-4097|64,a):null;case 19:return H(M),null;case 4:return eh(),null;case 10:return og(a),null;default:return null;}}function Ai(a,b){return{value:a,source:b,stack:qb(b)};}var Bi="function"===typeof WeakSet?WeakSet:Set;function Ci(a,b){var c=b.source,d=b.stack;null===d&&null!==c&&(d=qb(c));null!==c&&pb(c.type);b=b.value;null!==a&&1===a.tag&&pb(a.type);try{console.error(b);}catch(e){setTimeout(function(){throw e;});}}function Di(a,b){try{b.props=a.memoizedProps,b.state=a.memoizedState,b.componentWillUnmount();}catch(c){Ei(a,c);}}function Fi(a){var b=a.ref;if(null!==b)if("function"===typeof b)try{b(null);}catch(c){Ei(a,c);}else b.current=null;}function Gi(a,b){switch(b.tag){case 0:case 11:case 15:case 22:return;case 1:if(b.effectTag&256&&null!==a){var c=a.memoizedProps,d=a.memoizedState;a=b.stateNode;b=a.getSnapshotBeforeUpdate(b.elementType===b.type?c:ig(b.type,c),d);a.__reactInternalSnapshotBeforeUpdate=b;}return;case 3:case 5:case 6:case 4:case 17:return;}throw Error(u(163));}function Hi(a,b){b=b.updateQueue;b=null!==b?b.lastEffect:null;if(null!==b){var c=b=b.next;do{if((c.tag&a)===a){var d=c.destroy;c.destroy=void 0;void 0!==d&&d();}c=c.next;}while(c!==b);}}function Ii(a,b){b=b.updateQueue;b=null!==b?b.lastEffect:null;if(null!==b){var c=b=b.next;do{if((c.tag&a)===a){var d=c.create;c.destroy=d();}c=c.next;}while(c!==b);}}function Ji(a,b,c){switch(c.tag){case 0:case 11:case 15:case 22:Ii(3,c);return;case 1:a=c.stateNode;if(c.effectTag&4)if(null===b)a.componentDidMount();else{var d=c.elementType===c.type?b.memoizedProps:ig(c.type,b.memoizedProps);a.componentDidUpdate(d,b.memoizedState,a.__reactInternalSnapshotBeforeUpdate);}b=c.updateQueue;null!==b&&Cg(c,b,a);return;case 3:b=c.updateQueue;if(null!==b){a=null;if(null!==c.child)switch(c.child.tag){case 5:a=c.child.stateNode;break;case 1:a=c.child.stateNode;}Cg(c,b,a);}return;case 5:a=c.stateNode;null===b&&c.effectTag&4&&Fd(c.type,c.memoizedProps)&&a.focus();return;case 6:return;case 4:return;case 12:return;case 13:null===c.memoizedState&&(c=c.alternate,null!==c&&(c=c.memoizedState,null!==c&&(c=c.dehydrated,null!==c&&Vc(c))));return;case 19:case 17:case 20:case 21:return;}throw Error(u(163));}function Ki(a,b,c){"function"===typeof Li&&Li(b);switch(b.tag){case 0:case 11:case 14:case 15:case 22:a=b.updateQueue;if(null!==a&&(a=a.lastEffect,null!==a)){var d=a.next;cg(97<c?97:c,function(){var a=d;do{var c=a.destroy;if(void 0!==c){var g=b;try{c();}catch(h){Ei(g,h);}}a=a.next;}while(a!==d);});}break;case 1:Fi(b);c=b.stateNode;"function"===typeof c.componentWillUnmount&&Di(b,c);break;case 5:Fi(b);break;case 4:Mi(a,b,c);}}function Ni(a){var b=a.alternate;a.return=null;a.child=null;a.memoizedState=null;a.updateQueue=null;a.dependencies=null;a.alternate=null;a.firstEffect=null;a.lastEffect=null;a.pendingProps=null;a.memoizedProps=null;a.stateNode=null;null!==b&&Ni(b);}function Oi(a){return 5===a.tag||3===a.tag||4===a.tag;}function Pi(a){a:{for(var b=a.return;null!==b;){if(Oi(b)){var c=b;break a;}b=b.return;}throw Error(u(160));}b=c.stateNode;switch(c.tag){case 5:var d=!1;break;case 3:b=b.containerInfo;d=!0;break;case 4:b=b.containerInfo;d=!0;break;default:throw Error(u(161));}c.effectTag&16&&(Rb(b,""),c.effectTag&=-17);a:b:for(c=a;;){for(;null===c.sibling;){if(null===c.return||Oi(c.return)){c=null;break a;}c=c.return;}c.sibling.return=c.return;for(c=c.sibling;5!==c.tag&&6!==c.tag&&18!==c.tag;){if(c.effectTag&2)continue b;if(null===c.child||4===c.tag)continue b;else c.child.return=c,c=c.child;}if(!(c.effectTag&2)){c=c.stateNode;break a;}}d?Qi(a,c,b):Ri(a,c,b);}function Qi(a,b,c){var d=a.tag,e=5===d||6===d;if(e)a=e?a.stateNode:a.stateNode.instance,b?8===c.nodeType?c.parentNode.insertBefore(a,b):c.insertBefore(a,b):(8===c.nodeType?(b=c.parentNode,b.insertBefore(a,c)):(b=c,b.appendChild(a)),c=c._reactRootContainer,null!==c&&void 0!==c||null!==b.onclick||(b.onclick=sd));else if(4!==d&&(a=a.child,null!==a))for(Qi(a,b,c),a=a.sibling;null!==a;)Qi(a,b,c),a=a.sibling;}function Ri(a,b,c){var d=a.tag,e=5===d||6===d;if(e)a=e?a.stateNode:a.stateNode.instance,b?c.insertBefore(a,b):c.appendChild(a);else if(4!==d&&(a=a.child,null!==a))for(Ri(a,b,c),a=a.sibling;null!==a;)Ri(a,b,c),a=a.sibling;}function Mi(a,b,c){for(var d=b,e=!1,f,g;;){if(!e){e=d.return;a:for(;;){if(null===e)throw Error(u(160));f=e.stateNode;switch(e.tag){case 5:g=!1;break a;case 3:f=f.containerInfo;g=!0;break a;case 4:f=f.containerInfo;g=!0;break a;}e=e.return;}e=!0;}if(5===d.tag||6===d.tag){a:for(var h=a,k=d,l=c,m=k;;)if(Ki(h,m,l),null!==m.child&&4!==m.tag)m.child.return=m,m=m.child;else{if(m===k)break a;for(;null===m.sibling;){if(null===m.return||m.return===k)break a;m=m.return;}m.sibling.return=m.return;m=m.sibling;}g?(h=f,k=d.stateNode,8===h.nodeType?h.parentNode.removeChild(k):h.removeChild(k)):f.removeChild(d.stateNode);}else if(4===d.tag){if(null!==d.child){f=d.stateNode.containerInfo;g=!0;d.child.return=d;d=d.child;continue;}}else if(Ki(a,d,c),null!==d.child){d.child.return=d;d=d.child;continue;}if(d===b)break;for(;null===d.sibling;){if(null===d.return||d.return===b)return;d=d.return;4===d.tag&&(e=!1);}d.sibling.return=d.return;d=d.sibling;}}function Si(a,b){switch(b.tag){case 0:case 11:case 14:case 15:case 22:Hi(3,b);return;case 1:return;case 5:var c=b.stateNode;if(null!=c){var d=b.memoizedProps,e=null!==a?a.memoizedProps:d;a=b.type;var f=b.updateQueue;b.updateQueue=null;if(null!==f){c[Nd]=d;"input"===a&&"radio"===d.type&&null!=d.name&&Bb(c,d);pd(a,e);b=pd(a,d);for(e=0;e<f.length;e+=2){var g=f[e],h=f[e+1];"style"===g?md(c,h):"dangerouslySetInnerHTML"===g?Qb(c,h):"children"===g?Rb(c,h):Xa(c,g,h,b);}switch(a){case"input":Cb(c,d);break;case"textarea":Kb(c,d);break;case"select":b=c._wrapperState.wasMultiple,c._wrapperState.wasMultiple=!!d.multiple,a=d.value,null!=a?Hb(c,!!d.multiple,a,!1):b!==!!d.multiple&&(null!=d.defaultValue?Hb(c,!!d.multiple,d.defaultValue,!0):Hb(c,!!d.multiple,d.multiple?[]:"",!1));}}}return;case 6:if(null===b.stateNode)throw Error(u(162));b.stateNode.nodeValue=b.memoizedProps;return;case 3:b=b.stateNode;b.hydrate&&(b.hydrate=!1,Vc(b.containerInfo));return;case 12:return;case 13:c=b;null===b.memoizedState?d=!1:(d=!0,c=b.child,Ti=$f());if(null!==c)a:for(a=c;;){if(5===a.tag)f=a.stateNode,d?(f=f.style,"function"===typeof f.setProperty?f.setProperty("display","none","important"):f.display="none"):(f=a.stateNode,e=a.memoizedProps.style,e=void 0!==e&&null!==e&&e.hasOwnProperty("display")?e.display:null,f.style.display=ld("display",e));else if(6===a.tag)a.stateNode.nodeValue=d?"":a.memoizedProps;else if(13===a.tag&&null!==a.memoizedState&&null===a.memoizedState.dehydrated){f=a.child.sibling;f.return=a;a=f;continue;}else if(null!==a.child){a.child.return=a;a=a.child;continue;}if(a===c)break;for(;null===a.sibling;){if(null===a.return||a.return===c)break a;a=a.return;}a.sibling.return=a.return;a=a.sibling;}Ui(b);return;case 19:Ui(b);return;case 17:return;}throw Error(u(163));}function Ui(a){var b=a.updateQueue;if(null!==b){a.updateQueue=null;var c=a.stateNode;null===c&&(c=a.stateNode=new Bi());b.forEach(function(b){var d=Vi.bind(null,a,b);c.has(b)||(c.add(b),b.then(d,d));});}}var Wi="function"===typeof WeakMap?WeakMap:Map;function Xi(a,b,c){c=wg(c,null);c.tag=3;c.payload={element:null};var d=b.value;c.callback=function(){Yi||(Yi=!0,Zi=d);Ci(a,b);};return c;}function $i(a,b,c){c=wg(c,null);c.tag=3;var d=a.type.getDerivedStateFromError;if("function"===typeof d){var e=b.value;c.payload=function(){Ci(a,b);return d(e);};}var f=a.stateNode;null!==f&&"function"===typeof f.componentDidCatch&&(c.callback=function(){"function"!==typeof d&&(null===aj?aj=new Set([this]):aj.add(this),Ci(a,b));var c=b.stack;this.componentDidCatch(b.value,{componentStack:null!==c?c:""});});return c;}var bj=Math.ceil,cj=Wa.ReactCurrentDispatcher,dj=Wa.ReactCurrentOwner,V=0,ej=8,fj=16,gj=32,ti=0,hj=1,ij=2,ui=3,vi=4,jj=5,W=V,T=null,X=null,U=0,S=ti,kj=null,lj=1073741823,mj=1073741823,nj=null,wi=0,oj=!1,Ti=0,pj=500,Y=null,Yi=!1,Zi=null,aj=null,qj=!1,rj=null,sj=90,tj=null,uj=0,vj=null,wj=0;function Gg(){return(W&(fj|gj))!==V?1073741821-($f()/10|0):0!==wj?wj:wj=1073741821-($f()/10|0);}function Hg(a,b,c){b=b.mode;if(0===(b&2))return 1073741823;var d=ag();if(0===(b&4))return 99===d?1073741823:1073741822;if((W&fj)!==V)return U;if(null!==c)a=hg(a,c.timeoutMs|0||5E3,250);else switch(d){case 99:a=1073741823;break;case 98:a=hg(a,150,100);break;case 97:case 96:a=hg(a,5E3,250);break;case 95:a=2;break;default:throw Error(u(326));}null!==T&&a===U&&--a;return a;}function Ig(a,b){if(50<uj)throw uj=0,vj=null,Error(u(185));a=xj(a,b);if(null!==a){var c=ag();1073741823===b?(W&ej)!==V&&(W&(fj|gj))===V?yj(a):(Z(a),W===V&&gg()):Z(a);(W&4)===V||98!==c&&99!==c||(null===tj?tj=new Map([[a,b]]):(c=tj.get(a),(void 0===c||c>b)&&tj.set(a,b)));}}function xj(a,b){a.expirationTime<b&&(a.expirationTime=b);var c=a.alternate;null!==c&&c.expirationTime<b&&(c.expirationTime=b);var d=a.return,e=null;if(null===d&&3===a.tag)e=a.stateNode;else for(;null!==d;){c=d.alternate;d.childExpirationTime<b&&(d.childExpirationTime=b);null!==c&&c.childExpirationTime<b&&(c.childExpirationTime=b);if(null===d.return&&3===d.tag){e=d.stateNode;break;}d=d.return;}null!==e&&(T===e&&(Bg(b),S===vi&&xi(e,U)),yi(e,b));return e;}function zj(a){var b=a.lastExpiredTime;if(0!==b)return b;b=a.firstPendingTime;if(!Aj(a,b))return b;var c=a.lastPingedTime;a=a.nextKnownPendingLevel;a=c>a?c:a;return 2>=a&&b!==a?0:a;}function Z(a){if(0!==a.lastExpiredTime)a.callbackExpirationTime=1073741823,a.callbackPriority=99,a.callbackNode=eg(yj.bind(null,a));else{var b=zj(a),c=a.callbackNode;if(0===b)null!==c&&(a.callbackNode=null,a.callbackExpirationTime=0,a.callbackPriority=90);else{var d=Gg();1073741823===b?d=99:1===b||2===b?d=95:(d=10*(1073741821-b)-10*(1073741821-d),d=0>=d?99:250>=d?98:5250>=d?97:95);if(null!==c){var e=a.callbackPriority;if(a.callbackExpirationTime===b&&e>=d)return;c!==Tf&&Kf(c);}a.callbackExpirationTime=b;a.callbackPriority=d;b=1073741823===b?eg(yj.bind(null,a)):dg(d,Bj.bind(null,a),{timeout:10*(1073741821-b)-$f()});a.callbackNode=b;}}}function Bj(a,b){wj=0;if(b)return b=Gg(),Cj(a,b),Z(a),null;var c=zj(a);if(0!==c){b=a.callbackNode;if((W&(fj|gj))!==V)throw Error(u(327));Dj();a===T&&c===U||Ej(a,c);if(null!==X){var d=W;W|=fj;var e=Fj();do try{Gj();break;}catch(h){Hj(a,h);}while(1);ng();W=d;cj.current=e;if(S===hj)throw b=kj,Ej(a,c),xi(a,c),Z(a),b;if(null===X)switch(e=a.finishedWork=a.current.alternate,a.finishedExpirationTime=c,d=S,T=null,d){case ti:case hj:throw Error(u(345));case ij:Cj(a,2<c?2:c);break;case ui:xi(a,c);d=a.lastSuspendedTime;c===d&&(a.nextKnownPendingLevel=Ij(e));if(1073741823===lj&&(e=Ti+pj-$f(),10<e)){if(oj){var f=a.lastPingedTime;if(0===f||f>=c){a.lastPingedTime=c;Ej(a,c);break;}}f=zj(a);if(0!==f&&f!==c)break;if(0!==d&&d!==c){a.lastPingedTime=d;break;}a.timeoutHandle=Hd(Jj.bind(null,a),e);break;}Jj(a);break;case vi:xi(a,c);d=a.lastSuspendedTime;c===d&&(a.nextKnownPendingLevel=Ij(e));if(oj&&(e=a.lastPingedTime,0===e||e>=c)){a.lastPingedTime=c;Ej(a,c);break;}e=zj(a);if(0!==e&&e!==c)break;if(0!==d&&d!==c){a.lastPingedTime=d;break;}1073741823!==mj?d=10*(1073741821-mj)-$f():1073741823===lj?d=0:(d=10*(1073741821-lj)-5E3,e=$f(),c=10*(1073741821-c)-e,d=e-d,0>d&&(d=0),d=(120>d?120:480>d?480:1080>d?1080:1920>d?1920:3E3>d?3E3:4320>d?4320:1960*bj(d/1960))-d,c<d&&(d=c));if(10<d){a.timeoutHandle=Hd(Jj.bind(null,a),d);break;}Jj(a);break;case jj:if(1073741823!==lj&&null!==nj){f=lj;var g=nj;d=g.busyMinDurationMs|0;0>=d?d=0:(e=g.busyDelayMs|0,f=$f()-(10*(1073741821-f)-(g.timeoutMs|0||5E3)),d=f<=e?0:e+d-f);if(10<d){xi(a,c);a.timeoutHandle=Hd(Jj.bind(null,a),d);break;}}Jj(a);break;default:throw Error(u(329));}Z(a);if(a.callbackNode===b)return Bj.bind(null,a);}}return null;}function yj(a){var b=a.lastExpiredTime;b=0!==b?b:1073741823;if((W&(fj|gj))!==V)throw Error(u(327));Dj();a===T&&b===U||Ej(a,b);if(null!==X){var c=W;W|=fj;var d=Fj();do try{Kj();break;}catch(e){Hj(a,e);}while(1);ng();W=c;cj.current=d;if(S===hj)throw c=kj,Ej(a,b),xi(a,b),Z(a),c;if(null!==X)throw Error(u(261));a.finishedWork=a.current.alternate;a.finishedExpirationTime=b;T=null;Jj(a);Z(a);}return null;}function Lj(){if(null!==tj){var a=tj;tj=null;a.forEach(function(a,c){Cj(c,a);Z(c);});gg();}}function Mj(a,b){var c=W;W|=1;try{return a(b);}finally{W=c,W===V&&gg();}}function Nj(a,b){var c=W;W&=-2;W|=ej;try{return a(b);}finally{W=c,W===V&&gg();}}function Ej(a,b){a.finishedWork=null;a.finishedExpirationTime=0;var c=a.timeoutHandle;-1!==c&&(a.timeoutHandle=-1,Id(c));if(null!==X)for(c=X.return;null!==c;){var d=c;switch(d.tag){case 1:d=d.type.childContextTypes;null!==d&&void 0!==d&&Df();break;case 3:eh();H(K);H(J);break;case 5:gh(d);break;case 4:eh();break;case 13:H(M);break;case 19:H(M);break;case 10:og(d);}c=c.return;}T=a;X=Sg(a.current,null);U=b;S=ti;kj=null;mj=lj=1073741823;nj=null;wi=0;oj=!1;}function Hj(a,b){do{try{ng();jh.current=sh;if(mh)for(var c=N.memoizedState;null!==c;){var d=c.queue;null!==d&&(d.pending=null);c=c.next;}lh=0;P=O=N=null;mh=!1;if(null===X||null===X.return)return S=hj,kj=b,X=null;a:{var e=a,f=X.return,g=X,h=b;b=U;g.effectTag|=2048;g.firstEffect=g.lastEffect=null;if(null!==h&&"object"===typeof h&&"function"===typeof h.then){var k=h;if(0===(g.mode&2)){var l=g.alternate;l?(g.updateQueue=l.updateQueue,g.memoizedState=l.memoizedState,g.expirationTime=l.expirationTime):(g.updateQueue=null,g.memoizedState=null);}var m=0!==(M.current&1),p=f;do{var x;if(x=13===p.tag){var z=p.memoizedState;if(null!==z)x=null!==z.dehydrated?!0:!1;else{var ca=p.memoizedProps;x=void 0===ca.fallback?!1:!0!==ca.unstable_avoidThisFallback?!0:m?!1:!0;}}if(x){var D=p.updateQueue;if(null===D){var t=new Set();t.add(k);p.updateQueue=t;}else D.add(k);if(0===(p.mode&2)){p.effectTag|=64;g.effectTag&=-2981;if(1===g.tag)if(null===g.alternate)g.tag=17;else{var y=wg(1073741823,null);y.tag=2;xg(g,y);}g.expirationTime=1073741823;break a;}h=void 0;g=b;var A=e.pingCache;null===A?(A=e.pingCache=new Wi(),h=new Set(),A.set(k,h)):(h=A.get(k),void 0===h&&(h=new Set(),A.set(k,h)));if(!h.has(g)){h.add(g);var q=Oj.bind(null,e,k,g);k.then(q,q);}p.effectTag|=4096;p.expirationTime=b;break a;}p=p.return;}while(null!==p);h=Error((pb(g.type)||"A React component")+" suspended while rendering, but no fallback UI was specified.\n\nAdd a <Suspense fallback=...> component higher in the tree to provide a loading indicator or placeholder to display."+qb(g));}S!==jj&&(S=ij);h=Ai(h,g);p=f;do{switch(p.tag){case 3:k=h;p.effectTag|=4096;p.expirationTime=b;var B=Xi(p,k,b);yg(p,B);break a;case 1:k=h;var w=p.type,ub=p.stateNode;if(0===(p.effectTag&64)&&("function"===typeof w.getDerivedStateFromError||null!==ub&&"function"===typeof ub.componentDidCatch&&(null===aj||!aj.has(ub)))){p.effectTag|=4096;p.expirationTime=b;var vb=$i(p,k,b);yg(p,vb);break a;}}p=p.return;}while(null!==p);}X=Pj(X);}catch(Xc){b=Xc;continue;}break;}while(1);}function Fj(){var a=cj.current;cj.current=sh;return null===a?sh:a;}function Ag(a,b){a<lj&&2<a&&(lj=a);null!==b&&a<mj&&2<a&&(mj=a,nj=b);}function Bg(a){a>wi&&(wi=a);}function Kj(){for(;null!==X;)X=Qj(X);}function Gj(){for(;null!==X&&!Uf();)X=Qj(X);}function Qj(a){var b=Rj(a.alternate,a,U);a.memoizedProps=a.pendingProps;null===b&&(b=Pj(a));dj.current=null;return b;}function Pj(a){X=a;do{var b=X.alternate;a=X.return;if(0===(X.effectTag&2048)){b=si(b,X,U);if(1===U||1!==X.childExpirationTime){for(var c=0,d=X.child;null!==d;){var e=d.expirationTime,f=d.childExpirationTime;e>c&&(c=e);f>c&&(c=f);d=d.sibling;}X.childExpirationTime=c;}if(null!==b)return b;null!==a&&0===(a.effectTag&2048)&&(null===a.firstEffect&&(a.firstEffect=X.firstEffect),null!==X.lastEffect&&(null!==a.lastEffect&&(a.lastEffect.nextEffect=X.firstEffect),a.lastEffect=X.lastEffect),1<X.effectTag&&(null!==a.lastEffect?a.lastEffect.nextEffect=X:a.firstEffect=X,a.lastEffect=X));}else{b=zi(X);if(null!==b)return b.effectTag&=2047,b;null!==a&&(a.firstEffect=a.lastEffect=null,a.effectTag|=2048);}b=X.sibling;if(null!==b)return b;X=a;}while(null!==X);S===ti&&(S=jj);return null;}function Ij(a){var b=a.expirationTime;a=a.childExpirationTime;return b>a?b:a;}function Jj(a){var b=ag();cg(99,Sj.bind(null,a,b));return null;}function Sj(a,b){do Dj();while(null!==rj);if((W&(fj|gj))!==V)throw Error(u(327));var c=a.finishedWork,d=a.finishedExpirationTime;if(null===c)return null;a.finishedWork=null;a.finishedExpirationTime=0;if(c===a.current)throw Error(u(177));a.callbackNode=null;a.callbackExpirationTime=0;a.callbackPriority=90;a.nextKnownPendingLevel=0;var e=Ij(c);a.firstPendingTime=e;d<=a.lastSuspendedTime?a.firstSuspendedTime=a.lastSuspendedTime=a.nextKnownPendingLevel=0:d<=a.firstSuspendedTime&&(a.firstSuspendedTime=d-1);d<=a.lastPingedTime&&(a.lastPingedTime=0);d<=a.lastExpiredTime&&(a.lastExpiredTime=0);a===T&&(X=T=null,U=0);1<c.effectTag?null!==c.lastEffect?(c.lastEffect.nextEffect=c,e=c.firstEffect):e=c:e=c.firstEffect;if(null!==e){var f=W;W|=gj;dj.current=null;Dd=fd;var g=xd();if(yd(g)){if("selectionStart"in g)var h={start:g.selectionStart,end:g.selectionEnd};else a:{h=(h=g.ownerDocument)&&h.defaultView||window;var k=h.getSelection&&h.getSelection();if(k&&0!==k.rangeCount){h=k.anchorNode;var l=k.anchorOffset,m=k.focusNode;k=k.focusOffset;try{h.nodeType,m.nodeType;}catch(wb){h=null;break a;}var p=0,x=-1,z=-1,ca=0,D=0,t=g,y=null;b:for(;;){for(var A;;){t!==h||0!==l&&3!==t.nodeType||(x=p+l);t!==m||0!==k&&3!==t.nodeType||(z=p+k);3===t.nodeType&&(p+=t.nodeValue.length);if(null===(A=t.firstChild))break;y=t;t=A;}for(;;){if(t===g)break b;y===h&&++ca===l&&(x=p);y===m&&++D===k&&(z=p);if(null!==(A=t.nextSibling))break;t=y;y=t.parentNode;}t=A;}h=-1===x||-1===z?null:{start:x,end:z};}else h=null;}h=h||{start:0,end:0};}else h=null;Ed={activeElementDetached:null,focusedElem:g,selectionRange:h};fd=!1;Y=e;do try{Tj();}catch(wb){if(null===Y)throw Error(u(330));Ei(Y,wb);Y=Y.nextEffect;}while(null!==Y);Y=e;do try{for(g=a,h=b;null!==Y;){var q=Y.effectTag;q&16&&Rb(Y.stateNode,"");if(q&128){var B=Y.alternate;if(null!==B){var w=B.ref;null!==w&&("function"===typeof w?w(null):w.current=null);}}switch(q&1038){case 2:Pi(Y);Y.effectTag&=-3;break;case 6:Pi(Y);Y.effectTag&=-3;Si(Y.alternate,Y);break;case 1024:Y.effectTag&=-1025;break;case 1028:Y.effectTag&=-1025;Si(Y.alternate,Y);break;case 4:Si(Y.alternate,Y);break;case 8:l=Y,Mi(g,l,h),Ni(l);}Y=Y.nextEffect;}}catch(wb){if(null===Y)throw Error(u(330));Ei(Y,wb);Y=Y.nextEffect;}while(null!==Y);w=Ed;B=xd();q=w.focusedElem;h=w.selectionRange;if(B!==q&&q&&q.ownerDocument&&wd(q.ownerDocument.documentElement,q)){null!==h&&yd(q)&&(B=h.start,w=h.end,void 0===w&&(w=B),"selectionStart"in q?(q.selectionStart=B,q.selectionEnd=Math.min(w,q.value.length)):(w=(B=q.ownerDocument||document)&&B.defaultView||window,w.getSelection&&(w=w.getSelection(),l=q.textContent.length,g=Math.min(h.start,l),h=void 0===h.end?g:Math.min(h.end,l),!w.extend&&g>h&&(l=h,h=g,g=l),l=vd(q,g),m=vd(q,h),l&&m&&(1!==w.rangeCount||w.anchorNode!==l.node||w.anchorOffset!==l.offset||w.focusNode!==m.node||w.focusOffset!==m.offset)&&(B=B.createRange(),B.setStart(l.node,l.offset),w.removeAllRanges(),g>h?(w.addRange(B),w.extend(m.node,m.offset)):(B.setEnd(m.node,m.offset),w.addRange(B))))));B=[];for(w=q;w=w.parentNode;)1===w.nodeType&&B.push({element:w,left:w.scrollLeft,top:w.scrollTop});"function"===typeof q.focus&&q.focus();for(q=0;q<B.length;q++)w=B[q],w.element.scrollLeft=w.left,w.element.scrollTop=w.top;}fd=!!Dd;Ed=Dd=null;a.current=c;Y=e;do try{for(q=a;null!==Y;){var ub=Y.effectTag;ub&36&&Ji(q,Y.alternate,Y);if(ub&128){B=void 0;var vb=Y.ref;if(null!==vb){var Xc=Y.stateNode;switch(Y.tag){case 5:B=Xc;break;default:B=Xc;}"function"===typeof vb?vb(B):vb.current=B;}}Y=Y.nextEffect;}}catch(wb){if(null===Y)throw Error(u(330));Ei(Y,wb);Y=Y.nextEffect;}while(null!==Y);Y=null;Vf();W=f;}else a.current=c;if(qj)qj=!1,rj=a,sj=b;else for(Y=e;null!==Y;)b=Y.nextEffect,Y.nextEffect=null,Y=b;b=a.firstPendingTime;0===b&&(aj=null);1073741823===b?a===vj?uj++:(uj=0,vj=a):uj=0;"function"===typeof Uj&&Uj(c.stateNode,d);Z(a);if(Yi)throw Yi=!1,a=Zi,Zi=null,a;if((W&ej)!==V)return null;gg();return null;}function Tj(){for(;null!==Y;){var a=Y.effectTag;0!==(a&256)&&Gi(Y.alternate,Y);0===(a&512)||qj||(qj=!0,dg(97,function(){Dj();return null;}));Y=Y.nextEffect;}}function Dj(){if(90!==sj){var a=97<sj?97:sj;sj=90;return cg(a,Vj);}}function Vj(){if(null===rj)return!1;var a=rj;rj=null;if((W&(fj|gj))!==V)throw Error(u(331));var b=W;W|=gj;for(a=a.current.firstEffect;null!==a;){try{var c=a;if(0!==(c.effectTag&512))switch(c.tag){case 0:case 11:case 15:case 22:Hi(5,c),Ii(5,c);}}catch(d){if(null===a)throw Error(u(330));Ei(a,d);}c=a.nextEffect;a.nextEffect=null;a=c;}W=b;gg();return!0;}function Wj(a,b,c){b=Ai(c,b);b=Xi(a,b,1073741823);xg(a,b);a=xj(a,1073741823);null!==a&&Z(a);}function Ei(a,b){if(3===a.tag)Wj(a,a,b);else for(var c=a.return;null!==c;){if(3===c.tag){Wj(c,a,b);break;}else if(1===c.tag){var d=c.stateNode;if("function"===typeof c.type.getDerivedStateFromError||"function"===typeof d.componentDidCatch&&(null===aj||!aj.has(d))){a=Ai(b,a);a=$i(c,a,1073741823);xg(c,a);c=xj(c,1073741823);null!==c&&Z(c);break;}}c=c.return;}}function Oj(a,b,c){var d=a.pingCache;null!==d&&d.delete(b);T===a&&U===c?S===vi||S===ui&&1073741823===lj&&$f()-Ti<pj?Ej(a,U):oj=!0:Aj(a,c)&&(b=a.lastPingedTime,0!==b&&b<c||(a.lastPingedTime=c,Z(a)));}function Vi(a,b){var c=a.stateNode;null!==c&&c.delete(b);b=0;0===b&&(b=Gg(),b=Hg(b,a,null));a=xj(a,b);null!==a&&Z(a);}var Rj;Rj=function(a,b,c){var d=b.expirationTime;if(null!==a){var e=b.pendingProps;if(a.memoizedProps!==e||K.current)rg=!0;else{if(d<c){rg=!1;switch(b.tag){case 3:hi(b);Xh();break;case 5:fh(b);if(b.mode&4&&1!==c&&e.hidden)return b.expirationTime=b.childExpirationTime=1,null;break;case 1:L(b.type)&&Gf(b);break;case 4:dh(b,b.stateNode.containerInfo);break;case 10:d=b.memoizedProps.value;e=b.type._context;I(jg,e._currentValue);e._currentValue=d;break;case 13:if(null!==b.memoizedState){d=b.child.childExpirationTime;if(0!==d&&d>=c)return ji(a,b,c);I(M,M.current&1);b=$h(a,b,c);return null!==b?b.sibling:null;}I(M,M.current&1);break;case 19:d=b.childExpirationTime>=c;if(0!==(a.effectTag&64)){if(d)return mi(a,b,c);b.effectTag|=64;}e=b.memoizedState;null!==e&&(e.rendering=null,e.tail=null);I(M,M.current);if(!d)return null;}return $h(a,b,c);}rg=!1;}}else rg=!1;b.expirationTime=0;switch(b.tag){case 2:d=b.type;null!==a&&(a.alternate=null,b.alternate=null,b.effectTag|=2);a=b.pendingProps;e=Cf(b,J.current);qg(b,c);e=oh(null,b,d,a,e,c);b.effectTag|=1;if("object"===typeof e&&null!==e&&"function"===typeof e.render&&void 0===e.$$typeof){b.tag=1;b.memoizedState=null;b.updateQueue=null;if(L(d)){var f=!0;Gf(b);}else f=!1;b.memoizedState=null!==e.state&&void 0!==e.state?e.state:null;ug(b);var g=d.getDerivedStateFromProps;"function"===typeof g&&Fg(b,d,g,a);e.updater=Jg;b.stateNode=e;e._reactInternalFiber=b;Ng(b,d,a,c);b=gi(null,b,d,!0,f,c);}else b.tag=0,R(null,b,e,c),b=b.child;return b;case 16:a:{e=b.elementType;null!==a&&(a.alternate=null,b.alternate=null,b.effectTag|=2);a=b.pendingProps;ob(e);if(1!==e._status)throw e._result;e=e._result;b.type=e;f=b.tag=Xj(e);a=ig(e,a);switch(f){case 0:b=di(null,b,e,a,c);break a;case 1:b=fi(null,b,e,a,c);break a;case 11:b=Zh(null,b,e,a,c);break a;case 14:b=ai(null,b,e,ig(e.type,a),d,c);break a;}throw Error(u(306,e,""));}return b;case 0:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:ig(d,e),di(a,b,d,e,c);case 1:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:ig(d,e),fi(a,b,d,e,c);case 3:hi(b);d=b.updateQueue;if(null===a||null===d)throw Error(u(282));d=b.pendingProps;e=b.memoizedState;e=null!==e?e.element:null;vg(a,b);zg(b,d,null,c);d=b.memoizedState.element;if(d===e)Xh(),b=$h(a,b,c);else{if(e=b.stateNode.hydrate)Ph=Jd(b.stateNode.containerInfo.firstChild),Oh=b,e=Qh=!0;if(e)for(c=Yg(b,null,d,c),b.child=c;c;)c.effectTag=c.effectTag&-3|1024,c=c.sibling;else R(a,b,d,c),Xh();b=b.child;}return b;case 5:return fh(b),null===a&&Uh(b),d=b.type,e=b.pendingProps,f=null!==a?a.memoizedProps:null,g=e.children,Gd(d,e)?g=null:null!==f&&Gd(d,f)&&(b.effectTag|=16),ei(a,b),b.mode&4&&1!==c&&e.hidden?(b.expirationTime=b.childExpirationTime=1,b=null):(R(a,b,g,c),b=b.child),b;case 6:return null===a&&Uh(b),null;case 13:return ji(a,b,c);case 4:return dh(b,b.stateNode.containerInfo),d=b.pendingProps,null===a?b.child=Xg(b,null,d,c):R(a,b,d,c),b.child;case 11:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:ig(d,e),Zh(a,b,d,e,c);case 7:return R(a,b,b.pendingProps,c),b.child;case 8:return R(a,b,b.pendingProps.children,c),b.child;case 12:return R(a,b,b.pendingProps.children,c),b.child;case 10:a:{d=b.type._context;e=b.pendingProps;g=b.memoizedProps;f=e.value;var h=b.type._context;I(jg,h._currentValue);h._currentValue=f;if(null!==g)if(h=g.value,f=$e(h,f)?0:("function"===typeof d._calculateChangedBits?d._calculateChangedBits(h,f):1073741823)|0,0===f){if(g.children===e.children&&!K.current){b=$h(a,b,c);break a;}}else for(h=b.child,null!==h&&(h.return=b);null!==h;){var k=h.dependencies;if(null!==k){g=h.child;for(var l=k.firstContext;null!==l;){if(l.context===d&&0!==(l.observedBits&f)){1===h.tag&&(l=wg(c,null),l.tag=2,xg(h,l));h.expirationTime<c&&(h.expirationTime=c);l=h.alternate;null!==l&&l.expirationTime<c&&(l.expirationTime=c);pg(h.return,c);k.expirationTime<c&&(k.expirationTime=c);break;}l=l.next;}}else g=10===h.tag?h.type===b.type?null:h.child:h.child;if(null!==g)g.return=h;else for(g=h;null!==g;){if(g===b){g=null;break;}h=g.sibling;if(null!==h){h.return=g.return;g=h;break;}g=g.return;}h=g;}R(a,b,e.children,c);b=b.child;}return b;case 9:return e=b.type,f=b.pendingProps,d=f.children,qg(b,c),e=sg(e,f.unstable_observedBits),d=d(e),b.effectTag|=1,R(a,b,d,c),b.child;case 14:return e=b.type,f=ig(e,b.pendingProps),f=ig(e.type,f),ai(a,b,e,f,d,c);case 15:return ci(a,b,b.type,b.pendingProps,d,c);case 17:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:ig(d,e),null!==a&&(a.alternate=null,b.alternate=null,b.effectTag|=2),b.tag=1,L(d)?(a=!0,Gf(b)):a=!1,qg(b,c),Lg(b,d,e),Ng(b,d,e,c),gi(null,b,d,!0,a,c);case 19:return mi(a,b,c);}throw Error(u(156,b.tag));};var Uj=null,Li=null;function Yj(a){if("undefined"===typeof __REACT_DEVTOOLS_GLOBAL_HOOK__)return!1;var b=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(b.isDisabled||!b.supportsFiber)return!0;try{var c=b.inject(a);Uj=function(a){try{b.onCommitFiberRoot(c,a,void 0,64===(a.current.effectTag&64));}catch(e){}};Li=function(a){try{b.onCommitFiberUnmount(c,a);}catch(e){}};}catch(d){}return!0;}function Zj(a,b,c,d){this.tag=a;this.key=c;this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null;this.index=0;this.ref=null;this.pendingProps=b;this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null;this.mode=d;this.effectTag=0;this.lastEffect=this.firstEffect=this.nextEffect=null;this.childExpirationTime=this.expirationTime=0;this.alternate=null;}function Sh(a,b,c,d){return new Zj(a,b,c,d);}function bi(a){a=a.prototype;return!(!a||!a.isReactComponent);}function Xj(a){if("function"===typeof a)return bi(a)?1:0;if(void 0!==a&&null!==a){a=a.$$typeof;if(a===gb)return 11;if(a===jb)return 14;}return 2;}function Sg(a,b){var c=a.alternate;null===c?(c=Sh(a.tag,b,a.key,a.mode),c.elementType=a.elementType,c.type=a.type,c.stateNode=a.stateNode,c.alternate=a,a.alternate=c):(c.pendingProps=b,c.effectTag=0,c.nextEffect=null,c.firstEffect=null,c.lastEffect=null);c.childExpirationTime=a.childExpirationTime;c.expirationTime=a.expirationTime;c.child=a.child;c.memoizedProps=a.memoizedProps;c.memoizedState=a.memoizedState;c.updateQueue=a.updateQueue;b=a.dependencies;c.dependencies=null===b?null:{expirationTime:b.expirationTime,firstContext:b.firstContext,responders:b.responders};c.sibling=a.sibling;c.index=a.index;c.ref=a.ref;return c;}function Ug(a,b,c,d,e,f){var g=2;d=a;if("function"===typeof a)bi(a)&&(g=1);else if("string"===typeof a)g=5;else a:switch(a){case ab:return Wg(c.children,e,f,b);case fb:g=8;e|=7;break;case bb:g=8;e|=1;break;case cb:return a=Sh(12,c,b,e|8),a.elementType=cb,a.type=cb,a.expirationTime=f,a;case hb:return a=Sh(13,c,b,e),a.type=hb,a.elementType=hb,a.expirationTime=f,a;case ib:return a=Sh(19,c,b,e),a.elementType=ib,a.expirationTime=f,a;default:if("object"===typeof a&&null!==a)switch(a.$$typeof){case db:g=10;break a;case eb:g=9;break a;case gb:g=11;break a;case jb:g=14;break a;case kb:g=16;d=null;break a;case lb:g=22;break a;}throw Error(u(130,null==a?a:typeof a,""));}b=Sh(g,c,b,e);b.elementType=a;b.type=d;b.expirationTime=f;return b;}function Wg(a,b,c,d){a=Sh(7,a,d,b);a.expirationTime=c;return a;}function Tg(a,b,c){a=Sh(6,a,null,b);a.expirationTime=c;return a;}function Vg(a,b,c){b=Sh(4,null!==a.children?a.children:[],a.key,b);b.expirationTime=c;b.stateNode={containerInfo:a.containerInfo,pendingChildren:null,implementation:a.implementation};return b;}function ak(a,b,c){this.tag=b;this.current=null;this.containerInfo=a;this.pingCache=this.pendingChildren=null;this.finishedExpirationTime=0;this.finishedWork=null;this.timeoutHandle=-1;this.pendingContext=this.context=null;this.hydrate=c;this.callbackNode=null;this.callbackPriority=90;this.lastExpiredTime=this.lastPingedTime=this.nextKnownPendingLevel=this.lastSuspendedTime=this.firstSuspendedTime=this.firstPendingTime=0;}function Aj(a,b){var c=a.firstSuspendedTime;a=a.lastSuspendedTime;return 0!==c&&c>=b&&a<=b;}function xi(a,b){var c=a.firstSuspendedTime,d=a.lastSuspendedTime;c<b&&(a.firstSuspendedTime=b);if(d>b||0===c)a.lastSuspendedTime=b;b<=a.lastPingedTime&&(a.lastPingedTime=0);b<=a.lastExpiredTime&&(a.lastExpiredTime=0);}function yi(a,b){b>a.firstPendingTime&&(a.firstPendingTime=b);var c=a.firstSuspendedTime;0!==c&&(b>=c?a.firstSuspendedTime=a.lastSuspendedTime=a.nextKnownPendingLevel=0:b>=a.lastSuspendedTime&&(a.lastSuspendedTime=b+1),b>a.nextKnownPendingLevel&&(a.nextKnownPendingLevel=b));}function Cj(a,b){var c=a.lastExpiredTime;if(0===c||c>b)a.lastExpiredTime=b;}function bk(a,b,c,d){var e=b.current,f=Gg(),g=Dg.suspense;f=Hg(f,e,g);a:if(c){c=c._reactInternalFiber;b:{if(dc(c)!==c||1!==c.tag)throw Error(u(170));var h=c;do{switch(h.tag){case 3:h=h.stateNode.context;break b;case 1:if(L(h.type)){h=h.stateNode.__reactInternalMemoizedMergedChildContext;break b;}}h=h.return;}while(null!==h);throw Error(u(171));}if(1===c.tag){var k=c.type;if(L(k)){c=Ff(c,k,h);break a;}}c=h;}else c=Af;null===b.context?b.context=c:b.pendingContext=c;b=wg(f,g);b.payload={element:a};d=void 0===d?null:d;null!==d&&(b.callback=d);xg(e,b);Ig(e,f);return f;}function ck(a){a=a.current;if(!a.child)return null;switch(a.child.tag){case 5:return a.child.stateNode;default:return a.child.stateNode;}}function dk(a,b){a=a.memoizedState;null!==a&&null!==a.dehydrated&&a.retryTime<b&&(a.retryTime=b);}function ek(a,b){dk(a,b);(a=a.alternate)&&dk(a,b);}function fk(a,b,c){c=null!=c&&!0===c.hydrate;var d=new ak(a,b,c),e=Sh(3,null,null,2===b?7:1===b?3:0);d.current=e;e.stateNode=d;ug(e);a[Od]=d.current;c&&0!==b&&Jc(a,9===a.nodeType?a:a.ownerDocument);this._internalRoot=d;}fk.prototype.render=function(a){bk(a,this._internalRoot,null,null);};fk.prototype.unmount=function(){var a=this._internalRoot,b=a.containerInfo;bk(null,a,null,function(){b[Od]=null;});};function gk(a){return!(!a||1!==a.nodeType&&9!==a.nodeType&&11!==a.nodeType&&(8!==a.nodeType||" react-mount-point-unstable "!==a.nodeValue));}function hk(a,b){b||(b=a?9===a.nodeType?a.documentElement:a.firstChild:null,b=!(!b||1!==b.nodeType||!b.hasAttribute("data-reactroot")));if(!b)for(var c;c=a.lastChild;)a.removeChild(c);return new fk(a,0,b?{hydrate:!0}:void 0);}function ik(a,b,c,d,e){var f=c._reactRootContainer;if(f){var g=f._internalRoot;if("function"===typeof e){var h=e;e=function(){var a=ck(g);h.call(a);};}bk(b,g,a,e);}else{f=c._reactRootContainer=hk(c,d);g=f._internalRoot;if("function"===typeof e){var k=e;e=function(){var a=ck(g);k.call(a);};}Nj(function(){bk(b,g,a,e);});}return ck(g);}function jk(a,b,c){var d=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;return{$$typeof:$a,key:null==d?null:""+d,children:a,containerInfo:b,implementation:c};}wc=function(a){if(13===a.tag){var b=hg(Gg(),150,100);Ig(a,b);ek(a,b);}};xc=function(a){13===a.tag&&(Ig(a,3),ek(a,3));};yc=function(a){if(13===a.tag){var b=Gg();b=Hg(b,a,null);Ig(a,b);ek(a,b);}};za=function(a,b,c){switch(b){case"input":Cb(a,c);b=c.name;if("radio"===c.type&&null!=b){for(c=a;c.parentNode;)c=c.parentNode;c=c.querySelectorAll("input[name="+JSON.stringify(""+b)+'][type="radio"]');for(b=0;b<c.length;b++){var d=c[b];if(d!==a&&d.form===a.form){var e=Qd(d);if(!e)throw Error(u(90));yb(d);Cb(d,e);}}}break;case"textarea":Kb(a,c);break;case"select":b=c.value,null!=b&&Hb(a,!!c.multiple,b,!1);}};Fa=Mj;Ga=function(a,b,c,d,e){var f=W;W|=4;try{return cg(98,a.bind(null,b,c,d,e));}finally{W=f,W===V&&gg();}};Ha=function(){(W&(1|fj|gj))===V&&(Lj(),Dj());};Ia=function(a,b){var c=W;W|=2;try{return a(b);}finally{W=c,W===V&&gg();}};function kk(a,b){var c=2<arguments.length&&void 0!==arguments[2]?arguments[2]:null;if(!gk(b))throw Error(u(200));return jk(a,b,null,c);}var lk={Events:[Nc,Pd,Qd,xa,ta,Xd,function(a){jc(a,Wd);},Da,Ea,id,mc,Dj,{current:!1}]};(function(a){var b=a.findFiberByHostInstance;return Yj(n({},a,{overrideHookState:null,overrideProps:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:Wa.ReactCurrentDispatcher,findHostInstanceByFiber:function(a){a=hc(a);return null===a?null:a.stateNode;},findFiberByHostInstance:function(a){return b?b(a):null;},findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null}));})({findFiberByHostInstance:tc,bundleType:0,version:"16.13.1",rendererPackageName:"react-dom"});exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=lk;exports.createPortal=kk;exports.findDOMNode=function(a){if(null==a)return null;if(1===a.nodeType)return a;var b=a._reactInternalFiber;if(void 0===b){if("function"===typeof a.render)throw Error(u(188));throw Error(u(268,Object.keys(a)));}a=hc(b);a=null===a?null:a.stateNode;return a;};exports.flushSync=function(a,b){if((W&(fj|gj))!==V)throw Error(u(187));var c=W;W|=1;try{return cg(99,a.bind(null,b));}finally{W=c,gg();}};exports.hydrate=function(a,b,c){if(!gk(b))throw Error(u(200));return ik(null,a,b,!0,c);};exports.render=function(a,b,c){if(!gk(b))throw Error(u(200));return ik(null,a,b,!1,c);};exports.unmountComponentAtNode=function(a){if(!gk(a))throw Error(u(40));return a._reactRootContainer?(Nj(function(){ik(null,null,a,!1,function(){a._reactRootContainer=null;a[Od]=null;});}),!0):!1;};exports.unstable_batchedUpdates=Mj;exports.unstable_createPortal=function(a,b){return kk(a,b,2<arguments.length&&void 0!==arguments[2]?arguments[2]:null);};exports.unstable_renderSubtreeIntoContainer=function(a,b,c,d){if(!gk(c))throw Error(u(200));if(null==a||void 0===a._reactInternalFiber)throw Error(u(38));return ik(a,b,c,!1,d);};exports.version="16.13.1";

/***/ }),

/***/ "../../../node_modules/react-dom/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
function checkDCE(){/* global __REACT_DEVTOOLS_GLOBAL_HOOK__ */if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__==='undefined'||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!=='function'){return;}if(false){// This branch is unreachable because this function is only called
// in production, but the condition is true only in development.
// Therefore if the branch is still here, dead code elimination wasn't
// properly applied.
// Don't change the message. React DevTools relies on it. Also make sure
// this message doesn't occur elsewhere in this function, or it will cause
// a false positive.
throw new Error('^_^');}try{// Verify that the code above has been dead code eliminated (DCE'd).
__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);}catch(err){// DevTools shouldn't crash React, no matter what.
// We should still report in case we break this code.
console.error(err);}}if(true){// DCE check should happen before ReactDOM bundle executes so that
// DevTools can report bad minification during injection.
checkDCE();module.exports=__webpack_require__("../../../node_modules/react-dom/cjs/react-dom.production.min.js");}else{module.exports=require('./cjs/react-dom.development.js');}

/***/ }),

/***/ "../../../node_modules/react-hot-loader/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
module.exports=__webpack_require__("../../../node_modules/react-hot-loader/lib/index.js");

/***/ }),

/***/ "../../../node_modules/react-hot-loader/lib/AppContainer.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* eslint-disable global-require */if(true){module.exports=__webpack_require__("../../../node_modules/react-hot-loader/lib/AppContainer.prod.js");}else{module.exports=require('./AppContainer.dev');}

/***/ }),

/***/ "../../../node_modules/react-hot-loader/lib/AppContainer.prod.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}/* eslint-disable react/prop-types */var React=__webpack_require__("../../../node_modules/react/index.js");var Component=React.Component;var AppContainer=function(_Component){_inherits(AppContainer,_Component);function AppContainer(){_classCallCheck(this,AppContainer);return _possibleConstructorReturn(this,(AppContainer.__proto__||Object.getPrototypeOf(AppContainer)).apply(this,arguments));}_createClass(AppContainer,[{key:'render',value:function render(){if(this.props.component){return React.createElement(this.props.component,this.props.props);}return React.Children.only(this.props.children);}}]);return AppContainer;}(Component);module.exports=AppContainer;

/***/ }),

/***/ "../../../node_modules/react-hot-loader/lib/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* eslint-disable global-require */if(true){module.exports=__webpack_require__("../../../node_modules/react-hot-loader/lib/index.prod.js");}else{module.exports=require('./index.dev');}

/***/ }),

/***/ "../../../node_modules/react-hot-loader/lib/index.prod.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
module.exports.AppContainer=__webpack_require__("../../../node_modules/react-hot-loader/lib/AppContainer.js");

/***/ }),

/***/ "../../../node_modules/react-hot-loader/lib/patch.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* eslint-disable global-require */if(true){module.exports=__webpack_require__("../../../node_modules/react-hot-loader/lib/patch.prod.js");}else{module.exports=require('./patch.dev');}

/***/ }),

/***/ "../../../node_modules/react-hot-loader/lib/patch.prod.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* noop */

/***/ }),

/***/ "../../../node_modules/react-hot-loader/patch.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
module.exports=__webpack_require__("../../../node_modules/react-hot-loader/lib/patch.js");

/***/ }),

/***/ "../../../node_modules/react-lifecycles-compat/react-lifecycles-compat.es.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.polyfill=polyfill;/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */function componentWillMount(){// Call this.constructor.gDSFP to support sub-classes.
var state=this.constructor.getDerivedStateFromProps(this.props,this.state);if(state!==null&&state!==undefined){this.setState(state);}}function componentWillReceiveProps(nextProps){// Call this.constructor.gDSFP to support sub-classes.
// Use the setState() updater to ensure state isn't stale in certain edge cases.
function updater(prevState){var state=this.constructor.getDerivedStateFromProps(nextProps,prevState);return state!==null&&state!==undefined?state:null;}// Binding "this" is important for shallow renderer support.
this.setState(updater.bind(this));}function componentWillUpdate(nextProps,nextState){try{var prevProps=this.props;var prevState=this.state;this.props=nextProps;this.state=nextState;this.__reactInternalSnapshotFlag=true;this.__reactInternalSnapshot=this.getSnapshotBeforeUpdate(prevProps,prevState);}finally{this.props=prevProps;this.state=prevState;}}// React may warn about cWM/cWRP/cWU methods being deprecated.
// Add a flag to suppress these warnings for this special case.
componentWillMount.__suppressDeprecationWarning=true;componentWillReceiveProps.__suppressDeprecationWarning=true;componentWillUpdate.__suppressDeprecationWarning=true;function polyfill(Component){var prototype=Component.prototype;if(!prototype||!prototype.isReactComponent){throw new Error('Can only polyfill class components');}if(typeof Component.getDerivedStateFromProps!=='function'&&typeof prototype.getSnapshotBeforeUpdate!=='function'){return Component;}// If new component APIs are defined, "unsafe" lifecycles won't be called.
// Error if any of these lifecycles are present,
// Because they would work differently between older and newer (16.3+) versions of React.
var foundWillMountName=null;var foundWillReceivePropsName=null;var foundWillUpdateName=null;if(typeof prototype.componentWillMount==='function'){foundWillMountName='componentWillMount';}else if(typeof prototype.UNSAFE_componentWillMount==='function'){foundWillMountName='UNSAFE_componentWillMount';}if(typeof prototype.componentWillReceiveProps==='function'){foundWillReceivePropsName='componentWillReceiveProps';}else if(typeof prototype.UNSAFE_componentWillReceiveProps==='function'){foundWillReceivePropsName='UNSAFE_componentWillReceiveProps';}if(typeof prototype.componentWillUpdate==='function'){foundWillUpdateName='componentWillUpdate';}else if(typeof prototype.UNSAFE_componentWillUpdate==='function'){foundWillUpdateName='UNSAFE_componentWillUpdate';}if(foundWillMountName!==null||foundWillReceivePropsName!==null||foundWillUpdateName!==null){var componentName=Component.displayName||Component.name;var newApiName=typeof Component.getDerivedStateFromProps==='function'?'getDerivedStateFromProps()':'getSnapshotBeforeUpdate()';throw Error('Unsafe legacy lifecycles will not be called for components using new component APIs.\n\n'+componentName+' uses '+newApiName+' but also contains the following legacy lifecycles:'+(foundWillMountName!==null?'\n  '+foundWillMountName:'')+(foundWillReceivePropsName!==null?'\n  '+foundWillReceivePropsName:'')+(foundWillUpdateName!==null?'\n  '+foundWillUpdateName:'')+'\n\nThe above lifecycles should be removed. Learn more about this warning here:\n'+'https://fb.me/react-async-component-lifecycle-hooks');}// React <= 16.2 does not support static getDerivedStateFromProps.
// As a workaround, use cWM and cWRP to invoke the new static lifecycle.
// Newer versions of React will ignore these lifecycles if gDSFP exists.
if(typeof Component.getDerivedStateFromProps==='function'){prototype.componentWillMount=componentWillMount;prototype.componentWillReceiveProps=componentWillReceiveProps;}// React <= 16.2 does not support getSnapshotBeforeUpdate.
// As a workaround, use cWU to invoke the new lifecycle.
// Newer versions of React will ignore that lifecycle if gSBU exists.
if(typeof prototype.getSnapshotBeforeUpdate==='function'){if(typeof prototype.componentDidUpdate!=='function'){throw new Error('Cannot polyfill getSnapshotBeforeUpdate() for components that do not define componentDidUpdate() on the prototype');}prototype.componentWillUpdate=componentWillUpdate;var componentDidUpdate=prototype.componentDidUpdate;prototype.componentDidUpdate=function componentDidUpdatePolyfill(prevProps,prevState,maybeSnapshot){// 16.3+ will not execute our will-update method;
// It will pass a snapshot value to did-update though.
// Older versions will require our polyfilled will-update value.
// We need to handle both cases, but can't just check for the presence of "maybeSnapshot",
// Because for <= 15.x versions this might be a "prevContext" object.
// We also can't just check "__reactInternalSnapshot",
// Because get-snapshot might return a falsy value.
// So check for the explicit __reactInternalSnapshotFlag flag to determine behavior.
var snapshot=this.__reactInternalSnapshotFlag?this.__reactInternalSnapshot:maybeSnapshot;componentDidUpdate.call(this,prevProps,prevState,snapshot);};}return Component;}

/***/ }),

/***/ "../../../node_modules/react-modal/lib/components/Modal.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.bodyOpenClassName=exports.portalClassName=undefined;var _extends=Object.assign||function(target){for(var i=1;i<arguments.length;i++){var source=arguments[i];for(var key in source){if(Object.prototype.hasOwnProperty.call(source,key)){target[key]=source[key];}}}return target;};var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _react=__webpack_require__("../../../node_modules/react/index.js");var _react2=_interopRequireDefault(_react);var _reactDom=__webpack_require__("../../../node_modules/react-dom/index.js");var _reactDom2=_interopRequireDefault(_reactDom);var _propTypes=__webpack_require__("../../../node_modules/prop-types/index.js");var _propTypes2=_interopRequireDefault(_propTypes);var _ModalPortal=__webpack_require__("../../../node_modules/react-modal/lib/components/ModalPortal.js");var _ModalPortal2=_interopRequireDefault(_ModalPortal);var _ariaAppHider=__webpack_require__("../../../node_modules/react-modal/lib/helpers/ariaAppHider.js");var ariaAppHider=_interopRequireWildcard(_ariaAppHider);var _safeHTMLElement=__webpack_require__("../../../node_modules/react-modal/lib/helpers/safeHTMLElement.js");var _safeHTMLElement2=_interopRequireDefault(_safeHTMLElement);var _reactLifecyclesCompat=__webpack_require__("../../../node_modules/react-lifecycles-compat/react-lifecycles-compat.es.js");function _interopRequireWildcard(obj){if(obj&&obj.__esModule){return obj;}else{var newObj={};if(obj!=null){for(var key in obj){if(Object.prototype.hasOwnProperty.call(obj,key))newObj[key]=obj[key];}}newObj.default=obj;return newObj;}}function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}var portalClassName=exports.portalClassName="ReactModalPortal";var bodyOpenClassName=exports.bodyOpenClassName="ReactModal__Body--open";var isReact16=_reactDom2.default.createPortal!==undefined;var getCreatePortal=function getCreatePortal(){return isReact16?_reactDom2.default.createPortal:_reactDom2.default.unstable_renderSubtreeIntoContainer;};function getParentElement(parentSelector){return parentSelector();}var Modal=function(_Component){_inherits(Modal,_Component);function Modal(){var _ref;var _temp,_this,_ret;_classCallCheck(this,Modal);for(var _len=arguments.length,args=Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}return _ret=(_temp=(_this=_possibleConstructorReturn(this,(_ref=Modal.__proto__||Object.getPrototypeOf(Modal)).call.apply(_ref,[this].concat(args))),_this),_this.removePortal=function(){!isReact16&&_reactDom2.default.unmountComponentAtNode(_this.node);var parent=getParentElement(_this.props.parentSelector);if(parent){parent.removeChild(_this.node);}else{// eslint-disable-next-line no-console
console.warn('React-Modal: "parentSelector" prop did not returned any DOM '+"element. Make sure that the parent element is unmounted to "+"avoid any memory leaks.");}},_this.portalRef=function(ref){_this.portal=ref;},_this.renderPortal=function(props){var createPortal=getCreatePortal();var portal=createPortal(_this,_react2.default.createElement(_ModalPortal2.default,_extends({defaultStyles:Modal.defaultStyles},props)),_this.node);_this.portalRef(portal);},_temp),_possibleConstructorReturn(_this,_ret);}_createClass(Modal,[{key:"componentDidMount",value:function componentDidMount(){if(!_safeHTMLElement.canUseDOM)return;if(!isReact16){this.node=document.createElement("div");}this.node.className=this.props.portalClassName;var parent=getParentElement(this.props.parentSelector);parent.appendChild(this.node);!isReact16&&this.renderPortal(this.props);}},{key:"getSnapshotBeforeUpdate",value:function getSnapshotBeforeUpdate(prevProps){var prevParent=getParentElement(prevProps.parentSelector);var nextParent=getParentElement(this.props.parentSelector);return{prevParent:prevParent,nextParent:nextParent};}},{key:"componentDidUpdate",value:function componentDidUpdate(prevProps,_,snapshot){if(!_safeHTMLElement.canUseDOM)return;var _props=this.props,isOpen=_props.isOpen,portalClassName=_props.portalClassName;if(prevProps.portalClassName!==portalClassName){this.node.className=portalClassName;}var prevParent=snapshot.prevParent,nextParent=snapshot.nextParent;if(nextParent!==prevParent){prevParent.removeChild(this.node);nextParent.appendChild(this.node);}// Stop unnecessary renders if modal is remaining closed
if(!prevProps.isOpen&&!isOpen)return;!isReact16&&this.renderPortal(this.props);}},{key:"componentWillUnmount",value:function componentWillUnmount(){if(!_safeHTMLElement.canUseDOM||!this.node||!this.portal)return;var state=this.portal.state;var now=Date.now();var closesAt=state.isOpen&&this.props.closeTimeoutMS&&(state.closesAt||now+this.props.closeTimeoutMS);if(closesAt){if(!state.beforeClose){this.portal.closeWithTimeout();}setTimeout(this.removePortal,closesAt-now);}else{this.removePortal();}}},{key:"render",value:function render(){if(!_safeHTMLElement.canUseDOM||!isReact16){return null;}if(!this.node&&isReact16){this.node=document.createElement("div");}var createPortal=getCreatePortal();return createPortal(_react2.default.createElement(_ModalPortal2.default,_extends({ref:this.portalRef,defaultStyles:Modal.defaultStyles},this.props)),this.node);}}],[{key:"setAppElement",value:function setAppElement(element){ariaAppHider.setElement(element);}/* eslint-disable react/no-unused-prop-types */ /* eslint-enable react/no-unused-prop-types */}]);return Modal;}(_react.Component);Modal.propTypes={isOpen:_propTypes2.default.bool.isRequired,style:_propTypes2.default.shape({content:_propTypes2.default.object,overlay:_propTypes2.default.object}),portalClassName:_propTypes2.default.string,bodyOpenClassName:_propTypes2.default.string,htmlOpenClassName:_propTypes2.default.string,className:_propTypes2.default.oneOfType([_propTypes2.default.string,_propTypes2.default.shape({base:_propTypes2.default.string.isRequired,afterOpen:_propTypes2.default.string.isRequired,beforeClose:_propTypes2.default.string.isRequired})]),overlayClassName:_propTypes2.default.oneOfType([_propTypes2.default.string,_propTypes2.default.shape({base:_propTypes2.default.string.isRequired,afterOpen:_propTypes2.default.string.isRequired,beforeClose:_propTypes2.default.string.isRequired})]),appElement:_propTypes2.default.instanceOf(_safeHTMLElement2.default),onAfterOpen:_propTypes2.default.func,onRequestClose:_propTypes2.default.func,closeTimeoutMS:_propTypes2.default.number,ariaHideApp:_propTypes2.default.bool,shouldFocusAfterRender:_propTypes2.default.bool,shouldCloseOnOverlayClick:_propTypes2.default.bool,shouldReturnFocusAfterClose:_propTypes2.default.bool,parentSelector:_propTypes2.default.func,aria:_propTypes2.default.object,data:_propTypes2.default.object,role:_propTypes2.default.string,contentLabel:_propTypes2.default.string,shouldCloseOnEsc:_propTypes2.default.bool,overlayRef:_propTypes2.default.func,contentRef:_propTypes2.default.func};Modal.defaultProps={isOpen:false,portalClassName:portalClassName,bodyOpenClassName:bodyOpenClassName,role:"dialog",ariaHideApp:true,closeTimeoutMS:0,shouldFocusAfterRender:true,shouldCloseOnEsc:true,shouldCloseOnOverlayClick:true,shouldReturnFocusAfterClose:true,parentSelector:function parentSelector(){return document.body;}};Modal.defaultStyles={overlay:{position:"fixed",top:0,left:0,right:0,bottom:0,backgroundColor:"rgba(255, 255, 255, 0.75)"},content:{position:"absolute",top:"40px",left:"40px",right:"40px",bottom:"40px",border:"1px solid #ccc",background:"#fff",overflow:"auto",WebkitOverflowScrolling:"touch",borderRadius:"4px",outline:"none",padding:"20px"}};(0,_reactLifecyclesCompat.polyfill)(Modal);exports.default=Modal;

/***/ }),

/***/ "../../../node_modules/react-modal/lib/components/ModalPortal.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});var _extends=Object.assign||function(target){for(var i=1;i<arguments.length;i++){var source=arguments[i];for(var key in source){if(Object.prototype.hasOwnProperty.call(source,key)){target[key]=source[key];}}}return target;};var _typeof=typeof Symbol==="function"&&typeof Symbol.iterator==="symbol"?function(obj){return typeof obj;}:function(obj){return obj&&typeof Symbol==="function"&&obj.constructor===Symbol&&obj!==Symbol.prototype?"symbol":typeof obj;};var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _react=__webpack_require__("../../../node_modules/react/index.js");var _react2=_interopRequireDefault(_react);var _propTypes=__webpack_require__("../../../node_modules/prop-types/index.js");var _propTypes2=_interopRequireDefault(_propTypes);var _focusManager=__webpack_require__("../../../node_modules/react-modal/lib/helpers/focusManager.js");var focusManager=_interopRequireWildcard(_focusManager);var _scopeTab=__webpack_require__("../../../node_modules/react-modal/lib/helpers/scopeTab.js");var _scopeTab2=_interopRequireDefault(_scopeTab);var _ariaAppHider=__webpack_require__("../../../node_modules/react-modal/lib/helpers/ariaAppHider.js");var ariaAppHider=_interopRequireWildcard(_ariaAppHider);var _classList=__webpack_require__("../../../node_modules/react-modal/lib/helpers/classList.js");var classList=_interopRequireWildcard(_classList);var _safeHTMLElement=__webpack_require__("../../../node_modules/react-modal/lib/helpers/safeHTMLElement.js");var _safeHTMLElement2=_interopRequireDefault(_safeHTMLElement);var _portalOpenInstances=__webpack_require__("../../../node_modules/react-modal/lib/helpers/portalOpenInstances.js");var _portalOpenInstances2=_interopRequireDefault(_portalOpenInstances);__webpack_require__("../../../node_modules/react-modal/lib/helpers/bodyTrap.js");function _interopRequireWildcard(obj){if(obj&&obj.__esModule){return obj;}else{var newObj={};if(obj!=null){for(var key in obj){if(Object.prototype.hasOwnProperty.call(obj,key))newObj[key]=obj[key];}}newObj.default=obj;return newObj;}}function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}// so that our CSS is statically analyzable
var CLASS_NAMES={overlay:"ReactModal__Overlay",content:"ReactModal__Content"};var TAB_KEY=9;var ESC_KEY=27;var ariaHiddenInstances=0;var ModalPortal=function(_Component){_inherits(ModalPortal,_Component);function ModalPortal(props){_classCallCheck(this,ModalPortal);var _this=_possibleConstructorReturn(this,(ModalPortal.__proto__||Object.getPrototypeOf(ModalPortal)).call(this,props));_this.setOverlayRef=function(overlay){_this.overlay=overlay;_this.props.overlayRef&&_this.props.overlayRef(overlay);};_this.setContentRef=function(content){_this.content=content;_this.props.contentRef&&_this.props.contentRef(content);};_this.afterClose=function(){var _this$props=_this.props,appElement=_this$props.appElement,ariaHideApp=_this$props.ariaHideApp,htmlOpenClassName=_this$props.htmlOpenClassName,bodyOpenClassName=_this$props.bodyOpenClassName;// Remove classes.
bodyOpenClassName&&classList.remove(document.body,bodyOpenClassName);htmlOpenClassName&&classList.remove(document.getElementsByTagName("html")[0],htmlOpenClassName);// Reset aria-hidden attribute if all modals have been removed
if(ariaHideApp&&ariaHiddenInstances>0){ariaHiddenInstances-=1;if(ariaHiddenInstances===0){ariaAppHider.show(appElement);}}if(_this.props.shouldFocusAfterRender){if(_this.props.shouldReturnFocusAfterClose){focusManager.returnFocus();focusManager.teardownScopedFocus();}else{focusManager.popWithoutFocus();}}if(_this.props.onAfterClose){_this.props.onAfterClose();}_portalOpenInstances2.default.deregister(_this);};_this.open=function(){_this.beforeOpen();if(_this.state.afterOpen&&_this.state.beforeClose){clearTimeout(_this.closeTimer);_this.setState({beforeClose:false});}else{if(_this.props.shouldFocusAfterRender){focusManager.setupScopedFocus(_this.node);focusManager.markForFocusLater();}_this.setState({isOpen:true},function(){_this.setState({afterOpen:true});if(_this.props.isOpen&&_this.props.onAfterOpen){_this.props.onAfterOpen({overlayEl:_this.overlay,contentEl:_this.content});}});}};_this.close=function(){if(_this.props.closeTimeoutMS>0){_this.closeWithTimeout();}else{_this.closeWithoutTimeout();}};_this.focusContent=function(){return _this.content&&!_this.contentHasFocus()&&_this.content.focus();};_this.closeWithTimeout=function(){var closesAt=Date.now()+_this.props.closeTimeoutMS;_this.setState({beforeClose:true,closesAt:closesAt},function(){_this.closeTimer=setTimeout(_this.closeWithoutTimeout,_this.state.closesAt-Date.now());});};_this.closeWithoutTimeout=function(){_this.setState({beforeClose:false,isOpen:false,afterOpen:false,closesAt:null},_this.afterClose);};_this.handleKeyDown=function(event){if(event.keyCode===TAB_KEY){(0,_scopeTab2.default)(_this.content,event);}if(_this.props.shouldCloseOnEsc&&event.keyCode===ESC_KEY){event.stopPropagation();_this.requestClose(event);}};_this.handleOverlayOnClick=function(event){if(_this.shouldClose===null){_this.shouldClose=true;}if(_this.shouldClose&&_this.props.shouldCloseOnOverlayClick){if(_this.ownerHandlesClose()){_this.requestClose(event);}else{_this.focusContent();}}_this.shouldClose=null;};_this.handleContentOnMouseUp=function(){_this.shouldClose=false;};_this.handleOverlayOnMouseDown=function(event){if(!_this.props.shouldCloseOnOverlayClick&&event.target==_this.overlay){event.preventDefault();}};_this.handleContentOnClick=function(){_this.shouldClose=false;};_this.handleContentOnMouseDown=function(){_this.shouldClose=false;};_this.requestClose=function(event){return _this.ownerHandlesClose()&&_this.props.onRequestClose(event);};_this.ownerHandlesClose=function(){return _this.props.onRequestClose;};_this.shouldBeClosed=function(){return!_this.state.isOpen&&!_this.state.beforeClose;};_this.contentHasFocus=function(){return document.activeElement===_this.content||_this.content.contains(document.activeElement);};_this.buildClassName=function(which,additional){var classNames=(typeof additional==="undefined"?"undefined":_typeof(additional))==="object"?additional:{base:CLASS_NAMES[which],afterOpen:CLASS_NAMES[which]+"--after-open",beforeClose:CLASS_NAMES[which]+"--before-close"};var className=classNames.base;if(_this.state.afterOpen){className=className+" "+classNames.afterOpen;}if(_this.state.beforeClose){className=className+" "+classNames.beforeClose;}return typeof additional==="string"&&additional?className+" "+additional:className;};_this.attributesFromObject=function(prefix,items){return Object.keys(items).reduce(function(acc,name){acc[prefix+"-"+name]=items[name];return acc;},{});};_this.state={afterOpen:false,beforeClose:false};_this.shouldClose=null;_this.moveFromContentToOverlay=null;return _this;}_createClass(ModalPortal,[{key:"componentDidMount",value:function componentDidMount(){if(this.props.isOpen){this.open();}}},{key:"componentDidUpdate",value:function componentDidUpdate(prevProps,prevState){if(false){if(prevProps.bodyOpenClassName!==this.props.bodyOpenClassName){// eslint-disable-next-line no-console
console.warn('React-Modal: "bodyOpenClassName" prop has been modified. '+"This may cause unexpected behavior when multiple modals are open.");}if(prevProps.htmlOpenClassName!==this.props.htmlOpenClassName){// eslint-disable-next-line no-console
console.warn('React-Modal: "htmlOpenClassName" prop has been modified. '+"This may cause unexpected behavior when multiple modals are open.");}}if(this.props.isOpen&&!prevProps.isOpen){this.open();}else if(!this.props.isOpen&&prevProps.isOpen){this.close();}// Focus only needs to be set once when the modal is being opened
if(this.props.shouldFocusAfterRender&&this.state.isOpen&&!prevState.isOpen){this.focusContent();}}},{key:"componentWillUnmount",value:function componentWillUnmount(){if(this.state.isOpen){this.afterClose();}clearTimeout(this.closeTimer);}},{key:"beforeOpen",value:function beforeOpen(){var _props=this.props,appElement=_props.appElement,ariaHideApp=_props.ariaHideApp,htmlOpenClassName=_props.htmlOpenClassName,bodyOpenClassName=_props.bodyOpenClassName;// Add classes.
bodyOpenClassName&&classList.add(document.body,bodyOpenClassName);htmlOpenClassName&&classList.add(document.getElementsByTagName("html")[0],htmlOpenClassName);if(ariaHideApp){ariaHiddenInstances+=1;ariaAppHider.hide(appElement);}_portalOpenInstances2.default.register(this);}// Don't steal focus from inner elements
},{key:"render",value:function render(){var _props2=this.props,id=_props2.id,className=_props2.className,overlayClassName=_props2.overlayClassName,defaultStyles=_props2.defaultStyles;var contentStyles=className?{}:defaultStyles.content;var overlayStyles=overlayClassName?{}:defaultStyles.overlay;return this.shouldBeClosed()?null:_react2.default.createElement("div",{ref:this.setOverlayRef,className:this.buildClassName("overlay",overlayClassName),style:_extends({},overlayStyles,this.props.style.overlay),onClick:this.handleOverlayOnClick,onMouseDown:this.handleOverlayOnMouseDown},_react2.default.createElement("div",_extends({id:id,ref:this.setContentRef,style:_extends({},contentStyles,this.props.style.content),className:this.buildClassName("content",className),tabIndex:"-1",onKeyDown:this.handleKeyDown,onMouseDown:this.handleContentOnMouseDown,onMouseUp:this.handleContentOnMouseUp,onClick:this.handleContentOnClick,role:this.props.role,"aria-label":this.props.contentLabel},this.attributesFromObject("aria",this.props.aria||{}),this.attributesFromObject("data",this.props.data||{}),{"data-testid":this.props.testId}),this.props.children));}}]);return ModalPortal;}(_react.Component);ModalPortal.defaultProps={style:{overlay:{},content:{}},defaultStyles:{}};ModalPortal.propTypes={isOpen:_propTypes2.default.bool.isRequired,defaultStyles:_propTypes2.default.shape({content:_propTypes2.default.object,overlay:_propTypes2.default.object}),style:_propTypes2.default.shape({content:_propTypes2.default.object,overlay:_propTypes2.default.object}),className:_propTypes2.default.oneOfType([_propTypes2.default.string,_propTypes2.default.object]),overlayClassName:_propTypes2.default.oneOfType([_propTypes2.default.string,_propTypes2.default.object]),bodyOpenClassName:_propTypes2.default.string,htmlOpenClassName:_propTypes2.default.string,ariaHideApp:_propTypes2.default.bool,appElement:_propTypes2.default.instanceOf(_safeHTMLElement2.default),onAfterOpen:_propTypes2.default.func,onAfterClose:_propTypes2.default.func,onRequestClose:_propTypes2.default.func,closeTimeoutMS:_propTypes2.default.number,shouldFocusAfterRender:_propTypes2.default.bool,shouldCloseOnOverlayClick:_propTypes2.default.bool,shouldReturnFocusAfterClose:_propTypes2.default.bool,role:_propTypes2.default.string,contentLabel:_propTypes2.default.string,aria:_propTypes2.default.object,data:_propTypes2.default.object,children:_propTypes2.default.node,shouldCloseOnEsc:_propTypes2.default.bool,overlayRef:_propTypes2.default.func,contentRef:_propTypes2.default.func,id:_propTypes2.default.string,testId:_propTypes2.default.string};exports.default=ModalPortal;module.exports=exports["default"];

/***/ }),

/***/ "../../../node_modules/react-modal/lib/helpers/ariaAppHider.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.assertNodeList=assertNodeList;exports.setElement=setElement;exports.validateElement=validateElement;exports.hide=hide;exports.show=show;exports.documentNotReadyOrSSRTesting=documentNotReadyOrSSRTesting;exports.resetForTesting=resetForTesting;var _warning=__webpack_require__("../../../node_modules/warning/warning.js");var _warning2=_interopRequireDefault(_warning);var _safeHTMLElement=__webpack_require__("../../../node_modules/react-modal/lib/helpers/safeHTMLElement.js");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}var globalElement=null;function assertNodeList(nodeList,selector){if(!nodeList||!nodeList.length){throw new Error("react-modal: No elements were found for selector "+selector+".");}}function setElement(element){var useElement=element;if(typeof useElement==="string"&&_safeHTMLElement.canUseDOM){var el=document.querySelectorAll(useElement);assertNodeList(el,useElement);useElement="length"in el?el[0]:el;}globalElement=useElement||globalElement;return globalElement;}function validateElement(appElement){if(!appElement&&!globalElement){(0,_warning2.default)(false,["react-modal: App element is not defined.","Please use `Modal.setAppElement(el)` or set `appElement={el}`.","This is needed so screen readers don't see main content","when modal is opened. It is not recommended, but you can opt-out","by setting `ariaHideApp={false}`."].join(" "));return false;}return true;}function hide(appElement){if(validateElement(appElement)){(appElement||globalElement).setAttribute("aria-hidden","true");}}function show(appElement){if(validateElement(appElement)){(appElement||globalElement).removeAttribute("aria-hidden");}}function documentNotReadyOrSSRTesting(){globalElement=null;}function resetForTesting(){globalElement=null;}

/***/ }),

/***/ "../../../node_modules/react-modal/lib/helpers/bodyTrap.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var _portalOpenInstances=__webpack_require__("../../../node_modules/react-modal/lib/helpers/portalOpenInstances.js");var _portalOpenInstances2=_interopRequireDefault(_portalOpenInstances);function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}// Body focus trap see Issue #742
var before=void 0,after=void 0,instances=[];function focusContent(){if(instances.length===0){if(false){// eslint-disable-next-line no-console
console.warn("React-Modal: Open instances > 0 expected");}return;}instances[instances.length-1].focusContent();}function bodyTrap(eventType,openInstances){if(!before||!after){before=document.createElement("div");before.setAttribute("data-react-modal-body-trap","");before.style.position="absolute";before.style.opacity="0";before.setAttribute("tabindex","0");before.addEventListener("focus",focusContent);after=before.cloneNode();after.addEventListener("focus",focusContent);}instances=openInstances;if(instances.length>0){// Add focus trap
if(document.body.firstChild!==before){document.body.insertBefore(before,document.body.firstChild);}if(document.body.lastChild!==after){document.body.appendChild(after);}}else{// Remove focus trap
if(before.parentElement){before.parentElement.removeChild(before);}if(after.parentElement){after.parentElement.removeChild(after);}}}_portalOpenInstances2.default.subscribe(bodyTrap);

/***/ }),

/***/ "../../../node_modules/react-modal/lib/helpers/classList.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.dumpClassLists=dumpClassLists;var htmlClassList={};var docBodyClassList={};function dumpClassLists(){if(false){var classes=document.getElementsByTagName("html")[0].className;var buffer="Show tracked classes:\n\n";buffer+="<html /> ("+classes+"):\n";for(var x in htmlClassList){buffer+="  "+x+" "+htmlClassList[x]+"\n";}classes=document.body.className;// eslint-disable-next-line max-len
buffer+="\n\ndoc.body ("+classes+"):\n";for(var _x in docBodyClassList){buffer+="  "+_x+" "+docBodyClassList[_x]+"\n";}buffer+="\n";// eslint-disable-next-line no-console
console.log(buffer);}}/**
 * Track the number of reference of a class.
 * @param {object} poll The poll to receive the reference.
 * @param {string} className The class name.
 * @return {string}
 */var incrementReference=function incrementReference(poll,className){if(!poll[className]){poll[className]=0;}poll[className]+=1;return className;};/**
 * Drop the reference of a class.
 * @param {object} poll The poll to receive the reference.
 * @param {string} className The class name.
 * @return {string}
 */var decrementReference=function decrementReference(poll,className){if(poll[className]){poll[className]-=1;}return className;};/**
 * Track a class and add to the given class list.
 * @param {Object} classListRef A class list of an element.
 * @param {Object} poll         The poll to be used.
 * @param {Array}  classes      The list of classes to be tracked.
 */var trackClass=function trackClass(classListRef,poll,classes){classes.forEach(function(className){incrementReference(poll,className);classListRef.add(className);});};/**
 * Untrack a class and remove from the given class list if the reference
 * reaches 0.
 * @param {Object} classListRef A class list of an element.
 * @param {Object} poll         The poll to be used.
 * @param {Array}  classes      The list of classes to be untracked.
 */var untrackClass=function untrackClass(classListRef,poll,classes){classes.forEach(function(className){decrementReference(poll,className);poll[className]===0&&classListRef.remove(className);});};/**
 * Public inferface to add classes to the document.body.
 * @param {string} bodyClass The class string to be added.
 *                           It may contain more then one class
 *                           with ' ' as separator.
 */var add=exports.add=function add(element,classString){return trackClass(element.classList,element.nodeName.toLowerCase()=="html"?htmlClassList:docBodyClassList,classString.split(" "));};/**
 * Public inferface to remove classes from the document.body.
 * @param {string} bodyClass The class string to be added.
 *                           It may contain more then one class
 *                           with ' ' as separator.
 */var remove=exports.remove=function remove(element,classString){return untrackClass(element.classList,element.nodeName.toLowerCase()=="html"?htmlClassList:docBodyClassList,classString.split(" "));};

/***/ }),

/***/ "../../../node_modules/react-modal/lib/helpers/focusManager.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.handleBlur=handleBlur;exports.handleFocus=handleFocus;exports.markForFocusLater=markForFocusLater;exports.returnFocus=returnFocus;exports.popWithoutFocus=popWithoutFocus;exports.setupScopedFocus=setupScopedFocus;exports.teardownScopedFocus=teardownScopedFocus;var _tabbable=__webpack_require__("../../../node_modules/react-modal/lib/helpers/tabbable.js");var _tabbable2=_interopRequireDefault(_tabbable);function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}var focusLaterElements=[];var modalElement=null;var needToFocus=false;function handleBlur(){needToFocus=true;}function handleFocus(){if(needToFocus){needToFocus=false;if(!modalElement){return;}// need to see how jQuery shims document.on('focusin') so we don't need the
// setTimeout, firefox doesn't support focusin, if it did, we could focus
// the element outside of a setTimeout. Side-effect of this implementation
// is that the document.body gets focus, and then we focus our element right
// after, seems fine.
setTimeout(function(){if(modalElement.contains(document.activeElement)){return;}var el=(0,_tabbable2.default)(modalElement)[0]||modalElement;el.focus();},0);}}function markForFocusLater(){focusLaterElements.push(document.activeElement);}/* eslint-disable no-console */function returnFocus(){var toFocus=null;try{if(focusLaterElements.length!==0){toFocus=focusLaterElements.pop();toFocus.focus();}return;}catch(e){console.warn(["You tried to return focus to",toFocus,"but it is not in the DOM anymore"].join(" "));}}/* eslint-enable no-console */function popWithoutFocus(){focusLaterElements.length>0&&focusLaterElements.pop();}function setupScopedFocus(element){modalElement=element;if(window.addEventListener){window.addEventListener("blur",handleBlur,false);document.addEventListener("focus",handleFocus,true);}else{window.attachEvent("onBlur",handleBlur);document.attachEvent("onFocus",handleFocus);}}function teardownScopedFocus(){modalElement=null;if(window.addEventListener){window.removeEventListener("blur",handleBlur);document.removeEventListener("focus",handleFocus);}else{window.detachEvent("onBlur",handleBlur);document.detachEvent("onFocus",handleFocus);}}

/***/ }),

/***/ "../../../node_modules/react-modal/lib/helpers/portalOpenInstances.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}// Tracks portals that are open and emits events to subscribers
var PortalOpenInstances=function PortalOpenInstances(){var _this=this;_classCallCheck(this,PortalOpenInstances);this.register=function(openInstance){if(_this.openInstances.indexOf(openInstance)!==-1){if(false){// eslint-disable-next-line no-console
console.warn("React-Modal: Cannot register modal instance that's already open");}return;}_this.openInstances.push(openInstance);_this.emit("register");};this.deregister=function(openInstance){var index=_this.openInstances.indexOf(openInstance);if(index===-1){if(false){// eslint-disable-next-line no-console
console.warn("React-Modal: Unable to deregister "+openInstance+" as "+"it was never registered");}return;}_this.openInstances.splice(index,1);_this.emit("deregister");};this.subscribe=function(callback){_this.subscribers.push(callback);};this.emit=function(eventType){_this.subscribers.forEach(function(subscriber){return subscriber(eventType,// shallow copy to avoid accidental mutation
_this.openInstances.slice());});};this.openInstances=[];this.subscribers=[];};var portalOpenInstances=new PortalOpenInstances();exports.default=portalOpenInstances;module.exports=exports["default"];

/***/ }),

/***/ "../../../node_modules/react-modal/lib/helpers/safeHTMLElement.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.canUseDOM=undefined;var _exenv=__webpack_require__("../../../node_modules/exenv/index.js");var _exenv2=_interopRequireDefault(_exenv);function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}var EE=_exenv2.default;var SafeHTMLElement=EE.canUseDOM?window.HTMLElement:{};var canUseDOM=exports.canUseDOM=EE.canUseDOM;exports.default=SafeHTMLElement;

/***/ }),

/***/ "../../../node_modules/react-modal/lib/helpers/scopeTab.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=scopeTab;var _tabbable=__webpack_require__("../../../node_modules/react-modal/lib/helpers/tabbable.js");var _tabbable2=_interopRequireDefault(_tabbable);function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function scopeTab(node,event){var tabbable=(0,_tabbable2.default)(node);if(!tabbable.length){// Do nothing, since there are no elements that can receive focus.
event.preventDefault();return;}var target=void 0;var shiftKey=event.shiftKey;var head=tabbable[0];var tail=tabbable[tabbable.length-1];// proceed with default browser behavior on tab.
// Focus on last element on shift + tab.
if(node===document.activeElement){if(!shiftKey)return;target=tail;}if(tail===document.activeElement&&!shiftKey){target=head;}if(head===document.activeElement&&shiftKey){target=tail;}if(target){event.preventDefault();target.focus();return;}// Safari radio issue.
//
// Safari does not move the focus to the radio button,
// so we need to force it to really walk through all elements.
//
// This is very error prone, since we are trying to guess
// if it is a safari browser from the first occurence between
// chrome or safari.
//
// The chrome user agent contains the first ocurrence
// as the 'chrome/version' and later the 'safari/version'.
var checkSafari=/(\bChrome\b|\bSafari\b)\//.exec(navigator.userAgent);var isSafariDesktop=checkSafari!=null&&checkSafari[1]!="Chrome"&&/\biPod\b|\biPad\b/g.exec(navigator.userAgent)==null;// If we are not in safari desktop, let the browser control
// the focus
if(!isSafariDesktop)return;var x=tabbable.indexOf(document.activeElement);if(x>-1){x+=shiftKey?-1:1;}target=tabbable[x];// If the tabbable element does not exist,
// focus head/tail based on shiftKey
if(typeof target==="undefined"){event.preventDefault();target=shiftKey?tail:head;target.focus();return;}event.preventDefault();target.focus();}module.exports=exports["default"];

/***/ }),

/***/ "../../../node_modules/react-modal/lib/helpers/tabbable.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=findTabbableDescendants;/*!
 * Adapted from jQuery UI core
 *
 * http://jqueryui.com
 *
 * Copyright 2014 jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/category/ui-core/
 */var tabbableNode=/input|select|textarea|button|object/;function hidesContents(element){var zeroSize=element.offsetWidth<=0&&element.offsetHeight<=0;// If the node is empty, this is good enough
if(zeroSize&&!element.innerHTML)return true;// Otherwise we need to check some styles
var style=window.getComputedStyle(element);return zeroSize?style.getPropertyValue("overflow")!=="visible"||// if 'overflow: visible' set, check if there is actually any overflow
element.scrollWidth<=0&&element.scrollHeight<=0:style.getPropertyValue("display")=="none";}function visible(element){var parentElement=element;while(parentElement){if(parentElement===document.body)break;if(hidesContents(parentElement))return false;parentElement=parentElement.parentNode;}return true;}function focusable(element,isTabIndexNotNaN){var nodeName=element.nodeName.toLowerCase();var res=tabbableNode.test(nodeName)&&!element.disabled||(nodeName==="a"?element.href||isTabIndexNotNaN:isTabIndexNotNaN);return res&&visible(element);}function tabbable(element){var tabIndex=element.getAttribute("tabindex");if(tabIndex===null)tabIndex=undefined;var isTabIndexNaN=isNaN(tabIndex);return(isTabIndexNaN||tabIndex>=0)&&focusable(element,!isTabIndexNaN);}function findTabbableDescendants(element){return[].slice.call(element.querySelectorAll("*"),0).filter(tabbable);}module.exports=exports["default"];

/***/ }),

/***/ "../../../node_modules/react-modal/lib/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});var _Modal=__webpack_require__("../../../node_modules/react-modal/lib/components/Modal.js");var _Modal2=_interopRequireDefault(_Modal);function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}exports.default=_Modal2.default;module.exports=exports["default"];

/***/ }),

/***/ "../../../node_modules/react-tooltip/dist/index.es.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function ___$insertStyle(css){if(!css){return;}if(typeof window==='undefined'){return;}var style=document.createElement('style');style.setAttribute('type','text/css');style.innerHTML=css;document.head.appendChild(style);return css;}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}function _createClass(Constructor,protoProps,staticProps){if(protoProps)_defineProperties(Constructor.prototype,protoProps);if(staticProps)_defineProperties(Constructor,staticProps);return Constructor;}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}function _extends(){_extends=Object.assign||function(target){for(var i=1;i<arguments.length;i++){var source=arguments[i];for(var key in source){if(Object.prototype.hasOwnProperty.call(source,key)){target[key]=source[key];}}}return target;};return _extends.apply(this,arguments);}function ownKeys(object,enumerableOnly){var keys=Object.keys(object);if(Object.getOwnPropertySymbols){var symbols=Object.getOwnPropertySymbols(object);if(enumerableOnly)symbols=symbols.filter(function(sym){return Object.getOwnPropertyDescriptor(object,sym).enumerable;});keys.push.apply(keys,symbols);}return keys;}function _objectSpread2(target){for(var i=1;i<arguments.length;i++){var source=arguments[i]!=null?arguments[i]:{};if(i%2){ownKeys(Object(source),true).forEach(function(key){_defineProperty(target,key,source[key]);});}else if(Object.getOwnPropertyDescriptors){Object.defineProperties(target,Object.getOwnPropertyDescriptors(source));}else{ownKeys(Object(source)).forEach(function(key){Object.defineProperty(target,key,Object.getOwnPropertyDescriptor(source,key));});}}return target;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function");}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,writable:true,configurable:true}});if(superClass)_setPrototypeOf(subClass,superClass);}function _getPrototypeOf(o){_getPrototypeOf=Object.setPrototypeOf?Object.getPrototypeOf:function _getPrototypeOf(o){return o.__proto__||Object.getPrototypeOf(o);};return _getPrototypeOf(o);}function _setPrototypeOf(o,p){_setPrototypeOf=Object.setPrototypeOf||function _setPrototypeOf(o,p){o.__proto__=p;return o;};return _setPrototypeOf(o,p);}function _assertThisInitialized(self){if(self===void 0){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return self;}function _possibleConstructorReturn(self,call){if(call&&(typeof call==="object"||typeof call==="function")){return call;}return _assertThisInitialized(self);}function createCommonjsModule(fn,module){return module={exports:{}},fn(module,module.exports),module.exports;}/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * 
 */function makeEmptyFunction(arg){return function(){return arg;};}/**
 * This function accepts and discards inputs; it has no side effects. This is
 * primarily useful idiomatically for overridable function endpoints which
 * always need to be callable, since JS lacks a null-call idiom ala Cocoa.
 */var emptyFunction=function emptyFunction(){};emptyFunction.thatReturns=makeEmptyFunction;emptyFunction.thatReturnsFalse=makeEmptyFunction(false);emptyFunction.thatReturnsTrue=makeEmptyFunction(true);emptyFunction.thatReturnsNull=makeEmptyFunction(null);emptyFunction.thatReturnsThis=function(){return this;};emptyFunction.thatReturnsArgument=function(arg){return arg;};var emptyFunction_1=emptyFunction;/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ /**
 * Use invariant() to assert state which your program assumes to be true.
 *
 * Provide sprintf-style format (only %s is supported) and arguments
 * to provide information about what broke and what you were
 * expecting.
 *
 * The invariant message will be stripped in production, but the invariant
 * will remain to ensure logic does not differ in production.
 */var validateFormat=function validateFormat(format){};if(false){validateFormat=function validateFormat(format){if(format===undefined){throw new Error('invariant requires an error message argument');}};}function invariant(condition,format,a,b,c,d,e,f){validateFormat(format);if(!condition){var error;if(format===undefined){error=new Error('Minified exception occurred; use the non-minified dev environment '+'for the full error message and additional helpful warnings.');}else{var args=[a,b,c,d,e,f];var argIndex=0;error=new Error(format.replace(/%s/g,function(){return args[argIndex++];}));error.name='Invariant Violation';}error.framesToPop=1;// we don't care about invariant's own frame
throw error;}}var invariant_1=invariant;/**
 * Similar to invariant but only logs a warning if the condition is not met.
 * This can be used to log issues in development environments in critical
 * paths. Removing the logging code for production environments will keep the
 * same logic and follow the same code paths.
 */var warning=emptyFunction_1;if(false){var printWarning=function printWarning(format){for(var _len=arguments.length,args=Array(_len>1?_len-1:0),_key=1;_key<_len;_key++){args[_key-1]=arguments[_key];}var argIndex=0;var message='Warning: '+format.replace(/%s/g,function(){return args[argIndex++];});if(typeof console!=='undefined'){console.error(message);}try{// --- Welcome to debugging React ---
// This error was thrown as a convenience so that you can use this stack
// to find the callsite that caused this warning to fire.
throw new Error(message);}catch(x){}};warning=function warning(condition,format){if(format===undefined){throw new Error('`warning(condition, format, ...args)` requires a warning '+'message argument');}if(format.indexOf('Failed Composite propType: ')===0){return;// Ignore CompositeComponent proptype check.
}if(!condition){for(var _len2=arguments.length,args=Array(_len2>2?_len2-2:0),_key2=2;_key2<_len2;_key2++){args[_key2-2]=arguments[_key2];}printWarning.apply(undefined,[format].concat(args));}};}var warning_1=warning;/*
object-assign
(c) Sindre Sorhus
@license MIT
*/ /* eslint-disable no-unused-vars */var getOwnPropertySymbols=Object.getOwnPropertySymbols;var hasOwnProperty=Object.prototype.hasOwnProperty;var propIsEnumerable=Object.prototype.propertyIsEnumerable;function toObject(val){if(val===null||val===undefined){throw new TypeError('Object.assign cannot be called with null or undefined');}return Object(val);}function shouldUseNative(){try{if(!Object.assign){return false;}// Detect buggy property enumeration order in older V8 versions.
// https://bugs.chromium.org/p/v8/issues/detail?id=4118
var test1=new String('abc');// eslint-disable-line no-new-wrappers
test1[5]='de';if(Object.getOwnPropertyNames(test1)[0]==='5'){return false;}// https://bugs.chromium.org/p/v8/issues/detail?id=3056
var test2={};for(var i=0;i<10;i++){test2['_'+String.fromCharCode(i)]=i;}var order2=Object.getOwnPropertyNames(test2).map(function(n){return test2[n];});if(order2.join('')!=='0123456789'){return false;}// https://bugs.chromium.org/p/v8/issues/detail?id=3056
var test3={};'abcdefghijklmnopqrst'.split('').forEach(function(letter){test3[letter]=letter;});if(Object.keys(Object.assign({},test3)).join('')!=='abcdefghijklmnopqrst'){return false;}return true;}catch(err){// We don't expect any of the above to throw, but better to be safe.
return false;}}var objectAssign=shouldUseNative()?Object.assign:function(target,source){var from;var to=toObject(target);var symbols;for(var s=1;s<arguments.length;s++){from=Object(arguments[s]);for(var key in from){if(hasOwnProperty.call(from,key)){to[key]=from[key];}}if(getOwnPropertySymbols){symbols=getOwnPropertySymbols(from);for(var i=0;i<symbols.length;i++){if(propIsEnumerable.call(from,symbols[i])){to[symbols[i]]=from[symbols[i]];}}}}return to;};/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var ReactPropTypesSecret='SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';var ReactPropTypesSecret_1=ReactPropTypesSecret;if(false){var invariant$1=invariant_1;var warning$1=warning_1;var ReactPropTypesSecret$1=ReactPropTypesSecret_1;var loggedTypeFailures={};}/**
 * Assert that the values match with the type specs.
 * Error messages are memorized and will only be shown once.
 *
 * @param {object} typeSpecs Map of name to a ReactPropType
 * @param {object} values Runtime values that need to be type-checked
 * @param {string} location e.g. "prop", "context", "child context"
 * @param {string} componentName Name of the component for error messages.
 * @param {?Function} getStack Returns the component stack.
 * @private
 */function checkPropTypes(typeSpecs,values,location,componentName,getStack){if(false){for(var typeSpecName in typeSpecs){if(typeSpecs.hasOwnProperty(typeSpecName)){var error;// Prop type validation may throw. In case they do, we don't want to
// fail the render phase where it didn't fail before. So we log it.
// After these have been cleaned up, we'll let them throw.
try{// This is intentionally an invariant that gets caught. It's the same
// behavior as without this statement except with a better message.
invariant$1(typeof typeSpecs[typeSpecName]==='function','%s: %s type `%s` is invalid; it must be a function, usually from '+'the `prop-types` package, but received `%s`.',componentName||'React class',location,typeSpecName,typeof typeSpecs[typeSpecName]);error=typeSpecs[typeSpecName](values,typeSpecName,componentName,location,null,ReactPropTypesSecret$1);}catch(ex){error=ex;}warning$1(!error||error instanceof Error,'%s: type specification of %s `%s` is invalid; the type checker '+'function must return `null` or an `Error` but returned a %s. '+'You may have forgotten to pass an argument to the type checker '+'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and '+'shape all require an argument).',componentName||'React class',location,typeSpecName,typeof error);if(error instanceof Error&&!(error.message in loggedTypeFailures)){// Only monitor this failure once because there tends to be a lot of the
// same error.
loggedTypeFailures[error.message]=true;var stack=getStack?getStack():'';warning$1(false,'Failed %s type: %s%s',location,error.message,stack!=null?stack:'');}}}}}var checkPropTypes_1=checkPropTypes;var factoryWithTypeCheckers=function(isValidElement,throwOnDirectAccess){/* global Symbol */var ITERATOR_SYMBOL=typeof Symbol==='function'&&Symbol.iterator;var FAUX_ITERATOR_SYMBOL='@@iterator';// Before Symbol spec.
/**
   * Returns the iterator method function contained on the iterable object.
   *
   * Be sure to invoke the function with the iterable as context:
   *
   *     var iteratorFn = getIteratorFn(myIterable);
   *     if (iteratorFn) {
   *       var iterator = iteratorFn.call(myIterable);
   *       ...
   *     }
   *
   * @param {?object} maybeIterable
   * @return {?function}
   */function getIteratorFn(maybeIterable){var iteratorFn=maybeIterable&&(ITERATOR_SYMBOL&&maybeIterable[ITERATOR_SYMBOL]||maybeIterable[FAUX_ITERATOR_SYMBOL]);if(typeof iteratorFn==='function'){return iteratorFn;}}/**
   * Collection of methods that allow declaration and validation of props that are
   * supplied to React components. Example usage:
   *
   *   var Props = require('ReactPropTypes');
   *   var MyArticle = React.createClass({
   *     propTypes: {
   *       // An optional string prop named "description".
   *       description: Props.string,
   *
   *       // A required enum prop named "category".
   *       category: Props.oneOf(['News','Photos']).isRequired,
   *
   *       // A prop named "dialog" that requires an instance of Dialog.
   *       dialog: Props.instanceOf(Dialog).isRequired
   *     },
   *     render: function() { ... }
   *   });
   *
   * A more formal specification of how these methods are used:
   *
   *   type := array|bool|func|object|number|string|oneOf([...])|instanceOf(...)
   *   decl := ReactPropTypes.{type}(.isRequired)?
   *
   * Each and every declaration produces a function with the same signature. This
   * allows the creation of custom validation functions. For example:
   *
   *  var MyLink = React.createClass({
   *    propTypes: {
   *      // An optional string or URI prop named "href".
   *      href: function(props, propName, componentName) {
   *        var propValue = props[propName];
   *        if (propValue != null && typeof propValue !== 'string' &&
   *            !(propValue instanceof URI)) {
   *          return new Error(
   *            'Expected a string or an URI for ' + propName + ' in ' +
   *            componentName
   *          );
   *        }
   *      }
   *    },
   *    render: function() {...}
   *  });
   *
   * @internal
   */var ANONYMOUS='<<anonymous>>';// Important!
// Keep this list in sync with production version in `./factoryWithThrowingShims.js`.
var ReactPropTypes={array:createPrimitiveTypeChecker('array'),bool:createPrimitiveTypeChecker('boolean'),func:createPrimitiveTypeChecker('function'),number:createPrimitiveTypeChecker('number'),object:createPrimitiveTypeChecker('object'),string:createPrimitiveTypeChecker('string'),symbol:createPrimitiveTypeChecker('symbol'),any:createAnyTypeChecker(),arrayOf:createArrayOfTypeChecker,element:createElementTypeChecker(),instanceOf:createInstanceTypeChecker,node:createNodeChecker(),objectOf:createObjectOfTypeChecker,oneOf:createEnumTypeChecker,oneOfType:createUnionTypeChecker,shape:createShapeTypeChecker,exact:createStrictShapeTypeChecker};/**
   * inlined Object.is polyfill to avoid requiring consumers ship their own
   * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
   */ /*eslint-disable no-self-compare*/function is(x,y){// SameValue algorithm
if(x===y){// Steps 1-5, 7-10
// Steps 6.b-6.e: +0 != -0
return x!==0||1/x===1/y;}else{// Step 6.a: NaN == NaN
return x!==x&&y!==y;}}/*eslint-enable no-self-compare*/ /**
   * We use an Error-like object for backward compatibility as people may call
   * PropTypes directly and inspect their output. However, we don't use real
   * Errors anymore. We don't inspect their stack anyway, and creating them
   * is prohibitively expensive if they are created too often, such as what
   * happens in oneOfType() for any type before the one that matched.
   */function PropTypeError(message){this.message=message;this.stack='';}// Make `instanceof Error` still work for returned errors.
PropTypeError.prototype=Error.prototype;function createChainableTypeChecker(validate){if(false){var manualPropTypeCallCache={};var manualPropTypeWarningCount=0;}function checkType(isRequired,props,propName,componentName,location,propFullName,secret){componentName=componentName||ANONYMOUS;propFullName=propFullName||propName;if(secret!==ReactPropTypesSecret_1){if(throwOnDirectAccess){// New behavior only for users of `prop-types` package
invariant_1(false,'Calling PropTypes validators directly is not supported by the `prop-types` package. '+'Use `PropTypes.checkPropTypes()` to call them. '+'Read more at http://fb.me/use-check-prop-types');}else if(false){// Old behavior for people using React.PropTypes
var cacheKey=componentName+':'+propName;if(!manualPropTypeCallCache[cacheKey]&&// Avoid spamming the console because they are often not actionable except for lib authors
manualPropTypeWarningCount<3){warning_1(false,'You are manually calling a React.PropTypes validation '+'function for the `%s` prop on `%s`. This is deprecated '+'and will throw in the standalone `prop-types` package. '+'You may be seeing this warning due to a third-party PropTypes '+'library. See https://fb.me/react-warning-dont-call-proptypes '+'for details.',propFullName,componentName);manualPropTypeCallCache[cacheKey]=true;manualPropTypeWarningCount++;}}}if(props[propName]==null){if(isRequired){if(props[propName]===null){return new PropTypeError('The '+location+' `'+propFullName+'` is marked as required '+('in `'+componentName+'`, but its value is `null`.'));}return new PropTypeError('The '+location+' `'+propFullName+'` is marked as required in '+('`'+componentName+'`, but its value is `undefined`.'));}return null;}else{return validate(props,propName,componentName,location,propFullName);}}var chainedCheckType=checkType.bind(null,false);chainedCheckType.isRequired=checkType.bind(null,true);return chainedCheckType;}function createPrimitiveTypeChecker(expectedType){function validate(props,propName,componentName,location,propFullName,secret){var propValue=props[propName];var propType=getPropType(propValue);if(propType!==expectedType){// `propValue` being instance of, say, date/regexp, pass the 'object'
// check, but we can offer a more precise error message here rather than
// 'of type `object`'.
var preciseType=getPreciseType(propValue);return new PropTypeError('Invalid '+location+' `'+propFullName+'` of type '+('`'+preciseType+'` supplied to `'+componentName+'`, expected ')+('`'+expectedType+'`.'));}return null;}return createChainableTypeChecker(validate);}function createAnyTypeChecker(){return createChainableTypeChecker(emptyFunction_1.thatReturnsNull);}function createArrayOfTypeChecker(typeChecker){function validate(props,propName,componentName,location,propFullName){if(typeof typeChecker!=='function'){return new PropTypeError('Property `'+propFullName+'` of component `'+componentName+'` has invalid PropType notation inside arrayOf.');}var propValue=props[propName];if(!Array.isArray(propValue)){var propType=getPropType(propValue);return new PropTypeError('Invalid '+location+' `'+propFullName+'` of type '+('`'+propType+'` supplied to `'+componentName+'`, expected an array.'));}for(var i=0;i<propValue.length;i++){var error=typeChecker(propValue,i,componentName,location,propFullName+'['+i+']',ReactPropTypesSecret_1);if(error instanceof Error){return error;}}return null;}return createChainableTypeChecker(validate);}function createElementTypeChecker(){function validate(props,propName,componentName,location,propFullName){var propValue=props[propName];if(!isValidElement(propValue)){var propType=getPropType(propValue);return new PropTypeError('Invalid '+location+' `'+propFullName+'` of type '+('`'+propType+'` supplied to `'+componentName+'`, expected a single ReactElement.'));}return null;}return createChainableTypeChecker(validate);}function createInstanceTypeChecker(expectedClass){function validate(props,propName,componentName,location,propFullName){if(!(props[propName]instanceof expectedClass)){var expectedClassName=expectedClass.name||ANONYMOUS;var actualClassName=getClassName(props[propName]);return new PropTypeError('Invalid '+location+' `'+propFullName+'` of type '+('`'+actualClassName+'` supplied to `'+componentName+'`, expected ')+('instance of `'+expectedClassName+'`.'));}return null;}return createChainableTypeChecker(validate);}function createEnumTypeChecker(expectedValues){if(!Array.isArray(expectedValues)){ false?warning_1(false,'Invalid argument supplied to oneOf, expected an instance of array.'):void 0;return emptyFunction_1.thatReturnsNull;}function validate(props,propName,componentName,location,propFullName){var propValue=props[propName];for(var i=0;i<expectedValues.length;i++){if(is(propValue,expectedValues[i])){return null;}}var valuesString=JSON.stringify(expectedValues);return new PropTypeError('Invalid '+location+' `'+propFullName+'` of value `'+propValue+'` '+('supplied to `'+componentName+'`, expected one of '+valuesString+'.'));}return createChainableTypeChecker(validate);}function createObjectOfTypeChecker(typeChecker){function validate(props,propName,componentName,location,propFullName){if(typeof typeChecker!=='function'){return new PropTypeError('Property `'+propFullName+'` of component `'+componentName+'` has invalid PropType notation inside objectOf.');}var propValue=props[propName];var propType=getPropType(propValue);if(propType!=='object'){return new PropTypeError('Invalid '+location+' `'+propFullName+'` of type '+('`'+propType+'` supplied to `'+componentName+'`, expected an object.'));}for(var key in propValue){if(propValue.hasOwnProperty(key)){var error=typeChecker(propValue,key,componentName,location,propFullName+'.'+key,ReactPropTypesSecret_1);if(error instanceof Error){return error;}}}return null;}return createChainableTypeChecker(validate);}function createUnionTypeChecker(arrayOfTypeCheckers){if(!Array.isArray(arrayOfTypeCheckers)){ false?warning_1(false,'Invalid argument supplied to oneOfType, expected an instance of array.'):void 0;return emptyFunction_1.thatReturnsNull;}for(var i=0;i<arrayOfTypeCheckers.length;i++){var checker=arrayOfTypeCheckers[i];if(typeof checker!=='function'){warning_1(false,'Invalid argument supplied to oneOfType. Expected an array of check functions, but '+'received %s at index %s.',getPostfixForTypeWarning(checker),i);return emptyFunction_1.thatReturnsNull;}}function validate(props,propName,componentName,location,propFullName){for(var i=0;i<arrayOfTypeCheckers.length;i++){var checker=arrayOfTypeCheckers[i];if(checker(props,propName,componentName,location,propFullName,ReactPropTypesSecret_1)==null){return null;}}return new PropTypeError('Invalid '+location+' `'+propFullName+'` supplied to '+('`'+componentName+'`.'));}return createChainableTypeChecker(validate);}function createNodeChecker(){function validate(props,propName,componentName,location,propFullName){if(!isNode(props[propName])){return new PropTypeError('Invalid '+location+' `'+propFullName+'` supplied to '+('`'+componentName+'`, expected a ReactNode.'));}return null;}return createChainableTypeChecker(validate);}function createShapeTypeChecker(shapeTypes){function validate(props,propName,componentName,location,propFullName){var propValue=props[propName];var propType=getPropType(propValue);if(propType!=='object'){return new PropTypeError('Invalid '+location+' `'+propFullName+'` of type `'+propType+'` '+('supplied to `'+componentName+'`, expected `object`.'));}for(var key in shapeTypes){var checker=shapeTypes[key];if(!checker){continue;}var error=checker(propValue,key,componentName,location,propFullName+'.'+key,ReactPropTypesSecret_1);if(error){return error;}}return null;}return createChainableTypeChecker(validate);}function createStrictShapeTypeChecker(shapeTypes){function validate(props,propName,componentName,location,propFullName){var propValue=props[propName];var propType=getPropType(propValue);if(propType!=='object'){return new PropTypeError('Invalid '+location+' `'+propFullName+'` of type `'+propType+'` '+('supplied to `'+componentName+'`, expected `object`.'));}// We need to check all keys in case some are required but missing from
// props.
var allKeys=objectAssign({},props[propName],shapeTypes);for(var key in allKeys){var checker=shapeTypes[key];if(!checker){return new PropTypeError('Invalid '+location+' `'+propFullName+'` key `'+key+'` supplied to `'+componentName+'`.'+'\nBad object: '+JSON.stringify(props[propName],null,'  ')+'\nValid keys: '+JSON.stringify(Object.keys(shapeTypes),null,'  '));}var error=checker(propValue,key,componentName,location,propFullName+'.'+key,ReactPropTypesSecret_1);if(error){return error;}}return null;}return createChainableTypeChecker(validate);}function isNode(propValue){switch(typeof propValue){case'number':case'string':case'undefined':return true;case'boolean':return!propValue;case'object':if(Array.isArray(propValue)){return propValue.every(isNode);}if(propValue===null||isValidElement(propValue)){return true;}var iteratorFn=getIteratorFn(propValue);if(iteratorFn){var iterator=iteratorFn.call(propValue);var step;if(iteratorFn!==propValue.entries){while(!(step=iterator.next()).done){if(!isNode(step.value)){return false;}}}else{// Iterator will provide entry [k,v] tuples rather than values.
while(!(step=iterator.next()).done){var entry=step.value;if(entry){if(!isNode(entry[1])){return false;}}}}}else{return false;}return true;default:return false;}}function isSymbol(propType,propValue){// Native Symbol.
if(propType==='symbol'){return true;}// 19.4.3.5 Symbol.prototype[@@toStringTag] === 'Symbol'
if(propValue['@@toStringTag']==='Symbol'){return true;}// Fallback for non-spec compliant Symbols which are polyfilled.
if(typeof Symbol==='function'&&propValue instanceof Symbol){return true;}return false;}// Equivalent of `typeof` but with special handling for array and regexp.
function getPropType(propValue){var propType=typeof propValue;if(Array.isArray(propValue)){return'array';}if(propValue instanceof RegExp){// Old webkits (at least until Android 4.0) return 'function' rather than
// 'object' for typeof a RegExp. We'll normalize this here so that /bla/
// passes PropTypes.object.
return'object';}if(isSymbol(propType,propValue)){return'symbol';}return propType;}// This handles more types than `getPropType`. Only used for error messages.
// See `createPrimitiveTypeChecker`.
function getPreciseType(propValue){if(typeof propValue==='undefined'||propValue===null){return''+propValue;}var propType=getPropType(propValue);if(propType==='object'){if(propValue instanceof Date){return'date';}else if(propValue instanceof RegExp){return'regexp';}}return propType;}// Returns a string that is postfixed to a warning about an invalid type.
// For example, "undefined" or "of type array"
function getPostfixForTypeWarning(value){var type=getPreciseType(value);switch(type){case'array':case'object':return'an '+type;case'boolean':case'date':case'regexp':return'a '+type;default:return type;}}// Returns class name of the object, if any.
function getClassName(propValue){if(!propValue.constructor||!propValue.constructor.name){return ANONYMOUS;}return propValue.constructor.name;}ReactPropTypes.checkPropTypes=checkPropTypes_1;ReactPropTypes.PropTypes=ReactPropTypes;return ReactPropTypes;};var factoryWithThrowingShims=function(){function shim(props,propName,componentName,location,propFullName,secret){if(secret===ReactPropTypesSecret_1){// It is still safe when called from React.
return;}invariant_1(false,'Calling PropTypes validators directly is not supported by the `prop-types` package. '+'Use PropTypes.checkPropTypes() to call them. '+'Read more at http://fb.me/use-check-prop-types');}shim.isRequired=shim;function getShim(){return shim;}// Important!
// Keep this list in sync with production version in `./factoryWithTypeCheckers.js`.
var ReactPropTypes={array:shim,bool:shim,func:shim,number:shim,object:shim,string:shim,symbol:shim,any:shim,arrayOf:getShim,element:shim,instanceOf:getShim,node:shim,objectOf:getShim,oneOf:getShim,oneOfType:getShim,shape:getShim,exact:getShim};ReactPropTypes.checkPropTypes=emptyFunction_1;ReactPropTypes.PropTypes=ReactPropTypes;return ReactPropTypes;};var propTypes=createCommonjsModule(function(module){/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */if(false){var REACT_ELEMENT_TYPE=typeof Symbol==='function'&&Symbol.for&&Symbol.for('react.element')||0xeac7;var isValidElement=function(object){return typeof object==='object'&&object!==null&&object.$$typeof===REACT_ELEMENT_TYPE;};// By explicitly using `prop-types` you are opting into new development behavior.
// http://fb.me/prop-types-in-prod
var throwOnDirectAccess=true;module.exports=factoryWithTypeCheckers(isValidElement,throwOnDirectAccess);}else{// By explicitly using `prop-types` you are opting into new production behavior.
// http://fb.me/prop-types-in-prod
module.exports=factoryWithThrowingShims();}});var CONSTANT={GLOBAL:{HIDE:"__react_tooltip_hide_event",REBUILD:"__react_tooltip_rebuild_event",SHOW:"__react_tooltip_show_event"}};/**
 * Static methods for react-tooltip
 */var dispatchGlobalEvent=function dispatchGlobalEvent(eventName,opts){// Compatible with IE
// @see http://stackoverflow.com/questions/26596123/internet-explorer-9-10-11-event-constructor-doesnt-work
var event;if(typeof window.CustomEvent==="function"){event=new window.CustomEvent(eventName,{detail:opts});}else{event=document.createEvent("Event");event.initEvent(eventName,false,true);event.detail=opts;}window.dispatchEvent(event);};function staticMethods(target){/**
   * Hide all tooltip
   * @trigger ReactTooltip.hide()
   */target.hide=function(target){dispatchGlobalEvent(CONSTANT.GLOBAL.HIDE,{target:target});};/**
   * Rebuild all tooltip
   * @trigger ReactTooltip.rebuild()
   */target.rebuild=function(){dispatchGlobalEvent(CONSTANT.GLOBAL.REBUILD);};/**
   * Show specific tooltip
   * @trigger ReactTooltip.show()
   */target.show=function(target){dispatchGlobalEvent(CONSTANT.GLOBAL.SHOW,{target:target});};target.prototype.globalRebuild=function(){if(this.mount){this.unbindListener();this.bindListener();}};target.prototype.globalShow=function(event){if(this.mount){// Create a fake event, specific show will limit the type to `solid`
// only `float` type cares e.clientX e.clientY
var e={currentTarget:event.detail.target};this.showTooltip(e,true);}};target.prototype.globalHide=function(event){if(this.mount){var hasTarget=event&&event.detail&&event.detail.target&&true||false;this.hideTooltip({currentTarget:hasTarget&&event.detail.target},hasTarget);}};}/**
 * Events that should be bound to the window
 */function windowListener(target){target.prototype.bindWindowEvents=function(resizeHide){// ReactTooltip.hide
window.removeEventListener(CONSTANT.GLOBAL.HIDE,this.globalHide);window.addEventListener(CONSTANT.GLOBAL.HIDE,this.globalHide,false);// ReactTooltip.rebuild
window.removeEventListener(CONSTANT.GLOBAL.REBUILD,this.globalRebuild);window.addEventListener(CONSTANT.GLOBAL.REBUILD,this.globalRebuild,false);// ReactTooltip.show
window.removeEventListener(CONSTANT.GLOBAL.SHOW,this.globalShow);window.addEventListener(CONSTANT.GLOBAL.SHOW,this.globalShow,false);// Resize
if(resizeHide){window.removeEventListener("resize",this.onWindowResize);window.addEventListener("resize",this.onWindowResize,false);}};target.prototype.unbindWindowEvents=function(){window.removeEventListener(CONSTANT.GLOBAL.HIDE,this.globalHide);window.removeEventListener(CONSTANT.GLOBAL.REBUILD,this.globalRebuild);window.removeEventListener(CONSTANT.GLOBAL.SHOW,this.globalShow);window.removeEventListener("resize",this.onWindowResize);};/**
   * invoked by resize event of window
   */target.prototype.onWindowResize=function(){if(!this.mount)return;this.hideTooltip();};}/**
 * Custom events to control showing and hiding of tooltip
 *
 * @attributes
 * - `event` {String}
 * - `eventOff` {String}
 */var checkStatus=function checkStatus(dataEventOff,e){var show=this.state.show;var id=this.props.id;var isCapture=this.isCapture(e.currentTarget);var currentItem=e.currentTarget.getAttribute("currentItem");if(!isCapture)e.stopPropagation();if(show&&currentItem==="true"){if(!dataEventOff)this.hideTooltip(e);}else{e.currentTarget.setAttribute("currentItem","true");setUntargetItems(e.currentTarget,this.getTargetArray(id));this.showTooltip(e);}};var setUntargetItems=function setUntargetItems(currentTarget,targetArray){for(var i=0;i<targetArray.length;i++){if(currentTarget!==targetArray[i]){targetArray[i].setAttribute("currentItem","false");}else{targetArray[i].setAttribute("currentItem","true");}}};var customListeners={id:"9b69f92e-d3fe-498b-b1b4-c5e63a51b0cf",set:function set(target,event,listener){if(this.id in target){var map=target[this.id];map[event]=listener;}else{// this is workaround for WeakMap, which is not supported in older browsers, such as IE
Object.defineProperty(target,this.id,{configurable:true,value:_defineProperty({},event,listener)});}},get:function get(target,event){var map=target[this.id];if(map!==undefined){return map[event];}}};function customEvent(target){target.prototype.isCustomEvent=function(ele){var event=this.state.event;return event||!!ele.getAttribute("data-event");};/* Bind listener for custom event */target.prototype.customBindListener=function(ele){var _this=this;var _this$state=this.state,event=_this$state.event,eventOff=_this$state.eventOff;var dataEvent=ele.getAttribute("data-event")||event;var dataEventOff=ele.getAttribute("data-event-off")||eventOff;dataEvent.split(" ").forEach(function(event){ele.removeEventListener(event,customListeners.get(ele,event));var customListener=checkStatus.bind(_this,dataEventOff);customListeners.set(ele,event,customListener);ele.addEventListener(event,customListener,false);});if(dataEventOff){dataEventOff.split(" ").forEach(function(event){ele.removeEventListener(event,_this.hideTooltip);ele.addEventListener(event,_this.hideTooltip,false);});}};/* Unbind listener for custom event */target.prototype.customUnbindListener=function(ele){var _this$state2=this.state,event=_this$state2.event,eventOff=_this$state2.eventOff;var dataEvent=event||ele.getAttribute("data-event");var dataEventOff=eventOff||ele.getAttribute("data-event-off");ele.removeEventListener(dataEvent,customListeners.get(ele,event));if(dataEventOff)ele.removeEventListener(dataEventOff,this.hideTooltip);};}/**
 * Util method to judge if it should follow capture model
 */function isCapture(target){target.prototype.isCapture=function(currentTarget){return currentTarget&&currentTarget.getAttribute("data-iscapture")==="true"||this.props.isCapture||false;};}/**
 * Util method to get effect
 */function getEffect(target){target.prototype.getEffect=function(currentTarget){var dataEffect=currentTarget.getAttribute("data-effect");return dataEffect||this.props.effect||"float";};}/**
 * Util method to get effect
 */var makeProxy=function makeProxy(e){var proxy={};for(var key in e){if(typeof e[key]==="function"){proxy[key]=e[key].bind(e);}else{proxy[key]=e[key];}}return proxy;};var bodyListener=function bodyListener(callback,options,e){var _options$respectEffec=options.respectEffect,respectEffect=_options$respectEffec===void 0?false:_options$respectEffec,_options$customEvent=options.customEvent,customEvent=_options$customEvent===void 0?false:_options$customEvent;var id=this.props.id;var tip=e.target.getAttribute("data-tip")||null;var forId=e.target.getAttribute("data-for")||null;var target=e.target;if(this.isCustomEvent(target)&&!customEvent){return;}var isTargetBelongsToTooltip=id==null&&forId==null||forId===id;if(tip!=null&&(!respectEffect||this.getEffect(target)==="float")&&isTargetBelongsToTooltip){var proxy=makeProxy(e);proxy.currentTarget=target;callback(proxy);}};var findCustomEvents=function findCustomEvents(targetArray,dataAttribute){var events={};targetArray.forEach(function(target){var event=target.getAttribute(dataAttribute);if(event)event.split(" ").forEach(function(event){return events[event]=true;});});return events;};var getBody=function getBody(){return document.getElementsByTagName("body")[0];};function bodyMode(target){target.prototype.isBodyMode=function(){return!!this.props.bodyMode;};target.prototype.bindBodyListener=function(targetArray){var _this=this;var _this$state=this.state,event=_this$state.event,eventOff=_this$state.eventOff,possibleCustomEvents=_this$state.possibleCustomEvents,possibleCustomEventsOff=_this$state.possibleCustomEventsOff;var body=getBody();var customEvents=findCustomEvents(targetArray,"data-event");var customEventsOff=findCustomEvents(targetArray,"data-event-off");if(event!=null)customEvents[event]=true;if(eventOff!=null)customEventsOff[eventOff]=true;possibleCustomEvents.split(" ").forEach(function(event){return customEvents[event]=true;});possibleCustomEventsOff.split(" ").forEach(function(event){return customEventsOff[event]=true;});this.unbindBodyListener(body);var listeners=this.bodyModeListeners={};if(event==null){listeners.mouseover=bodyListener.bind(this,this.showTooltip,{});listeners.mousemove=bodyListener.bind(this,this.updateTooltip,{respectEffect:true});listeners.mouseout=bodyListener.bind(this,this.hideTooltip,{});}for(var _event in customEvents){listeners[_event]=bodyListener.bind(this,function(e){var targetEventOff=e.currentTarget.getAttribute("data-event-off")||eventOff;checkStatus.call(_this,targetEventOff,e);},{customEvent:true});}for(var _event2 in customEventsOff){listeners[_event2]=bodyListener.bind(this,this.hideTooltip,{customEvent:true});}for(var _event3 in listeners){body.addEventListener(_event3,listeners[_event3]);}};target.prototype.unbindBodyListener=function(body){body=body||getBody();var listeners=this.bodyModeListeners;for(var event in listeners){body.removeEventListener(event,listeners[event]);}};}/**
 * Tracking target removing from DOM.
 * It's necessary to hide tooltip when it's target disappears.
 * Otherwise, the tooltip would be shown forever until another target
 * is triggered.
 *
 * If MutationObserver is not available, this feature just doesn't work.
 */ // https://hacks.mozilla.org/2012/05/dom-mutationobserver-reacting-to-dom-changes-without-killing-browser-performance/
var getMutationObserverClass=function getMutationObserverClass(){return window.MutationObserver||window.WebKitMutationObserver||window.MozMutationObserver;};function trackRemoval(target){target.prototype.bindRemovalTracker=function(){var _this=this;var MutationObserver=getMutationObserverClass();if(MutationObserver==null)return;var observer=new MutationObserver(function(mutations){for(var m1=0;m1<mutations.length;m1++){var mutation=mutations[m1];for(var m2=0;m2<mutation.removedNodes.length;m2++){var element=mutation.removedNodes[m2];if(element===_this.state.currentTarget){_this.hideTooltip();return;}}}});observer.observe(window.document,{childList:true,subtree:true});this.removalTracker=observer;};target.prototype.unbindRemovalTracker=function(){if(this.removalTracker){this.removalTracker.disconnect();this.removalTracker=null;}};}/**
 * Calculate the position of tooltip
 *
 * @params
 * - `e` {Event} the event of current mouse
 * - `target` {Element} the currentTarget of the event
 * - `node` {DOM} the react-tooltip object
 * - `place` {String} top / right / bottom / left
 * - `effect` {String} float / solid
 * - `offset` {Object} the offset to default position
 *
 * @return {Object}
 * - `isNewState` {Bool} required
 * - `newState` {Object}
 * - `position` {Object} {left: {Number}, top: {Number}}
 */function getPosition(e,target,node,place,desiredPlace,effect,offset){var _getDimensions=getDimensions(node),tipWidth=_getDimensions.width,tipHeight=_getDimensions.height;var _getDimensions2=getDimensions(target),targetWidth=_getDimensions2.width,targetHeight=_getDimensions2.height;var _getCurrentOffset=getCurrentOffset(e,target,effect),mouseX=_getCurrentOffset.mouseX,mouseY=_getCurrentOffset.mouseY;var defaultOffset=getDefaultPosition(effect,targetWidth,targetHeight,tipWidth,tipHeight);var _calculateOffset=calculateOffset(offset),extraOffset_X=_calculateOffset.extraOffset_X,extraOffset_Y=_calculateOffset.extraOffset_Y;var windowWidth=window.innerWidth;var windowHeight=window.innerHeight;var _getParent=getParent(node),parentTop=_getParent.parentTop,parentLeft=_getParent.parentLeft;// Get the edge offset of the tooltip
var getTipOffsetLeft=function getTipOffsetLeft(place){var offset_X=defaultOffset[place].l;return mouseX+offset_X+extraOffset_X;};var getTipOffsetRight=function getTipOffsetRight(place){var offset_X=defaultOffset[place].r;return mouseX+offset_X+extraOffset_X;};var getTipOffsetTop=function getTipOffsetTop(place){var offset_Y=defaultOffset[place].t;return mouseY+offset_Y+extraOffset_Y;};var getTipOffsetBottom=function getTipOffsetBottom(place){var offset_Y=defaultOffset[place].b;return mouseY+offset_Y+extraOffset_Y;};//
// Functions to test whether the tooltip's sides are inside
// the client window for a given orientation p
//
//  _____________
// |             | <-- Right side
// | p = 'left'  |\
// |             |/  |\
// |_____________|   |_\  <-- Mouse
//      / \           |
//       |
//       |
//  Bottom side
//
var outsideLeft=function outsideLeft(p){return getTipOffsetLeft(p)<0;};var outsideRight=function outsideRight(p){return getTipOffsetRight(p)>windowWidth;};var outsideTop=function outsideTop(p){return getTipOffsetTop(p)<0;};var outsideBottom=function outsideBottom(p){return getTipOffsetBottom(p)>windowHeight;};// Check whether the tooltip with orientation p is completely inside the client window
var outside=function outside(p){return outsideLeft(p)||outsideRight(p)||outsideTop(p)||outsideBottom(p);};var inside=function inside(p){return!outside(p);};var placesList=["top","bottom","left","right"];var insideList=[];for(var i=0;i<4;i++){var p=placesList[i];if(inside(p)){insideList.push(p);}}var isNewState=false;var newPlace;var shouldUpdatePlace=desiredPlace!==place;if(inside(desiredPlace)&&shouldUpdatePlace){isNewState=true;newPlace=desiredPlace;}else if(insideList.length>0&&shouldUpdatePlace&&outside(desiredPlace)&&outside(place)){isNewState=true;newPlace=insideList[0];}if(isNewState){return{isNewState:true,newState:{place:newPlace}};}return{isNewState:false,position:{left:parseInt(getTipOffsetLeft(place)-parentLeft,10),top:parseInt(getTipOffsetTop(place)-parentTop,10)}};}var getDimensions=function getDimensions(node){var _node$getBoundingClie=node.getBoundingClientRect(),height=_node$getBoundingClie.height,width=_node$getBoundingClie.width;return{height:parseInt(height,10),width:parseInt(width,10)};};// Get current mouse offset
var getCurrentOffset=function getCurrentOffset(e,currentTarget,effect){var boundingClientRect=currentTarget.getBoundingClientRect();var targetTop=boundingClientRect.top;var targetLeft=boundingClientRect.left;var _getDimensions3=getDimensions(currentTarget),targetWidth=_getDimensions3.width,targetHeight=_getDimensions3.height;if(effect==="float"){return{mouseX:e.clientX,mouseY:e.clientY};}return{mouseX:targetLeft+targetWidth/2,mouseY:targetTop+targetHeight/2};};// List all possibility of tooltip final offset
// This is useful in judging if it is necessary for tooltip to switch position when out of window
var getDefaultPosition=function getDefaultPosition(effect,targetWidth,targetHeight,tipWidth,tipHeight){var top;var right;var bottom;var left;var disToMouse=3;var triangleHeight=2;var cursorHeight=12;// Optimize for float bottom only, cause the cursor will hide the tooltip
if(effect==="float"){top={l:-(tipWidth/2),r:tipWidth/2,t:-(tipHeight+disToMouse+triangleHeight),b:-disToMouse};bottom={l:-(tipWidth/2),r:tipWidth/2,t:disToMouse+cursorHeight,b:tipHeight+disToMouse+triangleHeight+cursorHeight};left={l:-(tipWidth+disToMouse+triangleHeight),r:-disToMouse,t:-(tipHeight/2),b:tipHeight/2};right={l:disToMouse,r:tipWidth+disToMouse+triangleHeight,t:-(tipHeight/2),b:tipHeight/2};}else if(effect==="solid"){top={l:-(tipWidth/2),r:tipWidth/2,t:-(targetHeight/2+tipHeight+triangleHeight),b:-(targetHeight/2)};bottom={l:-(tipWidth/2),r:tipWidth/2,t:targetHeight/2,b:targetHeight/2+tipHeight+triangleHeight};left={l:-(tipWidth+targetWidth/2+triangleHeight),r:-(targetWidth/2),t:-(tipHeight/2),b:tipHeight/2};right={l:targetWidth/2,r:tipWidth+targetWidth/2+triangleHeight,t:-(tipHeight/2),b:tipHeight/2};}return{top:top,bottom:bottom,left:left,right:right};};// Consider additional offset into position calculation
var calculateOffset=function calculateOffset(offset){var extraOffset_X=0;var extraOffset_Y=0;if(Object.prototype.toString.apply(offset)==="[object String]"){offset=JSON.parse(offset.toString().replace(/\'/g,'"'));}for(var key in offset){if(key==="top"){extraOffset_Y-=parseInt(offset[key],10);}else if(key==="bottom"){extraOffset_Y+=parseInt(offset[key],10);}else if(key==="left"){extraOffset_X-=parseInt(offset[key],10);}else if(key==="right"){extraOffset_X+=parseInt(offset[key],10);}}return{extraOffset_X:extraOffset_X,extraOffset_Y:extraOffset_Y};};// Get the offset of the parent elements
var getParent=function getParent(currentTarget){var currentParent=currentTarget;while(currentParent){if(window.getComputedStyle(currentParent).getPropertyValue("transform")!=="none")break;currentParent=currentParent.parentElement;}var parentTop=currentParent&&currentParent.getBoundingClientRect().top||0;var parentLeft=currentParent&&currentParent.getBoundingClientRect().left||0;return{parentTop:parentTop,parentLeft:parentLeft};};/**
 * To get the tooltip content
 * it may comes from data-tip or this.props.children
 * it should support multiline
 *
 * @params
 * - `tip` {String} value of data-tip
 * - `children` {ReactElement} this.props.children
 * - `multiline` {Any} could be Bool(true/false) or String('true'/'false')
 *
 * @return
 * - String or react component
 */function getTipContent(tip,children,getContent,multiline){if(children)return children;if(getContent!==undefined&&getContent!==null)return getContent;// getContent can be 0, '', etc.
if(getContent===null)return null;// Tip not exist and children is null or undefined
var regexp=/<br\s*\/?>/;if(!multiline||multiline==="false"||!regexp.test(tip)){// No trim(), so that user can keep their input
return tip;}// Multiline tooltip content
return tip.split(regexp).map(function(d,i){return _react.default.createElement("span",{key:i,className:"multi-line"},d);});}/**
 * Support aria- and role in ReactTooltip
 *
 * @params props {Object}
 * @return {Object}
 */function parseAria(props){var ariaObj={};Object.keys(props).filter(function(prop){// aria-xxx and role is acceptable
return /(^aria-\w+$|^role$)/.test(prop);}).forEach(function(prop){ariaObj[prop]=props[prop];});return ariaObj;}/**
 * Convert nodelist to array
 * @see https://github.com/facebook/fbjs/blob/e66ba20ad5be433eb54423f2b097d829324d9de6/packages/fbjs/src/core/createArrayFromMixed.js#L24
 * NodeLists are functions in Safari
 */function nodeListToArray(nodeList){var length=nodeList.length;if(nodeList.hasOwnProperty){return Array.prototype.slice.call(nodeList);}return new Array(length).fill().map(function(index){return nodeList[index];});}___$insertStyle(".__react_component_tooltip {\n  border-radius: 3px;\n  display: inline-block;\n  font-size: 13px;\n  left: -999em;\n  opacity: 0;\n  padding: 8px 21px;\n  position: fixed;\n  pointer-events: none;\n  transition: opacity 0.3s ease-out;\n  top: -999em;\n  visibility: hidden;\n  z-index: 999;\n}\n.__react_component_tooltip.allow_hover, .__react_component_tooltip.allow_click {\n  pointer-events: auto;\n}\n.__react_component_tooltip:before, .__react_component_tooltip:after {\n  content: \"\";\n  width: 0;\n  height: 0;\n  position: absolute;\n}\n.__react_component_tooltip.show {\n  opacity: 0.9;\n  margin-top: 0px;\n  margin-left: 0px;\n  visibility: visible;\n}\n.__react_component_tooltip.type-dark {\n  color: #fff;\n  background-color: #222;\n}\n.__react_component_tooltip.type-dark.place-top:after {\n  border-top-color: #222;\n  border-top-style: solid;\n  border-top-width: 6px;\n}\n.__react_component_tooltip.type-dark.place-bottom:after {\n  border-bottom-color: #222;\n  border-bottom-style: solid;\n  border-bottom-width: 6px;\n}\n.__react_component_tooltip.type-dark.place-left:after {\n  border-left-color: #222;\n  border-left-style: solid;\n  border-left-width: 6px;\n}\n.__react_component_tooltip.type-dark.place-right:after {\n  border-right-color: #222;\n  border-right-style: solid;\n  border-right-width: 6px;\n}\n.__react_component_tooltip.type-dark.border {\n  border: 1px solid #fff;\n}\n.__react_component_tooltip.type-dark.border.place-top:before {\n  border-top: 8px solid #fff;\n}\n.__react_component_tooltip.type-dark.border.place-bottom:before {\n  border-bottom: 8px solid #fff;\n}\n.__react_component_tooltip.type-dark.border.place-left:before {\n  border-left: 8px solid #fff;\n}\n.__react_component_tooltip.type-dark.border.place-right:before {\n  border-right: 8px solid #fff;\n}\n.__react_component_tooltip.type-success {\n  color: #fff;\n  background-color: #8DC572;\n}\n.__react_component_tooltip.type-success.place-top:after {\n  border-top-color: #8DC572;\n  border-top-style: solid;\n  border-top-width: 6px;\n}\n.__react_component_tooltip.type-success.place-bottom:after {\n  border-bottom-color: #8DC572;\n  border-bottom-style: solid;\n  border-bottom-width: 6px;\n}\n.__react_component_tooltip.type-success.place-left:after {\n  border-left-color: #8DC572;\n  border-left-style: solid;\n  border-left-width: 6px;\n}\n.__react_component_tooltip.type-success.place-right:after {\n  border-right-color: #8DC572;\n  border-right-style: solid;\n  border-right-width: 6px;\n}\n.__react_component_tooltip.type-success.border {\n  border: 1px solid #fff;\n}\n.__react_component_tooltip.type-success.border.place-top:before {\n  border-top: 8px solid #fff;\n}\n.__react_component_tooltip.type-success.border.place-bottom:before {\n  border-bottom: 8px solid #fff;\n}\n.__react_component_tooltip.type-success.border.place-left:before {\n  border-left: 8px solid #fff;\n}\n.__react_component_tooltip.type-success.border.place-right:before {\n  border-right: 8px solid #fff;\n}\n.__react_component_tooltip.type-warning {\n  color: #fff;\n  background-color: #F0AD4E;\n}\n.__react_component_tooltip.type-warning.place-top:after {\n  border-top-color: #F0AD4E;\n  border-top-style: solid;\n  border-top-width: 6px;\n}\n.__react_component_tooltip.type-warning.place-bottom:after {\n  border-bottom-color: #F0AD4E;\n  border-bottom-style: solid;\n  border-bottom-width: 6px;\n}\n.__react_component_tooltip.type-warning.place-left:after {\n  border-left-color: #F0AD4E;\n  border-left-style: solid;\n  border-left-width: 6px;\n}\n.__react_component_tooltip.type-warning.place-right:after {\n  border-right-color: #F0AD4E;\n  border-right-style: solid;\n  border-right-width: 6px;\n}\n.__react_component_tooltip.type-warning.border {\n  border: 1px solid #fff;\n}\n.__react_component_tooltip.type-warning.border.place-top:before {\n  border-top: 8px solid #fff;\n}\n.__react_component_tooltip.type-warning.border.place-bottom:before {\n  border-bottom: 8px solid #fff;\n}\n.__react_component_tooltip.type-warning.border.place-left:before {\n  border-left: 8px solid #fff;\n}\n.__react_component_tooltip.type-warning.border.place-right:before {\n  border-right: 8px solid #fff;\n}\n.__react_component_tooltip.type-error {\n  color: #fff;\n  background-color: #BE6464;\n}\n.__react_component_tooltip.type-error.place-top:after {\n  border-top-color: #BE6464;\n  border-top-style: solid;\n  border-top-width: 6px;\n}\n.__react_component_tooltip.type-error.place-bottom:after {\n  border-bottom-color: #BE6464;\n  border-bottom-style: solid;\n  border-bottom-width: 6px;\n}\n.__react_component_tooltip.type-error.place-left:after {\n  border-left-color: #BE6464;\n  border-left-style: solid;\n  border-left-width: 6px;\n}\n.__react_component_tooltip.type-error.place-right:after {\n  border-right-color: #BE6464;\n  border-right-style: solid;\n  border-right-width: 6px;\n}\n.__react_component_tooltip.type-error.border {\n  border: 1px solid #fff;\n}\n.__react_component_tooltip.type-error.border.place-top:before {\n  border-top: 8px solid #fff;\n}\n.__react_component_tooltip.type-error.border.place-bottom:before {\n  border-bottom: 8px solid #fff;\n}\n.__react_component_tooltip.type-error.border.place-left:before {\n  border-left: 8px solid #fff;\n}\n.__react_component_tooltip.type-error.border.place-right:before {\n  border-right: 8px solid #fff;\n}\n.__react_component_tooltip.type-info {\n  color: #fff;\n  background-color: #337AB7;\n}\n.__react_component_tooltip.type-info.place-top:after {\n  border-top-color: #337AB7;\n  border-top-style: solid;\n  border-top-width: 6px;\n}\n.__react_component_tooltip.type-info.place-bottom:after {\n  border-bottom-color: #337AB7;\n  border-bottom-style: solid;\n  border-bottom-width: 6px;\n}\n.__react_component_tooltip.type-info.place-left:after {\n  border-left-color: #337AB7;\n  border-left-style: solid;\n  border-left-width: 6px;\n}\n.__react_component_tooltip.type-info.place-right:after {\n  border-right-color: #337AB7;\n  border-right-style: solid;\n  border-right-width: 6px;\n}\n.__react_component_tooltip.type-info.border {\n  border: 1px solid #fff;\n}\n.__react_component_tooltip.type-info.border.place-top:before {\n  border-top: 8px solid #fff;\n}\n.__react_component_tooltip.type-info.border.place-bottom:before {\n  border-bottom: 8px solid #fff;\n}\n.__react_component_tooltip.type-info.border.place-left:before {\n  border-left: 8px solid #fff;\n}\n.__react_component_tooltip.type-info.border.place-right:before {\n  border-right: 8px solid #fff;\n}\n.__react_component_tooltip.type-light {\n  color: #222;\n  background-color: #fff;\n}\n.__react_component_tooltip.type-light.place-top:after {\n  border-top-color: #fff;\n  border-top-style: solid;\n  border-top-width: 6px;\n}\n.__react_component_tooltip.type-light.place-bottom:after {\n  border-bottom-color: #fff;\n  border-bottom-style: solid;\n  border-bottom-width: 6px;\n}\n.__react_component_tooltip.type-light.place-left:after {\n  border-left-color: #fff;\n  border-left-style: solid;\n  border-left-width: 6px;\n}\n.__react_component_tooltip.type-light.place-right:after {\n  border-right-color: #fff;\n  border-right-style: solid;\n  border-right-width: 6px;\n}\n.__react_component_tooltip.type-light.border {\n  border: 1px solid #222;\n}\n.__react_component_tooltip.type-light.border.place-top:before {\n  border-top: 8px solid #222;\n}\n.__react_component_tooltip.type-light.border.place-bottom:before {\n  border-bottom: 8px solid #222;\n}\n.__react_component_tooltip.type-light.border.place-left:before {\n  border-left: 8px solid #222;\n}\n.__react_component_tooltip.type-light.border.place-right:before {\n  border-right: 8px solid #222;\n}\n.__react_component_tooltip.place-top {\n  margin-top: -10px;\n}\n.__react_component_tooltip.place-top:before {\n  border-left: 10px solid transparent;\n  border-right: 10px solid transparent;\n  bottom: -8px;\n  left: 50%;\n  margin-left: -10px;\n}\n.__react_component_tooltip.place-top:after {\n  border-left: 8px solid transparent;\n  border-right: 8px solid transparent;\n  bottom: -6px;\n  left: 50%;\n  margin-left: -8px;\n}\n.__react_component_tooltip.place-bottom {\n  margin-top: 10px;\n}\n.__react_component_tooltip.place-bottom:before {\n  border-left: 10px solid transparent;\n  border-right: 10px solid transparent;\n  top: -8px;\n  left: 50%;\n  margin-left: -10px;\n}\n.__react_component_tooltip.place-bottom:after {\n  border-left: 8px solid transparent;\n  border-right: 8px solid transparent;\n  top: -6px;\n  left: 50%;\n  margin-left: -8px;\n}\n.__react_component_tooltip.place-left {\n  margin-left: -10px;\n}\n.__react_component_tooltip.place-left:before {\n  border-top: 6px solid transparent;\n  border-bottom: 6px solid transparent;\n  right: -8px;\n  top: 50%;\n  margin-top: -5px;\n}\n.__react_component_tooltip.place-left:after {\n  border-top: 5px solid transparent;\n  border-bottom: 5px solid transparent;\n  right: -6px;\n  top: 50%;\n  margin-top: -4px;\n}\n.__react_component_tooltip.place-right {\n  margin-left: 10px;\n}\n.__react_component_tooltip.place-right:before {\n  border-top: 6px solid transparent;\n  border-bottom: 6px solid transparent;\n  left: -8px;\n  top: 50%;\n  margin-top: -5px;\n}\n.__react_component_tooltip.place-right:after {\n  border-top: 5px solid transparent;\n  border-bottom: 5px solid transparent;\n  left: -6px;\n  top: 50%;\n  margin-top: -4px;\n}\n.__react_component_tooltip .multi-line {\n  display: block;\n  padding: 2px 0px;\n  text-align: center;\n}");var _class,_class2,_temp;var ReactTooltip=staticMethods(_class=windowListener(_class=customEvent(_class=isCapture(_class=getEffect(_class=bodyMode(_class=trackRemoval(_class=(_temp=_class2=/*#__PURE__*/function(_React$Component){_inherits(ReactTooltip,_React$Component);function ReactTooltip(props){var _this;_classCallCheck(this,ReactTooltip);_this=_possibleConstructorReturn(this,_getPrototypeOf(ReactTooltip).call(this,props));_this.state={place:props.place||"top",// Direction of tooltip
desiredPlace:props.place||"top",type:"dark",// Color theme of tooltip
effect:"float",// float or fixed
show:false,border:false,offset:{},extraClass:"",html:false,delayHide:0,delayShow:0,event:props.event||null,eventOff:props.eventOff||null,currentEvent:null,// Current mouse event
currentTarget:null,// Current target of mouse event
ariaProps:parseAria(props),// aria- and role attributes
isEmptyTip:false,disable:false,possibleCustomEvents:props.possibleCustomEvents||"",possibleCustomEventsOff:props.possibleCustomEventsOff||"",originTooltip:null,isMultiline:false};_this.bind(["showTooltip","updateTooltip","hideTooltip","hideTooltipOnScroll","getTooltipContent","globalRebuild","globalShow","globalHide","onWindowResize","mouseOnToolTip"]);_this.mount=true;_this.delayShowLoop=null;_this.delayHideLoop=null;_this.delayReshow=null;_this.intervalUpdateContent=null;return _this;}/**
   * For unify the bind and unbind listener
   */_createClass(ReactTooltip,[{key:"bind",value:function bind(methodArray){var _this2=this;methodArray.forEach(function(method){_this2[method]=_this2[method].bind(_this2);});}},{key:"componentDidMount",value:function componentDidMount(){var _this$props=this.props,insecure=_this$props.insecure,resizeHide=_this$props.resizeHide;this.bindListener();// Bind listener for tooltip
this.bindWindowEvents(resizeHide);// Bind global event for static method
}},{key:"componentWillUnmount",value:function componentWillUnmount(){this.mount=false;this.clearTimer();this.unbindListener();this.removeScrollListener();this.unbindWindowEvents();}/**
     * Return if the mouse is on the tooltip.
     * @returns {boolean} true - mouse is on the tooltip
     */},{key:"mouseOnToolTip",value:function mouseOnToolTip(){var show=this.state.show;if(show&&this.tooltipRef){/* old IE or Firefox work around */if(!this.tooltipRef.matches){/* old IE work around */if(this.tooltipRef.msMatchesSelector){this.tooltipRef.matches=this.tooltipRef.msMatchesSelector;}else{/* old Firefox work around */this.tooltipRef.matches=this.tooltipRef.mozMatchesSelector;}}return this.tooltipRef.matches(":hover");}return false;}/**
     * Pick out corresponded target elements
     */},{key:"getTargetArray",value:function getTargetArray(id){var targetArray;if(!id){targetArray=document.querySelectorAll("[data-tip]:not([data-for])");}else{var escaped=id.replace(/\\/g,"\\\\").replace(/"/g,'\\"');targetArray=document.querySelectorAll("[data-tip][data-for=\"".concat(escaped,"\"]"));}// targetArray is a NodeList, convert it to a real array
return nodeListToArray(targetArray);}/**
     * Bind listener to the target elements
     * These listeners used to trigger showing or hiding the tooltip
     */},{key:"bindListener",value:function bindListener(){var _this3=this;var _this$props2=this.props,id=_this$props2.id,globalEventOff=_this$props2.globalEventOff,isCapture=_this$props2.isCapture;var targetArray=this.getTargetArray(id);targetArray.forEach(function(target){if(target.getAttribute("currentItem")===null){target.setAttribute("currentItem","false");}_this3.unbindBasicListener(target);if(_this3.isCustomEvent(target)){_this3.customUnbindListener(target);}});if(this.isBodyMode()){this.bindBodyListener(targetArray);}else{targetArray.forEach(function(target){var isCaptureMode=_this3.isCapture(target);var effect=_this3.getEffect(target);if(_this3.isCustomEvent(target)){_this3.customBindListener(target);return;}target.addEventListener("mouseenter",_this3.showTooltip,isCaptureMode);if(effect==="float"){target.addEventListener("mousemove",_this3.updateTooltip,isCaptureMode);}target.addEventListener("mouseleave",_this3.hideTooltip,isCaptureMode);});}// Global event to hide tooltip
if(globalEventOff){window.removeEventListener(globalEventOff,this.hideTooltip);window.addEventListener(globalEventOff,this.hideTooltip,isCapture);}// Track removal of targetArray elements from DOM
this.bindRemovalTracker();}/**
     * Unbind listeners on target elements
     */},{key:"unbindListener",value:function unbindListener(){var _this4=this;var _this$props3=this.props,id=_this$props3.id,globalEventOff=_this$props3.globalEventOff;if(this.isBodyMode()){this.unbindBodyListener();}else{var targetArray=this.getTargetArray(id);targetArray.forEach(function(target){_this4.unbindBasicListener(target);if(_this4.isCustomEvent(target))_this4.customUnbindListener(target);});}if(globalEventOff)window.removeEventListener(globalEventOff,this.hideTooltip);this.unbindRemovalTracker();}/**
     * Invoke this before bind listener and unmount the component
     * it is necessary to invoke this even when binding custom event
     * so that the tooltip can switch between custom and default listener
     */},{key:"unbindBasicListener",value:function unbindBasicListener(target){var isCaptureMode=this.isCapture(target);target.removeEventListener("mouseenter",this.showTooltip,isCaptureMode);target.removeEventListener("mousemove",this.updateTooltip,isCaptureMode);target.removeEventListener("mouseleave",this.hideTooltip,isCaptureMode);}},{key:"getTooltipContent",value:function getTooltipContent(){var _this$props4=this.props,getContent=_this$props4.getContent,children=_this$props4.children;// Generate tooltip content
var content;if(getContent){if(Array.isArray(getContent)){content=getContent[0]&&getContent[0](this.state.originTooltip);}else{content=getContent(this.state.originTooltip);}}return getTipContent(this.state.originTooltip,children,content,this.state.isMultiline);}},{key:"isEmptyTip",value:function isEmptyTip(placeholder){return typeof placeholder==="string"&&placeholder===""||placeholder===null;}/**
     * When mouse enter, show the tooltip
     */},{key:"showTooltip",value:function showTooltip(e,isGlobalCall){if(isGlobalCall){// Don't trigger other elements belongs to other ReactTooltip
var targetArray=this.getTargetArray(this.props.id);var isMyElement=targetArray.some(function(ele){return ele===e.currentTarget;});if(!isMyElement)return;}// Get the tooltip content
// calculate in this phrase so that tip width height can be detected
var _this$props5=this.props,multiline=_this$props5.multiline,getContent=_this$props5.getContent;var originTooltip=e.currentTarget.getAttribute("data-tip");var isMultiline=e.currentTarget.getAttribute("data-multiline")||multiline||false;// If it is focus event or called by ReactTooltip.show, switch to `solid` effect
var switchToSolid=e instanceof window.FocusEvent||isGlobalCall;// if it needs to skip adding hide listener to scroll
var scrollHide=true;if(e.currentTarget.getAttribute("data-scroll-hide")){scrollHide=e.currentTarget.getAttribute("data-scroll-hide")==="true";}else if(this.props.scrollHide!=null){scrollHide=this.props.scrollHide;}// Make sure the correct place is set
var desiredPlace=e.currentTarget.getAttribute("data-place")||this.props.place||"top";var effect=switchToSolid&&"solid"||this.getEffect(e.currentTarget);var offset=e.currentTarget.getAttribute("data-offset")||this.props.offset||{};var result=getPosition(e,e.currentTarget,this.tooltipRef,desiredPlace,desiredPlace,effect,offset);if(result.position&&this.props.overridePosition){result.position=this.props.overridePosition(result.position,e.currentTarget,this.tooltipRef,desiredPlace,desiredPlace,effect,offset);}var place=result.isNewState?result.newState.place:desiredPlace;// To prevent previously created timers from triggering
this.clearTimer();var target=e.currentTarget;var reshowDelay=this.state.show?target.getAttribute("data-delay-update")||this.props.delayUpdate:0;var self=this;var updateState=function updateState(){self.setState({originTooltip:originTooltip,isMultiline:isMultiline,desiredPlace:desiredPlace,place:place,type:target.getAttribute("data-type")||self.props.type||"dark",effect:effect,offset:offset,html:target.getAttribute("data-html")?target.getAttribute("data-html")==="true":self.props.html||false,delayShow:target.getAttribute("data-delay-show")||self.props.delayShow||0,delayHide:target.getAttribute("data-delay-hide")||self.props.delayHide||0,delayUpdate:target.getAttribute("data-delay-update")||self.props.delayUpdate||0,border:target.getAttribute("data-border")?target.getAttribute("data-border")==="true":self.props.border||false,extraClass:target.getAttribute("data-class")||self.props["class"]||self.props.className||"",disable:target.getAttribute("data-tip-disable")?target.getAttribute("data-tip-disable")==="true":self.props.disable||false,currentTarget:target},function(){if(scrollHide)self.addScrollListener(self.state.currentTarget);self.updateTooltip(e);if(getContent&&Array.isArray(getContent)){self.intervalUpdateContent=setInterval(function(){if(self.mount){var _getContent=self.props.getContent;var placeholder=getTipContent(originTooltip,"",_getContent[0](),isMultiline);var isEmptyTip=self.isEmptyTip(placeholder);self.setState({isEmptyTip:isEmptyTip});self.updatePosition();}},getContent[1]);}});};// If there is no delay call immediately, don't allow events to get in first.
if(reshowDelay){this.delayReshow=setTimeout(updateState,reshowDelay);}else{updateState();}}/**
     * When mouse hover, update tool tip
     */},{key:"updateTooltip",value:function updateTooltip(e){var _this5=this;var _this$state=this.state,delayShow=_this$state.delayShow,disable=_this$state.disable;var afterShow=this.props.afterShow;var placeholder=this.getTooltipContent();var delayTime=parseInt(delayShow,10);var eventTarget=e.currentTarget||e.target;// Check if the mouse is actually over the tooltip, if so don't hide the tooltip
if(this.mouseOnToolTip()){return;}if(this.isEmptyTip(placeholder)||disable)return;// if the tooltip is empty, disable the tooltip
var updateState=function updateState(){if(Array.isArray(placeholder)&&placeholder.length>0||placeholder){var isInvisible=!_this5.state.show;_this5.setState({currentEvent:e,currentTarget:eventTarget,show:true},function(){_this5.updatePosition();if(isInvisible&&afterShow)afterShow(e);});}};clearTimeout(this.delayShowLoop);if(delayShow){this.delayShowLoop=setTimeout(updateState,delayTime);}else{updateState();}}/*
     * If we're mousing over the tooltip remove it when we leave.
     */},{key:"listenForTooltipExit",value:function listenForTooltipExit(){var show=this.state.show;if(show&&this.tooltipRef){this.tooltipRef.addEventListener("mouseleave",this.hideTooltip);}}},{key:"removeListenerForTooltipExit",value:function removeListenerForTooltipExit(){var show=this.state.show;if(show&&this.tooltipRef){this.tooltipRef.removeEventListener("mouseleave",this.hideTooltip);}}/**
     * When mouse leave, hide tooltip
     */},{key:"hideTooltip",value:function hideTooltip(e,hasTarget){var _this6=this;var options=arguments.length>2&&arguments[2]!==undefined?arguments[2]:{isScroll:false};var disable=this.state.disable;var isScroll=options.isScroll;var delayHide=isScroll?0:this.state.delayHide;var afterHide=this.props.afterHide;var placeholder=this.getTooltipContent();if(!this.mount)return;if(this.isEmptyTip(placeholder)||disable)return;// if the tooltip is empty, disable the tooltip
if(hasTarget){// Don't trigger other elements belongs to other ReactTooltip
var targetArray=this.getTargetArray(this.props.id);var isMyElement=targetArray.some(function(ele){return ele===e.currentTarget;});if(!isMyElement||!this.state.show)return;}var resetState=function resetState(){var isVisible=_this6.state.show;// Check if the mouse is actually over the tooltip, if so don't hide the tooltip
if(_this6.mouseOnToolTip()){_this6.listenForTooltipExit();return;}_this6.removeListenerForTooltipExit();_this6.setState({show:false},function(){_this6.removeScrollListener();if(isVisible&&afterHide)afterHide(e);});};this.clearTimer();if(delayHide){this.delayHideLoop=setTimeout(resetState,parseInt(delayHide,10));}else{resetState();}}/**
     * When scroll, hide tooltip
     */},{key:"hideTooltipOnScroll",value:function hideTooltipOnScroll(event,hasTarget){this.hideTooltip(event,hasTarget,{isScroll:true});}/**
     * Add scroll event listener when tooltip show
     * automatically hide the tooltip when scrolling
     */},{key:"addScrollListener",value:function addScrollListener(currentTarget){var isCaptureMode=this.isCapture(currentTarget);window.addEventListener("scroll",this.hideTooltipOnScroll,isCaptureMode);}},{key:"removeScrollListener",value:function removeScrollListener(){window.removeEventListener("scroll",this.hideTooltipOnScroll);}// Calculation the position
},{key:"updatePosition",value:function updatePosition(){var _this7=this;var _this$state2=this.state,currentEvent=_this$state2.currentEvent,currentTarget=_this$state2.currentTarget,place=_this$state2.place,desiredPlace=_this$state2.desiredPlace,effect=_this$state2.effect,offset=_this$state2.offset;var node=this.tooltipRef;var result=getPosition(currentEvent,currentTarget,node,place,desiredPlace,effect,offset);if(result.position&&this.props.overridePosition){result.position=this.props.overridePosition(result.position,currentEvent,currentTarget,node,place,desiredPlace,effect,offset);}if(result.isNewState){// Switch to reverse placement
return this.setState(result.newState,function(){_this7.updatePosition();});}// Set tooltip position
node.style.left=result.position.left+"px";node.style.top=result.position.top+"px";}/**
     * Set style tag in header
     * in this way we can insert default css
     */ /* setStyleHeader() {
      const head = document.getElementsByTagName("head")[0];
      if (!head.querySelector('style[id="react-tooltip"]')) {
        const tag = document.createElement("style");
        tag.id = "react-tooltip";
        tag.innerHTML = cssStyle; */ /* eslint-disable */ /*      if (typeof __webpack_nonce__ !== 'undefined' && __webpack_nonce__) {
            tag.setAttribute('nonce', __webpack_nonce__)
          }*/ /* eslint-enable */ /*    head.insertBefore(tag, head.firstChild);
      }
    } */ /**
     * CLear all kinds of timeout of interval
     */},{key:"clearTimer",value:function clearTimer(){clearTimeout(this.delayShowLoop);clearTimeout(this.delayHideLoop);clearTimeout(this.delayReshow);clearInterval(this.intervalUpdateContent);}},{key:"render",value:function render(){var _this8=this;var _this$state3=this.state,extraClass=_this$state3.extraClass,html=_this$state3.html,ariaProps=_this$state3.ariaProps,disable=_this$state3.disable;var placeholder=this.getTooltipContent();var isEmptyTip=this.isEmptyTip(placeholder);var tooltipClass="__react_component_tooltip"+(this.state.show&&!disable&&!isEmptyTip?" show":"")+(this.state.border?" border":"")+" place-".concat(this.state.place)+// top, bottom, left, right
" type-".concat(this.state.type)+(// dark, success, warning, error, info, light
this.props.delayUpdate?" allow_hover":"")+(this.props.clickable?" allow_click":"");var Wrapper=this.props.wrapper;if(ReactTooltip.supportedWrappers.indexOf(Wrapper)<0){Wrapper=ReactTooltip.defaultProps.wrapper;}var wrapperClassName=[tooltipClass,extraClass].filter(Boolean).join(" ");if(html){return _react.default.createElement(Wrapper,_extends({className:wrapperClassName,id:this.props.id,ref:function ref(_ref){return _this8.tooltipRef=_ref;}},ariaProps,{"data-id":"tooltip",dangerouslySetInnerHTML:{__html:placeholder}}));}else{return _react.default.createElement(Wrapper,_extends({className:wrapperClassName,id:this.props.id},ariaProps,{ref:function ref(_ref2){return _this8.tooltipRef=_ref2;},"data-id":"tooltip"}),placeholder);}}}],[{key:"getDerivedStateFromProps",value:function getDerivedStateFromProps(nextProps,prevState){var ariaProps=prevState.ariaProps;var newAriaProps=parseAria(nextProps);var isChanged=Object.keys(newAriaProps).some(function(props){return newAriaProps[props]!==ariaProps[props];});if(!isChanged){return null;}return _objectSpread2({},prevState,{ariaProps:newAriaProps});}}]);return ReactTooltip;}(_react.default.Component),_defineProperty(_class2,"propTypes",{children:propTypes.any,place:propTypes.string,type:propTypes.string,effect:propTypes.string,offset:propTypes.object,multiline:propTypes.bool,border:propTypes.bool,insecure:propTypes.bool,"class":propTypes.string,className:propTypes.string,id:propTypes.string,html:propTypes.bool,delayHide:propTypes.number,delayUpdate:propTypes.number,delayShow:propTypes.number,event:propTypes.string,eventOff:propTypes.string,watchWindow:propTypes.bool,isCapture:propTypes.bool,globalEventOff:propTypes.string,getContent:propTypes.any,afterShow:propTypes.func,afterHide:propTypes.func,overridePosition:propTypes.func,disable:propTypes.bool,scrollHide:propTypes.bool,resizeHide:propTypes.bool,wrapper:propTypes.string,bodyMode:propTypes.bool,possibleCustomEvents:propTypes.string,possibleCustomEventsOff:propTypes.string,clickable:propTypes.bool}),_defineProperty(_class2,"defaultProps",{insecure:true,resizeHide:true,wrapper:"div",clickable:false}),_defineProperty(_class2,"supportedWrappers",["div","span"]),_defineProperty(_class2,"displayName","ReactTooltip"),_temp))||_class)||_class)||_class)||_class)||_class)||_class)||_class;var _default=ReactTooltip;exports.default=_default;

/***/ }),

/***/ "../../../node_modules/react/cjs/react.production.min.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/** @license React v16.13.1
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var l=__webpack_require__("../../../node_modules/object-assign/index.js"),n="function"===typeof Symbol&&Symbol.for,p=n?Symbol.for("react.element"):60103,q=n?Symbol.for("react.portal"):60106,r=n?Symbol.for("react.fragment"):60107,t=n?Symbol.for("react.strict_mode"):60108,u=n?Symbol.for("react.profiler"):60114,v=n?Symbol.for("react.provider"):60109,w=n?Symbol.for("react.context"):60110,x=n?Symbol.for("react.forward_ref"):60112,y=n?Symbol.for("react.suspense"):60113,z=n?Symbol.for("react.memo"):60115,A=n?Symbol.for("react.lazy"):60116,B="function"===typeof Symbol&&Symbol.iterator;function C(a){for(var b="https://reactjs.org/docs/error-decoder.html?invariant="+a,c=1;c<arguments.length;c++)b+="&args[]="+encodeURIComponent(arguments[c]);return"Minified React error #"+a+"; visit "+b+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";}var D={isMounted:function(){return!1;},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},E={};function F(a,b,c){this.props=a;this.context=b;this.refs=E;this.updater=c||D;}F.prototype.isReactComponent={};F.prototype.setState=function(a,b){if("object"!==typeof a&&"function"!==typeof a&&null!=a)throw Error(C(85));this.updater.enqueueSetState(this,a,b,"setState");};F.prototype.forceUpdate=function(a){this.updater.enqueueForceUpdate(this,a,"forceUpdate");};function G(){}G.prototype=F.prototype;function H(a,b,c){this.props=a;this.context=b;this.refs=E;this.updater=c||D;}var I=H.prototype=new G();I.constructor=H;l(I,F.prototype);I.isPureReactComponent=!0;var J={current:null},K=Object.prototype.hasOwnProperty,L={key:!0,ref:!0,__self:!0,__source:!0};function M(a,b,c){var e,d={},g=null,k=null;if(null!=b)for(e in void 0!==b.ref&&(k=b.ref),void 0!==b.key&&(g=""+b.key),b)K.call(b,e)&&!L.hasOwnProperty(e)&&(d[e]=b[e]);var f=arguments.length-2;if(1===f)d.children=c;else if(1<f){for(var h=Array(f),m=0;m<f;m++)h[m]=arguments[m+2];d.children=h;}if(a&&a.defaultProps)for(e in f=a.defaultProps,f)void 0===d[e]&&(d[e]=f[e]);return{$$typeof:p,type:a,key:g,ref:k,props:d,_owner:J.current};}function N(a,b){return{$$typeof:p,type:a.type,key:b,ref:a.ref,props:a.props,_owner:a._owner};}function O(a){return"object"===typeof a&&null!==a&&a.$$typeof===p;}function escape(a){var b={"=":"=0",":":"=2"};return"$"+(""+a).replace(/[=:]/g,function(a){return b[a];});}var P=/\/+/g,Q=[];function R(a,b,c,e){if(Q.length){var d=Q.pop();d.result=a;d.keyPrefix=b;d.func=c;d.context=e;d.count=0;return d;}return{result:a,keyPrefix:b,func:c,context:e,count:0};}function S(a){a.result=null;a.keyPrefix=null;a.func=null;a.context=null;a.count=0;10>Q.length&&Q.push(a);}function T(a,b,c,e){var d=typeof a;if("undefined"===d||"boolean"===d)a=null;var g=!1;if(null===a)g=!0;else switch(d){case"string":case"number":g=!0;break;case"object":switch(a.$$typeof){case p:case q:g=!0;}}if(g)return c(e,a,""===b?"."+U(a,0):b),1;g=0;b=""===b?".":b+":";if(Array.isArray(a))for(var k=0;k<a.length;k++){d=a[k];var f=b+U(d,k);g+=T(d,f,c,e);}else if(null===a||"object"!==typeof a?f=null:(f=B&&a[B]||a["@@iterator"],f="function"===typeof f?f:null),"function"===typeof f)for(a=f.call(a),k=0;!(d=a.next()).done;)d=d.value,f=b+U(d,k++),g+=T(d,f,c,e);else if("object"===d)throw c=""+a,Error(C(31,"[object Object]"===c?"object with keys {"+Object.keys(a).join(", ")+"}":c,""));return g;}function V(a,b,c){return null==a?0:T(a,"",b,c);}function U(a,b){return"object"===typeof a&&null!==a&&null!=a.key?escape(a.key):b.toString(36);}function W(a,b){a.func.call(a.context,b,a.count++);}function aa(a,b,c){var e=a.result,d=a.keyPrefix;a=a.func.call(a.context,b,a.count++);Array.isArray(a)?X(a,e,c,function(a){return a;}):null!=a&&(O(a)&&(a=N(a,d+(!a.key||b&&b.key===a.key?"":(""+a.key).replace(P,"$&/")+"/")+c)),e.push(a));}function X(a,b,c,e,d){var g="";null!=c&&(g=(""+c).replace(P,"$&/")+"/");b=R(b,g,e,d);V(a,aa,b);S(b);}var Y={current:null};function Z(){var a=Y.current;if(null===a)throw Error(C(321));return a;}var ba={ReactCurrentDispatcher:Y,ReactCurrentBatchConfig:{suspense:null},ReactCurrentOwner:J,IsSomeRendererActing:{current:!1},assign:l};exports.Children={map:function(a,b,c){if(null==a)return a;var e=[];X(a,e,null,b,c);return e;},forEach:function(a,b,c){if(null==a)return a;b=R(null,null,b,c);V(a,W,b);S(b);},count:function(a){return V(a,function(){return null;},null);},toArray:function(a){var b=[];X(a,b,null,function(a){return a;});return b;},only:function(a){if(!O(a))throw Error(C(143));return a;}};exports.Component=F;exports.Fragment=r;exports.Profiler=u;exports.PureComponent=H;exports.StrictMode=t;exports.Suspense=y;exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=ba;exports.cloneElement=function(a,b,c){if(null===a||void 0===a)throw Error(C(267,a));var e=l({},a.props),d=a.key,g=a.ref,k=a._owner;if(null!=b){void 0!==b.ref&&(g=b.ref,k=J.current);void 0!==b.key&&(d=""+b.key);if(a.type&&a.type.defaultProps)var f=a.type.defaultProps;for(h in b)K.call(b,h)&&!L.hasOwnProperty(h)&&(e[h]=void 0===b[h]&&void 0!==f?f[h]:b[h]);}var h=arguments.length-2;if(1===h)e.children=c;else if(1<h){f=Array(h);for(var m=0;m<h;m++)f[m]=arguments[m+2];e.children=f;}return{$$typeof:p,type:a.type,key:d,ref:g,props:e,_owner:k};};exports.createContext=function(a,b){void 0===b&&(b=null);a={$$typeof:w,_calculateChangedBits:b,_currentValue:a,_currentValue2:a,_threadCount:0,Provider:null,Consumer:null};a.Provider={$$typeof:v,_context:a};return a.Consumer=a;};exports.createElement=M;exports.createFactory=function(a){var b=M.bind(null,a);b.type=a;return b;};exports.createRef=function(){return{current:null};};exports.forwardRef=function(a){return{$$typeof:x,render:a};};exports.isValidElement=O;exports.lazy=function(a){return{$$typeof:A,_ctor:a,_status:-1,_result:null};};exports.memo=function(a,b){return{$$typeof:z,type:a,compare:void 0===b?null:b};};exports.useCallback=function(a,b){return Z().useCallback(a,b);};exports.useContext=function(a,b){return Z().useContext(a,b);};exports.useDebugValue=function(){};exports.useEffect=function(a,b){return Z().useEffect(a,b);};exports.useImperativeHandle=function(a,b,c){return Z().useImperativeHandle(a,b,c);};exports.useLayoutEffect=function(a,b){return Z().useLayoutEffect(a,b);};exports.useMemo=function(a,b){return Z().useMemo(a,b);};exports.useReducer=function(a,b,c){return Z().useReducer(a,b,c);};exports.useRef=function(a){return Z().useRef(a);};exports.useState=function(a){return Z().useState(a);};exports.version="16.13.1";

/***/ }),

/***/ "../../../node_modules/react/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
if(true){module.exports=__webpack_require__("../../../node_modules/react/cjs/react.production.min.js");}else{module.exports=require('./cjs/react.development.js');}

/***/ }),

/***/ "../../../node_modules/scheduler/cjs/scheduler.production.min.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/** @license React v0.19.1
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var f,g,h,k,l;if("undefined"===typeof window||"function"!==typeof MessageChannel){var p=null,q=null,t=function(){if(null!==p)try{var a=exports.unstable_now();p(!0,a);p=null;}catch(b){throw setTimeout(t,0),b;}},u=Date.now();exports.unstable_now=function(){return Date.now()-u;};f=function(a){null!==p?setTimeout(f,0,a):(p=a,setTimeout(t,0));};g=function(a,b){q=setTimeout(a,b);};h=function(){clearTimeout(q);};k=function(){return!1;};l=exports.unstable_forceFrameRate=function(){};}else{var w=window.performance,x=window.Date,y=window.setTimeout,z=window.clearTimeout;if("undefined"!==typeof console){var A=window.cancelAnimationFrame;"function"!==typeof window.requestAnimationFrame&&console.error("This browser doesn't support requestAnimationFrame. Make sure that you load a polyfill in older browsers. https://fb.me/react-polyfills");"function"!==typeof A&&console.error("This browser doesn't support cancelAnimationFrame. Make sure that you load a polyfill in older browsers. https://fb.me/react-polyfills");}if("object"===typeof w&&"function"===typeof w.now)exports.unstable_now=function(){return w.now();};else{var B=x.now();exports.unstable_now=function(){return x.now()-B;};}var C=!1,D=null,E=-1,F=5,G=0;k=function(){return exports.unstable_now()>=G;};l=function(){};exports.unstable_forceFrameRate=function(a){0>a||125<a?console.error("forceFrameRate takes a positive int between 0 and 125, forcing framerates higher than 125 fps is not unsupported"):F=0<a?Math.floor(1E3/a):5;};var H=new MessageChannel(),I=H.port2;H.port1.onmessage=function(){if(null!==D){var a=exports.unstable_now();G=a+F;try{D(!0,a)?I.postMessage(null):(C=!1,D=null);}catch(b){throw I.postMessage(null),b;}}else C=!1;};f=function(a){D=a;C||(C=!0,I.postMessage(null));};g=function(a,b){E=y(function(){a(exports.unstable_now());},b);};h=function(){z(E);E=-1;};}function J(a,b){var c=a.length;a.push(b);a:for(;;){var d=c-1>>>1,e=a[d];if(void 0!==e&&0<K(e,b))a[d]=b,a[c]=e,c=d;else break a;}}function L(a){a=a[0];return void 0===a?null:a;}function M(a){var b=a[0];if(void 0!==b){var c=a.pop();if(c!==b){a[0]=c;a:for(var d=0,e=a.length;d<e;){var m=2*(d+1)-1,n=a[m],v=m+1,r=a[v];if(void 0!==n&&0>K(n,c))void 0!==r&&0>K(r,n)?(a[d]=r,a[v]=c,d=v):(a[d]=n,a[m]=c,d=m);else if(void 0!==r&&0>K(r,c))a[d]=r,a[v]=c,d=v;else break a;}}return b;}return null;}function K(a,b){var c=a.sortIndex-b.sortIndex;return 0!==c?c:a.id-b.id;}var N=[],O=[],P=1,Q=null,R=3,S=!1,T=!1,U=!1;function V(a){for(var b=L(O);null!==b;){if(null===b.callback)M(O);else if(b.startTime<=a)M(O),b.sortIndex=b.expirationTime,J(N,b);else break;b=L(O);}}function W(a){U=!1;V(a);if(!T)if(null!==L(N))T=!0,f(X);else{var b=L(O);null!==b&&g(W,b.startTime-a);}}function X(a,b){T=!1;U&&(U=!1,h());S=!0;var c=R;try{V(b);for(Q=L(N);null!==Q&&(!(Q.expirationTime>b)||a&&!k());){var d=Q.callback;if(null!==d){Q.callback=null;R=Q.priorityLevel;var e=d(Q.expirationTime<=b);b=exports.unstable_now();"function"===typeof e?Q.callback=e:Q===L(N)&&M(N);V(b);}else M(N);Q=L(N);}if(null!==Q)var m=!0;else{var n=L(O);null!==n&&g(W,n.startTime-b);m=!1;}return m;}finally{Q=null,R=c,S=!1;}}function Y(a){switch(a){case 1:return-1;case 2:return 250;case 5:return 1073741823;case 4:return 1E4;default:return 5E3;}}var Z=l;exports.unstable_IdlePriority=5;exports.unstable_ImmediatePriority=1;exports.unstable_LowPriority=4;exports.unstable_NormalPriority=3;exports.unstable_Profiling=null;exports.unstable_UserBlockingPriority=2;exports.unstable_cancelCallback=function(a){a.callback=null;};exports.unstable_continueExecution=function(){T||S||(T=!0,f(X));};exports.unstable_getCurrentPriorityLevel=function(){return R;};exports.unstable_getFirstCallbackNode=function(){return L(N);};exports.unstable_next=function(a){switch(R){case 1:case 2:case 3:var b=3;break;default:b=R;}var c=R;R=b;try{return a();}finally{R=c;}};exports.unstable_pauseExecution=function(){};exports.unstable_requestPaint=Z;exports.unstable_runWithPriority=function(a,b){switch(a){case 1:case 2:case 3:case 4:case 5:break;default:a=3;}var c=R;R=a;try{return b();}finally{R=c;}};exports.unstable_scheduleCallback=function(a,b,c){var d=exports.unstable_now();if("object"===typeof c&&null!==c){var e=c.delay;e="number"===typeof e&&0<e?d+e:d;c="number"===typeof c.timeout?c.timeout:Y(a);}else c=Y(a),e=d;c=e+c;a={id:P++,callback:b,priorityLevel:a,startTime:e,expirationTime:c,sortIndex:-1};e>d?(a.sortIndex=e,J(O,a),null===L(N)&&a===L(O)&&(U?h():U=!0,g(W,e-d))):(a.sortIndex=c,J(N,a),T||S||(T=!0,f(X)));return a;};exports.unstable_shouldYield=function(){var a=exports.unstable_now();V(a);var b=L(N);return b!==Q&&null!==Q&&null!==b&&null!==b.callback&&b.startTime<=a&&b.expirationTime<Q.expirationTime||k();};exports.unstable_wrapCallback=function(a){var b=R;return function(){var c=R;R=b;try{return a.apply(this,arguments);}finally{R=c;}};};

/***/ }),

/***/ "../../../node_modules/scheduler/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
if(true){module.exports=__webpack_require__("../../../node_modules/scheduler/cjs/scheduler.production.min.js");}else{module.exports=require('./cjs/scheduler.development.js');}

/***/ }),

/***/ "../../../node_modules/style-loader/lib/addStyles.js":
/***/ (function(module, exports, __webpack_require__) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/

var stylesInDom = {};

var	memoize = function (fn) {
	var memo;

	return function () {
		if (typeof memo === "undefined") memo = fn.apply(this, arguments);
		return memo;
	};
};

var isOldIE = memoize(function () {
	// Test for IE <= 9 as proposed by Browserhacks
	// @see http://browserhacks.com/#hack-e71d8692f65334173fee715c222cb805
	// Tests for existence of standard globals is to allow style-loader
	// to operate correctly into non-standard environments
	// @see https://github.com/webpack-contrib/style-loader/issues/177
	return window && document && document.all && !window.atob;
});

var getElement = (function (fn) {
	var memo = {};

	return function(selector) {
		if (typeof memo[selector] === "undefined") {
			memo[selector] = fn.call(this, selector);
		}

		return memo[selector]
	};
})(function (target) {
	return document.querySelector(target)
});

var singleton = null;
var	singletonCounter = 0;
var	stylesInsertedAtTop = [];

var	fixUrls = __webpack_require__("../../../node_modules/style-loader/lib/urls.js");

module.exports = function(list, options) {
	if (typeof DEBUG !== "undefined" && DEBUG) {
		if (typeof document !== "object") throw new Error("The style-loader cannot be used in a non-browser environment");
	}

	options = options || {};

	options.attrs = typeof options.attrs === "object" ? options.attrs : {};

	// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
	// tags it will allow on a page
	if (!options.singleton) options.singleton = isOldIE();

	// By default, add <style> tags to the <head> element
	if (!options.insertInto) options.insertInto = "head";

	// By default, add <style> tags to the bottom of the target
	if (!options.insertAt) options.insertAt = "bottom";

	var styles = listToStyles(list, options);

	addStylesToDom(styles, options);

	return function update (newList) {
		var mayRemove = [];

		for (var i = 0; i < styles.length; i++) {
			var item = styles[i];
			var domStyle = stylesInDom[item.id];

			domStyle.refs--;
			mayRemove.push(domStyle);
		}

		if(newList) {
			var newStyles = listToStyles(newList, options);
			addStylesToDom(newStyles, options);
		}

		for (var i = 0; i < mayRemove.length; i++) {
			var domStyle = mayRemove[i];

			if(domStyle.refs === 0) {
				for (var j = 0; j < domStyle.parts.length; j++) domStyle.parts[j]();

				delete stylesInDom[domStyle.id];
			}
		}
	};
};

function addStylesToDom (styles, options) {
	for (var i = 0; i < styles.length; i++) {
		var item = styles[i];
		var domStyle = stylesInDom[item.id];

		if(domStyle) {
			domStyle.refs++;

			for(var j = 0; j < domStyle.parts.length; j++) {
				domStyle.parts[j](item.parts[j]);
			}

			for(; j < item.parts.length; j++) {
				domStyle.parts.push(addStyle(item.parts[j], options));
			}
		} else {
			var parts = [];

			for(var j = 0; j < item.parts.length; j++) {
				parts.push(addStyle(item.parts[j], options));
			}

			stylesInDom[item.id] = {id: item.id, refs: 1, parts: parts};
		}
	}
}

function listToStyles (list, options) {
	var styles = [];
	var newStyles = {};

	for (var i = 0; i < list.length; i++) {
		var item = list[i];
		var id = options.base ? item[0] + options.base : item[0];
		var css = item[1];
		var media = item[2];
		var sourceMap = item[3];
		var part = {css: css, media: media, sourceMap: sourceMap};

		if(!newStyles[id]) styles.push(newStyles[id] = {id: id, parts: [part]});
		else newStyles[id].parts.push(part);
	}

	return styles;
}

function insertStyleElement (options, style) {
	var target = getElement(options.insertInto)

	if (!target) {
		throw new Error("Couldn't find a style target. This probably means that the value for the 'insertInto' parameter is invalid.");
	}

	var lastStyleElementInsertedAtTop = stylesInsertedAtTop[stylesInsertedAtTop.length - 1];

	if (options.insertAt === "top") {
		if (!lastStyleElementInsertedAtTop) {
			target.insertBefore(style, target.firstChild);
		} else if (lastStyleElementInsertedAtTop.nextSibling) {
			target.insertBefore(style, lastStyleElementInsertedAtTop.nextSibling);
		} else {
			target.appendChild(style);
		}
		stylesInsertedAtTop.push(style);
	} else if (options.insertAt === "bottom") {
		target.appendChild(style);
	} else {
		throw new Error("Invalid value for parameter 'insertAt'. Must be 'top' or 'bottom'.");
	}
}

function removeStyleElement (style) {
	if (style.parentNode === null) return false;
	style.parentNode.removeChild(style);

	var idx = stylesInsertedAtTop.indexOf(style);
	if(idx >= 0) {
		stylesInsertedAtTop.splice(idx, 1);
	}
}

function createStyleElement (options) {
	var style = document.createElement("style");

	options.attrs.type = "text/css";

	addAttrs(style, options.attrs);
	insertStyleElement(options, style);

	return style;
}

function createLinkElement (options) {
	var link = document.createElement("link");

	options.attrs.type = "text/css";
	options.attrs.rel = "stylesheet";

	addAttrs(link, options.attrs);
	insertStyleElement(options, link);

	return link;
}

function addAttrs (el, attrs) {
	Object.keys(attrs).forEach(function (key) {
		el.setAttribute(key, attrs[key]);
	});
}

function addStyle (obj, options) {
	var style, update, remove, result;

	// If a transform function was defined, run it on the css
	if (options.transform && obj.css) {
	    result = options.transform(obj.css);

	    if (result) {
	    	// If transform returns a value, use that instead of the original css.
	    	// This allows running runtime transformations on the css.
	    	obj.css = result;
	    } else {
	    	// If the transform function returns a falsy value, don't add this css.
	    	// This allows conditional loading of css
	    	return function() {
	    		// noop
	    	};
	    }
	}

	if (options.singleton) {
		var styleIndex = singletonCounter++;

		style = singleton || (singleton = createStyleElement(options));

		update = applyToSingletonTag.bind(null, style, styleIndex, false);
		remove = applyToSingletonTag.bind(null, style, styleIndex, true);

	} else if (
		obj.sourceMap &&
		typeof URL === "function" &&
		typeof URL.createObjectURL === "function" &&
		typeof URL.revokeObjectURL === "function" &&
		typeof Blob === "function" &&
		typeof btoa === "function"
	) {
		style = createLinkElement(options);
		update = updateLink.bind(null, style, options);
		remove = function () {
			removeStyleElement(style);

			if(style.href) URL.revokeObjectURL(style.href);
		};
	} else {
		style = createStyleElement(options);
		update = applyToTag.bind(null, style);
		remove = function () {
			removeStyleElement(style);
		};
	}

	update(obj);

	return function updateStyle (newObj) {
		if (newObj) {
			if (
				newObj.css === obj.css &&
				newObj.media === obj.media &&
				newObj.sourceMap === obj.sourceMap
			) {
				return;
			}

			update(obj = newObj);
		} else {
			remove();
		}
	};
}

var replaceText = (function () {
	var textStore = [];

	return function (index, replacement) {
		textStore[index] = replacement;

		return textStore.filter(Boolean).join('\n');
	};
})();

function applyToSingletonTag (style, index, remove, obj) {
	var css = remove ? "" : obj.css;

	if (style.styleSheet) {
		style.styleSheet.cssText = replaceText(index, css);
	} else {
		var cssNode = document.createTextNode(css);
		var childNodes = style.childNodes;

		if (childNodes[index]) style.removeChild(childNodes[index]);

		if (childNodes.length) {
			style.insertBefore(cssNode, childNodes[index]);
		} else {
			style.appendChild(cssNode);
		}
	}
}

function applyToTag (style, obj) {
	var css = obj.css;
	var media = obj.media;

	if(media) {
		style.setAttribute("media", media)
	}

	if(style.styleSheet) {
		style.styleSheet.cssText = css;
	} else {
		while(style.firstChild) {
			style.removeChild(style.firstChild);
		}

		style.appendChild(document.createTextNode(css));
	}
}

function updateLink (link, options, obj) {
	var css = obj.css;
	var sourceMap = obj.sourceMap;

	/*
		If convertToAbsoluteUrls isn't defined, but sourcemaps are enabled
		and there is no publicPath defined then lets turn convertToAbsoluteUrls
		on by default.  Otherwise default to the convertToAbsoluteUrls option
		directly
	*/
	var autoFixUrls = options.convertToAbsoluteUrls === undefined && sourceMap;

	if (options.convertToAbsoluteUrls || autoFixUrls) {
		css = fixUrls(css);
	}

	if (sourceMap) {
		// http://stackoverflow.com/a/26603875
		css += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + " */";
	}

	var blob = new Blob([css], { type: "text/css" });

	var oldSrc = link.href;

	link.href = URL.createObjectURL(blob);

	if(oldSrc) URL.revokeObjectURL(oldSrc);
}


/***/ }),

/***/ "../../../node_modules/style-loader/lib/urls.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * When source maps are enabled, `style-loader` uses a link element with a data-uri to
 * embed the css on the page. This breaks all relative urls because now they are relative to a
 * bundle instead of the current page.
 *
 * One solution is to only use full urls, but that may be impossible.
 *
 * Instead, this function "fixes" the relative urls to be absolute according to the current page location.
 *
 * A rudimentary test suite is located at `test/fixUrls.js` and can be run via the `npm test` command.
 *
 */module.exports=function(css){// get current location
var location=typeof window!=="undefined"&&window.location;if(!location){throw new Error("fixUrls requires window.location");}// blank or null?
if(!css||typeof css!=="string"){return css;}var baseUrl=location.protocol+"//"+location.host;var currentDir=baseUrl+location.pathname.replace(/\/[^\/]*$/,"/");// convert each url(...)
/*
	This regular expression is just a way to recursively match brackets within
	a string.

	 /url\s*\(  = Match on the word "url" with any whitespace after it and then a parens
	   (  = Start a capturing group
	     (?:  = Start a non-capturing group
	         [^)(]  = Match anything that isn't a parentheses
	         |  = OR
	         \(  = Match a start parentheses
	             (?:  = Start another non-capturing groups
	                 [^)(]+  = Match anything that isn't a parentheses
	                 |  = OR
	                 \(  = Match a start parentheses
	                     [^)(]*  = Match anything that isn't a parentheses
	                 \)  = Match a end parentheses
	             )  = End Group
              *\) = Match anything and then a close parens
          )  = Close non-capturing group
          *  = Match anything
       )  = Close capturing group
	 \)  = Match a close parens

	 /gi  = Get all matches, not the first.  Be case insensitive.
	 */var fixedCss=css.replace(/url\s*\(((?:[^)(]|\((?:[^)(]+|\([^)(]*\))*\))*)\)/gi,function(fullMatch,origUrl){// strip quotes (if they exist)
var unquotedOrigUrl=origUrl.trim().replace(/^"(.*)"$/,function(o,$1){return $1;}).replace(/^'(.*)'$/,function(o,$1){return $1;});// already a full url? no change
if(/^(#|data:|http:\/\/|https:\/\/|file:\/\/\/)/i.test(unquotedOrigUrl)){return fullMatch;}// convert the url to a full url
var newUrl;if(unquotedOrigUrl.indexOf("//")===0){//TODO: should we add protocol?
newUrl=unquotedOrigUrl;}else if(unquotedOrigUrl.indexOf("/")===0){// path should be relative to the base url
newUrl=baseUrl+unquotedOrigUrl;// already starts with '/'
}else{// path should be relative to current directory
newUrl=currentDir+unquotedOrigUrl.replace(/^\.\//,"");// Strip leading './'
}// send back the fixed url(...)
return"url("+JSON.stringify(newUrl)+")";});// send back the fixed css
return fixedCss;};

/***/ }),

/***/ "../../../node_modules/ua-parser-js/src/ua-parser.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var __WEBPACK_AMD_DEFINE_RESULT__;/*!
 * UAParser.js v0.7.21
 * Lightweight JavaScript-based User-Agent string parser
 * https://github.com/faisalman/ua-parser-js
 *
 * Copyright © 2012-2019 Faisal Salman <f@faisalman.com>
 * Licensed under MIT License
 */(function(window,undefined){'use strict';//////////////
// Constants
/////////////
var LIBVERSION='0.7.21',EMPTY='',UNKNOWN='?',FUNC_TYPE='function',UNDEF_TYPE='undefined',OBJ_TYPE='object',STR_TYPE='string',MAJOR='major',// deprecated
MODEL='model',NAME='name',TYPE='type',VENDOR='vendor',VERSION='version',ARCHITECTURE='architecture',CONSOLE='console',MOBILE='mobile',TABLET='tablet',SMARTTV='smarttv',WEARABLE='wearable',EMBEDDED='embedded';///////////
// Helper
//////////
var util={extend:function(regexes,extensions){var mergedRegexes={};for(var i in regexes){if(extensions[i]&&extensions[i].length%2===0){mergedRegexes[i]=extensions[i].concat(regexes[i]);}else{mergedRegexes[i]=regexes[i];}}return mergedRegexes;},has:function(str1,str2){if(typeof str1==="string"){return str2.toLowerCase().indexOf(str1.toLowerCase())!==-1;}else{return false;}},lowerize:function(str){return str.toLowerCase();},major:function(version){return typeof version===STR_TYPE?version.replace(/[^\d\.]/g,'').split(".")[0]:undefined;},trim:function(str){return str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,'');}};///////////////
// Map helper
//////////////
var mapper={rgx:function(ua,arrays){var i=0,j,k,p,q,matches,match;// loop through all regexes maps
while(i<arrays.length&&!matches){var regex=arrays[i],// even sequence (0,2,4,..)
props=arrays[i+1];// odd sequence (1,3,5,..)
j=k=0;// try matching uastring with regexes
while(j<regex.length&&!matches){matches=regex[j++].exec(ua);if(!!matches){for(p=0;p<props.length;p++){match=matches[++k];q=props[p];// check if given property is actually array
if(typeof q===OBJ_TYPE&&q.length>0){if(q.length==2){if(typeof q[1]==FUNC_TYPE){// assign modified match
this[q[0]]=q[1].call(this,match);}else{// assign given value, ignore regex match
this[q[0]]=q[1];}}else if(q.length==3){// check whether function or regex
if(typeof q[1]===FUNC_TYPE&&!(q[1].exec&&q[1].test)){// call function (usually string mapper)
this[q[0]]=match?q[1].call(this,match,q[2]):undefined;}else{// sanitize match using given regex
this[q[0]]=match?match.replace(q[1],q[2]):undefined;}}else if(q.length==4){this[q[0]]=match?q[3].call(this,match.replace(q[1],q[2])):undefined;}}else{this[q]=match?match:undefined;}}}}i+=2;}},str:function(str,map){for(var i in map){// check if array
if(typeof map[i]===OBJ_TYPE&&map[i].length>0){for(var j=0;j<map[i].length;j++){if(util.has(map[i][j],str)){return i===UNKNOWN?undefined:i;}}}else if(util.has(map[i],str)){return i===UNKNOWN?undefined:i;}}return str;}};///////////////
// String map
//////////////
var maps={browser:{oldsafari:{version:{'1.0':'/8','1.2':'/1','1.3':'/3','2.0':'/412','2.0.2':'/416','2.0.3':'/417','2.0.4':'/419','?':'/'}}},device:{amazon:{model:{'Fire Phone':['SD','KF']}},sprint:{model:{'Evo Shift 4G':'7373KT'},vendor:{'HTC':'APA','Sprint':'Sprint'}}},os:{windows:{version:{'ME':'4.90','NT 3.11':'NT3.51','NT 4.0':'NT4.0','2000':'NT 5.0','XP':['NT 5.1','NT 5.2'],'Vista':'NT 6.0','7':'NT 6.1','8':'NT 6.2','8.1':'NT 6.3','10':['NT 6.4','NT 10.0'],'RT':'ARM'}}}};//////////////
// Regex map
/////////////
var regexes={browser:[[// Presto based
/(opera\smini)\/([\w\.-]+)/i,// Opera Mini
/(opera\s[mobiletab]+).+version\/([\w\.-]+)/i,// Opera Mobi/Tablet
/(opera).+version\/([\w\.]+)/i,// Opera > 9.80
/(opera)[\/\s]+([\w\.]+)/i// Opera < 9.80
],[NAME,VERSION],[/(opios)[\/\s]+([\w\.]+)/i// Opera mini on iphone >= 8.0
],[[NAME,'Opera Mini'],VERSION],[/\s(opr)\/([\w\.]+)/i// Opera Webkit
],[[NAME,'Opera'],VERSION],[// Mixed
/(kindle)\/([\w\.]+)/i,// Kindle
/(lunascape|maxthon|netfront|jasmine|blazer)[\/\s]?([\w\.]*)/i,// Lunascape/Maxthon/Netfront/Jasmine/Blazer
// Trident based
/(avant\s|iemobile|slim)(?:browser)?[\/\s]?([\w\.]*)/i,// Avant/IEMobile/SlimBrowser
/(bidubrowser|baidubrowser)[\/\s]?([\w\.]+)/i,// Baidu Browser
/(?:ms|\()(ie)\s([\w\.]+)/i,// Internet Explorer
// Webkit/KHTML based
/(rekonq)\/([\w\.]*)/i,// Rekonq
/(chromium|flock|rockmelt|midori|epiphany|silk|skyfire|ovibrowser|bolt|iron|vivaldi|iridium|phantomjs|bowser|quark|qupzilla|falkon)\/([\w\.-]+)/i// Chromium/Flock/RockMelt/Midori/Epiphany/Silk/Skyfire/Bolt/Iron/Iridium/PhantomJS/Bowser/QupZilla/Falkon
],[NAME,VERSION],[/(konqueror)\/([\w\.]+)/i// Konqueror
],[[NAME,'Konqueror'],VERSION],[/(trident).+rv[:\s]([\w\.]+).+like\sgecko/i// IE11
],[[NAME,'IE'],VERSION],[/(edge|edgios|edga|edg)\/((\d+)?[\w\.]+)/i// Microsoft Edge
],[[NAME,'Edge'],VERSION],[/(yabrowser)\/([\w\.]+)/i// Yandex
],[[NAME,'Yandex'],VERSION],[/(Avast)\/([\w\.]+)/i// Avast Secure Browser
],[[NAME,'Avast Secure Browser'],VERSION],[/(AVG)\/([\w\.]+)/i// AVG Secure Browser
],[[NAME,'AVG Secure Browser'],VERSION],[/(puffin)\/([\w\.]+)/i// Puffin
],[[NAME,'Puffin'],VERSION],[/(focus)\/([\w\.]+)/i// Firefox Focus
],[[NAME,'Firefox Focus'],VERSION],[/(opt)\/([\w\.]+)/i// Opera Touch
],[[NAME,'Opera Touch'],VERSION],[/((?:[\s\/])uc?\s?browser|(?:juc.+)ucweb)[\/\s]?([\w\.]+)/i// UCBrowser
],[[NAME,'UCBrowser'],VERSION],[/(comodo_dragon)\/([\w\.]+)/i// Comodo Dragon
],[[NAME,/_/g,' '],VERSION],[/(windowswechat qbcore)\/([\w\.]+)/i// WeChat Desktop for Windows Built-in Browser
],[[NAME,'WeChat(Win) Desktop'],VERSION],[/(micromessenger)\/([\w\.]+)/i// WeChat
],[[NAME,'WeChat'],VERSION],[/(brave)\/([\w\.]+)/i// Brave browser
],[[NAME,'Brave'],VERSION],[/(qqbrowserlite)\/([\w\.]+)/i// QQBrowserLite
],[NAME,VERSION],[/(QQ)\/([\d\.]+)/i// QQ, aka ShouQ
],[NAME,VERSION],[/m?(qqbrowser)[\/\s]?([\w\.]+)/i// QQBrowser
],[NAME,VERSION],[/(baiduboxapp)[\/\s]?([\w\.]+)/i// Baidu App
],[NAME,VERSION],[/(2345Explorer)[\/\s]?([\w\.]+)/i// 2345 Browser
],[NAME,VERSION],[/(MetaSr)[\/\s]?([\w\.]+)/i// SouGouBrowser
],[NAME],[/(LBBROWSER)/i// LieBao Browser
],[NAME],[/xiaomi\/miuibrowser\/([\w\.]+)/i// MIUI Browser
],[VERSION,[NAME,'MIUI Browser']],[/;fbav\/([\w\.]+);/i// Facebook App for iOS & Android
],[VERSION,[NAME,'Facebook']],[/safari\s(line)\/([\w\.]+)/i,// Line App for iOS
/android.+(line)\/([\w\.]+)\/iab/i// Line App for Android
],[NAME,VERSION],[/headlesschrome(?:\/([\w\.]+)|\s)/i// Chrome Headless
],[VERSION,[NAME,'Chrome Headless']],[/\swv\).+(chrome)\/([\w\.]+)/i// Chrome WebView
],[[NAME,/(.+)/,'$1 WebView'],VERSION],[/((?:oculus|samsung)browser)\/([\w\.]+)/i],[[NAME,/(.+(?:g|us))(.+)/,'$1 $2'],VERSION],[// Oculus / Samsung Browser
/android.+version\/([\w\.]+)\s+(?:mobile\s?safari|safari)*/i// Android Browser
],[VERSION,[NAME,'Android Browser']],[/(sailfishbrowser)\/([\w\.]+)/i// Sailfish Browser
],[[NAME,'Sailfish Browser'],VERSION],[/(chrome|omniweb|arora|[tizenoka]{5}\s?browser)\/v?([\w\.]+)/i// Chrome/OmniWeb/Arora/Tizen/Nokia
],[NAME,VERSION],[/(dolfin)\/([\w\.]+)/i// Dolphin
],[[NAME,'Dolphin'],VERSION],[/(qihu|qhbrowser|qihoobrowser|360browser)/i// 360
],[[NAME,'360 Browser']],[/((?:android.+)crmo|crios)\/([\w\.]+)/i// Chrome for Android/iOS
],[[NAME,'Chrome'],VERSION],[/(coast)\/([\w\.]+)/i// Opera Coast
],[[NAME,'Opera Coast'],VERSION],[/fxios\/([\w\.-]+)/i// Firefox for iOS
],[VERSION,[NAME,'Firefox']],[/version\/([\w\.]+).+?mobile\/\w+\s(safari)/i// Mobile Safari
],[VERSION,[NAME,'Mobile Safari']],[/version\/([\w\.]+).+?(mobile\s?safari|safari)/i// Safari & Safari Mobile
],[VERSION,NAME],[/webkit.+?(gsa)\/([\w\.]+).+?(mobile\s?safari|safari)(\/[\w\.]+)/i// Google Search Appliance on iOS
],[[NAME,'GSA'],VERSION],[/webkit.+?(mobile\s?safari|safari)(\/[\w\.]+)/i// Safari < 3.0
],[NAME,[VERSION,mapper.str,maps.browser.oldsafari.version]],[/(webkit|khtml)\/([\w\.]+)/i],[NAME,VERSION],[// Gecko based
/(navigator|netscape)\/([\w\.-]+)/i// Netscape
],[[NAME,'Netscape'],VERSION],[/(swiftfox)/i,// Swiftfox
/(icedragon|iceweasel|camino|chimera|fennec|maemo\sbrowser|minimo|conkeror)[\/\s]?([\w\.\+]+)/i,// IceDragon/Iceweasel/Camino/Chimera/Fennec/Maemo/Minimo/Conkeror
/(firefox|seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([\w\.-]+)$/i,// Firefox/SeaMonkey/K-Meleon/IceCat/IceApe/Firebird/Phoenix
/(mozilla)\/([\w\.]+).+rv\:.+gecko\/\d+/i,// Mozilla
// Other
/(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf|sleipnir)[\/\s]?([\w\.]+)/i,// Polaris/Lynx/Dillo/iCab/Doris/Amaya/w3m/NetSurf/Sleipnir
/(links)\s\(([\w\.]+)/i,// Links
/(gobrowser)\/?([\w\.]*)/i,// GoBrowser
/(ice\s?browser)\/v?([\w\._]+)/i,// ICE Browser
/(mosaic)[\/\s]([\w\.]+)/i// Mosaic
],[NAME,VERSION]],cpu:[[/(?:(amd|x(?:(?:86|64)[_-])?|wow|win)64)[;\)]/i// AMD64
],[[ARCHITECTURE,'amd64']],[/(ia32(?=;))/i// IA32 (quicktime)
],[[ARCHITECTURE,util.lowerize]],[/((?:i[346]|x)86)[;\)]/i// IA32
],[[ARCHITECTURE,'ia32']],[// PocketPC mistakenly identified as PowerPC
/windows\s(ce|mobile);\sppc;/i],[[ARCHITECTURE,'arm']],[/((?:ppc|powerpc)(?:64)?)(?:\smac|;|\))/i// PowerPC
],[[ARCHITECTURE,/ower/,'',util.lowerize]],[/(sun4\w)[;\)]/i// SPARC
],[[ARCHITECTURE,'sparc']],[/((?:avr32|ia64(?=;))|68k(?=\))|arm(?:64|(?=v\d+[;l]))|(?=atmel\s)avr|(?:irix|mips|sparc)(?:64)?(?=;)|pa-risc)/i// IA64, 68K, ARM/64, AVR/32, IRIX/64, MIPS/64, SPARC/64, PA-RISC
],[[ARCHITECTURE,util.lowerize]]],device:[[/\((ipad|playbook);[\w\s\),;-]+(rim|apple)/i// iPad/PlayBook
],[MODEL,VENDOR,[TYPE,TABLET]],[/applecoremedia\/[\w\.]+ \((ipad)/ // iPad
],[MODEL,[VENDOR,'Apple'],[TYPE,TABLET]],[/(apple\s{0,1}tv)/i// Apple TV
],[[MODEL,'Apple TV'],[VENDOR,'Apple'],[TYPE,SMARTTV]],[/(archos)\s(gamepad2?)/i,// Archos
/(hp).+(touchpad)/i,// HP TouchPad
/(hp).+(tablet)/i,// HP Tablet
/(kindle)\/([\w\.]+)/i,// Kindle
/\s(nook)[\w\s]+build\/(\w+)/i,// Nook
/(dell)\s(strea[kpr\s\d]*[\dko])/i// Dell Streak
],[VENDOR,MODEL,[TYPE,TABLET]],[/(kf[A-z]+)\sbuild\/.+silk\//i// Kindle Fire HD
],[MODEL,[VENDOR,'Amazon'],[TYPE,TABLET]],[/(sd|kf)[0349hijorstuw]+\sbuild\/.+silk\//i// Fire Phone
],[[MODEL,mapper.str,maps.device.amazon.model],[VENDOR,'Amazon'],[TYPE,MOBILE]],[/android.+aft([bms])\sbuild/i// Fire TV
],[MODEL,[VENDOR,'Amazon'],[TYPE,SMARTTV]],[/\((ip[honed|\s\w*]+);.+(apple)/i// iPod/iPhone
],[MODEL,VENDOR,[TYPE,MOBILE]],[/\((ip[honed|\s\w*]+);/i// iPod/iPhone
],[MODEL,[VENDOR,'Apple'],[TYPE,MOBILE]],[/(blackberry)[\s-]?(\w+)/i,// BlackBerry
/(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus|dell|meizu|motorola|polytron)[\s_-]?([\w-]*)/i,// BenQ/Palm/Sony-Ericsson/Acer/Asus/Dell/Meizu/Motorola/Polytron
/(hp)\s([\w\s]+\w)/i,// HP iPAQ
/(asus)-?(\w+)/i// Asus
],[VENDOR,MODEL,[TYPE,MOBILE]],[/\(bb10;\s(\w+)/i// BlackBerry 10
],[MODEL,[VENDOR,'BlackBerry'],[TYPE,MOBILE]],[// Asus Tablets
/android.+(transfo[prime\s]{4,10}\s\w+|eeepc|slider\s\w+|nexus 7|padfone|p00c)/i],[MODEL,[VENDOR,'Asus'],[TYPE,TABLET]],[/(sony)\s(tablet\s[ps])\sbuild\//i,// Sony
/(sony)?(?:sgp.+)\sbuild\//i],[[VENDOR,'Sony'],[MODEL,'Xperia Tablet'],[TYPE,TABLET]],[/android.+\s([c-g]\d{4}|so[-l]\w+)(?=\sbuild\/|\).+chrome\/(?![1-6]{0,1}\d\.))/i],[MODEL,[VENDOR,'Sony'],[TYPE,MOBILE]],[/\s(ouya)\s/i,// Ouya
/(nintendo)\s([wids3u]+)/i// Nintendo
],[VENDOR,MODEL,[TYPE,CONSOLE]],[/android.+;\s(shield)\sbuild/i// Nvidia
],[MODEL,[VENDOR,'Nvidia'],[TYPE,CONSOLE]],[/(playstation\s[34portablevi]+)/i// Playstation
],[MODEL,[VENDOR,'Sony'],[TYPE,CONSOLE]],[/(sprint\s(\w+))/i// Sprint Phones
],[[VENDOR,mapper.str,maps.device.sprint.vendor],[MODEL,mapper.str,maps.device.sprint.model],[TYPE,MOBILE]],[/(htc)[;_\s-]+([\w\s]+(?=\)|\sbuild)|\w+)/i,// HTC
/(zte)-(\w*)/i,// ZTE
/(alcatel|geeksphone|nexian|panasonic|(?=;\s)sony)[_\s-]?([\w-]*)/i// Alcatel/GeeksPhone/Nexian/Panasonic/Sony
],[VENDOR,[MODEL,/_/g,' '],[TYPE,MOBILE]],[/(nexus\s9)/i// HTC Nexus 9
],[MODEL,[VENDOR,'HTC'],[TYPE,TABLET]],[/d\/huawei([\w\s-]+)[;\)]/i,/(nexus\s6p|vog-l29|ane-lx1|eml-l29)/i// Huawei
],[MODEL,[VENDOR,'Huawei'],[TYPE,MOBILE]],[/android.+(bah2?-a?[lw]\d{2})/i// Huawei MediaPad
],[MODEL,[VENDOR,'Huawei'],[TYPE,TABLET]],[/(microsoft);\s(lumia[\s\w]+)/i// Microsoft Lumia
],[VENDOR,MODEL,[TYPE,MOBILE]],[/[\s\(;](xbox(?:\sone)?)[\s\);]/i// Microsoft Xbox
],[MODEL,[VENDOR,'Microsoft'],[TYPE,CONSOLE]],[/(kin\.[onetw]{3})/i// Microsoft Kin
],[[MODEL,/\./g,' '],[VENDOR,'Microsoft'],[TYPE,MOBILE]],[// Motorola
/\s(milestone|droid(?:[2-4x]|\s(?:bionic|x2|pro|razr))?:?(\s4g)?)[\w\s]+build\//i,/mot[\s-]?(\w*)/i,/(XT\d{3,4}) build\//i,/(nexus\s6)/i],[MODEL,[VENDOR,'Motorola'],[TYPE,MOBILE]],[/android.+\s(mz60\d|xoom[\s2]{0,2})\sbuild\//i],[MODEL,[VENDOR,'Motorola'],[TYPE,TABLET]],[/hbbtv\/\d+\.\d+\.\d+\s+\([\w\s]*;\s*(\w[^;]*);([^;]*)/i// HbbTV devices
],[[VENDOR,util.trim],[MODEL,util.trim],[TYPE,SMARTTV]],[/hbbtv.+maple;(\d+)/i],[[MODEL,/^/,'SmartTV'],[VENDOR,'Samsung'],[TYPE,SMARTTV]],[/\(dtv[\);].+(aquos)/i// Sharp
],[MODEL,[VENDOR,'Sharp'],[TYPE,SMARTTV]],[/android.+((sch-i[89]0\d|shw-m380s|gt-p\d{4}|gt-n\d+|sgh-t8[56]9|nexus 10))/i,/((SM-T\w+))/i],[[VENDOR,'Samsung'],MODEL,[TYPE,TABLET]],[// Samsung
/smart-tv.+(samsung)/i],[VENDOR,[TYPE,SMARTTV],MODEL],[/((s[cgp]h-\w+|gt-\w+|galaxy\snexus|sm-\w[\w\d]+))/i,/(sam[sung]*)[\s-]*(\w+-?[\w-]*)/i,/sec-((sgh\w+))/i],[[VENDOR,'Samsung'],MODEL,[TYPE,MOBILE]],[/sie-(\w*)/i// Siemens
],[MODEL,[VENDOR,'Siemens'],[TYPE,MOBILE]],[/(maemo|nokia).*(n900|lumia\s\d+)/i,// Nokia
/(nokia)[\s_-]?([\w-]*)/i],[[VENDOR,'Nokia'],MODEL,[TYPE,MOBILE]],[/android[x\d\.\s;]+\s([ab][1-7]\-?[0178a]\d\d?)/i// Acer
],[MODEL,[VENDOR,'Acer'],[TYPE,TABLET]],[/android.+([vl]k\-?\d{3})\s+build/i// LG Tablet
],[MODEL,[VENDOR,'LG'],[TYPE,TABLET]],[/android\s3\.[\s\w;-]{10}(lg?)-([06cv9]{3,4})/i// LG Tablet
],[[VENDOR,'LG'],MODEL,[TYPE,TABLET]],[/(lg) netcast\.tv/i// LG SmartTV
],[VENDOR,MODEL,[TYPE,SMARTTV]],[/(nexus\s[45])/i,// LG
/lg[e;\s\/-]+(\w*)/i,/android.+lg(\-?[\d\w]+)\s+build/i],[MODEL,[VENDOR,'LG'],[TYPE,MOBILE]],[/(lenovo)\s?(s(?:5000|6000)(?:[\w-]+)|tab(?:[\s\w]+))/i// Lenovo tablets
],[VENDOR,MODEL,[TYPE,TABLET]],[/android.+(ideatab[a-z0-9\-\s]+)/i// Lenovo
],[MODEL,[VENDOR,'Lenovo'],[TYPE,TABLET]],[/(lenovo)[_\s-]?([\w-]+)/i],[VENDOR,MODEL,[TYPE,MOBILE]],[/linux;.+((jolla));/i// Jolla
],[VENDOR,MODEL,[TYPE,MOBILE]],[/((pebble))app\/[\d\.]+\s/i// Pebble
],[VENDOR,MODEL,[TYPE,WEARABLE]],[/android.+;\s(oppo)\s?([\w\s]+)\sbuild/i// OPPO
],[VENDOR,MODEL,[TYPE,MOBILE]],[/crkey/i// Google Chromecast
],[[MODEL,'Chromecast'],[VENDOR,'Google'],[TYPE,SMARTTV]],[/android.+;\s(glass)\s\d/i// Google Glass
],[MODEL,[VENDOR,'Google'],[TYPE,WEARABLE]],[/android.+;\s(pixel c)[\s)]/i// Google Pixel C
],[MODEL,[VENDOR,'Google'],[TYPE,TABLET]],[/android.+;\s(pixel( [23])?( xl)?)[\s)]/i// Google Pixel
],[MODEL,[VENDOR,'Google'],[TYPE,MOBILE]],[/android.+;\s(\w+)\s+build\/hm\1/i,// Xiaomi Hongmi 'numeric' models
/android.+(hm[\s\-_]*note?[\s_]*(?:\d\w)?)\s+build/i,// Xiaomi Hongmi
/android.+(mi[\s\-_]*(?:a\d|one|one[\s_]plus|note lte)?[\s_]*(?:\d?\w?)[\s_]*(?:plus)?)\s+build/i,// Xiaomi Mi
/android.+(redmi[\s\-_]*(?:note)?(?:[\s_]*[\w\s]+))\s+build/i// Redmi Phones
],[[MODEL,/_/g,' '],[VENDOR,'Xiaomi'],[TYPE,MOBILE]],[/android.+(mi[\s\-_]*(?:pad)(?:[\s_]*[\w\s]+))\s+build/i// Mi Pad tablets
],[[MODEL,/_/g,' '],[VENDOR,'Xiaomi'],[TYPE,TABLET]],[/android.+;\s(m[1-5]\snote)\sbuild/i// Meizu
],[MODEL,[VENDOR,'Meizu'],[TYPE,MOBILE]],[/(mz)-([\w-]{2,})/i],[[VENDOR,'Meizu'],MODEL,[TYPE,MOBILE]],[/android.+a000(1)\s+build/i,// OnePlus
/android.+oneplus\s(a\d{4})[\s)]/i],[MODEL,[VENDOR,'OnePlus'],[TYPE,MOBILE]],[/android.+[;\/]\s*(RCT[\d\w]+)\s+build/i// RCA Tablets
],[MODEL,[VENDOR,'RCA'],[TYPE,TABLET]],[/android.+[;\/\s]+(Venue[\d\s]{2,7})\s+build/i// Dell Venue Tablets
],[MODEL,[VENDOR,'Dell'],[TYPE,TABLET]],[/android.+[;\/]\s*(Q[T|M][\d\w]+)\s+build/i// Verizon Tablet
],[MODEL,[VENDOR,'Verizon'],[TYPE,TABLET]],[/android.+[;\/]\s+(Barnes[&\s]+Noble\s+|BN[RT])(V?.*)\s+build/i// Barnes & Noble Tablet
],[[VENDOR,'Barnes & Noble'],MODEL,[TYPE,TABLET]],[/android.+[;\/]\s+(TM\d{3}.*\b)\s+build/i// Barnes & Noble Tablet
],[MODEL,[VENDOR,'NuVision'],[TYPE,TABLET]],[/android.+;\s(k88)\sbuild/i// ZTE K Series Tablet
],[MODEL,[VENDOR,'ZTE'],[TYPE,TABLET]],[/android.+[;\/]\s*(gen\d{3})\s+build.*49h/i// Swiss GEN Mobile
],[MODEL,[VENDOR,'Swiss'],[TYPE,MOBILE]],[/android.+[;\/]\s*(zur\d{3})\s+build/i// Swiss ZUR Tablet
],[MODEL,[VENDOR,'Swiss'],[TYPE,TABLET]],[/android.+[;\/]\s*((Zeki)?TB.*\b)\s+build/i// Zeki Tablets
],[MODEL,[VENDOR,'Zeki'],[TYPE,TABLET]],[/(android).+[;\/]\s+([YR]\d{2})\s+build/i,/android.+[;\/]\s+(Dragon[\-\s]+Touch\s+|DT)(\w{5})\sbuild/i// Dragon Touch Tablet
],[[VENDOR,'Dragon Touch'],MODEL,[TYPE,TABLET]],[/android.+[;\/]\s*(NS-?\w{0,9})\sbuild/i// Insignia Tablets
],[MODEL,[VENDOR,'Insignia'],[TYPE,TABLET]],[/android.+[;\/]\s*((NX|Next)-?\w{0,9})\s+build/i// NextBook Tablets
],[MODEL,[VENDOR,'NextBook'],[TYPE,TABLET]],[/android.+[;\/]\s*(Xtreme\_)?(V(1[045]|2[015]|30|40|60|7[05]|90))\s+build/i],[[VENDOR,'Voice'],MODEL,[TYPE,MOBILE]],[// Voice Xtreme Phones
/android.+[;\/]\s*(LVTEL\-)?(V1[12])\s+build/i// LvTel Phones
],[[VENDOR,'LvTel'],MODEL,[TYPE,MOBILE]],[/android.+;\s(PH-1)\s/i],[MODEL,[VENDOR,'Essential'],[TYPE,MOBILE]],[// Essential PH-1
/android.+[;\/]\s*(V(100MD|700NA|7011|917G).*\b)\s+build/i// Envizen Tablets
],[MODEL,[VENDOR,'Envizen'],[TYPE,TABLET]],[/android.+[;\/]\s*(Le[\s\-]+Pan)[\s\-]+(\w{1,9})\s+build/i// Le Pan Tablets
],[VENDOR,MODEL,[TYPE,TABLET]],[/android.+[;\/]\s*(Trio[\s\-]*.*)\s+build/i// MachSpeed Tablets
],[MODEL,[VENDOR,'MachSpeed'],[TYPE,TABLET]],[/android.+[;\/]\s*(Trinity)[\-\s]*(T\d{3})\s+build/i// Trinity Tablets
],[VENDOR,MODEL,[TYPE,TABLET]],[/android.+[;\/]\s*TU_(1491)\s+build/i// Rotor Tablets
],[MODEL,[VENDOR,'Rotor'],[TYPE,TABLET]],[/android.+(KS(.+))\s+build/i// Amazon Kindle Tablets
],[MODEL,[VENDOR,'Amazon'],[TYPE,TABLET]],[/android.+(Gigaset)[\s\-]+(Q\w{1,9})\s+build/i// Gigaset Tablets
],[VENDOR,MODEL,[TYPE,TABLET]],[/\s(tablet|tab)[;\/]/i,// Unidentifiable Tablet
/\s(mobile)(?:[;\/]|\ssafari)/i// Unidentifiable Mobile
],[[TYPE,util.lowerize],VENDOR,MODEL],[/[\s\/\(](smart-?tv)[;\)]/i// SmartTV
],[[TYPE,SMARTTV]],[/(android[\w\.\s\-]{0,9});.+build/i// Generic Android Device
],[MODEL,[VENDOR,'Generic']]],engine:[[/windows.+\sedge\/([\w\.]+)/i// EdgeHTML
],[VERSION,[NAME,'EdgeHTML']],[/webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i// Blink
],[VERSION,[NAME,'Blink']],[/(presto)\/([\w\.]+)/i,// Presto
/(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna)\/([\w\.]+)/i,// WebKit/Trident/NetFront/NetSurf/Amaya/Lynx/w3m/Goanna
/(khtml|tasman|links)[\/\s]\(?([\w\.]+)/i,// KHTML/Tasman/Links
/(icab)[\/\s]([23]\.[\d\.]+)/i// iCab
],[NAME,VERSION],[/rv\:([\w\.]{1,9}).+(gecko)/i// Gecko
],[VERSION,NAME]],os:[[// Windows based
/microsoft\s(windows)\s(vista|xp)/i// Windows (iTunes)
],[NAME,VERSION],[/(windows)\snt\s6\.2;\s(arm)/i,// Windows RT
/(windows\sphone(?:\sos)*)[\s\/]?([\d\.\s\w]*)/i,// Windows Phone
/(windows\smobile|windows)[\s\/]?([ntce\d\.\s]+\w)/i],[NAME,[VERSION,mapper.str,maps.os.windows.version]],[/(win(?=3|9|n)|win\s9x\s)([nt\d\.]+)/i],[[NAME,'Windows'],[VERSION,mapper.str,maps.os.windows.version]],[// Mobile/Embedded OS
/\((bb)(10);/i// BlackBerry 10
],[[NAME,'BlackBerry'],VERSION],[/(blackberry)\w*\/?([\w\.]*)/i,// Blackberry
/(tizen|kaios)[\/\s]([\w\.]+)/i,// Tizen/KaiOS
/(android|webos|palm\sos|qnx|bada|rim\stablet\sos|meego|sailfish|contiki)[\/\s-]?([\w\.]*)/i// Android/WebOS/Palm/QNX/Bada/RIM/MeeGo/Contiki/Sailfish OS
],[NAME,VERSION],[/(symbian\s?os|symbos|s60(?=;))[\/\s-]?([\w\.]*)/i// Symbian
],[[NAME,'Symbian'],VERSION],[/\((series40);/i// Series 40
],[NAME],[/mozilla.+\(mobile;.+gecko.+firefox/i// Firefox OS
],[[NAME,'Firefox OS'],VERSION],[// Console
/(nintendo|playstation)\s([wids34portablevu]+)/i,// Nintendo/Playstation
// GNU/Linux based
/(mint)[\/\s\(]?(\w*)/i,// Mint
/(mageia|vectorlinux)[;\s]/i,// Mageia/VectorLinux
/(joli|[kxln]?ubuntu|debian|suse|opensuse|gentoo|(?=\s)arch|slackware|fedora|mandriva|centos|pclinuxos|redhat|zenwalk|linpus)[\/\s-]?(?!chrom)([\w\.-]*)/i,// Joli/Ubuntu/Debian/SUSE/Gentoo/Arch/Slackware
// Fedora/Mandriva/CentOS/PCLinuxOS/RedHat/Zenwalk/Linpus
/(hurd|linux)\s?([\w\.]*)/i,// Hurd/Linux
/(gnu)\s?([\w\.]*)/i// GNU
],[NAME,VERSION],[/(cros)\s[\w]+\s([\w\.]+\w)/i// Chromium OS
],[[NAME,'Chromium OS'],VERSION],[// Solaris
/(sunos)\s?([\w\.\d]*)/i// Solaris
],[[NAME,'Solaris'],VERSION],[// BSD based
/\s([frentopc-]{0,4}bsd|dragonfly)\s?([\w\.]*)/i// FreeBSD/NetBSD/OpenBSD/PC-BSD/DragonFly
],[NAME,VERSION],[/(haiku)\s(\w+)/i// Haiku
],[NAME,VERSION],[/cfnetwork\/.+darwin/i,/ip[honead]{2,4}(?:.*os\s([\w]+)\slike\smac|;\sopera)/i// iOS
],[[VERSION,/_/g,'.'],[NAME,'iOS']],[/(mac\sos\sx)\s?([\w\s\.]*)/i,/(macintosh|mac(?=_powerpc)\s)/i// Mac OS
],[[NAME,'Mac OS'],[VERSION,/_/g,'.']],[// Other
/((?:open)?solaris)[\/\s-]?([\w\.]*)/i,// Solaris
/(aix)\s((\d)(?=\.|\)|\s)[\w\.])*/i,// AIX
/(plan\s9|minix|beos|os\/2|amigaos|morphos|risc\sos|openvms|fuchsia)/i,// Plan9/Minix/BeOS/OS2/AmigaOS/MorphOS/RISCOS/OpenVMS/Fuchsia
/(unix)\s?([\w\.]*)/i// UNIX
],[NAME,VERSION]]};/////////////////
// Constructor
////////////////
var UAParser=function(uastring,extensions){if(typeof uastring==='object'){extensions=uastring;uastring=undefined;}if(!(this instanceof UAParser)){return new UAParser(uastring,extensions).getResult();}var ua=uastring||(window&&window.navigator&&window.navigator.userAgent?window.navigator.userAgent:EMPTY);var rgxmap=extensions?util.extend(regexes,extensions):regexes;this.getBrowser=function(){var browser={name:undefined,version:undefined};mapper.rgx.call(browser,ua,rgxmap.browser);browser.major=util.major(browser.version);// deprecated
return browser;};this.getCPU=function(){var cpu={architecture:undefined};mapper.rgx.call(cpu,ua,rgxmap.cpu);return cpu;};this.getDevice=function(){var device={vendor:undefined,model:undefined,type:undefined};mapper.rgx.call(device,ua,rgxmap.device);return device;};this.getEngine=function(){var engine={name:undefined,version:undefined};mapper.rgx.call(engine,ua,rgxmap.engine);return engine;};this.getOS=function(){var os={name:undefined,version:undefined};mapper.rgx.call(os,ua,rgxmap.os);return os;};this.getResult=function(){return{ua:this.getUA(),browser:this.getBrowser(),engine:this.getEngine(),os:this.getOS(),device:this.getDevice(),cpu:this.getCPU()};};this.getUA=function(){return ua;};this.setUA=function(uastring){ua=uastring;return this;};return this;};UAParser.VERSION=LIBVERSION;UAParser.BROWSER={NAME:NAME,MAJOR:MAJOR,// deprecated
VERSION:VERSION};UAParser.CPU={ARCHITECTURE:ARCHITECTURE};UAParser.DEVICE={MODEL:MODEL,VENDOR:VENDOR,TYPE:TYPE,CONSOLE:CONSOLE,MOBILE:MOBILE,SMARTTV:SMARTTV,TABLET:TABLET,WEARABLE:WEARABLE,EMBEDDED:EMBEDDED};UAParser.ENGINE={NAME:NAME,VERSION:VERSION};UAParser.OS={NAME:NAME,VERSION:VERSION};///////////
// Export
//////////
// check js environment
if(typeof exports!==UNDEF_TYPE){// nodejs env
if(typeof module!==UNDEF_TYPE&&module.exports){exports=module.exports=UAParser;}exports.UAParser=UAParser;}else{// requirejs env (optional)
if(true){!(__WEBPACK_AMD_DEFINE_RESULT__ = (function(){return UAParser;}).call(exports, __webpack_require__, exports, module),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));}else if(window){// browser env
window.UAParser=UAParser;}}// jQuery/Zepto specific (optional)
// Note:
//   In AMD env the global scope should be kept clean, but jQuery is an exception.
//   jQuery always exports to global scope, unless jQuery.noConflict(true) is used,
//   and we should catch that.
var $=window&&(window.jQuery||window.Zepto);if($&&!$.ua){var parser=new UAParser();$.ua=parser.getResult();$.ua.get=function(){return parser.getUA();};$.ua.set=function(uastring){parser.setUA(uastring);var result=parser.getResult();for(var prop in result){$.ua[prop]=result[prop];}};}})(typeof window==='object'?window:void 0);

/***/ }),

/***/ "../../../node_modules/uuid/lib/bytesToUuid.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */var byteToHex=[];for(var i=0;i<256;++i){byteToHex[i]=(i+0x100).toString(16).substr(1);}function bytesToUuid(buf,offset){var i=offset||0;var bth=byteToHex;// join used to fix memory issue caused by concatenation: https://bugs.chromium.org/p/v8/issues/detail?id=3175#c4
return[bth[buf[i++]],bth[buf[i++]],bth[buf[i++]],bth[buf[i++]],'-',bth[buf[i++]],bth[buf[i++]],'-',bth[buf[i++]],bth[buf[i++]],'-',bth[buf[i++]],bth[buf[i++]],'-',bth[buf[i++]],bth[buf[i++]],bth[buf[i++]],bth[buf[i++]],bth[buf[i++]],bth[buf[i++]]].join('');}module.exports=bytesToUuid;

/***/ }),

/***/ "../../../node_modules/uuid/lib/rng-browser.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// Unique ID creation requires a high quality random # generator.  In the
// browser this is a little complicated due to unknown quality of Math.random()
// and inconsistent support for the `crypto` API.  We do the best we can via
// feature-detection
// getRandomValues needs to be invoked in a context where "this" is a Crypto
// implementation. Also, find the complete implementation of crypto on IE11.
var getRandomValues=typeof crypto!='undefined'&&crypto.getRandomValues&&crypto.getRandomValues.bind(crypto)||typeof msCrypto!='undefined'&&typeof window.msCrypto.getRandomValues=='function'&&msCrypto.getRandomValues.bind(msCrypto);if(getRandomValues){// WHATWG crypto RNG - http://wiki.whatwg.org/wiki/Crypto
var rnds8=new Uint8Array(16);// eslint-disable-line no-undef
module.exports=function whatwgRNG(){getRandomValues(rnds8);return rnds8;};}else{// Math.random()-based (RNG)
//
// If all else fails, use Math.random().  It's fast, but is of unspecified
// quality.
var rnds=new Array(16);module.exports=function mathRNG(){for(var i=0,r;i<16;i++){if((i&0x03)===0)r=Math.random()*0x100000000;rnds[i]=r>>>((i&0x03)<<3)&0xff;}return rnds;};}

/***/ }),

/***/ "../../../node_modules/uuid/v4.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var rng=__webpack_require__("../../../node_modules/uuid/lib/rng-browser.js");var bytesToUuid=__webpack_require__("../../../node_modules/uuid/lib/bytesToUuid.js");function v4(options,buf,offset){var i=buf&&offset||0;if(typeof options=='string'){buf=options==='binary'?new Array(16):null;options=null;}options=options||{};var rnds=options.random||(options.rng||rng)();// Per 4.4, set bits for version and `clock_seq_hi_and_reserved`
rnds[6]=rnds[6]&0x0f|0x40;rnds[8]=rnds[8]&0x3f|0x80;// Copy bytes to buffer, if provided
if(buf){for(var ii=0;ii<16;++ii){buf[i+ii]=rnds[ii];}}return buf||bytesToUuid(rnds);}module.exports=v4;

/***/ }),

/***/ "../../../node_modules/warning/warning.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *//**
 * Similar to invariant but only logs a warning if the condition is not met.
 * This can be used to log issues in development environments in critical
 * paths. Removing the logging code for production environments will keep the
 * same logic and follow the same code paths.
 */var __DEV__="production"!=='production';var warning=function(){};if(__DEV__){var printWarning=function printWarning(format,args){var len=arguments.length;args=new Array(len>1?len-1:0);for(var key=1;key<len;key++){args[key-1]=arguments[key];}var argIndex=0;var message='Warning: '+format.replace(/%s/g,function(){return args[argIndex++];});if(typeof console!=='undefined'){console.error(message);}try{// --- Welcome to debugging React ---
// This error was thrown as a convenience so that you can use this stack
// to find the callsite that caused this warning to fire.
throw new Error(message);}catch(x){}};warning=function(condition,format,args){var len=arguments.length;args=new Array(len>2?len-2:0);for(var key=2;key<len;key++){args[key-2]=arguments[key];}if(format===undefined){throw new Error('`warning(condition, format, ...args)` requires a warning '+'message argument');}if(!condition){printWarning.apply(null,[format].concat(args));}};}module.exports=warning;

/***/ }),

/***/ "../../../node_modules/webextension-polyfill/dist/browser-polyfill.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function(global,factory){if(true){!(__WEBPACK_AMD_DEFINE_ARRAY__ = [module], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
				__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
				(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));}else if(typeof exports!=="undefined"){factory(module);}else{var mod={exports:{}};factory(mod);global.browser=mod.exports;}})(void 0,function(module){/* webextension-polyfill - v0.3.1 - Tue Aug 21 2018 10:09:34 */ /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */ /* vim: set sts=2 sw=2 et tw=80: */ /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */"use strict";if(typeof browser==="undefined"||Object.getPrototypeOf(browser)!==Object.prototype){const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE="The message port closed before a response was received.";const SEND_RESPONSE_DEPRECATION_WARNING="Returning a Promise is the preferred way to send a reply from an onMessage/onMessageExternal listener, as the sendResponse will be removed from the specs (See https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/runtime/onMessage)";// Wrapping the bulk of this polyfill in a one-time-use function is a minor
// optimization for Firefox. Since Spidermonkey does not fully parse the
// contents of a function until the first time it's called, and since it will
// never actually need to be called, this allows the polyfill to be included
// in Firefox nearly for free.
const wrapAPIs=()=>{// NOTE: apiMetadata is associated to the content of the api-metadata.json file
// at build time by replacing the following "include" with the content of the
// JSON file.
const apiMetadata={"alarms":{"clear":{"minArgs":0,"maxArgs":1},"clearAll":{"minArgs":0,"maxArgs":0},"get":{"minArgs":0,"maxArgs":1},"getAll":{"minArgs":0,"maxArgs":0}},"bookmarks":{"create":{"minArgs":1,"maxArgs":1},"get":{"minArgs":1,"maxArgs":1},"getChildren":{"minArgs":1,"maxArgs":1},"getRecent":{"minArgs":1,"maxArgs":1},"getSubTree":{"minArgs":1,"maxArgs":1},"getTree":{"minArgs":0,"maxArgs":0},"move":{"minArgs":2,"maxArgs":2},"remove":{"minArgs":1,"maxArgs":1},"removeTree":{"minArgs":1,"maxArgs":1},"search":{"minArgs":1,"maxArgs":1},"update":{"minArgs":2,"maxArgs":2}},"browserAction":{"disable":{"minArgs":0,"maxArgs":1,"fallbackToNoCallback":true},"enable":{"minArgs":0,"maxArgs":1,"fallbackToNoCallback":true},"getBadgeBackgroundColor":{"minArgs":1,"maxArgs":1},"getBadgeText":{"minArgs":1,"maxArgs":1},"getPopup":{"minArgs":1,"maxArgs":1},"getTitle":{"minArgs":1,"maxArgs":1},"openPopup":{"minArgs":0,"maxArgs":0},"setBadgeBackgroundColor":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"setBadgeText":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"setIcon":{"minArgs":1,"maxArgs":1},"setPopup":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"setTitle":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true}},"browsingData":{"remove":{"minArgs":2,"maxArgs":2},"removeCache":{"minArgs":1,"maxArgs":1},"removeCookies":{"minArgs":1,"maxArgs":1},"removeDownloads":{"minArgs":1,"maxArgs":1},"removeFormData":{"minArgs":1,"maxArgs":1},"removeHistory":{"minArgs":1,"maxArgs":1},"removeLocalStorage":{"minArgs":1,"maxArgs":1},"removePasswords":{"minArgs":1,"maxArgs":1},"removePluginData":{"minArgs":1,"maxArgs":1},"settings":{"minArgs":0,"maxArgs":0}},"commands":{"getAll":{"minArgs":0,"maxArgs":0}},"contextMenus":{"remove":{"minArgs":1,"maxArgs":1},"removeAll":{"minArgs":0,"maxArgs":0},"update":{"minArgs":2,"maxArgs":2}},"cookies":{"get":{"minArgs":1,"maxArgs":1},"getAll":{"minArgs":1,"maxArgs":1},"getAllCookieStores":{"minArgs":0,"maxArgs":0},"remove":{"minArgs":1,"maxArgs":1},"set":{"minArgs":1,"maxArgs":1}},"devtools":{"inspectedWindow":{"eval":{"minArgs":1,"maxArgs":2}},"panels":{"create":{"minArgs":3,"maxArgs":3,"singleCallbackArg":true}}},"downloads":{"cancel":{"minArgs":1,"maxArgs":1},"download":{"minArgs":1,"maxArgs":1},"erase":{"minArgs":1,"maxArgs":1},"getFileIcon":{"minArgs":1,"maxArgs":2},"open":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"pause":{"minArgs":1,"maxArgs":1},"removeFile":{"minArgs":1,"maxArgs":1},"resume":{"minArgs":1,"maxArgs":1},"search":{"minArgs":1,"maxArgs":1},"show":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true}},"extension":{"isAllowedFileSchemeAccess":{"minArgs":0,"maxArgs":0},"isAllowedIncognitoAccess":{"minArgs":0,"maxArgs":0}},"history":{"addUrl":{"minArgs":1,"maxArgs":1},"deleteAll":{"minArgs":0,"maxArgs":0},"deleteRange":{"minArgs":1,"maxArgs":1},"deleteUrl":{"minArgs":1,"maxArgs":1},"getVisits":{"minArgs":1,"maxArgs":1},"search":{"minArgs":1,"maxArgs":1}},"i18n":{"detectLanguage":{"minArgs":1,"maxArgs":1},"getAcceptLanguages":{"minArgs":0,"maxArgs":0}},"identity":{"launchWebAuthFlow":{"minArgs":1,"maxArgs":1}},"idle":{"queryState":{"minArgs":1,"maxArgs":1}},"management":{"get":{"minArgs":1,"maxArgs":1},"getAll":{"minArgs":0,"maxArgs":0},"getSelf":{"minArgs":0,"maxArgs":0},"setEnabled":{"minArgs":2,"maxArgs":2},"uninstallSelf":{"minArgs":0,"maxArgs":1}},"notifications":{"clear":{"minArgs":1,"maxArgs":1},"create":{"minArgs":1,"maxArgs":2},"getAll":{"minArgs":0,"maxArgs":0},"getPermissionLevel":{"minArgs":0,"maxArgs":0},"update":{"minArgs":2,"maxArgs":2}},"pageAction":{"getPopup":{"minArgs":1,"maxArgs":1},"getTitle":{"minArgs":1,"maxArgs":1},"hide":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"setIcon":{"minArgs":1,"maxArgs":1},"setPopup":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"setTitle":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true},"show":{"minArgs":1,"maxArgs":1,"fallbackToNoCallback":true}},"permissions":{"contains":{"minArgs":1,"maxArgs":1},"getAll":{"minArgs":0,"maxArgs":0},"remove":{"minArgs":1,"maxArgs":1},"request":{"minArgs":1,"maxArgs":1}},"runtime":{"getBackgroundPage":{"minArgs":0,"maxArgs":0},"getBrowserInfo":{"minArgs":0,"maxArgs":0},"getPlatformInfo":{"minArgs":0,"maxArgs":0},"openOptionsPage":{"minArgs":0,"maxArgs":0},"requestUpdateCheck":{"minArgs":0,"maxArgs":0},"sendMessage":{"minArgs":1,"maxArgs":3},"sendNativeMessage":{"minArgs":2,"maxArgs":2},"setUninstallURL":{"minArgs":1,"maxArgs":1}},"sessions":{"getDevices":{"minArgs":0,"maxArgs":1},"getRecentlyClosed":{"minArgs":0,"maxArgs":1},"restore":{"minArgs":0,"maxArgs":1}},"storage":{"local":{"clear":{"minArgs":0,"maxArgs":0},"get":{"minArgs":0,"maxArgs":1},"getBytesInUse":{"minArgs":0,"maxArgs":1},"remove":{"minArgs":1,"maxArgs":1},"set":{"minArgs":1,"maxArgs":1}},"managed":{"get":{"minArgs":0,"maxArgs":1},"getBytesInUse":{"minArgs":0,"maxArgs":1}},"sync":{"clear":{"minArgs":0,"maxArgs":0},"get":{"minArgs":0,"maxArgs":1},"getBytesInUse":{"minArgs":0,"maxArgs":1},"remove":{"minArgs":1,"maxArgs":1},"set":{"minArgs":1,"maxArgs":1}}},"tabs":{"captureVisibleTab":{"minArgs":0,"maxArgs":2},"create":{"minArgs":1,"maxArgs":1},"detectLanguage":{"minArgs":0,"maxArgs":1},"discard":{"minArgs":0,"maxArgs":1},"duplicate":{"minArgs":1,"maxArgs":1},"executeScript":{"minArgs":1,"maxArgs":2},"get":{"minArgs":1,"maxArgs":1},"getCurrent":{"minArgs":0,"maxArgs":0},"getZoom":{"minArgs":0,"maxArgs":1},"getZoomSettings":{"minArgs":0,"maxArgs":1},"highlight":{"minArgs":1,"maxArgs":1},"insertCSS":{"minArgs":1,"maxArgs":2},"move":{"minArgs":2,"maxArgs":2},"query":{"minArgs":1,"maxArgs":1},"reload":{"minArgs":0,"maxArgs":2},"remove":{"minArgs":1,"maxArgs":1},"removeCSS":{"minArgs":1,"maxArgs":2},"sendMessage":{"minArgs":2,"maxArgs":3},"setZoom":{"minArgs":1,"maxArgs":2},"setZoomSettings":{"minArgs":1,"maxArgs":2},"update":{"minArgs":1,"maxArgs":2}},"topSites":{"get":{"minArgs":0,"maxArgs":0}},"webNavigation":{"getAllFrames":{"minArgs":1,"maxArgs":1},"getFrame":{"minArgs":1,"maxArgs":1}},"webRequest":{"handlerBehaviorChanged":{"minArgs":0,"maxArgs":0}},"windows":{"create":{"minArgs":0,"maxArgs":1},"get":{"minArgs":1,"maxArgs":2},"getAll":{"minArgs":0,"maxArgs":1},"getCurrent":{"minArgs":0,"maxArgs":1},"getLastFocused":{"minArgs":0,"maxArgs":1},"remove":{"minArgs":1,"maxArgs":1},"update":{"minArgs":2,"maxArgs":2}}};if(Object.keys(apiMetadata).length===0){throw new Error("api-metadata.json has not been included in browser-polyfill");}/**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */class DefaultWeakMap extends WeakMap{constructor(createItem,items=undefined){super(items);this.createItem=createItem;}get(key){if(!this.has(key)){this.set(key,this.createItem(key));}return super.get(key);}}/**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */const isThenable=value=>{return value&&typeof value==="object"&&typeof value.then==="function";};/**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.rejection
       *        The promise's rejection function.
       * @param {object} metadata
       *        Metadata about the wrapped method which has created the callback.
       * @param {integer} metadata.maxResolvedArgs
       *        The maximum number of arguments which may be passed to the
       *        callback created by the wrapped async function.
       *
       * @returns {function}
       *        The generated callback function.
       */const makeCallback=(promise,metadata)=>{return(...callbackArgs)=>{if(chrome.runtime.lastError){promise.reject(chrome.runtime.lastError);}else if(metadata.singleCallbackArg||callbackArgs.length<=1){promise.resolve(callbackArgs[0]);}else{promise.resolve(callbackArgs);}};};const pluralizeArguments=numArgs=>numArgs==1?"argument":"arguments";/**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxResolvedArgs
       *        The maximum number of arguments which may be passed to the
       *        callback created by the wrapped async function.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */const wrapAsyncFunction=(name,metadata)=>{return function asyncFunctionWrapper(target,...args){if(args.length<metadata.minArgs){throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);}if(args.length>metadata.maxArgs){throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);}return new Promise((resolve,reject)=>{if(metadata.fallbackToNoCallback){// This API method has currently no callback on Chrome, but it return a promise on Firefox,
// and so the polyfill will try to call it with a callback first, and it will fallback
// to not passing the callback if the first call fails.
try{target[name](...args,makeCallback({resolve,reject},metadata));}catch(cbError){console.warn(`${name} API method doesn't seem to support the callback parameter, `+"falling back to call it without a callback: ",cbError);target[name](...args);// Update the API method metadata, so that the next API calls will not try to
// use the unsupported callback anymore.
metadata.fallbackToNoCallback=false;metadata.noCallback=true;resolve();}}else if(metadata.noCallback){target[name](...args);resolve();}else{target[name](...args,makeCallback({resolve,reject},metadata));}});};};/**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the original method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */const wrapMethod=(target,method,wrapper)=>{return new Proxy(method,{apply(targetMethod,thisObj,args){return wrapper.call(thisObj,target,...args);}});};let hasOwnProperty=Function.call.bind(Object.prototype.hasOwnProperty);/**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */const wrapObject=(target,wrappers={},metadata={})=>{let cache=Object.create(null);let handlers={has(proxyTarget,prop){return prop in target||prop in cache;},get(proxyTarget,prop,receiver){if(prop in cache){return cache[prop];}if(!(prop in target)){return undefined;}let value=target[prop];if(typeof value==="function"){// This is a method on the underlying object. Check if we need to do
// any wrapping.
if(typeof wrappers[prop]==="function"){// We have a special-case wrapper for this method.
value=wrapMethod(target,target[prop],wrappers[prop]);}else if(hasOwnProperty(metadata,prop)){// This is an async method that we have metadata for. Create a
// Promise wrapper for it.
let wrapper=wrapAsyncFunction(prop,metadata[prop]);value=wrapMethod(target,target[prop],wrapper);}else{// This is a method that we don't know or care about. Return the
// original method, bound to the underlying object.
value=value.bind(target);}}else if(typeof value==="object"&&value!==null&&(hasOwnProperty(wrappers,prop)||hasOwnProperty(metadata,prop))){// This is an object that we need to do some wrapping for the children
// of. Create a sub-object wrapper for it with the appropriate child
// metadata.
value=wrapObject(value,wrappers[prop],metadata[prop]);}else{// We don't need to do any wrapping for this property,
// so just forward all access to the underlying object.
Object.defineProperty(cache,prop,{configurable:true,enumerable:true,get(){return target[prop];},set(value){target[prop]=value;}});return value;}cache[prop]=value;return value;},set(proxyTarget,prop,value,receiver){if(prop in cache){cache[prop]=value;}else{target[prop]=value;}return true;},defineProperty(proxyTarget,prop,desc){return Reflect.defineProperty(cache,prop,desc);},deleteProperty(proxyTarget,prop){return Reflect.deleteProperty(cache,prop);}};// Per contract of the Proxy API, the "get" proxy handler must return the
// original value of the target if that value is declared read-only and
// non-configurable. For this reason, we create an object with the
// prototype set to `target` instead of using `target` directly.
// Otherwise we cannot return a custom object for APIs that
// are declared read-only and non-configurable, such as `chrome.devtools`.
//
// The proxy handlers themselves will still use the original `target`
// instead of the `proxyTarget`, so that the methods and properties are
// dereferenced via the original targets.
let proxyTarget=Object.create(target);return new Proxy(proxyTarget,handlers);};/**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */const wrapEvent=wrapperMap=>({addListener(target,listener,...args){target.addListener(wrapperMap.get(listener),...args);},hasListener(target,listener){return target.hasListener(wrapperMap.get(listener));},removeListener(target,listener){target.removeListener(wrapperMap.get(listener));}});// Keep track if the deprecation warning has been logged at least once.
let loggedSendResponseDeprecationWarning=false;const onMessageWrappers=new DefaultWeakMap(listener=>{if(typeof listener!=="function"){return listener;}/**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */return function onMessage(message,sender,sendResponse){let didCallSendResponse=false;let wrappedSendResponse;let sendResponsePromise=new Promise(resolve=>{wrappedSendResponse=function(response){if(!loggedSendResponseDeprecationWarning){console.warn(SEND_RESPONSE_DEPRECATION_WARNING,new Error().stack);loggedSendResponseDeprecationWarning=true;}didCallSendResponse=true;resolve(response);};});let result;try{result=listener(message,sender,wrappedSendResponse);}catch(err){result=Promise.reject(err);}const isResultThenable=result!==true&&isThenable(result);// If the listener didn't returned true or a Promise, or called
// wrappedSendResponse synchronously, we can exit earlier
// because there will be no response sent from this listener.
if(result!==true&&!isResultThenable&&!didCallSendResponse){return false;}// A small helper to send the message if the promise resolves
// and an error if the promise rejects (a wrapped sendMessage has
// to translate the message into a resolved promise or a rejected
// promise).
const sendPromisedResult=promise=>{promise.then(msg=>{// send the message value.
sendResponse(msg);},error=>{// Send a JSON representation of the error if the rejected value
// is an instance of error, or the object itself otherwise.
let message;if(error&&(error instanceof Error||typeof error.message==="string")){message=error.message;}else{message="An unexpected error occurred";}sendResponse({__mozWebExtensionPolyfillReject__:true,message});}).catch(err=>{// Print an error on the console if unable to send the response.
console.error("Failed to send onMessage rejected reply",err);});};// If the listener returned a Promise, send the resolved value as a
// result, otherwise wait the promise related to the wrappedSendResponse
// callback to resolve and send it as a response.
if(isResultThenable){sendPromisedResult(result);}else{sendPromisedResult(sendResponsePromise);}// Let Chrome know that the listener is replying.
return true;};});const wrappedSendMessageCallback=({reject,resolve},reply)=>{if(chrome.runtime.lastError){// Detect when none of the listeners replied to the sendMessage call and resolve
// the promise to undefined as in Firefox.
// See https://github.com/mozilla/webextension-polyfill/issues/130
if(chrome.runtime.lastError.message===CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE){resolve();}else{reject(chrome.runtime.lastError);}}else if(reply&&reply.__mozWebExtensionPolyfillReject__){// Convert back the JSON representation of the error into
// an Error instance.
reject(new Error(reply.message));}else{resolve(reply);}};const wrappedSendMessage=(name,metadata,apiNamespaceObj,...args)=>{if(args.length<metadata.minArgs){throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);}if(args.length>metadata.maxArgs){throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);}return new Promise((resolve,reject)=>{const wrappedCb=wrappedSendMessageCallback.bind(null,{resolve,reject});args.push(wrappedCb);apiNamespaceObj.sendMessage(...args);});};const staticWrappers={runtime:{onMessage:wrapEvent(onMessageWrappers),onMessageExternal:wrapEvent(onMessageWrappers),sendMessage:wrappedSendMessage.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:wrappedSendMessage.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}};const settingMetadata={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};apiMetadata.privacy={network:{networkPredictionEnabled:settingMetadata,webRTCIPHandlingPolicy:settingMetadata},services:{passwordSavingEnabled:settingMetadata},websites:{hyperlinkAuditingEnabled:settingMetadata,referrersEnabled:settingMetadata}};return wrapObject(chrome,staticWrappers,apiMetadata);};// The build process adds a UMD wrapper around this file, which makes the
// `module` variable available.
module.exports=wrapAPIs();// eslint-disable-line no-undef
}else{module.exports=browser;// eslint-disable-line no-undef
}});

/***/ }),

/***/ "../node_modules/webpack/buildin/global.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var g;// This works in non-strict mode
g=function(){return this;}();try{// This works if eval is allowed (see CSP)
g=g||Function("return this")()||(1,eval)("this");}catch(e){// This works if the window reference is available
if(typeof window==="object")g=window;}// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}
module.exports=g;

/***/ }),

/***/ "./IO/filesystem.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.downloadFile=downloadFile;var _webextensionPolyfill=_interopRequireDefault(__webpack_require__("../../../node_modules/webextension-polyfill/dist/browser-polyfill.js"));function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function downloadFile(input){_webextensionPolyfill.default.downloads.download({filename:'visual-grid-config.yml',url:createBlob('application/yaml',input),saveAs:false,conflictAction:'overwrite'});}let previousFile;function createBlob(_mimeType,data){const blob=new Blob([data],{type:'text/plain'});// If we are replacing a previously generated file we need to
// manually revoke the object URL to avoid memory leaks.
if(previousFile!==null){window.URL.revokeObjectURL(previousFile);}previousFile=window.URL.createObjectURL(blob);return previousFile;}

/***/ }),

/***/ "./IO/message-port.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.sendMessage=sendMessage;exports.startPolling=startPolling;exports.stopPolling=stopPolling;exports.DEFAULT_ID=void 0;var _webextensionPolyfill=_interopRequireDefault(__webpack_require__("../../../node_modules/webextension-polyfill/dist/browser-polyfill.js"));var _userAgent=__webpack_require__("./background/utils/userAgent.js");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function sendMessage(payload){return getId().then(id=>_webextensionPolyfill.default.runtime.sendMessage(id,payload));}const DEFAULT_ID=_userAgent.isChrome?'mooikfkahbdckldjjndioackbalphokd':_userAgent.isFirefox?'{a6fd85ed-e919-4a43-a5af-8da18bda539f}':'';// eslint-disable-line indent
exports.DEFAULT_ID=DEFAULT_ID;function bundledId(){let id=undefined;if(!id){id=DEFAULT_ID;}return id;}function getId(){return _webextensionPolyfill.default.storage.local.get(['seideId']).then(results=>results.seideId?results.seideId:bundledId());}let interval;function startPolling(payload,cb){interval=setInterval(()=>{sendMessage({uri:'/health',verb:'get'}).catch(res=>({error:res.message})).then(res=>{if(!res){sendMessage({uri:'/register',verb:'post',payload}).then(()=>{cb();});}else if(res===true){cb();}else if(res.error){cb(new Error(res.error));}});},1000);}function stopPolling(){clearInterval(interval);}

/***/ }),

/***/ "./IO/storage.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.get=get;exports.set=set;exports.default=void 0;var _webextensionPolyfill=_interopRequireDefault(__webpack_require__("../../../node_modules/webextension-polyfill/dist/browser-polyfill.js"));function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function get(...argv){if(_webextensionPolyfill.default.storage){return _webextensionPolyfill.default.storage.local.get(...argv);}else{return Promise.reject(new Error('Storage module is unavailable'));}}function set(...argv){if(_webextensionPolyfill.default.storage){return _webextensionPolyfill.default.storage.local.set(...argv);}else{return Promise.reject(new Error('Storage module is unavailable'));}}var _default={get,set};exports.default=_default;

/***/ }),

/***/ "./app/assets/images/ic_add.svg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "media/ic_add.10dd23c3.svg";

/***/ }),

/***/ "./app/assets/images/ic_delete.svg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "media/ic_delete.26c8b669.svg";

/***/ }),

/***/ "./app/assets/images/ic_download.svg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "media/ic_download.0ab14103.svg";

/***/ }),

/***/ "./app/assets/images/ic_x_close.svg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "media/ic_x_close.14f9be4a.svg";

/***/ }),

/***/ "./app/assets/images/sad_face.png":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "media/sad_face.bf5193c0.png";

/***/ }),

/***/ "./app/assets/images/tick.png":
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAABnpJREFUeAHtm1uIVVUYx+ekjtlFTbQpwjILES0xEIqKMhMqeqiHKEgh6iG6YhfDciohEoQEp6REg7KIpofqJWIqCofIejAyXzSSpnIsKg2FnMxMT7//Ya9cfWfvc/bdc5z54O/aa63v8v/WPnvvdRk7OkZkZASG9QhUysq+Wq12EutCMANMBxPBaaAKeiuVypeUJ5aQ9DywAmwCf4Eo+ZOOqSdE9iQyGXSDHSCJ3NjWA0Cm54AeMJQk60B3kFKPROkyOmtEiOvZfhg8BU5t4m83/dvBt+A3cADsAX28A/ZTtpeQ/EywHUTJETq+AE+AWe2VXRO2JHQD2A/CZC+NS0FXEzft2R0kp7trRc//SjChVTKDyySwDNwNxmTihYNO8BoIk400np0pQM7G8DkXDHhk12UKgaOw5A/Tfm8mxwUYw8kmr3HYkToUxnqmrehZn5/aaUGGcApLXtxXpQqJoV549pnXROf8VA4LNIJTVPK99I1KHBojfers2153flgkP4ZE7Xdez/z8xCNZsAGc8r3z4otTfT6stMsLT7zT/eyD5DW3P2Cy36i+VhL45X/nlSCOnzfJa5LT6t95Rzn9nQ+Sn4Inu6pbOSzufDAA3W4og1Jv/Vaa3hbzs3d3mGS/MQOw1PUd7xJehSc/zySvCVBLrOoKTz74+a8wA/D58b7rAa9i77xLkuT7zQA87vrCSnRPAe+AX8BakHmXycbBZ2nJa7lrd28b7uSg/xjw5XUquW2346uc5DXqBJvlZ8L1oL0bto7OcmOj6hqrl6aOn/KSF0EC3iz2nnzYjDi62nH5zrNxl082s23Uj5NykxcZgj7q2Afl2kYkXR+608HPxlbVe5xOkhK78pMXQQI/I9aeaKs7lmBzMdjn2epSn9DbYjkIlNDPPXl8jgIPgHXg0kg+dK4BvjwUqRzSgeHlwE6h/6btuhD1uib0ck9eQfDr/7K1wDvLBT/JXQTlWFM/ZOoNqxxuaM5wCzjsKWonVp/Jy7y2ukslT2M/sBstb9G2GN9HKNPK1Z6hDm/muLodgCHXEZTNTnqMekcHRPtovAPo1NeJ/LxPkrNdg18WnLxC2XXMQRffDsAfriMoTzf1WFUGoRfFB43yJOofkew0v72E5BXO5qEjuXqBzH3Al1fqteK34Ohp31lwvZOyS14oC3nmLUPiaDXry1SrU6ujsdDX4npzqGKCRny8YHyquhXoqzGgipFsmxmGG741T/FFf4sQPlOlQ3fEF+0GZ5rbY18Bb/hOg2u7za7mXJPXWODz2iCeK7aZMTpWRUNk9zjNoFxwTCPdFX5GA70EG0nuyYstAe2n/dWGWWDwtmHZ09AgZic+x4HPjG9XLSR5USOAnabrCxUtGNzvWAXlQLR2sh78TQTbjP8ik59tYqmq+Ua0oKDtcPt8XhRtkawH313gA/A76AHJj6tihsS3/jDDly2xTLH42Lfi+uVYhi2kBOex4EeTx5JYFDFabAz/oT4zlnGLKMH3EZODNnrOjEUPRZ0J2tF7N5ZxCyjBfQKwk5/1iajhQMtHKw0XNIkCFKgM6WcNcf2CL0gUEgM9Q5q2+vIVlXGJHJWsDL85QLM9X15KRQMP+sMIK1rotKRAdAr4wRDWxO6M1IQxftM4VHV5aocFGcJJ761PRc7I7ZlC4kz7/lq8+HKUyk2ZHOdsDJ8NPsHgenUuYXCmRdKvJsBB6otyCZDBCRx058OS76M9v0kWzq4Ah4CVVTTYjZUMKcU3Ja6e+bCfvQ537S5QfMdRmji9C4TJezSOj7Irop14etvbF564aYo9o4iYNZ84vxUMASvf07AIhG825MQI/+OBvvP2U0dT7Vi/uORdDgS6BOxSxBD5mrbrnW5eJT41L9H01s7waKqJnvn8f/ZRCRBMq7rNtdDh//TTfCeIN/+OCIS9lrRa1dmpOU3/yWqu8nvhRXCpayaoTpO146KpZpRoaa2BWgbmgpPrHHkN9GsPbwGQX7uZQdP/RJOcTN/5XJ5XSOig4UVwpZdL1OVROgaB/seItuF1+KJzA21da7d2MmgmOiTZALrZgt/XTLm0fgZiIfgEFCVa0q4HyRY2pY1AEAiC+kQ9B34CecgWnCwBmd4nYeOQyyMQ5lhtENYEaS64BlwFtLV2Hmj0wtKx1U6wFWwS+JnvoixECh2AMMYMSift04A+WXrudSCrM0m9D/aC3SRcpRyRkREoYQT+BYm7y7GlSHsUAAAAAElFTkSuQmCC"

/***/ }),

/***/ "./app/assets/images/warning.png":
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAABR9JREFUeAHtmzmMFEcUhpkFgSEAyTgAhFhHsJHtEIgMpBxCXDFHxBGQcEReiDkSg2OOCAjNEXGkWHZgEyDsBDsBCTuwJZ9rj79X7rf6tz3dU9Uz9PTMTklv63XV/7/3/72rVdUsLFgwHvP7DbQGZb/dbq+l97as/8NWq/XDoLTU3hfze4g/CR+W76ldyCAaYnQz8Zc7l9nWNg9CU209MThBfCmmvyK38GF7E7UJqrsR5o64U+ZfiXVZWO7jSN26aumHuxXEa3fJ/Ik3tlzWDbPC90ZmxtRlMfmSfKmbs5ywNR+XfW8kZlxNEfpbf2/eGPt73X2GncpjhvYZQw/E3KMiI2AeCe5BEW6o1jG0S0zNkH9QZMD2CMP42FWEHYp1XCwhvnM3zJ92E24YwRt3STdOY/cRf1bM/Ej+bjexhiEM6+NsN04j91G/hvjFXTAfjRVqWOFZjTWx3MbgEH1TTHxNvjBWnGEJ4/i4GcttBA7Vm4h/XD3zx6nCjCN8q7UptcZA8Ai18/4XIv5WVSHUuCV1rGbz7wmIPCyi7Yw/2ekFCCakBZhJNvWecLgTrjFriM2f96eLxAXX8qUENy2wZt8TEHpJxM457+cNCi6k+X1/ZjN/T7jke42aEZo/7+8rExj7AqwG2H2CtztF8+4JiNLz/uMy85kp8dRuR+AfC6FZ9wSE7RRxped9Nyr4kPp60Qwof0/YWYStdR1hi4lvg4v/vlyJESD4kEZyrgjPei6O4b1VDCLOiCg7w6+MaSickEZyVgLWe8KZGN5bwyBmNaHn/WOxzYJr+ZLAOyY06706ltt3HM1viJjU875Qu/8SdPGQ8veEG75X64yQ/Hl/S4qAOe55SORuEX799wSatwg9799OMWBYMRDSCvzbUsO01PdnPpodkuaF5/0yU8IPaRm20x6kSULvCYc64fq+RtPlxCvCx7kqTZzsc8Ua55zPbJqWV6mTxKHJRWn6PfmypAIZWGqEtGKNZZBNg4+LVepEc+iygdDP9/dHk3NAV+xzbjv6Ef5+r8Fs2jZEk1OBFL8vzZ6k8hUvdUKqe6k5BZ5Ivfup/Cg8DXZIEzvvfxhFLABJrZAWwKKWTQthmnzsiCLGgqiaP+9fjeUW4Vypz0W42HXqXPVazP29J1DwtBT/iTzqvF8mXuqFtAwbs2eaCNPm43QMryuGavnz/vGupAEB0Hrc3TP3555AoetS9Bvy6M/3634Ppo0wjT6u96SBKhsJ/Xx/a08FayCjd6u7z7RvrNQWsp33n0qxO5UKDYCE5jui2zyk3xMgHZQiv5G/PwAvlVqaVsI0+ziYVAhW/rx/PqlAA8B4OO/umdPuCRAuCNnO2pXO+2XvQeqHtAxbZc80E6bdx4WoOqDz5/0DUcREkKvyOZEeBaf2Aa/PHHdPAHhPSD2d98tUSo+QlmF72aO43hPuldYCvF2E/U3+USmhh03pE9IeSpVSzQNhXnxs70hg1877LxzF/FlH4BAumhfxZR7///cEFk8JqC/n/aa8K3zl7wmn5mgDsIr4WV7AiTmAEXjA2wnxZ15Xzdri4ZpsPiNfNLs5Iol5Isybj2vBGk/2Z+2hOu9X/Z7gc5u7zzxP2efzJ2XxbtXiw8LD613xe9J+1GdE/Ho2p+V5FNP1YmrGbnz2j5ieE+/IxnxIf8fk1AT/W+slyW7ij/ngOvNoXneb95abzn4S7JT0HjG77vsjMtsfYd8Qn2ff+BGxNbYxfgPjNzB+A+M3UO0N/At6rLwC94GmXgAAAABJRU5ErkJggg=="

/***/ }),

/***/ "./app/components/ActionButtons/ActionButton/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _classnames=_interopRequireDefault(__webpack_require__("../../../node_modules/classnames/index.js"));function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class ActionButton extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement("div",{className:(0,_classnames.default)(this.props.type,'outer',this.props.isSelected?'selected':undefined,this.props.className?this.props.className:undefined),onClick:this.props.onClick},/*#__PURE__*/_react.default.createElement("div",{className:(0,_classnames.default)(this.props.type,'inner',this.props.isSelected?'selected':undefined,this.props.className?this.props.className:undefined),style:{mask:`url(${this.props.imgPath})`,maskSize:this.props.size,maskPosition:this.props.position,WebkitMaskImage:`url(${this.props.imgPath})`,WebkitMaskSize:this.props.size,WebkitMaskPosition:this.props.position}}));}}exports.default=ActionButton;_defineProperty(ActionButton,"propTypes",{type:_propTypes.default.string.isRequired,size:_propTypes.default.string.isRequired,position:_propTypes.default.string.isRequired,imgPath:_propTypes.default.string.isRequired,onClick:_propTypes.default.func,isSelected:_propTypes.default.bool,className:_propTypes.default.string});

/***/ }),

/***/ "./app/components/ActionButtons/AddButton/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _ActionButton=_interopRequireDefault(__webpack_require__("./app/components/ActionButtons/ActionButton/index.jsx"));var _ic_add=_interopRequireDefault(__webpack_require__("./app/assets/images/ic_add.svg"));__webpack_require__("./app/components/ActionButtons/AddButton/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class AddButton extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement(_ActionButton.default,{type:"add",size:"19px",position:"center",imgPath:_ic_add.default,onClick:this.props.onClick,isSelected:this.props.isSelected});}}exports.default=AddButton;_defineProperty(AddButton,"propTypes",{onClick:_propTypes.default.func.isRequired,isSelected:_propTypes.default.bool});

/***/ }),

/***/ "./app/components/ActionButtons/AddButton/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/ActionButtons/AddButton/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/components/ActionButtons/DeleteButton/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _ActionButton=_interopRequireDefault(__webpack_require__("./app/components/ActionButtons/ActionButton/index.jsx"));var _ic_delete=_interopRequireDefault(__webpack_require__("./app/assets/images/ic_delete.svg"));__webpack_require__("./app/components/ActionButtons/DeleteButton/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class DeleteButton extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement(_ActionButton.default,{className:"delete",type:"close",size:"16px",position:"center",imgPath:_ic_delete.default,onClick:this.props.onClick});}}exports.default=DeleteButton;_defineProperty(DeleteButton,"propTypes",{onClick:_propTypes.default.func});

/***/ }),

/***/ "./app/components/ActionButtons/DeleteButton/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/ActionButtons/DeleteButton/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/components/ActionButtons/DownloadButton/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _ActionButton=_interopRequireDefault(__webpack_require__("./app/components/ActionButtons/ActionButton/index.jsx"));var _ic_download=_interopRequireDefault(__webpack_require__("./app/assets/images/ic_download.svg"));var _Tooltip=_interopRequireDefault(__webpack_require__("./commons/components/Tooltip/index.jsx"));__webpack_require__("./app/components/ActionButtons/DownloadButton/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class DownloadButton extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement(_react.default.Fragment,null,/*#__PURE__*/_react.default.createElement(_ActionButton.default,{className:"download",type:"close",size:"25px",position:"center",imgPath:_ic_download.default,onClick:this.props.onClick}),/*#__PURE__*/_react.default.createElement(_Tooltip.default,null));}}exports.default=DownloadButton;_defineProperty(DownloadButton,"propTypes",{onClick:_propTypes.default.func});

/***/ }),

/***/ "./app/components/ActionButtons/DownloadButton/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/ActionButtons/DownloadButton/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/components/ActionButtons/RemoveButton/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _ActionButton=_interopRequireDefault(__webpack_require__("./app/components/ActionButtons/ActionButton/index.jsx"));var _ic_x_close=_interopRequireDefault(__webpack_require__("./app/assets/images/ic_x_close.svg"));__webpack_require__("./app/components/ActionButtons/RemoveButton/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class RemoveButton extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement(_ActionButton.default,{className:"remove",type:"close",size:"16px",position:"center",imgPath:_ic_x_close.default,onClick:this.props.onClick});}}exports.default=RemoveButton;_defineProperty(RemoveButton,"propTypes",{onClick:_propTypes.default.func});

/***/ }),

/***/ "./app/components/ActionButtons/RemoveButton/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/ActionButtons/RemoveButton/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/components/ButtonList/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));__webpack_require__("./app/components/ButtonList/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class ButtonList extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement("ul",{className:"buttons"},this.props.items.map(item=>/*#__PURE__*/_react.default.createElement(ListButton,{key:item,name:item,label:this.props.label,onClick:this.props.onClick})));}}exports.default=ButtonList;_defineProperty(ButtonList,"propTypes",{items:_propTypes.default.array.isRequired,label:_propTypes.default.string,onClick:_propTypes.default.func.isRequired});class ListButton extends _react.default.Component{constructor(props){super(props);this.handleClick=this.handleClick.bind(this);this.state={label:props.label,selectedCommand:false};}async displaySelectedNotification(){this.setState({label:'✓ Added to test',selectedCommand:true});await new Promise(resolve=>setTimeout(resolve,1000));this.setState({selectedCommand:false});await new Promise(resolve=>setTimeout(resolve,200));this.setState({label:this.props.label});}handleClick(){this.props.onClick(this.props.name);this.displaySelectedNotification();}render(){return/*#__PURE__*/_react.default.createElement("li",{tabIndex:"0",onClick:this.handleClick},/*#__PURE__*/_react.default.createElement("button",{tabIndex:"-1"},this.props.name),this.state.label&&/*#__PURE__*/_react.default.createElement("a",{className:this.state.selectedCommand?'selected-command':undefined},this.state.label));}}_defineProperty(ListButton,"propTypes",{name:_propTypes.default.string.isRequired,label:_propTypes.default.string,onClick:_propTypes.default.func.isRequired});

/***/ }),

/***/ "./app/components/ButtonList/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/ButtonList/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/components/DisconnectBanner/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _SpinnerBanner=_interopRequireWildcard(__webpack_require__("./app/components/SpinnerBanner/index.jsx"));function _getRequireWildcardCache(){if(typeof WeakMap!=="function")return null;var cache=new WeakMap();_getRequireWildcardCache=function(){return cache;};return cache;}function _interopRequireWildcard(obj){if(obj&&obj.__esModule){return obj;}if(obj===null||typeof obj!=="object"&&typeof obj!=="function"){return{default:obj};}var cache=_getRequireWildcardCache();if(cache&&cache.has(obj)){return cache.get(obj);}var newObj={};var hasPropertyDescriptor=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var key in obj){if(Object.prototype.hasOwnProperty.call(obj,key)){var desc=hasPropertyDescriptor?Object.getOwnPropertyDescriptor(obj,key):null;if(desc&&(desc.get||desc.set)){Object.defineProperty(newObj,key,desc);}else{newObj[key]=obj[key];}}}newObj.default=obj;if(cache){cache.set(obj,newObj);}return newObj;}function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}class DiconnectBanner extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement(_SpinnerBanner.default,{state:_SpinnerBanner.SpinnerStates.ERROR,style:{height:'75px'}},"Please open Selenium IDE.");}}exports.default=DiconnectBanner;

/***/ }),

/***/ "./app/components/DownloadConfig/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _parsers=__webpack_require__("./background/utils/parsers.js");var _filesystem=__webpack_require__("./IO/filesystem.js");var _DownloadButton=_interopRequireDefault(__webpack_require__("./app/components/ActionButtons/DownloadButton/index.jsx"));function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}const yaml=__webpack_require__("../../../node_modules/js-yaml/index.js");class DownloadConfig extends _react.default.Component{generateYaml(){return yaml.dump({params:{eyesRendering:(0,_parsers.parseBrowsers)(this.props.projectSettings.selectedBrowsers,this.props.projectSettings.selectedViewportSizes,this.props.projectSettings.selectedDevices,this.props.projectSettings.selectedDeviceOrientations).matrix}});}render(){return/*#__PURE__*/_react.default.createElement("div",{className:"download-config","data-tip":"<p>Download Ultrafast Grid configuration</p>","data-place":"left"},/*#__PURE__*/_react.default.createElement(_DownloadButton.default,{onClick:()=>{(0,_filesystem.downloadFile)(this.generateYaml());}}));}}exports.default=DownloadConfig;_defineProperty(DownloadConfig,"propTypes",{projectSettings:_propTypes.default.object.isRequired});

/***/ }),

/***/ "./app/components/MoreInfo/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=MoreInfo;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _Link=_interopRequireDefault(__webpack_require__("./commons/components/Link/index.jsx"));function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function MoreInfo(){return/*#__PURE__*/_react.default.createElement("span",null,"For more information read the ",/*#__PURE__*/_react.default.createElement(_Link.default,{href:"https://applitools.com/tutorials/selenium-ide.html"},"tutorial"),".");}

/***/ }),

/***/ "./app/components/SpinnerBanner/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=exports.SpinnerStates=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _classnames=_interopRequireDefault(__webpack_require__("../../../node_modules/classnames/index.js"));var _tick=_interopRequireDefault(__webpack_require__("./app/assets/images/tick.png"));var _warning=_interopRequireDefault(__webpack_require__("./app/assets/images/warning.png"));__webpack_require__("./app/components/SpinnerBanner/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}const SpinnerStates={SUCCESS:'success',SETUP:'setup',ERROR:'error'};exports.SpinnerStates=SpinnerStates;const StatusImages={[SpinnerStates.SUCCESS]:_tick.default,[SpinnerStates.ERROR]:_warning.default};class SpinnerBanner extends _react.default.Component{constructor(props){super(props);this.renderSpinner=this.renderSpinner.bind(this);}renderSpinner(style){return/*#__PURE__*/_react.default.createElement("div",{className:(0,_classnames.default)('banner',this.props.state),style:Object.assign({},this.props.style,style)},this.props.spin&&/*#__PURE__*/_react.default.createElement("span",{className:"loader"}),!this.props.spin&&(StatusImages[this.props.state]?/*#__PURE__*/_react.default.createElement("img",{width:"32px",src:StatusImages[this.props.state],style:{marginRight:'10px'}}):/*#__PURE__*/_react.default.createElement("span",{className:"loader stopped"})),/*#__PURE__*/_react.default.createElement("span",null,this.props.children));}render(){return/*#__PURE__*/_react.default.createElement(_react.default.Fragment,null,this.renderSpinner({position:'fixed'}),this.renderSpinner());}}exports.default=SpinnerBanner;_defineProperty(SpinnerBanner,"propTypes",{children:_propTypes.default.node,spin:_propTypes.default.bool,state:_propTypes.default.oneOf(Object.values(SpinnerStates)).isRequired,style:_propTypes.default.object});_defineProperty(SpinnerBanner,"defaultProps",{spin:true});

/***/ }),

/***/ "./app/components/SpinnerBanner/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/SpinnerBanner/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/components/VisualGrid/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _storage=_interopRequireDefault(__webpack_require__("./IO/storage.js"));var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _classnames=_interopRequireDefault(__webpack_require__("../../../node_modules/classnames/index.js"));var _VisualGridOptionGroup=_interopRequireDefault(__webpack_require__("./app/components/VisualGridOptionGroup/index.jsx"));var _VisualGridOptionCategory=_interopRequireDefault(__webpack_require__("./app/components/VisualGridOptionCategory/index.jsx"));var _VisualGridViewports=_interopRequireDefault(__webpack_require__("./app/components/VisualGridViewports/index.jsx"));var _DownloadConfig=_interopRequireDefault(__webpack_require__("./app/components/DownloadConfig/index.jsx"));var _options=__webpack_require__("./app/components/VisualGrid/options.js");__webpack_require__("./app/components/VisualGrid/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function ownKeys(object,enumerableOnly){var keys=Object.keys(object);if(Object.getOwnPropertySymbols){var symbols=Object.getOwnPropertySymbols(object);if(enumerableOnly)symbols=symbols.filter(function(sym){return Object.getOwnPropertyDescriptor(object,sym).enumerable;});keys.push.apply(keys,symbols);}return keys;}function _objectSpread(target){for(var i=1;i<arguments.length;i++){var source=arguments[i]!=null?arguments[i]:{};if(i%2){ownKeys(Object(source),true).forEach(function(key){_defineProperty(target,key,source[key]);});}else if(Object.getOwnPropertyDescriptors){Object.defineProperties(target,Object.getOwnPropertyDescriptors(source));}else{ownKeys(Object(source)).forEach(function(key){Object.defineProperty(target,key,Object.getOwnPropertyDescriptor(source,key));});}}return target;}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}const ALL_BROWSERS=[..._options.browsers,..._options.experimentalBrowsers];class VisualGrid extends _react.default.Component{constructor(props){super(props);this.state={modal:{browsers:false,viewports:false,devices:false,orientations:false},projectSettings:_objectSpread({},props.projectSettings),devices:Object.values(_options.DeviceName)};}componentDidUpdate(prevProps){if(prevProps.projectSettings!==this.props.projectSettings)this.setState({projectSettings:this.props.projectSettings});}// MODAL state management
_setModal(type,value){this.setState({modal:_objectSpread({},this.state.modal,{[type]:value})});}modalOpen(type){this._setModal(type,true);}modalClose(type){this._setModal(type,false);}// REMOVE an option
remove(key,value){const result=this.state['projectSettings'][key].filter(option=>option!==value);this.save({[key]:result});}removeBrowser(value){this.remove('selectedBrowsers',value);}removeSelectedViewport(value){this.remove('selectedViewportSizes',value);}removeDevice(value){this.remove('selectedDevices',value);}removeSelectedDeviceOrientation(value){this.remove('selectedDeviceOrientations',value);}// SAVE options
saveBrowsers(browsers){this.save({selectedBrowsers:browsers});}saveViewports(selectedViewports,customViewports){this.save({selectedViewportSizes:selectedViewports,customViewportSizes:customViewports});}saveDevices(devices){this.save({selectedDevices:devices});}saveDeviceOrientations(deviceOrientations){this.save({selectedDeviceOrientations:deviceOrientations});}save(result){_storage.default.get(['projectSettings']).then(({projectSettings})=>{_storage.default.set({['projectSettings']:_objectSpread({},projectSettings,{[this.props.projectId]:_objectSpread({},this.state.projectSettings,{},result)})}).then(()=>{this.setState({['projectSettings']:_objectSpread({},this.state.projectSettings,{},result)});});});}render(){const hasOptionsSelected=!!(this.state.projectSettings.selectedDevices.length||this.state.projectSettings.selectedDeviceOrientations.length||this.state.projectSettings.selectedBrowsers.length||this.state.projectSettings.selectedViewportSizes.length);const hasValidOptions=this.state.projectSettings.selectedDevices.length&&this.state.projectSettings.selectedDeviceOrientations.length||this.state.projectSettings.selectedBrowsers.length&&this.state.projectSettings.selectedViewportSizes.length;return/*#__PURE__*/_react.default.createElement("div",{className:"visual-grid-options"},hasValidOptions?/*#__PURE__*/_react.default.createElement(_DownloadConfig.default,{projectSettings:this.state.projectSettings}):undefined,!hasOptionsSelected?/*#__PURE__*/_react.default.createElement("div",{className:(0,_classnames.default)('error-message','general-error')},"No options selected."):undefined,/*#__PURE__*/_react.default.createElement(_VisualGridOptionGroup.default,{name:"Browsers",selectedCount:this.state.projectSettings.selectedBrowsers.length*this.state.projectSettings.selectedViewportSizes.length},/*#__PURE__*/_react.default.createElement("div",{className:"category browsers"},/*#__PURE__*/_react.default.createElement(_VisualGridOptionCategory.default,{name:"Browsers",errorMessage:this.state.projectSettings.selectedDevices.length||this.state.projectSettings.selectedDeviceOrientations.length||!hasOptionsSelected?'':'A browser is required.',modalIsOpen:this.state.modal.browsers,modalOpen:this.modalOpen.bind(this,'browsers'),modalClose:this.modalClose.bind(this,'browsers'),modalStyles:{content:{top:'auto',left:'auto',right:'-30%',bottom:'11%',width:'170px',transform:'translate(-50%, -50%)'}},options:this.props.isExperimental?ALL_BROWSERS:_options.browsers,selectedOptions:this.state.projectSettings.selectedBrowsers,removeOption:this.removeBrowser.bind(this),onSubmit:this.saveBrowsers.bind(this)})),/*#__PURE__*/_react.default.createElement("div",{className:"category viewports"},/*#__PURE__*/_react.default.createElement(_VisualGridViewports.default,{name:"Viewport Sizes",errorMessage:this.state.projectSettings.selectedBrowsers.length?'A viewport size is required.':'',modalIsOpen:this.state.modal.viewports,modalOpen:this.modalOpen.bind(this,'viewports'),modalClose:this.modalClose.bind(this,'viewports'),modalStyles:{content:{top:'325px',left:'auto',right:'-90px',bottom:'auto',width:'175px',maxHeight:'370px',transform:'translate(-50%, -50%)'}},options:_options.viewportSizes,customOptions:this.state.projectSettings.customViewportSizes,selectedOptions:this.state.projectSettings.selectedViewportSizes,removeOption:this.removeSelectedViewport.bind(this),onSubmit:this.saveViewports.bind(this)}))),/*#__PURE__*/_react.default.createElement("hr",{className:"group-divider"}),/*#__PURE__*/_react.default.createElement(_VisualGridOptionGroup.default,{name:"Devices",selectedCount:this.state.projectSettings.selectedDevices.length*this.state.projectSettings.selectedDeviceOrientations.length},/*#__PURE__*/_react.default.createElement("div",{className:"category devices"},/*#__PURE__*/_react.default.createElement(_VisualGridOptionCategory.default,{name:"Devices",errorMessage:this.state.projectSettings.selectedDeviceOrientations.length?'A device is required.':'',modalIsOpen:this.state.modal.devices,modalOpen:this.modalOpen.bind(this,'devices'),modalClose:this.modalClose.bind(this,'devices'),modalStyles:{content:{top:'auto',left:'auto',right:'-30%',bottom:'-11%',overflow:'hidden',width:'170px',height:'351px',transform:'translate(-50%, -50%)'}},options:this.state.devices,selectedOptions:this.state.projectSettings.selectedDevices,removeOption:this.removeDevice.bind(this),onSubmit:this.saveDevices.bind(this),isSearch:true})),/*#__PURE__*/_react.default.createElement("div",{className:"category device-orientations"},/*#__PURE__*/_react.default.createElement(_VisualGridOptionCategory.default,{name:"Orientations",errorMessage:this.state.projectSettings.selectedDevices.length?'A device orientation is required.':'',modalIsOpen:this.state.modal.orientations,modalOpen:this.modalOpen.bind(this,'orientations'),modalClose:this.modalClose.bind(this,'orientations'),modalStyles:{content:{top:'auto',left:'auto',right:'-30%',bottom:'6%',width:'170px',transform:'translate(-50%, -50%)'}},options:_options.orientations,selectedOptions:this.state.projectSettings.selectedDeviceOrientations,removeOption:this.removeSelectedDeviceOrientation.bind(this),onSubmit:this.saveDeviceOrientations.bind(this)}))));}}exports.default=VisualGrid;_defineProperty(VisualGrid,"propTypes",{projectId:_propTypes.default.string.isRequired,projectSettings:_propTypes.default.object.isRequired,isExperimental:_propTypes.default.bool});

/***/ }),

/***/ "./app/components/VisualGrid/options.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.updateBrowserNamesForBackwardsCompatibility=updateBrowserNamesForBackwardsCompatibility;exports.DeviceName=exports.orientations=exports.viewportSizes=exports.experimentalBrowsers=exports.browserIds=exports.browsers=void 0;const browsers=['Chrome','Safari','Firefox','Edge Chromium','Edge Legacy','IE11','IE10'];exports.browsers=browsers;const browserIds={ie10:'IE_10',ie11:'IE_11'};exports.browserIds=browserIds;const experimentalBrowsers=[];exports.experimentalBrowsers=experimentalBrowsers;const viewportSizes=['2560x1440','2048x1536','1920x1080','750x1334','720x1280'];exports.viewportSizes=viewportSizes;const orientations=['Portrait','Landscape'];// Copied from @applitools/eyes-sdk-core/lib/config/DeviceName.js
// since it can't easily be loaded into the browser (yet).
exports.orientations=orientations;const DeviceName={Blackberry_PlayBook:'Blackberry PlayBook',BlackBerry_Z30:'BlackBerry Z30',Galaxy_A5:'Galaxy A5',Galaxy_Note_10:'Galaxy Note 10',Galaxy_Note_10_Plus:'Galaxy Note 10 Plus',Galaxy_Note_2:'Galaxy Note 2',Galaxy_Note_3:'Galaxy Note 3',Galaxy_Note_4:'Galaxy Note 4',Galaxy_Note_8:'Galaxy Note 8',Galaxy_Note_9:'Galaxy Note 9',Galaxy_S10:'Galaxy S10',Galaxy_S10_Plus:'Galaxy S10 Plus',Galaxy_S3:'Galaxy S3',Galaxy_S5:'Galaxy S5',Galaxy_S8:'Galaxy S8',Galaxy_S8_Plus:'Galaxy S8 Plus',Galaxy_S9:'Galaxy S9',Galaxy_S9_Plus:'Galaxy S9 Plus',iPad:'iPad',iPad_6th_Gen:'iPad 6th Gen',iPad_7th_Gen:'iPad 7th Gen',iPad_Air_2:'iPad Air 2',iPad_Mini:'iPad Mini',iPad_Pro:'iPad Pro',iPhone_11:'iPhone 11',iPhone_11_Pro:'iPhone 11 Pro',iPhone_11_Pro_Max:'iPhone 11 Pro Max',iPhone_4:'iPhone 4',iPhone_5SE:'iPhone 5/SE',iPhone_6_7_8:'iPhone 6/7/8',iPhone_6_7_8_Plus:'iPhone 6/7/8 Plus',iPhone_X:'iPhone X',iPhone_XR:'iPhone XR',iPhone_XS:'iPhone XS',iPhone_XS_Max:'iPhone XS Max',Kindle_Fire_HDX:'Kindle Fire HDX',Laptop_with_HiDPI_screen:'Laptop with HiDPI screen',Laptop_with_MDPI_screen:'Laptop with MDPI screen',Laptop_with_touch:'Laptop with touch',LG_G6:'LG G6',LG_Optimus_L70:'LG Optimus L70',Microsoft_Lumia_550:'Microsoft Lumia 550',Microsoft_Lumia_950:'Microsoft Lumia 950',Nexus_10:'Nexus 10',Nexus_4:'Nexus 4',Nexus_5:'Nexus 5',Nexus_5X:'Nexus 5X',Nexus_6:'Nexus 6',Nexus_6P:'Nexus 6P',Nexus_7:'Nexus 7',Nokia_Lumia_520:'Nokia Lumia 520',Nokia_N9:'Nokia N9',OnePlus_7T:'OnePlus 7T',OnePlus_7T_Pro:'OnePlus 7T Pro',// OnePlus_8: 'OnePlus 8',
// OnePlus_8_Pro: 'OnePlus 8 Pro',
Pixel_2:'Pixel 2',Pixel_2_XL:'Pixel 2 XL',Pixel_3:'Pixel 3',Pixel_3_XL:'Pixel 3 XL',Pixel_4:'Pixel 4',Pixel_4_XL:'Pixel 4 XL'};exports.DeviceName=DeviceName;function updateBrowserNamesForBackwardsCompatibility(browsers){return browsers.map(browserName=>{switch(browserName){case'Edge':return'Edge Legacy';default:return browserName;}});}

/***/ }),

/***/ "./app/components/VisualGrid/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/VisualGrid/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/components/VisualGridCustomViewportSize/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _Checkbox=_interopRequireDefault(__webpack_require__("./commons/components/Checkbox/index.jsx"));var _Input=_interopRequireDefault(__webpack_require__("./commons/components/Input/index.jsx"));var _DeleteButton=_interopRequireDefault(__webpack_require__("./app/components/ActionButtons/DeleteButton/index.jsx"));__webpack_require__("./app/components/VisualGridCustomViewportSize/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class CustomViewportSize extends _react.default.Component{constructor(props){super(props);this.state={isSelected:props.selected};}onWidthChange(value){const isSelected=value.length&&this.props.height.length?true:false;this.setState({isSelected});this.props.onViewportChange(this.props.id,value,this.props.height,isSelected);}onHeightChange(value){const isSelected=this.props.width.length&&value.length?true:false;this.setState({isSelected});this.props.onViewportChange(this.props.id,this.props.width,value,isSelected);}onSelect(e){this.setState({isSelected:e.target.checked});this.props.onViewportChange(this.props.id,this.props.width,this.props.height,e.target.checked);}render(){return/*#__PURE__*/_react.default.createElement("div",{className:"custom-viewport-size"},/*#__PURE__*/_react.default.createElement(_Checkbox.default,{id:this.props.id,className:"checkbox",name:"enable-custom-viewport",label:"",checked:this.state.isSelected,onChange:this.onSelect.bind(this)}),/*#__PURE__*/_react.default.createElement(_Input.default,{className:"width",type:"number",name:"custom-viewport-size-width",value:this.props.width,onChange:this.onWidthChange.bind(this)}),/*#__PURE__*/_react.default.createElement("div",{className:"dimension-separator"},"x"),/*#__PURE__*/_react.default.createElement(_Input.default,{className:"height",type:"number",name:"custom-viewport-size-height",value:this.props.height,onChange:this.onHeightChange.bind(this)}),/*#__PURE__*/_react.default.createElement(_DeleteButton.default,{onClick:this.props.deleteOption.bind(this,this.props.id)}));}}exports.default=CustomViewportSize;_defineProperty(CustomViewportSize,"propTypes",{id:_propTypes.default.string.isRequired,width:_propTypes.default.string,height:_propTypes.default.string,selected:_propTypes.default.bool,isSelected:_propTypes.default.func,onViewportChange:_propTypes.default.func.isRequired,deleteOption:_propTypes.default.func.isRequired});

/***/ }),

/***/ "./app/components/VisualGridCustomViewportSize/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/VisualGridCustomViewportSize/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/components/VisualGridEula/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _FlatButton=_interopRequireDefault(__webpack_require__("./commons/components/FlatButton/index.jsx"));function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class VisualGridEula extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement("div",{className:"disclaimer"},/*#__PURE__*/_react.default.createElement("p",null,"Visual Grid functionality allows\xA0parallel, cross-browser, multi viewport, ultra-fast visual testing."),/*#__PURE__*/_react.default.createElement("p",null,"This functionality is offered as a free trial until March 31, 2019."),/*#__PURE__*/_react.default.createElement(_FlatButton.default,{full:true,onClick:this.props.onEulaSigned},"I Understand"));}}exports.default=VisualGridEula;_defineProperty(VisualGridEula,"propTypes",{onEulaSigned:_propTypes.default.func.isRequired});

/***/ }),

/***/ "./app/components/VisualGridOptionCategory/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _AddButton=_interopRequireDefault(__webpack_require__("./app/components/ActionButtons/AddButton/index.jsx"));var _VisualGridOptionSelector=_interopRequireDefault(__webpack_require__("./app/components/VisualGridOptionSelector/index.jsx"));var _VisualGridSelectedOptions=_interopRequireDefault(__webpack_require__("./app/components/VisualGridSelectedOptions/index.jsx"));__webpack_require__("./app/components/VisualGridOptionCategory/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class VisualGridOptionCategory extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement(_react.default.Fragment,null,/*#__PURE__*/_react.default.createElement("div",{className:"option-header"},/*#__PURE__*/_react.default.createElement("div",{className:"title"},this.props.name),/*#__PURE__*/_react.default.createElement(_AddButton.default,{onClick:this.props.modalOpen,isSelected:this.props.modalIsOpen}),/*#__PURE__*/_react.default.createElement(_VisualGridOptionSelector.default,{modalIsOpen:this.props.modalIsOpen,modalClose:this.props.modalClose,options:this.props.options,selectedOptions:this.props.selectedOptions,onSubmit:this.props.onSubmit,customStyles:this.props.modalStyles,isSearch:this.props.isSearch})),this.props.selectedOptions.length?/*#__PURE__*/_react.default.createElement(_VisualGridSelectedOptions.default,{items:this.props.selectedOptions,removeOption:this.props.removeOption}):this.props.errorMessage?/*#__PURE__*/_react.default.createElement("div",{className:"error-message"},this.props.errorMessage):undefined);}}exports.default=VisualGridOptionCategory;_defineProperty(VisualGridOptionCategory,"propTypes",{name:_propTypes.default.string.isRequired,errorMessage:_propTypes.default.string,modalIsOpen:_propTypes.default.bool.isRequired,modalOpen:_propTypes.default.func.isRequired,modalClose:_propTypes.default.func.isRequired,modalStyles:_propTypes.default.object.isRequired,options:_propTypes.default.array.isRequired,selectedOptions:_propTypes.default.array.isRequired,removeOption:_propTypes.default.func.isRequired,onSubmit:_propTypes.default.func.isRequired,isSearch:_propTypes.default.bool});

/***/ }),

/***/ "./app/components/VisualGridOptionCategory/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/VisualGridOptionCategory/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/components/VisualGridOptionGroup/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _classnames=_interopRequireDefault(__webpack_require__("../../../node_modules/classnames/index.js"));var _ArrowIndicator=_interopRequireDefault(__webpack_require__("./commons/components/ArrowIndicator/index.jsx"));__webpack_require__("./app/components/VisualGridOptionGroup/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class VisualGridOptionGroup extends _react.default.Component{constructor(props){super(props);this.state={isSelected:false};}onClick(){this.setState({isSelected:!this.state.isSelected});}render(){return/*#__PURE__*/_react.default.createElement("div",{className:"group"},/*#__PURE__*/_react.default.createElement("div",{className:(0,_classnames.default)('group-header',this.props.name.toLowerCase()),onClick:this.onClick.bind(this)},/*#__PURE__*/_react.default.createElement("div",{className:"title"},this.props.name),/*#__PURE__*/_react.default.createElement("div",{className:"selected-count"},this.props.selectedCount),/*#__PURE__*/_react.default.createElement("div",{className:"control"},/*#__PURE__*/_react.default.createElement(_ArrowIndicator.default,{directionIsUp:this.state.isSelected}))),this.state.isSelected&&/*#__PURE__*/_react.default.createElement("div",{className:"contents"},this.props.children));}}exports.default=VisualGridOptionGroup;_defineProperty(VisualGridOptionGroup,"propTypes",{name:_propTypes.default.string.isRequired,selectedCount:_propTypes.default.number.isRequired});

/***/ }),

/***/ "./app/components/VisualGridOptionGroup/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/VisualGridOptionGroup/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/components/VisualGridOptionSelector/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _Modal=_interopRequireDefault(__webpack_require__("./commons/components/Modal/index.jsx"));var _CheckList=_interopRequireDefault(__webpack_require__("./commons/components/CheckList/index.jsx"));var _FlatButton=_interopRequireDefault(__webpack_require__("./commons/components/FlatButton/index.jsx"));var _Input=_interopRequireDefault(__webpack_require__("./commons/components/Input/index.jsx"));var _fuse=_interopRequireDefault(__webpack_require__("../../../node_modules/fuse.js/dist/fuse.js"));__webpack_require__("./app/components/VisualGridOptionSelector/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class VisualGridOptionSelector extends _react.default.Component{constructor(props){super(props);this.state={selectedOptions:[...this.props.selectedOptions]};}componentDidUpdate(prevProps){// NOTE:
// Refreshing the state since it is passed throught props and is altered
// in the parent component. Also because when the user closes the window
// we discard the state, but selections from the parent component need to
// persist into this window.
if(prevProps.selectedOptions!==this.props.selectedOptions||!prevProps.modalIsOpen&&this.props.modalIsOpen)this.setState({selectedOptions:[...this.props.selectedOptions]});}close(){this.setState({['selectedOptions']:[]});this.props.modalClose();}handleOptionChange(option,event){if(event&&event.target.checked){if(!this.isOptionSelected(option)){this.setState({['selectedOptions']:[...this.state.selectedOptions,option]});}}else{this.setState({['selectedOptions']:this.state.selectedOptions.filter(selectedOption=>selectedOption!==option)});}}isOptionSelected(option){return!!this.state.selectedOptions.filter(selectedOption=>selectedOption===option)[0];}onSubmit(){this.props.onSubmit(this.state.selectedOptions);this.props.modalClose();}search(pattern){const fuse=new _fuse.default(this.props.options,{shouldSort:false,includeMatches:true,threshold:0.3,location:0,distance:100,maxPatternLength:20,minMatchCharLength:1});const result=fuse.search(pattern).map(r=>r.matches[0].value);this.setState({searchResults:pattern?result:this.props.options});}render(){return/*#__PURE__*/_react.default.createElement(_Modal.default,{customStyles:this.props.customStyles,modalIsOpen:this.props.modalIsOpen,onRequestClose:this.close.bind(this)},/*#__PURE__*/_react.default.createElement("div",{className:"selections"},this.props.isSearch?/*#__PURE__*/_react.default.createElement(_Input.default,{onChange:this.search.bind(this),name:"",label:"",placeholder:"Search",autoFocus:true}):undefined,/*#__PURE__*/_react.default.createElement("div",{className:"selector"},/*#__PURE__*/_react.default.createElement(_CheckList.default,{items:this.state.searchResults?this.state.searchResults:this.props.options,optionSelected:this.isOptionSelected.bind(this),handleOptionChange:this.handleOptionChange.bind(this)}))),/*#__PURE__*/_react.default.createElement(_FlatButton.default,{className:"confirm",type:"submit",onClick:this.onSubmit.bind(this)},"Confirm"));}}exports.default=VisualGridOptionSelector;_defineProperty(VisualGridOptionSelector,"propTypes",{modalIsOpen:_propTypes.default.bool.isRequired,modalClose:_propTypes.default.func.isRequired,options:_propTypes.default.array.isRequired,selectedOptions:_propTypes.default.array.isRequired,onSubmit:_propTypes.default.func.isRequired,customStyles:_propTypes.default.object.isRequired,isSearch:_propTypes.default.bool});

/***/ }),

/***/ "./app/components/VisualGridOptionSelector/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/VisualGridOptionSelector/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/components/VisualGridSelectedOptions/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _RemoveButton=_interopRequireDefault(__webpack_require__("./app/components/ActionButtons/RemoveButton/index.jsx"));__webpack_require__("./app/components/VisualGridSelectedOptions/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class VisualGridSelectedOptions extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement("div",{className:"selected-options"},this.props.items.map(function(item){return/*#__PURE__*/_react.default.createElement("div",{className:"option",key:item},/*#__PURE__*/_react.default.createElement("div",{className:"option-text"},item),/*#__PURE__*/_react.default.createElement(_RemoveButton.default,{onClick:this.props.removeOption.bind(this,item)}));},this));}}exports.default=VisualGridSelectedOptions;_defineProperty(VisualGridSelectedOptions,"propTypes",{items:_propTypes.default.array.isRequired,removeOption:_propTypes.default.func.isRequired});

/***/ }),

/***/ "./app/components/VisualGridSelectedOptions/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/VisualGridSelectedOptions/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/components/VisualGridViewports/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _Modal=_interopRequireDefault(__webpack_require__("./commons/components/Modal/index.jsx"));var _VisualGridCustomViewportSize=_interopRequireDefault(__webpack_require__("./app/components/VisualGridCustomViewportSize/index.jsx"));var _VisualGridSelectedOptions=_interopRequireDefault(__webpack_require__("./app/components/VisualGridSelectedOptions/index.jsx"));var _AddButton=_interopRequireDefault(__webpack_require__("./app/components/ActionButtons/AddButton/index.jsx"));var _FlatButton=_interopRequireDefault(__webpack_require__("./commons/components/FlatButton/index.jsx"));var _CheckList=_interopRequireDefault(__webpack_require__("./commons/components/CheckList/index.jsx"));var _v=_interopRequireDefault(__webpack_require__("../../../node_modules/uuid/v4.js"));__webpack_require__("./app/components/VisualGridViewports/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class VisualGridViewports extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement(_react.default.Fragment,null,/*#__PURE__*/_react.default.createElement("div",{className:"option-header"},/*#__PURE__*/_react.default.createElement("div",{className:"title"},this.props.name),/*#__PURE__*/_react.default.createElement(_AddButton.default,{onClick:this.props.modalOpen,isSelected:this.props.modalIsOpen}),/*#__PURE__*/_react.default.createElement(ViewportSelectionModal,{modalIsOpen:this.props.modalIsOpen,modalClose:this.props.modalClose,modalStyles:this.props.modalStyles,options:this.props.options,customOptions:this.props.customOptions,selectedOptions:this.props.selectedOptions,onSubmit:this.props.onSubmit})),this.props.selectedOptions.length?/*#__PURE__*/_react.default.createElement(_VisualGridSelectedOptions.default,{items:this.props.selectedOptions,removeOption:this.props.removeOption}):/*#__PURE__*/_react.default.createElement("div",{className:"error-message"},this.props.errorMessage));}}exports.default=VisualGridViewports;_defineProperty(VisualGridViewports,"propTypes",{name:_propTypes.default.string.isRequired,errorMessage:_propTypes.default.string.isRequired,options:_propTypes.default.array.isRequired,customOptions:_propTypes.default.array.isRequired,selectedOptions:_propTypes.default.array.isRequired,removeOption:_propTypes.default.func.isRequired,modalIsOpen:_propTypes.default.bool.isRequired,modalOpen:_propTypes.default.func.isRequired,modalClose:_propTypes.default.func.isRequired,modalStyles:_propTypes.default.object.isRequired,onSubmit:_propTypes.default.func.isRequired});class ViewportSelectionModal extends _react.default.Component{constructor(props){super(props);this.state={customViewportSizes:[...this.props.customOptions],selectedViewportSizes:[...this.props.selectedOptions]};}componentDidUpdate(prevProps){// Refreshing the state since it is passed throught props and is altered
// in the parent component. Also because when the user closes the window
// we discard the state, but selections from the parent component need to
// persist into this window.
if(prevProps.selectedOptions!==this.props.selectedOptions||!prevProps.modalIsOpen&&this.props.modalIsOpen||prevProps.customOptions!==this.props.customOptions)this.setState({selectedViewportSizes:[...this.props.selectedOptions],customViewportSizes:[...this.props.customOptions]});}addCustomViewportSize(){this.setState({['customViewportSizes']:[...this.state['customViewportSizes'],{id:(0,_v.default)(),width:'',height:'',selected:false}]});}close(){this.setState({selectedViewportSizes:[],customViewportSizes:[]});this.props.modalClose();}deleteCustomViewport(id){this.setState({['customViewportSizes']:this.state.customViewportSizes.filter(viewport=>viewport.id!==id)});this.handleOptionChange(this.generateDimensions(this.state.customViewportSizes.find(size=>size.id===id)),false);}findNumber(input){const match=input.match(/\d/g);return match?match.join(''):'';}generateDimensions(viewport,width,height){if(viewport)return`${viewport.width}x${viewport.height}`;else return`${width}x${height}`;}handleOptionChange(dimensions,event){const isEnabled=typeof event==='boolean'?event:event.target.checked;if(isEnabled){if(!this.isOptionSelected(dimensions)){this.setState({['selectedViewportSizes']:[...this.state.selectedViewportSizes,dimensions]});}}else{this.setState({['selectedViewportSizes']:this.state.selectedViewportSizes.filter(option=>option!==dimensions)});}}isOptionSelected(dimensions){return!!this.state.selectedViewportSizes.filter(option=>option===dimensions)[0];}onViewportChange(id,width='',height='',selected=false){width=this.findNumber(width);height=this.findNumber(height);this.setState({['customViewportSizes']:this.state.customViewportSizes.map(viewport=>viewport.id===id?{id,width,height,selected}:viewport)});}async syncSelectedViewportSizes(){if(!this.state.customViewportSizes.length)return;this.state.customViewportSizes.forEach(viewportSize=>{if(viewportSize.width.length&&viewportSize.height.length){this.handleOptionChange(this.generateDimensions(undefined,viewportSize.width,viewportSize.height),viewportSize.selected);}});}onViewportSubmit(){this.syncSelectedViewportSizes().then(()=>{this.props.onSubmit(this.state.selectedViewportSizes,this.state.customViewportSizes);this.props.modalClose();});}render(){return/*#__PURE__*/_react.default.createElement(_Modal.default,{customStyles:this.props.modalStyles,modalIsOpen:this.props.modalIsOpen,onRequestClose:this.close.bind(this)},/*#__PURE__*/_react.default.createElement("div",{className:"predefined-viewport-sizes"},/*#__PURE__*/_react.default.createElement(_CheckList.default,{items:this.props.options,optionSelected:this.isOptionSelected.bind(this),handleOptionChange:this.handleOptionChange.bind(this)})),/*#__PURE__*/_react.default.createElement("hr",null),/*#__PURE__*/_react.default.createElement("div",{className:"custom-viewport-sizes"},/*#__PURE__*/_react.default.createElement("div",{className:"header"},/*#__PURE__*/_react.default.createElement("div",{className:"title"},"Custom"),/*#__PURE__*/_react.default.createElement(_AddButton.default,{onClick:this.addCustomViewportSize.bind(this)})),/*#__PURE__*/_react.default.createElement("div",{className:"collection"},this.state.customViewportSizes.map(function(viewport){return/*#__PURE__*/_react.default.createElement(_VisualGridCustomViewportSize.default,{key:viewport.id,id:viewport.id,width:viewport.width,height:viewport.height,selected:this.isOptionSelected(this.generateDimensions(viewport)),onViewportChange:this.onViewportChange.bind(this),deleteOption:this.deleteCustomViewport.bind(this)});},this))),/*#__PURE__*/_react.default.createElement(_FlatButton.default,{className:"confirm",type:"submit",onClick:this.onViewportSubmit.bind(this)},"Confirm"));}}_defineProperty(ViewportSelectionModal,"propTypes",{modalStyles:_propTypes.default.object.isRequired,modalIsOpen:_propTypes.default.bool.isRequired,modalClose:_propTypes.default.func.isRequired,options:_propTypes.default.array.isRequired,customOptions:_propTypes.default.array.isRequired,selectedOptions:_propTypes.default.array.isRequired,onSubmit:_propTypes.default.func.isRequired});

/***/ }),

/***/ "./app/components/VisualGridViewports/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/components/VisualGridViewports/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/containers/Disconnect/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _MoreInfo=_interopRequireDefault(__webpack_require__("./app/components/MoreInfo/index.jsx"));var _sad_face=_interopRequireDefault(__webpack_require__("./app/assets/images/sad_face.png"));__webpack_require__("./app/containers/Disconnect/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}class Disconnect extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement("div",{className:"disconnect"},/*#__PURE__*/_react.default.createElement("img",{src:_sad_face.default,width:"200px",style:{margin:'20px'}}),/*#__PURE__*/_react.default.createElement("footer",null,/*#__PURE__*/_react.default.createElement("p",null,"Please make sure Selenium IDE is installed and opened. ",/*#__PURE__*/_react.default.createElement(_MoreInfo.default,null))));}}exports.default=Disconnect;

/***/ }),

/***/ "./app/containers/Disconnect/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/containers/Disconnect/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/containers/Normal/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _webextensionPolyfill=_interopRequireDefault(__webpack_require__("../../../node_modules/webextension-polyfill/dist/browser-polyfill.js"));var _storage=_interopRequireDefault(__webpack_require__("./IO/storage.js"));var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _Checkbox=_interopRequireDefault(__webpack_require__("./commons/components/Checkbox/index.jsx"));var _Combobox=_interopRequireDefault(__webpack_require__("./commons/components/Combobox/index.jsx"));var _Input=_interopRequireDefault(__webpack_require__("./commons/components/Input/index.jsx"));var _MoreInfo=_interopRequireDefault(__webpack_require__("./app/components/MoreInfo/index.jsx"));var _Link=_interopRequireDefault(__webpack_require__("./commons/components/Link/index.jsx"));var _api=__webpack_require__("./commons/api.js");var _VisualGrid=_interopRequireDefault(__webpack_require__("./app/components/VisualGrid/index.jsx"));var _VisualGridEula=_interopRequireDefault(__webpack_require__("./app/components/VisualGridEula/index.jsx"));var _parsers=__webpack_require__("./background/utils/parsers.js");__webpack_require__("./app/containers/Normal/style.css");var _options=__webpack_require__("./app/components/VisualGrid/options.js");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function ownKeys(object,enumerableOnly){var keys=Object.keys(object);if(Object.getOwnPropertySymbols){var symbols=Object.getOwnPropertySymbols(object);if(enumerableOnly)symbols=symbols.filter(function(sym){return Object.getOwnPropertyDescriptor(object,sym).enumerable;});keys.push.apply(keys,symbols);}return keys;}function _objectSpread(target){for(var i=1;i<arguments.length;i++){var source=arguments[i]!=null?arguments[i]:{};if(i%2){ownKeys(Object(source),true).forEach(function(key){_defineProperty(target,key,source[key]);});}else if(Object.getOwnPropertyDescriptors){Object.defineProperties(target,Object.getOwnPropertyDescriptors(source));}else{ownKeys(Object(source)).forEach(function(key){Object.defineProperty(target,key,Object.getOwnPropertyDescriptor(source,key));});}}return target;}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class Normal extends _react.default.Component{constructor(props){super(props);this.state={eyesServer:'',enableVisualGrid:true};this.setProjectSettings();this.setProjectSettings=this.setProjectSettings.bind(this);this.signEula=this.signEula.bind(this);}componentDidUpdate(prevProps){if(prevProps.projectId!==this.props.projectId){this.setProjectSettings();}}openOptionsPage(){_webextensionPolyfill.default.runtime.openOptionsPage();}handleCheckboxChange(name,e){if(name){const{checked}=e.target;this.setProjectSettings().then(()=>this.handleInputChange(name,checked));}else{this.props.visualCheckpointsChanged(e.target.checked);}}handleInputChange(name,value){// used for branches and visual grid checkbox
const result=_objectSpread({},this.state.projectSettings,{[name]:value});_storage.default.get(['projectSettings']).then(({projectSettings})=>{_storage.default.set({['projectSettings']:_objectSpread({},projectSettings,{[this.props.projectId]:result})}).then(()=>{this.setState({projectSettings:result});});});}setProjectSettings(){return _storage.default.get(['eyesServer','eulaSignDate','isFree','projectSettings','experimentalEnabled','accountInfo']).then(({eyesServer,eulaSignDate,isFree,projectSettings,experimentalEnabled,accountInfo})=>{const settings=projectSettings&&projectSettings[this.props.projectId]?projectSettings[this.props.projectId]:{branch:'',parentBranch:'',enableVisualGrid:false,enableContrastAdvisor:false,enablePatternsDom:false,selectedBrowsers:['Chrome'],selectedViewportSizes:['1920x1080'],customViewportSizes:[],selectedDevices:[],selectedDeviceOrientations:[],enableAccessibilityValidations:false,accessibilityLevel:'AA',accessibilityVersion:'2.0',accountInfo:{}};if(!experimentalEnabled&&projectSettings&&projectSettings[this.props.projectId]){settings.selectedBrowsers=settings.selectedBrowsers.filter(b=>!(0,_parsers.isExperimentalBrowser)(b.toLowerCase()));_storage.default.set({['projectSettings']:_objectSpread({},projectSettings,{[this.props.projectId]:_objectSpread({},settings)})});}if(projectSettings&&projectSettings[this.props.projectId]){settings.selectedBrowsers=(0,_options.updateBrowserNamesForBackwardsCompatibility)(settings.selectedBrowsers);_storage.default.set({['projectSettings']:_objectSpread({},projectSettings,{[this.props.projectId]:_objectSpread({},settings)})});}this.setState({eyesServer,eulaSigned:!!eulaSignDate,isFree,projectSettings:settings,isExperimental:experimentalEnabled,accountInfo});});}signEula(){this.setState({eulaSigned:true});_storage.default.set({eulaSignDate:new Date().toISOString()}).then(()=>{this.setState({eulaSigned:true});});}render(){return/*#__PURE__*/_react.default.createElement("div",{className:"project-settings"},/*#__PURE__*/_react.default.createElement(_Checkbox.default,{id:"enable-checks",className:"checkbox",name:"enable-checks",label:"Enable visual checkpoints",checked:this.props.enableVisualCheckpoints,onChange:this.handleCheckboxChange.bind(this,undefined)}),this.state.projectSettings&&/*#__PURE__*/_react.default.createElement(_react.default.Fragment,null,/*#__PURE__*/_react.default.createElement("hr",null),/*#__PURE__*/_react.default.createElement("h4",null,"Project settings"),/*#__PURE__*/_react.default.createElement(_Input.default,{name:"branch",label:"Branch name",value:this.state.projectSettings.branch,onChange:this.handleInputChange.bind(this,'branch')}),/*#__PURE__*/_react.default.createElement(_Input.default,{name:"parentBranch",label:"Parent branch name",value:this.state.projectSettings.parentBranch,onChange:this.handleInputChange.bind(this,'parentBranch')}),/*#__PURE__*/_react.default.createElement(_Checkbox.default,{id:"enable-visual-grid",className:"checkbox",name:"enable-visual-grid",label:"Execute using Ultrafast Grid",checked:this.state.projectSettings.enableVisualGrid,onChange:this.handleCheckboxChange.bind(this,'enableVisualGrid')}),this.state.projectSettings.enableVisualGrid&&!this.state.eulaSigned&&!this.state.isFree&&/*#__PURE__*/_react.default.createElement(_VisualGridEula.default,{onEulaSigned:this.signEula}),this.state.projectSettings.enableVisualGrid&&(this.state.eulaSigned||this.state.isFree)&&/*#__PURE__*/_react.default.createElement(_VisualGrid.default,{projectId:this.props.projectId,projectSettings:this.state.projectSettings,isExperimental:this.state.isExperimental}),this.state.accountInfo&&this.state.accountInfo.features&&this.state.accountInfo.features.includes('accessibility')&&/*#__PURE__*/_react.default.createElement(_react.default.Fragment,null,/*#__PURE__*/_react.default.createElement(_Checkbox.default,{id:"enable-accessibility-validations",label:"Enable Contrast Advisor",checked:this.state.projectSettings.enableAccessibilityValidations,onChange:this.handleCheckboxChange.bind(this,'enableAccessibilityValidations')}),this.state.projectSettings.enableAccessibilityValidations&&/*#__PURE__*/_react.default.createElement("div",{id:"accessibility-options"},/*#__PURE__*/_react.default.createElement(_Combobox.default,{className:"accessibility-option",label:"WCAG Version",items:['2.0','2.1'],selectedItem:this.state.projectSettings.accessibilityVersion,disabled:!this.state.projectSettings.enableAccessibilityValidations,onChange:this.handleInputChange.bind(this,'accessibilityVersion')}),/*#__PURE__*/_react.default.createElement(_Combobox.default,{className:"accessibility-option",label:"Conformance Level",items:['AA','AAA'],selectedItem:this.state.projectSettings.accessibilityLevel,disabled:!this.state.projectSettings.enableAccessibilityValidations,onChange:this.handleInputChange.bind(this,'accessibilityLevel')}))),this.state.isExperimental&&/*#__PURE__*/_react.default.createElement(_react.default.Fragment,null,/*#__PURE__*/_react.default.createElement(_Checkbox.default,{id:"enable-patterns-dom",label:"Enable advanced pattern matching",checked:this.state.projectSettings.enablePatternsDom,onChange:this.handleCheckboxChange.bind(this,'enablePatternsDom')}))),/*#__PURE__*/_react.default.createElement("hr",null),/*#__PURE__*/_react.default.createElement("div",{className:"open-global-settings"},/*#__PURE__*/_react.default.createElement("a",{href:"#",onClick:this.openOptionsPage},"Open global settings"),/*#__PURE__*/_react.default.createElement(_Link.default,{href:new URL('/app/test-results/',this.state.eyesServer||_api.DEFAULT_SERVER).href,style:{display:'block',lineHeight:'17px'}},"Open test manager")),/*#__PURE__*/_react.default.createElement("footer",null,/*#__PURE__*/_react.default.createElement("p",{className:"more-options"},"More options will be available when running or recording tests. ",/*#__PURE__*/_react.default.createElement(_MoreInfo.default,null))));}}exports.default=Normal;_defineProperty(Normal,"propTypes",{enableVisualCheckpoints:_propTypes.default.bool.isRequired,visualCheckpointsChanged:_propTypes.default.func.isRequired,projectId:_propTypes.default.string.isRequired});

/***/ }),

/***/ "./app/containers/Normal/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/containers/Normal/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/containers/Panel/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _webextensionPolyfill=_interopRequireDefault(__webpack_require__("../../../node_modules/webextension-polyfill/dist/browser-polyfill.js"));var _uaParserJs=_interopRequireDefault(__webpack_require__("../../../node_modules/ua-parser-js/src/ua-parser.js"));var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _modes=_interopRequireDefault(__webpack_require__("./commons/modes.js"));var _Disconnect=_interopRequireDefault(__webpack_require__("./app/containers/Disconnect/index.jsx"));var _Normal=_interopRequireDefault(__webpack_require__("./app/containers/Normal/index.jsx"));var _Setup=_interopRequireDefault(__webpack_require__("./app/containers/Setup/index.jsx"));var _Record=_interopRequireDefault(__webpack_require__("./app/containers/Record/index.jsx"));var _Playback=_interopRequireDefault(__webpack_require__("./app/containers/Playback/index.jsx"));var _SpinnerBanner=_interopRequireWildcard(__webpack_require__("./app/components/SpinnerBanner/index.jsx"));var _DisconnectBanner=_interopRequireDefault(__webpack_require__("./app/components/DisconnectBanner/index.jsx"));__webpack_require__("./commons/styles/elements.css");__webpack_require__("./app/styles/app.css");function _getRequireWildcardCache(){if(typeof WeakMap!=="function")return null;var cache=new WeakMap();_getRequireWildcardCache=function(){return cache;};return cache;}function _interopRequireWildcard(obj){if(obj&&obj.__esModule){return obj;}if(obj===null||typeof obj!=="object"&&typeof obj!=="function"){return{default:obj};}var cache=_getRequireWildcardCache();if(cache&&cache.has(obj)){return cache.get(obj);}var newObj={};var hasPropertyDescriptor=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var key in obj){if(Object.prototype.hasOwnProperty.call(obj,key)){var desc=hasPropertyDescriptor?Object.getOwnPropertyDescriptor(obj,key):null;if(desc&&(desc.get||desc.set)){Object.defineProperty(newObj,key,desc);}else{newObj[key]=obj[key];}}}newObj.default=obj;if(cache){cache.set(obj,newObj);}return newObj;}function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}const userAgent=(0,_uaParserJs.default)(window.navigator.userAgent);if(userAgent.browser.name==='Chrome'){__webpack_require__("./commons/styles/chrome.css");}if(userAgent.os.name==='Windows'){__webpack_require__("./commons/styles/windows.css");}class Panel extends _react.default.Component{constructor(props){super(props);this.state={mode:_modes.default.NORMAL,enableVisualCheckpoints:true,isSubmitting:false,projectId:''};_webextensionPolyfill.default.runtime.sendMessage({requestExternalState:true}).then(({state})=>{this.setState(state);});_webextensionPolyfill.default.runtime.sendMessage({requestProject:true}).then(({project})=>{this.setState({projectId:project.id});});this.setExternalState=this.setExternalState.bind(this);this.visualCheckpointsChanged=this.visualCheckpointsChanged.bind(this);this.setSubmitting=this.setSubmitting.bind(this);}componentDidMount(){// BEWARE CONVOLUTED API AHEAD!!!
// When using onMessage or onMessageExternal listeners only one response can
// be returned, or else it will throw (sometimes throw in a different message at all!)
// When returning in the listener, the listener will treat this as the response:
// return 5 is the same as sendResponse(5)
// For that reason async operations are convoluted, if foo is async then this:
// return foo().then(sendRespnse) will throw, because foo returns a promise
// which will be used as the response value, and when the promise resolves
// another value is returned using sendResponse
// To use async operations with onMessage, return true, this will inform chrome
// to wait until the sendResponse callback is explicitly called, which results in:
// foo().then(sendResponse); return true
// PASTE THIS IN EVERY PLACE THAT LISTENS TO onMessage!!
_webextensionPolyfill.default.runtime.onMessage.addListener(this.setExternalState);}componentWillUnmount(){_webextensionPolyfill.default.runtime.onMessage.removeListener(this.setExternalState);}setExternalState(message,_backgroundPage,_sendResponse){// eslint-disable-line no-unused-vars
if(message.state){this.setState(Object.assign({isSubmitting:false},message.state));}}visualCheckpointsChanged(value){_webextensionPolyfill.default.runtime.sendMessage({setVisualChecks:true,enableVisualCheckpoints:value}).catch();}setSubmitting(){this.setState({mode:_modes.default.SETUP,isSubmitting:true});}render(){return/*#__PURE__*/_react.default.createElement("div",null,this.state.mode===_modes.default.DISCONNECTED&&/*#__PURE__*/_react.default.createElement(_DisconnectBanner.default,null),this.state.mode===_modes.default.NORMAL&&(this.state.enableVisualCheckpoints?/*#__PURE__*/_react.default.createElement(_SpinnerBanner.default,{state:_SpinnerBanner.SpinnerStates.SUCCESS,spin:false},"Successfully connected with Selenium IDE"):/*#__PURE__*/_react.default.createElement(_SpinnerBanner.default,{state:_SpinnerBanner.SpinnerStates.ERROR,spin:false},"Visual checkpoints are disabled.")),this.state.mode===_modes.default.SETUP&&(!this.state.isSubmitting?/*#__PURE__*/_react.default.createElement(_SpinnerBanner.default,{state:_SpinnerBanner.SpinnerStates.ERROR,spin:false},"Applitools account details are not set!"):/*#__PURE__*/_react.default.createElement(_SpinnerBanner.default,{state:_SpinnerBanner.SpinnerStates.ERROR},"Verifying account details...")),this.state.mode===_modes.default.INVALID&&/*#__PURE__*/_react.default.createElement(_SpinnerBanner.default,{state:_SpinnerBanner.SpinnerStates.ERROR,spin:false},"Unable to verify Applitools account details!"),this.state.mode===_modes.default.RECORD&&/*#__PURE__*/_react.default.createElement(_SpinnerBanner.default,{state:_SpinnerBanner.SpinnerStates.SUCCESS},`Recording test: ${this.state.record.testName}`),this.state.mode===_modes.default.PLAYBACK&&/*#__PURE__*/_react.default.createElement(_SpinnerBanner.default,{state:_SpinnerBanner.SpinnerStates.SUCCESS},`Running test: ${this.state.playback.testName}`),/*#__PURE__*/_react.default.createElement("div",{className:"container"},this.state.mode===_modes.default.DISCONNECTED&&/*#__PURE__*/_react.default.createElement(_Disconnect.default,null),this.state.mode===_modes.default.NORMAL&&(this.state.projectId?/*#__PURE__*/_react.default.createElement(_Normal.default,{enableVisualCheckpoints:this.state.enableVisualCheckpoints,visualCheckpointsChanged:this.visualCheckpointsChanged,projectId:this.state.projectId}):undefined),(this.state.mode===_modes.default.SETUP||this.state.mode===_modes.default.INVALID)&&/*#__PURE__*/_react.default.createElement(_Setup.default,{isInvalid:this.state.mode===_modes.default.INVALID,setSubmitMode:this.setSubmitting}),this.state.mode===_modes.default.RECORD&&/*#__PURE__*/_react.default.createElement(_Record.default,null),this.state.mode===_modes.default.PLAYBACK&&/*#__PURE__*/_react.default.createElement(_Playback.default,{testName:this.state.playback.testName,startTime:new Date(this.state.playback.startTime),hasFailed:this.state.playback.hasFailed,batchName:this.state.playback.batchName,appName:this.state.playback.appName,eyesServer:this.state.playback.eyesServer,environment:this.state.playback.environment,branch:this.state.playback.branch})));}}exports.default=Panel;

/***/ }),

/***/ "./app/containers/Playback/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _FormLabel=_interopRequireDefault(__webpack_require__("./commons/components/FormLabel/index.jsx"));var _Timer=_interopRequireDefault(__webpack_require__("./commons/components/Timer/index.jsx"));var _api=__webpack_require__("./commons/api.js");__webpack_require__("./app/containers/Playback/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class PlaybackBanner extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement("div",null,/*#__PURE__*/_react.default.createElement("div",{className:"playback-info"},/*#__PURE__*/_react.default.createElement(_FormLabel.default,{label:"Batch name"},this.props.batchName),/*#__PURE__*/_react.default.createElement(_FormLabel.default,{label:"App name"},this.props.appName),/*#__PURE__*/_react.default.createElement(_FormLabel.default,{label:"Eyes server",placeholder:_api.DEFAULT_API_SERVER},this.props.eyesServer),/*#__PURE__*/_react.default.createElement(_FormLabel.default,{label:"Environment",placeholder:"Undetermined"},this.props.environment),/*#__PURE__*/_react.default.createElement(_FormLabel.default,{label:"Branch",placeholder:"default"},this.props.branch),/*#__PURE__*/_react.default.createElement(_FormLabel.default,{label:"Started at"},`${this.props.startTime.getHours()}:${this.props.startTime.getMinutes()}`," (",/*#__PURE__*/_react.default.createElement(_Timer.default,{time:this.props.startTime}),")")));}}exports.default=PlaybackBanner;_defineProperty(PlaybackBanner,"propTypes",{testName:_propTypes.default.string.isRequired,startTime:_propTypes.default.instanceOf(Date).isRequired,hasFailed:_propTypes.default.bool,batchName:_propTypes.default.string,appName:_propTypes.default.string,eyesServer:_propTypes.default.string,environment:_propTypes.default.string,branch:_propTypes.default.string});

/***/ }),

/***/ "./app/containers/Playback/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/containers/Playback/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/containers/Record/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _webextensionPolyfill=_interopRequireDefault(__webpack_require__("../../../node_modules/webextension-polyfill/dist/browser-polyfill.js"));var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _messagePort=__webpack_require__("./IO/message-port.js");var _ButtonList=_interopRequireDefault(__webpack_require__("./app/components/ButtonList/index.jsx"));var _commands=__webpack_require__("./commons/commands.js");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}class Record extends _react.default.Component{constructor(props){super(props);this.commands={['Check window']:{command:_commands.CommandIds.CheckWindow,target:'',value:''},['Check element']:{command:_commands.CommandIds.CheckElement,target:'',value:'',select:true},['Set viewport size']:{command:_commands.CommandIds.SetViewportSize,target:'1280x800',value:''},['Set match timeout']:{command:_commands.CommandIds.SetMatchTimeout,target:'2000',value:''},['Set match level']:{command:_commands.CommandIds.SetMatchLevel,target:'Strict',value:''}};this.handleCommandClick=this.handleCommandClick.bind(this);}handleCommandClick(command){if(command==='Set viewport size'){return(0,_messagePort.sendMessage)({uri:'/record/tab',verb:'get'}).then(res=>{if(res.error==='No active tab found'){return _webextensionPolyfill.default.runtime.sendMessage({recordCommand:true,command:this.commands[command]});}else{return _webextensionPolyfill.default.tabs.get(res.id).then(tab=>{return _webextensionPolyfill.default.runtime.sendMessage({recordCommand:true,command:{command:_commands.CommandIds.SetViewportSize,target:`${tab.width}x${Math.max(tab.height-100,100)}`,value:''}});});}});}else{return _webextensionPolyfill.default.runtime.sendMessage({recordCommand:true,command:this.commands[command]});}}render(){return/*#__PURE__*/_react.default.createElement("div",null,/*#__PURE__*/_react.default.createElement("p",{style:{padding:'0 3px'}},"You can use the following Eyes commands in Selenium IDE or click them while recording your test:"),/*#__PURE__*/_react.default.createElement(_ButtonList.default,{items:Object.keys(this.commands),label:"Add to test",onClick:this.handleCommandClick}));}}exports.default=Record;

/***/ }),

/***/ "./app/containers/Root/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var _webextensionPolyfill=_interopRequireDefault(__webpack_require__("../../../node_modules/webextension-polyfill/dist/browser-polyfill.js"));var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _reactDom=_interopRequireDefault(__webpack_require__("../../../node_modules/react-dom/index.js"));var _reactHotLoader=__webpack_require__("../../../node_modules/react-hot-loader/index.js");var _Panel=_interopRequireDefault(__webpack_require__("./app/containers/Panel/index.jsx"));function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}const render=Component=>{_reactDom.default.render(/*#__PURE__*/_react.default.createElement(_reactHotLoader.AppContainer,null,/*#__PURE__*/_react.default.createElement(Component,null)),document.getElementById('root'));};render(_Panel.default);if(false){module.hot.accept('../Panel/index.jsx',()=>{const NextRootContainer=require('../Panel').default;render(NextRootContainer);});}_webextensionPolyfill.default.runtime.onMessageExternal.addListener(()=>{});

/***/ }),

/***/ "./app/containers/Setup/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _webextensionPolyfill=_interopRequireDefault(__webpack_require__("../../../node_modules/webextension-polyfill/dist/browser-polyfill.js"));var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _Link=_interopRequireDefault(__webpack_require__("./commons/components/Link/index.jsx"));var _Input=_interopRequireDefault(__webpack_require__("./commons/components/Input/index.jsx"));var _FlatButton=_interopRequireDefault(__webpack_require__("./commons/components/FlatButton/index.jsx"));__webpack_require__("./app/containers/Setup/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class Setup extends _react.default.Component{constructor(props){super(props);this.state={apiKey:'',serverUrl:''};this.handleApiKeyChange=this.handleApiKeyChange.bind(this);this.handleServerUrlChange=this.handleServerUrlChange.bind(this);this.submitInfo=this.submitInfo.bind(this);_webextensionPolyfill.default.storage.local.get(['apiKey','eyesServer']).then(({apiKey,eyesServer})=>{this.setState({apiKey:apiKey||this.state.apiKey,eyesServer:eyesServer||this.state.serverUrl});});}handleApiKeyChange(value){this.setState({apiKey:value});}handleServerUrlChange(value){this.setState({serverUrl:value});}submitInfo(){if(this.props.setSubmitMode){this.props.setSubmitMode();}_webextensionPolyfill.default.storage.local.set({apiKey:this.state.apiKey,eyesServer:this.state.serverUrl}).then(()=>{_webextensionPolyfill.default.runtime.sendMessage({optionsUpdated:true});});}render(){return/*#__PURE__*/_react.default.createElement("div",null,/*#__PURE__*/_react.default.createElement("form",{className:"setup",onSubmit:e=>{e.preventDefault();}},/*#__PURE__*/_react.default.createElement("p",null,/*#__PURE__*/_react.default.createElement(_Link.default,{href:"https://applitools.com/users/register"},"Sign up for a free account")," if you don\u2019t already have one, or see",' ',/*#__PURE__*/_react.default.createElement(_Link.default,{href:"https://applitools.com/docs/topics/overview/obtain-api-key.html"},"How to obtain your API key")),/*#__PURE__*/_react.default.createElement(_Input.default,{name:"apiKey",label:"API key",value:this.state.apiKey,onChange:this.handleApiKeyChange}),/*#__PURE__*/_react.default.createElement(_Input.default,{name:"serverUrl",label:"Server URL",placeholder:"https://eyes.applitools.com",value:this.state.serverUrl,onChange:this.handleServerUrlChange}),/*#__PURE__*/_react.default.createElement(_FlatButton.default,{type:"submit",onClick:this.submitInfo,style:{float:'right',margin:'15px 0'}},"Apply")));}}exports.default=Setup;_defineProperty(Setup,"propTypes",{isInvalid:_propTypes.default.bool,setSubmitMode:_propTypes.default.func});

/***/ }),

/***/ "./app/containers/Setup/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/containers/Setup/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./app/styles/app.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./app/styles/app.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../node_modules/postcss-loader/lib/index.js??postcss!./app.css", function() {
			var newContent = require("!!../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../node_modules/postcss-loader/lib/index.js??postcss!./app.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./background/utils/parsers.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.parseBrowsers=parseBrowsers;exports.isExperimentalBrowser=isExperimentalBrowser;exports.parseViewport=parseViewport;exports.parseRegion=parseRegion;exports.parseEnvironment=parseEnvironment;exports.parseApiServer=parseApiServer;exports.parseMatchLevel=parseMatchLevel;exports.maxExperimentalResolution=void 0;var _options=__webpack_require__("./app/components/VisualGrid/options.js");var _uaParserJs=_interopRequireDefault(__webpack_require__("../../../node_modules/ua-parser-js/src/ua-parser.js"));function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}const parser=new _uaParserJs.default();const maxExperimentalResolution='1280x1024';exports.maxExperimentalResolution=maxExperimentalResolution;const parsedMax=parseViewport(maxExperimentalResolution);function getDeviceId(deviceName){return Object.keys(_options.DeviceName).find(key=>_options.DeviceName[key]===deviceName);}function parseBrowsers(browsers=['Chrome'],viewports=['1920x1080'],devices=[],orientations=['Portrait']){const matrix=[];let didRemoveResolution=false;browsers.forEach(browser=>{const name=browser.replace(/ /,'').toLowerCase();viewports.forEach(viewport=>{const{width,height}=parseViewport(viewport);if(!(isExperimentalBrowser(name)&&isBiggerResolution(parseViewport(viewport),parsedMax))){const result={width,height,name};const id=_options.browserIds[name.toLowerCase()];if(id)result.id=id;matrix.push(result);}else{didRemoveResolution=true;}});});devices.forEach(device=>{orientations.forEach(orientation=>{matrix.push({screenOrientation:orientation.toLowerCase(),deviceName:device,deviceId:getDeviceId(device)});});});return{matrix,didRemoveResolution};}function isExperimentalBrowser(browser){if(!browser)return;return _options.experimentalBrowsers.includes(browser.toLowerCase());}function isBiggerResolution(res1,res2){return res1.height>res2.height||res1.width>res2.width;}function parseViewport(vp){const[width,height]=vp.split('x').map(s=>parseInt(s));return{width,height};}function parseRegion(region){const x=+(region.match(/x:\s*(\d*)/)||[])[1];const y=+(region.match(/y:\s*(\d*)/)||[])[1];const width=+(region.match(/width:\s*(\d*)/)||[])[1];const height=+(region.match(/height:\s*(\d*)/)||[])[1];return{x,y,width,height};}function parseEnvironment(userAgent,viewport){parser.setUA(userAgent);return`${parser.getBrowser().name} ${parser.getOS().name} ${viewport.width}x${viewport.height}`;}function parseApiServer(server){if(/^(?!.*(api)\.).*\.applitools\.com\/?$/.test(server)){if(server==='localhost.applitools.com')return server;return server.replace('.applitools.com','api.applitools.com');}return server;}function parseMatchLevel(level='Strict'){const lvl=level[0].toUpperCase()+level.substr(1).toLowerCase();return lvl==='Layout'?'Layout2':lvl;}

/***/ }),

/***/ "./background/utils/userAgent.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.isFirefox=exports.isChrome=exports.browserName=void 0;var _uaParserJs=_interopRequireDefault(__webpack_require__("../../../node_modules/ua-parser-js/src/ua-parser.js"));function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}const parser=new _uaParserJs.default(window.navigator.userAgent);const browserName=parser.getBrowser().name;exports.browserName=browserName;const isChrome=browserName==='Chrome';exports.isChrome=isChrome;const isFirefox=browserName==='Firefox';exports.isFirefox=isFirefox;

/***/ }),

/***/ "./commons/api.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.verifyStoredAPIKey=verifyStoredAPIKey;exports.getAccountInfo=getAccountInfo;exports.DEFAULT_API_SERVER=exports.DEFAULT_SERVER=void 0;var _webextensionPolyfill=_interopRequireDefault(__webpack_require__("../../../node_modules/webextension-polyfill/dist/browser-polyfill.js"));function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}const DEFAULT_SERVER='https://eyes.applitools.com/';exports.DEFAULT_SERVER=DEFAULT_SERVER;const DEFAULT_API_SERVER='https://eyesapi.applitools.com/';exports.DEFAULT_API_SERVER=DEFAULT_API_SERVER;async function verifyStoredAPIKey(){const{apiKey,eyesServer}=await _webextensionPolyfill.default.storage.local.get(['apiKey','eyesServer']);if(!apiKey){throw new Error("API key can't be empty");}else{const response=await fetch(`${new URL('/api/auth/access',eyesServer||DEFAULT_API_SERVER).href}?accessKey=${apiKey}&format=json`);if(response.ok){try{const{isFree}=await response.json();await _webextensionPolyfill.default.storage.local.set({isFree:!!isFree});return;}catch(e){await _webextensionPolyfill.default.storage.local.set({isFree:false});return;}}else{throw new Error('Unable to verify API check, verify the key and server correctness');}}}async function getAccountInfo(){const{apiKey,eyesServer}=await _webextensionPolyfill.default.storage.local.get(['apiKey','eyesServer']);const response=await fetch(`${new URL('/api/admin/accountinfo',eyesServer||DEFAULT_API_SERVER).href}?accessKey=${apiKey}&format=json`);if(response.ok){const accountInfo=await response.json();await _webextensionPolyfill.default.storage.local.set({accountInfo});}}

/***/ }),

/***/ "./commons/commands.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.isEyesCommand=isEyesCommand;exports.isCheckCommand=isCheckCommand;exports.containsEyesCommands=containsEyesCommands;exports.dedupeSetWindowSizeIfNecessary=dedupeSetWindowSizeIfNecessary;exports.elevateSetWindowSizeIfNecessary=elevateSetWindowSizeIfNecessary;exports.getTabViewportSize=getTabViewportSize;exports.CommandIds=void 0;var _webextensionPolyfill=_interopRequireDefault(__webpack_require__("../../../node_modules/webextension-polyfill/dist/browser-polyfill.js"));var _messagePort=__webpack_require__("./IO/message-port.js");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}// If you change aynthing here make sure to also change plugin-manifest.json
const CommandIds={CheckWindow:'eyesCheckWindow',CheckElement:'eyesCheckElement',SetMatchLevel:'eyesSetMatchLevel',SetMatchTimeout:'eyesSetMatchTimeout',SetViewportSize:'eyesSetViewportSize',SetBaselineEnvName:'eyesSetBaselineEnvName',SetPreRenderHook:'eyesSetPreRenderHook'};exports.CommandIds=CommandIds;const CommandNames=Object.values(CommandIds);function isEyesCommand(command,exclusions=[]){return CommandNames.includes(command.command)&&!exclusions.includes(command.command);}function isCheckCommand(command){return command.command===CommandIds.CheckWindow||command.command===CommandIds.CheckElement;}function containsEyesCommands(commands,exclusions){if(!Array.isArray(commands))return false;return!!commands.find(command=>isEyesCommand(command,exclusions));}async function dedupeSetWindowSizeIfNecessary(){const{commands}=await(0,_messagePort.sendMessage)({uri:'/record/command',verb:'get'});const setWindowSize=commands.find(cmd=>cmd.command==='setWindowSize');if(setWindowSize){return(0,_messagePort.sendMessage)({uri:'/record/command',verb:'delete',payload:{id:setWindowSize.id}});}}async function elevateSetWindowSizeIfNecessary(){const{commands}=await(0,_messagePort.sendMessage)({uri:'/record/command',verb:'get'});const hasSetViewportSize=!!commands.find(cmd=>cmd.command===CommandIds.SetViewportSize);if(!hasSetViewportSize){const tabId=(await(0,_messagePort.sendMessage)({uri:'/record/tab',verb:'get'})).id;const{width,height}=await getTabViewportSize(tabId);const setWindowSize=commands.find(cmd=>cmd.command==='setWindowSize');if(setWindowSize){return(0,_messagePort.sendMessage)({uri:'/record/command',verb:'put',payload:{id:setWindowSize.id,command:CommandIds.SetViewportSize,target:`${width}x${height}`,value:''}});}}}async function getTabViewportSize(tabId){const tab=await _webextensionPolyfill.default.tabs.get(tabId);return{width:tab.width,height:Math.max(tab.height-100,100)};}

/***/ }),

/***/ "./commons/components/ArrowIndicator/arrow_sm.svg":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "media/arrow_sm.5f4c5d34.svg";

/***/ }),

/***/ "./commons/components/ArrowIndicator/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _arrow_sm=_interopRequireDefault(__webpack_require__("./commons/components/ArrowIndicator/arrow_sm.svg"));function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}class ArrowIndicator extends _react.default.Component{generateStyle(){let radian;this.props.directionIsUp?radian=270:radian=90;return{transform:`rotate(${radian}deg)`};}render(){return/*#__PURE__*/_react.default.createElement("img",{src:_arrow_sm.default,alt:"arrow",style:this.generateStyle()});}}exports.default=ArrowIndicator;

/***/ }),

/***/ "./commons/components/CheckList/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _Checkbox=_interopRequireDefault(__webpack_require__("./commons/components/Checkbox/index.jsx"));function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class CheckList extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement(_react.default.Fragment,null,this.props.items.map(function(item){return/*#__PURE__*/_react.default.createElement(_react.default.Fragment,{key:item},/*#__PURE__*/_react.default.createElement(_Checkbox.default,{id:item,label:item,checked:this.props.optionSelected(item),onChange:this.props.handleOptionChange.bind(this,item)}));},this));}}exports.default=CheckList;_defineProperty(CheckList,"propTypes",{items:_propTypes.default.array.isRequired,optionSelected:_propTypes.default.func.isRequired,handleOptionChange:_propTypes.default.func.isRequired});

/***/ }),

/***/ "./commons/components/Checkbox/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));__webpack_require__("./commons/components/Checkbox/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class Checkbox extends _react.default.Component{render(){const checked=this.props.checked||this.props.hasOwnProperty('checked')&&this.props.checked!==false||this.props.hasOwnProperty('isChecked')&&this.props.isChecked();return/*#__PURE__*/_react.default.createElement("div",{className:"control"},/*#__PURE__*/_react.default.createElement("input",{type:"checkbox",className:"checkbox",id:this.props.id,name:this.props.name,checked:checked,onChange:this.props.onChange}),/*#__PURE__*/_react.default.createElement("label",{key:"label",htmlFor:this.props.id},/*#__PURE__*/_react.default.createElement("span",null,checked?'✓':''),/*#__PURE__*/_react.default.createElement("div",null,this.props.label),this.props.disclaimer?/*#__PURE__*/_react.default.createElement("div",{className:"disclaimer"},this.props.disclaimer):undefined));}}exports.default=Checkbox;_defineProperty(Checkbox,"propTypes",{id:_propTypes.default.string.isRequired,name:_propTypes.default.string,label:_propTypes.default.string,width:_propTypes.default.number,checked:_propTypes.default.bool,isChecked:_propTypes.default.func,onChange:_propTypes.default.func.isRequired,disclaimer:_propTypes.default.string});

/***/ }),

/***/ "./commons/components/Checkbox/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/components/Checkbox/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./commons/components/Combobox/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _classnames=_interopRequireDefault(__webpack_require__("../../../node_modules/classnames/index.js"));var _Modal=_interopRequireDefault(__webpack_require__("./commons/components/Modal/index.jsx"));var _ArrowIndicator=_interopRequireDefault(__webpack_require__("./commons/components/ArrowIndicator/index.jsx"));__webpack_require__("./commons/components/Combobox/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function ownKeys(object,enumerableOnly){var keys=Object.keys(object);if(Object.getOwnPropertySymbols){var symbols=Object.getOwnPropertySymbols(object);if(enumerableOnly)symbols=symbols.filter(function(sym){return Object.getOwnPropertyDescriptor(object,sym).enumerable;});keys.push.apply(keys,symbols);}return keys;}function _objectSpread(target){for(var i=1;i<arguments.length;i++){var source=arguments[i]!=null?arguments[i]:{};if(i%2){ownKeys(Object(source),true).forEach(function(key){_defineProperty(target,key,source[key]);});}else if(Object.getOwnPropertyDescriptors){Object.defineProperties(target,Object.getOwnPropertyDescriptors(source));}else{ownKeys(Object(source)).forEach(function(key){Object.defineProperty(target,key,Object.getOwnPropertyDescriptor(source,key));});}}return target;}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class Combobox extends _react.default.Component{constructor(props){super(props);const selectedItemIndex=props.items.indexOf(props.selectedItem);this.state={selectedIndex:selectedItemIndex!==-1?selectedItemIndex:0,isOpen:false};}click(item,index){this.setState({selectedIndex:index});this.props.onChange(item);this.closeCombobox();}openCombobox(){if(!this.props.disabled){this.setState({isOpen:true});}}closeCombobox(){this.setState({isOpen:false});}calculateModalPosition(){const rect=this.button?this.button.getBoundingClientRect():{top:0,left:0};return{top:`${rect.top}px`,left:`${rect.left}px`,bottom:'initial',right:'initial'};}render(){return/*#__PURE__*/_react.default.createElement("div",{style:{display:'flex',flexDirection:'row',alignItems:'baseline',justifyContent:'space-between'},className:this.props.className},this.props.label&&/*#__PURE__*/_react.default.createElement("div",null,this.props.label),/*#__PURE__*/_react.default.createElement("a",{className:(0,_classnames.default)('combobox',{disabled:this.props.disabled}),ref:button=>{this.button=button;},href:"#",onClick:this.openCombobox.bind(this)},/*#__PURE__*/_react.default.createElement(_react.default.Fragment,null,/*#__PURE__*/_react.default.createElement("span",{style:{marginRight:'5px'}},this.props.items[this.state.selectedIndex]),/*#__PURE__*/_react.default.createElement(_ArrowIndicator.default,{directionIsUp:this.state.isOpen}))),/*#__PURE__*/_react.default.createElement(_Modal.default,{modalIsOpen:this.state.isOpen,onRequestClose:this.closeCombobox.bind(this),customStyles:{content:_objectSpread({padding:'5px 0'},this.calculateModalPosition())}},/*#__PURE__*/_react.default.createElement("ul",{className:"combobox-content"},this.props.items.map((item,index)=>/*#__PURE__*/_react.default.createElement("li",{key:item,name:item,label:this.props.label,onClick:this.props.onClick},/*#__PURE__*/_react.default.createElement("a",{className:"combobox-item",href:"#",onClick:()=>this.click(item,index)},item))))));}}exports.default=Combobox;_defineProperty(Combobox,"propTypes",{selectedItem:_propTypes.default.string,items:_propTypes.default.array.isRequired,disabled:_propTypes.default.bool,onChange:_propTypes.default.func.isRequired,label:_propTypes.default.string,className:_propTypes.default.string});

/***/ }),

/***/ "./commons/components/Combobox/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/components/Combobox/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./commons/components/FlatButton/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));var _classnames=_interopRequireDefault(__webpack_require__("../../../node_modules/classnames/index.js"));__webpack_require__("./commons/components/FlatButton/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _extends(){_extends=Object.assign||function(target){for(var i=1;i<arguments.length;i++){var source=arguments[i];for(var key in source){if(Object.prototype.hasOwnProperty.call(source,key)){target[key]=source[key];}}}return target;};return _extends.apply(this,arguments);}function ownKeys(object,enumerableOnly){var keys=Object.keys(object);if(Object.getOwnPropertySymbols){var symbols=Object.getOwnPropertySymbols(object);if(enumerableOnly)symbols=symbols.filter(function(sym){return Object.getOwnPropertyDescriptor(object,sym).enumerable;});keys.push.apply(keys,symbols);}return keys;}function _objectSpread(target){for(var i=1;i<arguments.length;i++){var source=arguments[i]!=null?arguments[i]:{};if(i%2){ownKeys(Object(source),true).forEach(function(key){_defineProperty(target,key,source[key]);});}else if(Object.getOwnPropertyDescriptors){Object.defineProperties(target,Object.getOwnPropertyDescriptors(source));}else{ownKeys(Object(source)).forEach(function(key){Object.defineProperty(target,key,Object.getOwnPropertyDescriptor(source,key));});}}return target;}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class FlatButton extends _react.default.Component{render(){const full=this.props.full||this.props.hasOwnProperty('full')&&this.props.full!==false;const props=_objectSpread({},this.props);delete props.buttonRef;delete props.full;return/*#__PURE__*/_react.default.createElement("button",_extends({type:"button",ref:this.props.buttonRef},props,{className:(0,_classnames.default)('btn',{'btn-full':full},this.props.className)}));}}exports.default=FlatButton;_defineProperty(FlatButton,"propTypes",{buttonRef:_propTypes.default.func});

/***/ }),

/***/ "./commons/components/FlatButton/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/components/FlatButton/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./commons/components/FormLabel/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));__webpack_require__("./commons/components/FormLabel/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class FormLabel extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement("div",{className:"form-label"},/*#__PURE__*/_react.default.createElement("div",{className:"bold"},this.props.label),/*#__PURE__*/_react.default.createElement("div",null,this.props.children||this.props.placeholder));}}exports.default=FormLabel;_defineProperty(FormLabel,"propTypes",{children:_propTypes.default.node,label:_propTypes.default.string.isRequired,placeholder:_propTypes.default.string});

/***/ }),

/***/ "./commons/components/FormLabel/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/components/FormLabel/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./commons/components/Input/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));__webpack_require__("./commons/components/Input/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class Input extends _react.default.Component{render(){const props=Object.assign({},this.props,{onChange:e=>{if(this.props.onChange)this.props.onChange(e.target.value);}});return/*#__PURE__*/_react.default.createElement("div",{className:"input"},this.props.label&&/*#__PURE__*/_react.default.createElement("label",{htmlFor:this.props.name},this.props.label),this.props.children?this.props.children:/*#__PURE__*/_react.default.createElement("input",props));}}exports.default=Input;_defineProperty(Input,"propTypes",{name:_propTypes.default.string.isRequired,label:_propTypes.default.string,children:_propTypes.default.element,onChange:_propTypes.default.func});_defineProperty(Input,"defaultProps",{type:'text'});

/***/ }),

/***/ "./commons/components/Input/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/components/Input/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./commons/components/Link/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _extends(){_extends=Object.assign||function(target){for(var i=1;i<arguments.length;i++){var source=arguments[i];for(var key in source){if(Object.prototype.hasOwnProperty.call(source,key)){target[key]=source[key];}}}return target;};return _extends.apply(this,arguments);}// as we can't open target="_self" links in extention popup we'll use a component to always add target="_blank"
class Link extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement("a",_extends({target:"_blank"},this.props));}}exports.default=Link;

/***/ }),

/***/ "./commons/components/Modal/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _reactModal=_interopRequireDefault(__webpack_require__("../../../node_modules/react-modal/lib/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));__webpack_require__("./commons/components/Modal/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class Modal extends _react.default.Component{handleKeyDown(event){if(event.nativeEvent.key==='Escape'){event.stopPropagation();event.preventDefault();this.props.onRequestClose();}}render(){// react-modal doesn't fully support passing a callback through keyDown.
// 	The library recommends the approach below (e.g., a parent div within
// 	the modal, ref focusing on it, and setting the tab index to -1).
//
// For details see: https://github.com/reactjs/react-modal/issues/184.
//
// Also, to prevent React's focus auto-styling, style.css was added with the
//	appropriate bits.
return/*#__PURE__*/_react.default.createElement(_reactModal.default,{isOpen:this.props.modalIsOpen,onRequestClose:this.props.onRequestClose,shouldCloseOnOverlayClick:true,ariaHideApp:false,style:this.props.customStyles,onAfterOpen:()=>this.myEl&&this.myEl.focus()},/*#__PURE__*/_react.default.createElement("div",{className:"keydownHook",ref:el=>{this.myEl=el;},tabIndex:"-1"// Enables key handlers on div
,onKeyDown:this.handleKeyDown.bind(this)},this.props.children));}}exports.default=Modal;_defineProperty(Modal,"propTypes",{customStyles:_propTypes.default.object,modalIsOpen:_propTypes.default.bool,onRequestClose:_propTypes.default.func});

/***/ }),

/***/ "./commons/components/Modal/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/components/Modal/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./commons/components/Timer/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _propTypes=_interopRequireDefault(__webpack_require__("../../../node_modules/prop-types/index.js"));function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _defineProperty(obj,key,value){if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true});}else{obj[key]=value;}return obj;}class Timer extends _react.default.Component{constructor(props){super(props);const parseTime=(time,placeholder)=>{if(time){// This fails when DST is on, but we calculate under 1 hour, thus its fine.
const diff=new Date(new Date()-time);return`${diff.getMinutes()} min, ${diff.getSeconds()} seconds`;}else{return placeholder||'idle';}};this.state={time:parseTime(props.time,props.placeholder)};this.intervalDisposer=setInterval(()=>{this.setState({time:parseTime(this.props.time,this.props.placeholder)});},1000);}componentWillUnmount(){clearInterval(this.intervalDisposer);}render(){return/*#__PURE__*/_react.default.createElement("span",null,this.state.time);}}exports.default=Timer;_defineProperty(Timer,"propTypes",{time:_propTypes.default.instanceOf(Date),placeholder:_propTypes.default.string});

/***/ }),

/***/ "./commons/components/Tooltip/index.jsx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.rebuild=exports.default=void 0;var _react=_interopRequireDefault(__webpack_require__("../../../node_modules/react/index.js"));var _reactTooltip=_interopRequireDefault(__webpack_require__("../../../node_modules/react-tooltip/dist/index.es.js"));__webpack_require__("./commons/components/Tooltip/style.css");function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _extends(){_extends=Object.assign||function(target){for(var i=1;i<arguments.length;i++){var source=arguments[i];for(var key in source){if(Object.prototype.hasOwnProperty.call(source,key)){target[key]=source[key];}}}return target;};return _extends.apply(this,arguments);}class Tooltip extends _react.default.Component{render(){return/*#__PURE__*/_react.default.createElement(_reactTooltip.default,_extends({className:"eyes-tooltip",place:"bottom",effect:"solid",html:true},this.props));}}exports.default=Tooltip;const rebuild=_reactTooltip.default.rebuild;exports.rebuild=rebuild;

/***/ }),

/***/ "./commons/components/Tooltip/style.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/components/Tooltip/style.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css", function() {
			var newContent = require("!!../../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../../node_modules/postcss-loader/lib/index.js??postcss!./style.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./commons/modes.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});exports.default=void 0;var _default={NORMAL:'normal',SETUP:'setup',INVALID:'invalid',DISCONNECTED:'disconnected',PLAYBACK:'playback',RECORD:'record'};exports.default=_default;

/***/ }),

/***/ "./commons/styles/chrome.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/styles/chrome.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../node_modules/postcss-loader/lib/index.js??postcss!./chrome.css", function() {
			var newContent = require("!!../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../node_modules/postcss-loader/lib/index.js??postcss!./chrome.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./commons/styles/elements.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/styles/elements.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../node_modules/postcss-loader/lib/index.js??postcss!./elements.css", function() {
			var newContent = require("!!../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../node_modules/postcss-loader/lib/index.js??postcss!./elements.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./commons/styles/windows.css":
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__("../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../node_modules/postcss-loader/lib/index.js??postcss!./commons/styles/windows.css");
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__("../../../node_modules/style-loader/lib/addStyles.js")(content, options);
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../node_modules/postcss-loader/lib/index.js??postcss!./windows.css", function() {
			var newContent = require("!!../../../../../node_modules/css-loader/index.js??ref--0-oneOf-3-1!../../../../../node_modules/postcss-loader/lib/index.js??postcss!./windows.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 8:
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__("../../../node_modules/react-hot-loader/patch.js");
module.exports = __webpack_require__("./app/containers/Root/index.jsx");


/***/ })

/******/ });
});
//# sourceMappingURL=app.js.map